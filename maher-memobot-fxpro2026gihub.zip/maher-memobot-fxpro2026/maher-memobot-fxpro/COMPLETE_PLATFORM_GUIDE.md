# Complete Platform Setup Guide

This guide provides step-by-step instructions to run the entire MemoBot FX-PRO platform including both frontend and backend.

## Prerequisites

### Required Software
- **Node.js** (v18+ recommended) - For frontend
- **Python** (v3.10+) - For backend
- **PostgreSQL** (v14+) - Database
- **Git** - Version control
- **Cloudflare CLI** (cloudflared) - For tunneling (optional for local dev)

### Required Accounts
- **Firebase account** - For frontend hosting
- **Cloudflare account** - For domain and tunneling (optional for local dev)
- **Exchange API credentials** - Binance or other supported exchanges

---

## Step 1: Database Setup (PostgreSQL)

### 1.1 Install PostgreSQL

**Windows:**
```powershell
# Download from https://www.postgresql.org/download/windows/
# Or use chocolatey:
choco install postgresql
```

**Mac:**
```bash
brew install postgresql@14
brew services start postgresql@14
```

**Linux (Ubuntu/Debian):**
```bash
sudo apt update
sudo apt install postgresql postgresql-contrib
sudo systemctl start postgresql
sudo systemctl enable postgresql
```

### 1.2 Create Database

```bash
# Login to PostgreSQL
psql -U postgres

# Create database
CREATE DATABASE memobot_db;

# Create user (optional, or use postgres)
CREATE USER memobot_user WITH PASSWORD 'your_secure_password';
GRANT ALL PRIVILEGES ON DATABASE memobot_db TO memobot_user;

# Exit
\q
```

### 1.3 Configure Backend Database Connection

Create `.env` file in `backend/` directory:

```env
# Database Configuration
DATABASE_URL=postgresql://postgres:your_password@localhost:5432/memobot_db
# Or if you created a user:
# DATABASE_URL=postgresql://memobot_user:your_secure_password@localhost:5432/memobot_db

# JWT Configuration
JWT_SECRET_KEY=your_super_secret_jwt_key_change_this_in_production
JWT_ALGORITHM=HS256
JWT_EXPIRATION_HOURS=24

# Exchange API (Optional - can be configured in vault)
BINANCE_API_KEY=your_binance_api_key
BINANCE_API_SECRET=your_binance_api_secret

# AI Services (Optional)
GEMINI_API_KEY=your_gemini_api_key
OPENAI_API_KEY=your_openai_api_key

# Notification Services (Optional)
TELEGRAM_BOT_TOKEN=your_telegram_bot_token
TELEGRAM_CHAT_ID=your_telegram_chat_id
WHATSAPP_API_KEY=your_whatsapp_api_key
```

---

## Step 2: Backend Setup

### 2.1 Navigate to Backend Directory

```bash
cd maher-memobot-fxpro/backend
```

### 2.2 Create Python Virtual Environment

```bash
# Create virtual environment
python -m venv venv

# Activate virtual environment
# Windows:
venv\Scripts\activate
# Mac/Linux:
source venv/bin/activate
```

### 2.3 Install Dependencies

```bash
pip install -r requirements.txt
```

### 2.4 Initialize Database Tables

```bash
# Run database initialization/migrations
python -c "from app.database import init_db; init_db()"
```

### 2.5 Test Backend Configuration

```bash
# Test database connection
python verify_flow.py
```

### 2.6 Start Backend Server

**Development Mode:**
```bash
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

**Production Mode:**
```bash
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 4
```

### 2.7 Verify Backend is Running

Open browser and visit:
```
http://localhost:8000/docs
```

You should see the FastAPI automatic documentation page.

---

## Step 3: Frontend Setup

### 3.1 Navigate to Frontend Directory

```bash
cd maher-memobot-fxpro/Memo-frontend-only
```

### 3.2 Install Dependencies

```bash
npm install
```

### 3.3 Configure Environment Variables

Create `.env` file in `Memo-frontend-only/` directory:

```env
# Backend API URL
VITE_API_URL=http://localhost:8000

# For production with Cloudflare Tunnel:
# VITE_API_URL=https://api.memobot-fxpro.com
```

### 3.4 Start Frontend Development Server

```bash
npm run dev
```

Frontend will be available at:
```
http://localhost:5173
```

### 3.5 Build for Production

```bash
npm run build
```

---

## Step 4: Cloudflare Tunnel Setup (For Production)

### 4.1 Install Cloudflared

**Windows:**
```powershell
winget install --id Cloudflare.cloudflared
```

**Mac:**
```bash
brew install cloudflared
```

**Linux:**
```bash
wget -q https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64.deb
sudo dpkg -i cloudflared-linux-amd64.deb
```

### 4.2 Authenticate with Cloudflare

```bash
cloudflared tunnel login
```

This will open a browser to authenticate with your Cloudflare account.

### 4.3 Create Tunnel

```bash
cloudflared tunnel create memobot-backend
```

Save the tunnel ID that is returned.

### 4.4 Create Configuration File

Create `cloudflared.yml` in project root:

```yaml
tunnel: <YOUR_TUNNEL_ID>
credentials-file: /path/to/your/tunnel-credentials.json

ingress:
  - hostname: api.memobot-fxpro.com
    service: http://localhost:8000
  - service: http_status:404
```

Replace `<YOUR_TUNNEL_ID>` with the ID from step 4.3.

### 4.5 Set Up DNS

```bash
cloudflared tunnel route dns memobot-backend api.memobot-fxpro.com
```

### 4.6 Run Tunnel

**Development:**
```bash
cloudflared tunnel --config cloudflared.yml run memobot-backend
```

**Production (as service):**

**Windows:**
```powershell
cloudflared service install
cloudflared tunnel --config cloudflared.yml run memobot-backend
```

**Linux:**
```bash
sudo cloudflared --config /path/to/cloudflared.yml service install
sudo systemctl start cloudflared
sudo systemctl enable cloudflared
```

### 4.7 Update Frontend Environment

Update `.env` in frontend:
```env
VITE_API_URL=https://api.memobot-fxpro.com
```

---

## Step 5: Firebase Deployment (Frontend)

### 5.1 Install Firebase CLI

```bash
npm install -g firebase-tools
```

### 5.2 Login to Firebase

```bash
firebase login
```

### 5.3 Initialize Firebase Project

```bash
cd Memo-frontend-only
firebase init
```

Select:
- Hosting
- Your Firebase project
- Use existing project directory: `dist`
- Configure as single-page app: `Yes`
- Set up automatic builds: `No`

### 5.4 Deploy to Firebase

```bash
firebase deploy --only hosting
```

Your frontend will be deployed to Firebase hosting.

---

## Step 6: Complete Platform Startup (Local Development)

### 6.1 Start PostgreSQL Database

```bash
# Make sure PostgreSQL is running
# Windows: Services > PostgreSQL
# Mac: brew services start postgresql@14
# Linux: sudo systemctl start postgresql
```

### 6.2 Start Backend

```bash
cd maher-memobot-fxpro/backend

# Activate virtual environment
# Windows:
venv\Scripts\activate
# Mac/Linux:
source venv/bin/activate

# Start backend
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

Backend will be available at: `http://localhost:8000`

### 6.3 Start Frontend

```bash
cd maher-memobot-fxpro/Memo-frontend-only
npm run dev
```

Frontend will be available at: `http://localhost:5173`

### 6.4 Access the Platform

1. Open browser: `http://localhost:5173`
2. You will see the Cinematic Intro animation
3. Then the Hero View with "Silence the market"
4. Click "MEMOBOT™" button to access login
5. Enter credentials to login
6. After successful login, you'll be redirected to the trading dashboard

---

## Step 7: Complete Platform Startup (Production)

### 7.1 Start PostgreSQL Database

Ensure PostgreSQL is running on your server.

### 7.2 Start Cloudflare Tunnel

```bash
cd maher-memobot-fxpro
cloudflared tunnel --config cloudflared.yml run memobot-backend
```

### 7.3 Start Backend

```bash
cd maher-memobot-fxpro/backend

# Activate virtual environment
source venv/bin/activate

# Start backend in production mode
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 4
```

### 7.4 Deploy Frontend to Firebase

```bash
cd maher-memobot-fxpro/Memo-frontend-only
npm run build
firebase deploy --only hosting
```

### 7.5 Access the Platform

1. Open browser: `https://memobot-fxpro.com` (your Firebase domain)
2. Same flow as local development

---

## Step 8: Troubleshooting

### Backend Issues

**Database Connection Error:**
- Verify PostgreSQL is running
- Check DATABASE_URL in `.env`
- Ensure database exists

**Port Already in Use:**
```bash
# Windows (PowerShell)
netstat -ano | findstr :8000
taskkill /PID <PID> /F

# Mac/Linux
lsof -ti:8000 | xargs kill -9
```

**Import Errors:**
```bash
pip install -r requirements.txt --upgrade
```

### Frontend Issues

**Build Errors:**
```bash
rm -rf node_modules package-lock.json
npm install
npm run build
```

**Port Already in Use:**
```bash
# Vite will automatically try the next available port
# Or kill the process using the port
```

### Cloudflare Tunnel Issues

**Tunnel Not Connecting:**
```bash
cloudflared tunnel list
# Verify tunnel exists and is running
```

**DNS Not Resolving:**
- Check Cloudflare DNS settings
- Verify CNAME record exists
- Use `cloudflared tunnel route dns` to verify

---

## Step 9: Platform Architecture Overview

```
┌─────────────────────────────────────────────────────────┐
│                    Firebase Hosting                       │
│                 (Frontend: React + Vite)                │
│                        │                                │
│                        ▼                                │
│              https://memobot-fxpro.com                 │
└─────────────────────────────────────────────────────────┘
                          │
                          │ HTTPS Requests
                          ▼
┌─────────────────────────────────────────────────────────┐
│                  Cloudflare Tunnel                       │
│              (api.memobot-fxpro.com)                   │
│                        │                                │
│                        ▼                                │
│                 http://localhost:8000                   │
└─────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────┐
│                  FastAPI Backend                         │
│                    (Python 3.10+)                        │
│  ┌──────────────────────────────────────────────────┐  │
│  │  Database Layer (PostgreSQL)                     │  │
│  │  - Users, Engines, Positions, Audit Logs         │  │
│  └──────────────────────────────────────────────────┘  │
│  ┌──────────────────────────────────────────────────┐  │
│  │  Trading Engine                                 │  │
│  │  - Market Data, Risk Management, Execution       │  │
│  └──────────────────────────────────────────────────┘  │
│  ┌──────────────────────────────────────────────────┐  │
│  │  Exchange Integration (CCXT)                    │  │
│  │  - Binance API, Vault Security                  │  │
│  └──────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────┘
```

---

## Step 10: Quick Start Script (Optional)

Create a `start.sh` (Mac/Linux) or `start.bat` (Windows) to automate startup:

**Windows (start.bat):**
```batch
@echo off
echo Starting MemoBot FX-PRO Platform...

echo Starting Backend...
cd backend
call venv\Scripts\activate
start "Backend" python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
cd ..

echo Starting Frontend...
cd Memo-frontend-only
start "Frontend" npm run dev
cd ..

echo Platform started!
echo Backend: http://localhost:8000
echo Frontend: http://localhost:5173
pause
```

**Mac/Linux (start.sh):**
```bash
#!/bin/bash
echo "Starting MemoBot FX-PRO Platform..."

echo "Starting Backend..."
cd backend
source venv/bin/activate
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload &
cd ..

echo "Starting Frontend..."
cd Memo-frontend-only
npm run dev &
cd ..

echo "Platform started!"
echo "Backend: http://localhost:8000"
echo "Frontend: http://localhost:5173"
```

Make it executable:
```bash
chmod +x start.sh
./start.sh
```

---

## Step 11: Security Best Practices

### Backend Security
- Change default JWT secret key in production
- Use strong database passwords
- Enable HTTPS in production
- Keep API keys in environment variables (never commit to git)
- Use separate database user for production

### Frontend Security
- Firebase Hosting provides automatic HTTPS
- Security headers configured in firebase.json
- Never commit .env files
- Use different API URLs for development vs production

### Network Security
- Cloudflare Tunnel provides DDoS protection
- Use firewall rules to restrict database access
- Keep software updated

---

## Step 12: Monitoring and Maintenance

### Backend Monitoring
- Check backend logs for errors
- Monitor database performance
- Set up alerts for critical failures
- Regular backup of PostgreSQL database

### Frontend Monitoring
- Firebase provides basic analytics
- Monitor Firebase Console for errors
- Check build logs for deployment issues

### Database Maintenance
```bash
# Backup database
pg_dump memobot_db > backup_$(date +%Y%m%d).sql

# Restore database
psql memobot_db < backup_20240101.sql
```

---

## Summary

### Local Development Flow:
1. Start PostgreSQL
2. Start Backend (port 8000)
3. Start Frontend (port 5173)
4. Access at http://localhost:5173

### Production Flow:
1. Start PostgreSQL
2. Start Cloudflare Tunnel
3. Start Backend (port 8000)
4. Deploy Frontend to Firebase
5. Access at https://memobot-fxpro.com

### Key Files:
- **Backend**: `backend/.env`, `backend/app/main.py`
- **Frontend**: `Memo-frontend-only/.env`, `Memo-frontend-only/src/App.tsx`
- **Tunnel**: `cloudflared.yml`, `firebase.json`

### Ports:
- **Backend**: 8000
- **Frontend**: 5173 (dev), varies in production
- **PostgreSQL**: 5432

### Documentation:
- Backend: `backend/README.md`
- Deployment: `DEPLOYMENT_GUIDE.md`
- Cloudflare: `CLOUDFLARE_TUNNEL_SETUP.md`
- This Guide: `COMPLETE_PLATFORM_GUIDE.md`

---

**Platform is now ready to run!** 🚀