# Cloudflare Tunnel Setup for Local Backend

This guide explains how to set up Cloudflare Tunnels to route your local backend to the deployed Firebase frontend.

## Prerequisites

1. Cloudflare account with a domain (e.g., memobot-fxpro.com)
2. Cloudflare CLI (`cloudflared`) installed
3. Local backend running on a specific port (default: 8000)

## Installation

### Install cloudflared

**Windows:**

```powershell
# Download from https://github.com/cloudflare/cloudflared/releases/latest
# Or use winget:
winget install --id Cloudflare.cloudflared
```

**Mac:**

```bash
brew install cloudflared
```

**Linux:**

```bash
# Ubuntu/Debian
wget -q https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64.deb
sudo dpkg -i cloudflared-linux-amd64.deb
```

## Setup Steps

### Authenticate with Cloudflare

```bash
cloudflared tunnel login
```

This will open a browser window to authenticate with your Cloudflare account.

### Create a Tunnel

```bash
cloudflared tunnel create memobot-backend
```

This will create a tunnel and give you a tunnel ID. Save this ID.

### Configure the Tunnel

Create a configuration file `cloudflared.yml`:

```yaml
tunnel: <YOUR_TUNNEL_ID>
credentials-file: /path/to/your/tunnel-credentials.json

ingress:
  - hostname: api.memobot-fxpro.com
    service: http://localhost:8000
  - service: http_status:404
```

Replace `<YOUR_TUNNEL_ID>` with the ID from step 2.

### Set Up DNS Records

```bash
cloudflared tunnel route dns memobot-backend api.memobot-fxpro.com
```

This will automatically create a CNAME record in your Cloudflare DNS.

### Run the Tunnel

**Development:**

```bash
cloudflared tunnel --config cloudflared.yml run memobot-backend
```

**Production (as service):**

**Windows:**

```powershell
# Install as service
cloudflared service install
cloudflared tunnel --config cloudflared.yml run memobot-backend
```

**Linux:**

```bash
# Create systemd service
sudo cloudflared --config /path/to/cloudflared.yml service install
sudo systemctl start cloudflared
sudo systemctl enable cloudflared
```

## Environment Configuration

Update your `.env` file in Memo-frontend-only:

```env
VITE_API_URL=https://api.memobot-fxpro.com
```

## Backend Configuration

Ensure your FastAPI backend is configured to accept requests from the Cloudflare tunnel domain. Update your backend CORS settings:

```python
# backend/app/main.py or similar
from fastapi.middleware.cors import CORSMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "https://memobot-fxpro.com",
        "https://api.memobot-fxpro.com",
        "http://localhost:5173"  # For local development
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
```

## Testing

1. Start your local backend

```bash
cd backend
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000
```

1. Start the Cloudflare tunnel

```bash
cloudflared tunnel --config cloudflared.yml run memobot-backend
```

1. Test the API

```bash
curl https://api.memobot-fxpro.com/api/v1/health
```

## Security Features

Cloudflare Tunnels provide:

- **No open ports**: No need to open ports on your router
- **TLS encryption**: Automatic HTTPS
- **DDoS protection**: Cloudflare's built-in protection
- **Access control**: Can add Cloudflare Access for additional security

## Troubleshooting

### Tunnel not connecting

- Check if cloudflared is running: `cloudflared tunnel list`
- Verify credentials file path
- Check firewall settings

### DNS not resolving

- Verify DNS record exists in Cloudflare dashboard
- Check tunnel routing: `cloudflared tunnel route dns <tunnel-name>`

### Backend not accessible

- Ensure backend is running on the configured port
- Check backend CORS settings
- Verify backend accepts requests from the tunnel domain

## Maintenance

### Update tunnel configuration

Edit `cloudflared.yml` and restart the tunnel service.

### View tunnel metrics

```bash
cloudflared tunnel info memobot-backend
```

### Delete tunnel

```bash
cloudflared tunnel delete memobot-backend
```

## Production Deployment

For production deployment:

1. Use a dedicated server or VPS for the backend
2. Set up proper process management (systemd, supervisor)
3. Configure monitoring and logging
4. Set up automatic restart on failure
5. Use environment variables for sensitive configuration

## Cost

Cloudflare Tunnels are **free** for personal use with:

- Unlimited bandwidth
- No data transfer limits
- All Cloudflare security features included
