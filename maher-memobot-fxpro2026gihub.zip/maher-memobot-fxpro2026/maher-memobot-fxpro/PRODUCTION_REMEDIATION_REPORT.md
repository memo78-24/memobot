# MEMOBOT FX-PRO — Production Remediation Baseline

**Date:** 2026-08-10
**Baseline:** uploaded `Memobot-fxpro_AI_Engineering` archive
**Purpose:** reconcile the application contracts that were inconsistent in the uploaded baseline.

## Remediated in this build

1. **Database session contract**
   - Legacy application routers/services now receive a synchronous SQLAlchemy `Session`, matching their existing `db.query()/commit()/add()` usage.
   - The newer V2 event/outbox architecture retains a separate `AsyncSessionLocal` path.
   - Readiness uses a real `SELECT 1` round trip.

2. **Canonical SQLAlchemy metadata**
   - All legacy models now share one declarative `Base`.
   - This establishes one metadata registry for Alembic and schema inspection.

3. **Authentication model/service reconciliation**
   - Added the fields actually consumed by authentication services.
   - Refresh-token JTI/session revocation fields are now represented in `UserSession`.
   - Login now verifies the submitted password.
   - The previous fabricated fallback admin account was removed.
   - Failed-login tracking and temporary lockout are enforced.
   - Email verification now sets `is_email_verified=True`.

4. **Execution model reconciliation**
   - `PaperBalance` now contains `asset/free/locked`, matching paper-account logic.
   - `TradeRecord` now contains the canonical fields used by the execution engine and dashboards.
   - `Order` and `Position` contain the compatibility fields consumed by the newer execution services.

5. **Billing/webhook model reconciliation**
   - Subscription plan capabilities and subscription metadata used by the application are now represented in the ORM.
   - `PaymentTransaction` and `WebhookEvent` now expose the provider/idempotency fields used by Stripe webhook handling.

6. **Notification model reconciliation**
   - Notification type aliases and user notification preferences were added to match the notification manager.

7. **Shariah execution gate**
   - The actual `/api/execution/trade` endpoint now performs the Shariah validation before calling the execution engine when Islamic compliance mode is active.
   - This closes the previous gap where the standalone Shariah pipeline existed but was not mounted as the primary execution route.

8. **Live trading fail-safe**
   - Engine startup defaults to `Paper` mode.
   - Live mode requires explicit confirmation after a mode transition.

9. **CORS/configuration**
   - Wildcard CORS was removed from the production configuration path.
   - `CORS_ORIGINS` is environment-driven.
   - `ENVIRONMENT` and legacy `ENV` are normalized.
   - `JWT_SECRET` accepts the documented `SECRET_KEY` fallback for compatibility.

10. **Secrets hygiene**
    - Populated `.env` files were removed from the deliverable archive.
    - `.env.example` files remain as templates.
    - If the removed values were real credentials, they must be rotated before deployment.

11. **Migration foundation**
    - Added Alembic environment configuration and a non-destructive schema reconciliation migration.
    - The migration creates missing tables and adds missing columns without destructive drops.

12. **Verification**
    - Added contract tests covering canonical metadata, authentication contracts, execution contracts, billing contracts, password verification, and fail-safe live mode.

## Local verification performed

- Python bytecode compilation: **PASS**
- Contract tests: **6/6 PASS**
- Canonical SQLAlchemy metadata: **29 tables registered**
- Populated `.env` files in deliverable: **0**

## Still requires deployment-environment verification

These cannot honestly be certified from a source archive alone:

- Real PostgreSQL connection against the target production database.
- `alembic upgrade head` against a backup/clone of the production schema.
- End-to-end registration → email verification → login → refresh → logout.
- Real Binance test/sandbox execution and reconciliation.
- Stripe webhook signature/idempotency tests with the actual endpoint.
- External dependency/SCA/SAST/DAST scans.
- Production Cloudflare/Firebase configuration and DNS verification.
- Credential rotation and secure secret injection in the deployment environment.

## Release rule

This build is a **remediation baseline**, not a claim that live-money trading has been independently certified. Live release should occur only after the deployment-environment verification list above passes.
