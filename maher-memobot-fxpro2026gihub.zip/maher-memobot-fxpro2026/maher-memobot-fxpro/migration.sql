CREATE TABLE IF NOT EXISTS engine_safety_state (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id),
    engine_name VARCHAR(50) NOT NULL,
    day_date DATE NOT NULL,
    day_start_balance_usd DOUBLE PRECISION NOT NULL,
    session_start_balance_usd DOUBLE PRECISION NOT NULL,
    consecutive_losses INTEGER NOT NULL DEFAULT 0,
    is_halted BOOLEAN NOT NULL DEFAULT FALSE,
    halt_reason TEXT,
    halted_at TIMESTAMP,
    updated_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(user_id, engine_name, day_date)
);
