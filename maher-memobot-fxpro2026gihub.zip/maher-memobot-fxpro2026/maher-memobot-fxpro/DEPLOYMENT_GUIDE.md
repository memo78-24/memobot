# MemoBot FX-PRO Deployment Guide

This guide covers the complete deployment setup for MemoBot FX-PRO using Firebase Hosting for the frontend and Cloudflare Tunnels for local backend routing.

## Architecture Overview

```
┌─────────────────┐         ┌─────────────────┐         ┌─────────────────┐
│   Firebase      │         │   Cloudflare    │         │   Local         │
│   Hosting       │◄────────┤   Tunnel        │◄────────┤   Backend       │
│   (Frontend)    │  HTTPS  │   (Routing)     │  Tunnel  │   (FastAPI)     │
└─────────────────┘         └─────────────────┘         └─────────────────┘
```

- **Frontend**: Deployed to Firebase Hosting (memobot-fxpro.com)
- **Backend**: Runs locally with Cloudflare Tunnel routing (api.memobot-fxpro.com)
- **Database**: PostgreSQL running locally

## Prerequisites

1. **Firebase Account** with a project created
2. **Cloudflare Account** with a domain (memobot-fxpro.com)
3. **Node.js** (v18+) and npm installed
4. **Python** (v3.9+) for backend
5. **PostgreSQL** installed locally

## Step 1: Frontend Deployment (Firebase)

### 1.1 Install Firebase CLI

```bash
npm install -g firebase-tools
```

### 1.2 Initialize Firebase

```bash
cd Memo-frontend-only
firebase login
firebase init
```

Follow the prompts:
- Select **Hosting**
- Use existing project or create new one
- Public directory: `dist`
- Configure as single-page app: **Yes**
- Set up automatic builds: **No**

### 1.3 Configure Environment Variables

Create `.env` file:

```env
VITE_API_URL=https://api.memobot-fxpro.com
```

### 1.4 Build and Deploy

```bash
npm install
npm run build
firebase deploy --only hosting
```

Your frontend will be deployed to: `https://memobot-fxpro.com`

## Step 2: Backend Setup (Local)

### 2.1 Set Up PostgreSQL Database

```bash
# Create database
createdb memobot_db

# Or using psql
psql -U postgres
CREATE DATABASE memobot_db;
```

### 2.2 Configure Backend Environment

Copy `.env.example` to `.env`:

```bash
cd backend
cp .env.example .env
```

Edit `.env` with your configuration:

```env
DATABASE_URL=postgresql+asyncpg://postgres:YOUR_PASSWORD@localhost:5432/memobot_db
SECRET_KEY=your_super_secret_key_change_me
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=1440
```

### 2.3 Install Dependencies

```bash
cd backend
pip install -r requirements.txt
```

### 2.4 Run Database Migrations

```bash
python -m alembic upgrade head
```

### 2.5 Start Backend Server

```bash
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000
```

Backend will be available at: `http://localhost:8000`

## Step 3: Cloudflare Tunnel Setup

### 3.1 Install Cloudflared

**Windows:**
```powershell
winget install --id Cloudflare.cloudflared
```

**Mac:**
```bash
brew install cloudflared
```

**Linux:**
```bash
wget -q https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64.deb
sudo dpkg -i cloudflared-linux-amd64.deb
```

### 3.2 Authenticate with Cloudflare

```bash
cloudflared tunnel login
```

### 3.3 Create Tunnel

```bash
cloudflared tunnel create memobot-backend
```

Save the tunnel ID that's returned.

### 3.4 Configure Tunnel

Create `cloudflared.yml` in the project root:

```yaml
tunnel: <YOUR_TUNNEL_ID>
credentials-file: ~/.cloudflared/<Tunnel_ID>.json

ingress:
  - hostname: api.memobot-fxpro.com
    service: http://localhost:8000
  - service: http_status:404
```

Replace `<YOUR_TUNNEL_ID>` with your actual tunnel ID.

### 3.5 Set Up DNS

```bash
cloudflared tunnel route dns memobot-backend api.memobot-fxpro.com
```

### 3.6 Start Tunnel

```bash
cloudflared tunnel --config cloudflared.yml run memobot-backend
```

Your backend API will now be accessible at: `https://api.memobot-fxpro.com`

## Step 4: Configure CORS

Update your backend CORS settings to allow requests from Firebase:

```python
# backend/app/main.py
from fastapi.middleware.cors import CORSMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "https://memobot-fxpro.com",
        "https://api.memobot-fxpro.com",
        "http://localhost:5173"  # For local development
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
```

## Step 5: Production Setup

### 5.1 Run Backend as Service

**Windows (using NSSM):**
```powershell
# Install NSSM
# Download from https://nssm.cc/download

nssm install MemobotBackend python
nssm set MemobotBackend AppDirectory "E:\Memobot-fxpro_AI_Engineering\maher-memobot-fxpro\backend"
nssm set MemobotBackend AppParameters "-m uvicorn app.main:app --host 0.0.0.0 --port 8000"
nssm start MemobotBackend
```

**Linux (systemd):**
```bash
sudo nano /etc/systemd/system/memobot-backend.service
```

```ini
[Unit]
Description=MemoBot Backend Service
After=network.target

[Service]
User=your_user
WorkingDirectory=/path/to/backend
ExecStart=/usr/bin/python -m uvicorn app.main:app --host 0.0.0.0 --port 8000
Restart=always

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable memobot-backend
sudo systemctl start memobot-backend
```

### 5.2 Run Cloudflare Tunnel as Service

**Windows:**
```powershell
cloudflared service install
cloudflared tunnel --config cloudflared.yml run memobot-backend
```

**Linux:**
```bash
sudo cloudflared --config /path/to/cloudflared.yml service install
sudo systemctl start cloudflared
sudo systemctl enable cloudflared
```

## Step 6: Testing

### 6.1 Test Frontend
1. Visit `https://memobot-fxpro.com`
2. Click "ACCESS MEMOBOT TERMINAL"
3. Login with your credentials
4. Verify dashboard loads correctly

### 6.2 Test Backend API
```bash
curl https://api.memobot-fxpro.com/api/v1/health
```

### 6.3 Test Authentication
```bash
curl -X POST https://api.memobot-fxpro.com/api/v1/auth/login-json \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"your_password"}'
```

## Step 7: Monitoring

### 7.1 Backend Logs
```bash
# Check backend service logs
sudo journalctl -u memobot-backend -f

# Or manually run to see logs
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000
```

### 7.2 Cloudflare Tunnel Logs
```bash
cloudflared tunnel info memobot-backend
```

### 7.3 Firebase Logs
Visit Firebase Console → Hosting → Logs

## Troubleshooting

### Frontend Issues
- **Blank page**: Check browser console for errors
- **API errors**: Verify VITE_API_URL is correct
- **Build failures**: Check Node.js version and dependencies

### Backend Issues
- **Connection refused**: Ensure backend is running on port 8000
- **Database errors**: Check PostgreSQL is running and credentials are correct
- **CORS errors**: Verify CORS configuration includes Firebase domain

### Tunnel Issues
- **Tunnel not connecting**: Check cloudflared logs and credentials
- **DNS not resolving**: Verify DNS record in Cloudflare dashboard
- **Timeout errors**: Check backend response times and network connectivity

## Security Best Practices

1. **Environment Variables**: Never commit `.env` files
2. **Database Security**: Use strong passwords, restrict access
3. **API Security**: Implement rate limiting, input validation
4. **HTTPS**: Always use HTTPS in production
5. **Firewall**: Restrict database access to localhost only
6. **Updates**: Keep dependencies updated regularly

## Backup Strategy

### Database Backup
```bash
# Manual backup
pg_dump memobot_db > backup_$(date +%Y%m%d).sql

# Automated backup (cron job)
0 2 * * * pg_dump memobot_db > /backups/memobot_$(date +\%Y\%m\%d).sql
```

### Configuration Backup
```bash
# Backup environment files
cp .env .env.backup
cp cloudflared.yml cloudflared.yml.backup
```

## Scaling Considerations

For production scaling:

1. **Move backend to VPS/dedicated server**
2. **Use managed PostgreSQL (e.g., AWS RDS)**
3. **Implement load balancing**
4. **Add caching layer (Redis)**
5. **Set up monitoring (Prometheus, Grafana)**
6. **Implement CI/CD pipeline**

## Cost Breakdown

- **Firebase Hosting**: Free tier included
- **Cloudflare Tunnel**: Free for personal use
- **Domain**: ~$10-15/year
- **VPS (if needed)**: $5-20/month
- **Total**: Minimal cost for initial setup

## Support

For issues or questions:
- Firebase: https://firebase.google.com/support
- Cloudflare: https://developers.cloudflare.com/cloudflare-one/connections/connect-apps/
- Backend: Check backend documentation