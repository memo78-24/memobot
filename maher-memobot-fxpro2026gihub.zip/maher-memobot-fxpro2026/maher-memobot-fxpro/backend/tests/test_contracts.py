"""Fast contract tests for the repaired production baseline."""
import inspect
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from backend.shared.models.base import Base
from backend.shared.models.user import User, UserSession, AuthVerificationChallenge, TelegramLinkChallenge
from backend.shared.models.trading import PaperBalance, TradeRecord, Portfolio
from backend.shared.models.orders import Order
from backend.shared.models.billing import UserSubscription, SubscriptionPlan, PaymentTransaction, WebhookEvent
from backend.shared.models.portfolio import Position
from backend.shared.models.success_fee import SuccessDecisionFee


def test_single_canonical_model_metadata():
    assert len(Base.metadata.tables) >= 29
    assert User.metadata is Base.metadata
    assert TradeRecord.metadata is Base.metadata


def test_auth_contract_fields_exist():
    for field in ["status", "is_email_verified", "preferred_language", "telegram_chat_id", "encrypted_totp_secret", "failed_login_attempts", "locked_until"]:
        assert hasattr(User, field)
    for field in ["refresh_token_jti", "is_revoked", "session_token"]:
        assert hasattr(UserSession, field)
    for field in ["code_hash", "consumed_at", "attempt_count", "last_sent_at"]:
        assert hasattr(AuthVerificationChallenge, field)
    for field in ["link_token", "status", "linked_chat_id"]:
        assert hasattr(TelegramLinkChallenge, field)


def test_execution_contract_fields_exist():
    for model, fields in [
        (PaperBalance, ["asset", "free", "locked"]),
        (TradeRecord, ["order_id", "symbol", "type", "amount", "price", "fill_price", "fill_amount", "status", "execution_mode", "timestamp"]),
        (Order, ["order_id", "account_id", "intent_id", "client_order_id", "symbol", "requested_qty", "requested_price", "status"]),
        (Position, ["position_id", "account_id", "symbol", "position_side", "status", "qty_open", "avg_entry_price"]),
    ]:
        for field in fields:
            assert hasattr(model, field), f"{model.__name__}.{field} missing"


def test_billing_contract_fields_exist():
    for field in ["live_trading_enabled", "max_leverage", "max_live_positions", "api_access", "max_symbols"]:
        assert hasattr(SubscriptionPlan, field)
    assert hasattr(UserSubscription, "plan")
    for field in ["provider_charge_id", "provider_payment_intent_id", "amount", "refunded_amount"]:
        assert hasattr(PaymentTransaction, field)
    for field in ["provider", "payload_json", "processing_status"]:
        assert hasattr(WebhookEvent, field)


def test_login_service_never_fabricates_admin_and_verifies_password():
    source = Path(__file__).resolve().parents[1] / "app/services/auth/login_service.py"
    text = source.read_text()
    assert "Dummy admin" not in text
    assert "verify_password(password, user.password_hash)" in text


def test_live_mode_is_fail_safe_by_default():
    source = Path(__file__).resolve().parents[1] / "app/engine.py"
    text = source.read_text()
    assert 'self.mode = "Paper"' in text
    assert 'self.live_mode_confirmed = False' in text
