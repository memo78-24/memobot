"""
TEST: HTML PROTECTION SECURITY
"""
import pytest
from backend.app.html_protection import (
    sanitize_html,
    sanitize_input,
    validate_url,
    generate_csrf_token,
    verify_csrf_token
)

class TestXSSProtection:
    """Test XSS protection functions"""
    
    def test_sanitize_input_removes_script_tags(self):
        """XSS: Script tags should be removed"""
        malicious = "<script>alert('XSS')</script>Hello"
        result = sanitize_input(malicious)
        assert "<script>" not in result
        assert "alert" not in result
        assert "Hello" in result
    
    def test_sanitize_input_removes_dangerous_chars(self):
        """XSS: Dangerous characters should be removed"""
        malicious = "<img src=x onerror='alert(1)'>"
        result = sanitize_input(malicious)
        assert "<" not in result
        assert ">" not in result
        assert "onerror" not in result
    
    def test_sanitize_input_escapes_entities(self):
        """XSS: HTML entities should be escaped"""
        input_text = 'Hello & "World"'
        result = sanitize_input(input_text)
        assert "&amp;" in result
        assert "&quot;" in result
    
    def test_sanitize_html_allows_safe_tags(self):
        """XSS: Safe HTML tags should be preserved"""
        html = "<p>Hello <b>World</b></p>"
        result = sanitize_html(html)
        assert "<p>" in result or "Hello" in result
        assert "<b>" in result or "World" in result
    
    def test_sanitize_html_removes_script_tags(self):
        """XSS: Script tags should be removed from HTML"""
        html = "<p>Hello</p><script>alert(1)</script>"
        result = sanitize_html(html)
        assert "<script>" not in result
        assert "alert" not in result
        assert "<p>" in result or "Hello" in result
    
    def test_sanitize_html_removes_event_handlers(self):
        """XSS: Event handlers should be removed"""
        html = '<div onclick="alert(1)">Click me</div>'
        result = sanitize_html(html)
        assert "onclick" not in result
        assert "alert" not in result

class TestCSRFProtection:
    """Test CSRF token generation and verification"""
    
    def test_csrf_token_generation(self):
        """CSRF: Token should be generated"""
        user_id = "user123"
        token = generate_csrf_token(user_id)
        assert token is not None
        assert len(token) > 20
    
    def test_csrf_token_verification(self):
        """CSRF: Valid token should be verified"""
        user_id = "user123"
        token = generate_csrf_token(user_id)
        assert verify_csrf_token(user_id, token) is True
    
    def test_csrf_token_fails_with_wrong_token(self):
        """CSRF: Invalid token should fail verification"""
        user_id = "user123"
        token = generate_csrf_token(user_id)
        fake_token = "fake_token_12345"
        assert verify_csrf_token(user_id, fake_token) is False
    
    def test_csrf_token_fails_with_wrong_user(self):
        """CSRF: Token for one user shouldn't work for another"""
        user_id = "user123"
        token = generate_csrf_token(user_id)
        assert verify_csrf_token("different_user", token) is False

class TestURLValidation:
    """Test URL validation to prevent open redirects"""
    
    def test_validate_url_allows_relative_urls(self):
        """URL: Relative URLs should be allowed"""
        # validate_url("/api/user") would need request context
        # This is a placeholder for actual testing
        pass
    
    def test_validate_url_blocks_external_urls(self):
        """URL: External URLs should be blocked"""
        # In real context, external URLs should fail
        pass

class TestSecurityHeaders:
    """Test security headers are properly configured"""
    
    def test_csp_header_format(self):
        """Headers: CSP should be properly formatted"""
        # This would be tested in integration tests
        pass
    
    def test_no_sensitive_headers_leaked(self):
        """Headers: Server info should not be leaked"""
        # This would be tested in integration tests
        pass

if __name__ == "__main__":
    # Run tests
    pytest.main([__file__, "-v"])
