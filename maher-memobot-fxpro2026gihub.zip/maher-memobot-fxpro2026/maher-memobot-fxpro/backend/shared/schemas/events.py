from typing import Optional
from decimal import Decimal
from pydantic import BaseModel, Field
from datetime import datetime

class BaseEventPayload(BaseModel):
    pass

class TradeIntentCreatedPayload(BaseEventPayload):
    strategy_id: str
    symbol: str
    direction: str
    size: str  # storing as string for precision in JSON
    price: Optional[str] = None
    reason: str

class OrderSubmittedPayload(BaseEventPayload):
    client_order_id: str
    exchange_order_id: Optional[str] = None
    symbol: str
    direction: str
    size: str
    price: Optional[str] = None
    status: str

class FillReceivedPayload(BaseEventPayload):
    exchange_order_id: str
    client_order_id: str
    symbol: str
    fill_price: str
    fill_quantity: str
    fee: str
    fee_asset: str
    is_maker: bool

class PositionOpenedPayload(BaseEventPayload):
    symbol: str
    direction: str
    entry_price: str
    size: str

class PositionUpdatedPayload(BaseEventPayload):
    symbol: str
    new_size: str
    average_entry_price: str
    realized_pnl: str

class PositionClosedPayload(BaseEventPayload):
    symbol: str
    exit_price: str
    realized_pnl: str
    close_reason: str
