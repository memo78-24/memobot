import time
import hmac
import hashlib
import urllib.parse
import math
import asyncio
import uuid
import aiohttp
from typing import Dict, Any
import ccxt.async_support as ccxt
from backend.app.security import decrypt_secret
from backend.app.observability import log_structured

def retry_with_backoff(retries=3, backoff_in_seconds=1):
    def r(f):
        async def wrapper(*args, **kwargs):
            x = 0
            while True:
                try:
                    return await f(*args, **kwargs)
                except Exception as e:
                    err_str = str(e)
                    if "429" in err_str or "Too Many" in err_str or "500" in err_str or "502" in err_str or "503" in err_str or "504" in err_str:
                        if x == retries:
                            raise
                        sleep = (backoff_in_seconds * 2 ** x)
                        log_structured("WARN", f"Rate limited or server error, retrying in {sleep}s: {err_str}")
                        await asyncio.sleep(sleep)
                        x += 1
                    else:
                        raise
        return wrapper
    return r


class BinanceClientWrapper:
    """Wrapper around Binance REST Spot client with custom HMAC signatures and validation."""
    def __init__(self, api_key_encrypted: str = None, api_secret_encrypted: str = None, testnet: bool = True):
        self.is_configured = False
        self.testnet = testnet
        self.client = None
        self.api_key = None
        self.api_secret = None
        self.base_url = "https://testnet.binance.vision" if testnet else "https://api.binance.com"
        
        if api_key_encrypted and api_secret_encrypted:
            try:
                self.api_key = decrypt_secret(api_key_encrypted)
                self.api_secret = decrypt_secret(api_secret_encrypted)
                
                # Instantiate ccxt binance client for secondary queries
                self.client = ccxt.binance({
                    'apiKey': self.api_key,
                    'secret': self.api_secret,
                    'enableRateLimit': True,
                    'options': {
                        'defaultType': 'spot',
                    }
                })
                self.client.set_sandbox_mode(testnet)
                self.is_configured = True
            except Exception as e:
                log_structured("ERROR", f"Failed to decrypt Binance credentials or init client: {e}")
                self.is_configured = False

    async def close(self):
        """Close the underlying aiohttp session in ccxt."""
        if self.client:
            await self.client.close()

    def _sign(self, params: dict) -> str:
        query_string = urllib.parse.urlencode(params)
        return hmac.new(
            self.api_secret.encode('utf-8'),
            query_string.encode('utf-8'),
            hashlib.sha256
        ).hexdigest()

    async def validate_credentials(self) -> bool:
        """Validate if the API key and secret are correct."""
        if not self.is_configured:
            return False
        try:
            res = await self._request("GET", "/api/v3/account", signed=True)
            return "canTrade" in res
        except Exception as e:
            log_structured("WARN", f"API Key validation failed: {e}")
            return False

    @retry_with_backoff(retries=3)

    async def _request(self, method: str, path: str, params: dict = None, signed: bool = False) -> dict:
        if params is None:
            params = {}
        
        if path.startswith("http://") or path.startswith("https://"):
            url = path
        else:
            url = f"{self.base_url}{path}"
        
        if signed:
            params["timestamp"] = int(time.time() * 1000)
            params["recvWindow"] = 10000  # Generous window to prevent sync issues
            params["signature"] = self._sign(params)
            
        headers = {}
        if self.api_key:
            headers["X-MBX-APIKEY"] = self.api_key
            
        async with aiohttp.ClientSession() as session:
            if method.upper() == "GET":
                async with session.get(url, params=params, headers=headers) as resp:
                    text = await resp.text()
                    if resp.status != 200:
                        raise RuntimeError(f"Binance HTTP {resp.status} GET {path}: {text}")
                    return json_loads(text)
            elif method.upper() == "POST":
                headers["Content-Type"] = "application/x-www-form-urlencoded"
                async with session.post(url, data=params, headers=headers) as resp:
                    text = await resp.text()
                    if resp.status != 200:
                        raise RuntimeError(f"Binance HTTP {resp.status} POST {path}: {text}")
                    return json_loads(text)
            elif method.upper() == "DELETE":
                headers["Content-Type"] = "application/x-www-form-urlencoded"
                async with session.delete(url, data=params, headers=headers) as resp:
                    text = await resp.text()
                    if resp.status != 200:
                        raise RuntimeError(f"Binance HTTP {resp.status} DELETE {path}: {text}")
                    return json_loads(text)
        raise ValueError(f"Unsupported HTTP method: {method}")

    async def get_symbol_info(self, symbol: str) -> dict:
        """Fetches symbol rules and filters from Binance exchangeInfo endpoint."""
        if not hasattr(self, "_symbol_info_cache"):
            self._symbol_info_cache = {}
        if symbol in self._symbol_info_cache:
            return self._symbol_info_cache[symbol]
            
        try:
            res = await self._request("GET", "/api/v3/exchangeInfo", {"symbol": symbol})
            symbols = res.get("symbols", [])
            if symbols:
                info = symbols[0]
                self._symbol_info_cache[symbol] = info
                return info
            else:
                raise ValueError(f"Symbol {symbol} not found in exchangeInfo response.")
        except Exception as e:
            log_structured("ERROR", f"Failed to fetch symbol info for {symbol}: {e}")
            raise

    async def fetch_balance(self) -> Dict[str, Any]:
        """Fetch asset spot balances from Binance using typed call."""
        if not self.is_configured:
            raise ValueError("Binance API client is not configured with valid credentials.")
        
        try:
            account_info = await self._request("GET", "/api/v3/account", signed=True)
            balances = {}
            for b in account_info.get("balances", []):
                asset = b["asset"]
                free = float(b["free"])
                locked = float(b["locked"])
                total = free + locked
                if total > 0:
                    balances[asset] = total
            return balances
        except Exception as e:
            log_structured("ERROR", f"Binance REST Error fetching balance: {e}")
            raise RuntimeError(f"Error communicating with Binance: {e}")

    async def fetch_all_balances(self) -> Dict[str, Any]:
        """Fetch combined balances across Spot, Margin, Futures, Funding, Earn, and Sub-Accounts in parallel."""
        import asyncio
        if not self.is_configured:
            return {
                "success": False,
                "breakdown": {
                    "spot": {}, "futures_usdt": {}, "futures_coin": {},
                    "margin": {}, "isolated_margin": {}, "funding": {},
                    "earn": {}, "sub_accounts": {}
                },
                "asset_totals": {},
                "net_worth": 0.0,
                "prices": {}
            }
            
        breakdown = {
            "spot": {},
            "futures_usdt": {},
            "futures_coin": {},
            "margin": {},
            "isolated_margin": {},
            "funding": {},
            "earn": {},
            "sub_accounts": {}
        }
        
        query_failed = False

        # Define individual fetchers with self-contained try/except
        async def get_spot():
            try:
                return await self.fetch_balance()
            except Exception as e:
                log_structured("WARN", f"Failed to fetch Spot balance: {e}")
                nonlocal query_failed
                query_failed = True
                return {}

        async def get_futures_usdt():
            if self.testnet: return {}
            try:
                data = await self._request("GET", "https://fapi.binance.com/fapi/v2/account", signed=True)
                return {a['asset']: float(a['walletBalance']) for a in data.get('assets', []) if float(a.get('walletBalance', 0)) > 0}
            except Exception as e:
                log_structured("WARN", f"Failed to fetch Futures USDT-M balance: {e}")
            return {}

        async def get_futures_coin():
            if self.testnet: return {}
            try:
                data = await self._request("GET", "https://dapi.binance.com/dapi/v1/account", signed=True)
                return {a['asset']: float(a['walletBalance']) for a in data.get('assets', []) if float(a.get('walletBalance', 0)) > 0}
            except Exception as e:
                log_structured("WARN", f"Failed to fetch Futures COIN-M balance: {e}")
            return {}

        async def get_margin():
            try:
                margin = await self._request("GET", "/sapi/v1/margin/account", signed=True)
                return {a['asset']: float(a['free']) + float(a['locked']) for a in margin.get('userAssets', []) if float(a['free']) + float(a['locked']) > 0}
            except Exception as e:
                log_structured("WARN", f"Failed to fetch Margin balance: {e}")
            return {}

        async def get_isolated_margin():
            try:
                isolated = await self._request("GET", "/sapi/v1/margin/isolated/account", signed=True)
                iso_assets = {}
                for pair in isolated.get('assets', []):
                    base = float(pair['baseAsset']['free']) + float(pair['baseAsset']['locked'])
                    quote = float(pair['quoteAsset']['free']) + float(pair['quoteAsset']['locked'])
                    if base > 0:
                        iso_assets[pair['baseAsset']['asset']] = iso_assets.get(pair['baseAsset']['asset'], 0.0) + base
                    if quote > 0:
                        iso_assets[pair['quoteAsset']['asset']] = iso_assets.get(pair['quoteAsset']['asset'], 0.0) + quote
                return iso_assets
            except Exception as e:
                log_structured("WARN", f"Failed to fetch Isolated Margin balance: {e}")
            return {}

        async def get_funding():
            if self.testnet: return {}
            try:
                funding_user = await self._request("POST", "/sapi/v1/asset/get-funding-asset", signed=True)
                funding = {}
                if isinstance(funding_user, list):
                    for asset_info in funding_user:
                        asset = asset_info.get('asset')
                        free = float(asset_info.get('free', 0))
                        locked = float(asset_info.get('locked', 0))
                        total = free + locked
                        if total > 0:
                            funding[asset] = total
                return funding
            except Exception as e:
                log_structured("WARN", f"Failed to fetch Funding wallet: {e}")
            return {}

        async def get_user_assets():
            if self.testnet: return {}
            try:
                user_assets = await self._request("POST", "/sapi/v3/asset/getUserAsset", signed=True)
                bals = {}
                if isinstance(user_assets, list):
                    for a in user_assets:
                        asset = a.get('asset')
                        total = float(a.get('free', 0)) + float(a.get('locked', 0)) + float(a.get('freeze', 0)) + float(a.get('withdrawing', 0))
                        if total > 0:
                            bals[asset] = total
                return bals
            except Exception as e:
                log_structured("WARN", f"Failed to fetch SAPI v3 getUserAsset: {e}")
            return {}

        async def get_earn():
            if self.testnet: return {}
            earn_bal = {}
            
            async def get_flex():
                try:
                    flex = await self._request("GET", "/sapi/v1/simple-earn/flexible/position", signed=True)
                    for row in flex.get('rows', []):
                        asset = row.get('asset')
                        total_amount = float(row.get('totalAmount', 0))
                        if total_amount > 0:
                            earn_bal[asset] = earn_bal.get(asset, 0.0) + total_amount
                except Exception as flex_err:
                    log_structured("WARN", f"Failed to fetch Flexible Earn: {flex_err}")

            async def get_locked():
                try:
                    locked = await self._request("GET", "/sapi/v1/simple-earn/locked/position", signed=True)
                    for row in locked.get('rows', []):
                        asset = row.get('asset')
                        total_amount = float(row.get('totalAmount', 0))
                        if total_amount > 0:
                            earn_bal[asset] = earn_bal.get(asset, 0.0) + total_amount
                except Exception as locked_err:
                    log_structured("WARN", f"Failed to fetch Locked Earn: {locked_err}")

            await asyncio.gather(get_flex(), get_locked())
            return earn_bal

        async def get_sub_accounts():
            if self.testnet: return {}
            sub_balances = {}
            try:
                # 1. Query Spot Summary across all sub-accounts directly
                try:
                    summary = await self._request("GET", "/sapi/v1/sub-account/spotSummary", signed=True)
                    for user_spot in summary.get("spotSubUserAssetBtcVoList", []):
                        email = user_spot.get("email", "sub_account")
                        total_asset_btc = float(user_spot.get("totalAsset", 0))
                        if total_asset_btc > 0:
                            sub_balances[email] = {"BTC": total_asset_btc}
                except Exception as sum_err:
                    log_structured("WARN", f"Failed to fetch Sub-Account spot summary: {sum_err}")

                # 2. Query Sub-Account List and individual balances
                subs = await self._request("GET", "/sapi/v1/sub-account/list", signed=True)
                sub_tasks = []
                
                async def fetch_one_sub(sub_info):
                    email = sub_info.get('email')
                    sub_bal = {}
                    
                    # Spot Sub
                    try:
                        spot_sub = await self._request("GET", "/sapi/v3/sub-account/assets", {"email": email}, signed=True)
                        for item in spot_sub.get('balances', []):
                            asset = item.get('asset')
                            free = float(item.get('free', 0))
                            locked = float(item.get('locked', 0))
                            total = free + locked
                            if total > 0:
                                sub_bal[asset] = sub_bal.get(asset, 0.0) + total
                    except Exception as e_sub_spot:
                        log_structured("WARN", f"Failed to fetch Spot for sub-account {email}: {e_sub_spot}")
                        
                    # Futures Sub
                    try:
                        futures_sub = await self._request("GET", "/sapi/v2/sub-account/futures/account", {"email": email}, signed=True)
                        for asset_info in futures_sub.get('assets', []):
                            asset = asset_info.get('asset')
                            wallet_bal = float(asset_info.get('walletBalance', 0))
                            if wallet_bal > 0:
                                sub_bal[asset] = sub_bal.get(asset, 0.0) + wallet_bal
                    except Exception as e_sub_fut:
                        log_structured("WARN", f"Failed to fetch Futures for sub-account {email}: {e_sub_fut}")
                        
                    # Margin Sub
                    try:
                        margin_sub = await self._request("GET", "/sapi/v1/sub-account/margin/account", {"email": email}, signed=True)
                        for item in margin_sub.get('marginAssets', []):
                            asset = item.get('asset')
                            free = float(item.get('free', 0))
                            locked = float(item.get('locked', 0))
                            total = free + locked
                            if total > 0:
                                sub_bal[asset] = sub_bal.get(asset, 0.0) + total
                    except Exception as e_sub_margin:
                        log_structured("WARN", f"Failed to fetch Margin for sub-account {email}: {e_sub_margin}")
                        
                    if sub_bal:
                        sub_balances[email] = sub_bal

                for sub in subs.get('subAccounts', [])[:10]: # Cap to 10 to avoid heavy rate limits
                    sub_tasks.append(fetch_one_sub(sub))
                
                if sub_tasks:
                    await asyncio.gather(*sub_tasks)
            except Exception as e:
                log_structured("WARN", f"Failed to fetch Sub-Accounts list: {e}")
            return sub_balances

        async def get_wallet_balance():
            if self.testnet: return {}
            try:
                wb = await self._request("GET", "/sapi/v1/asset/wallet/balance", signed=True)
                res = {}
                if isinstance(wb, list):
                    for item in wb:
                        w_name = item.get("walletName")
                        bal_btc = float(item.get("balance", 0))
                        if bal_btc > 0:
                            res[w_name] = bal_btc
                return res
            except Exception as e:
                log_structured("WARN", f"Failed to fetch sapiGetAssetWalletBalance: {e}")
            return {}

        # Trigger all top-level wallet calls concurrently
        tasks = {
            "spot": get_spot(),
            "user_assets": get_user_assets(),
            "futures_usdt": get_futures_usdt(),
            "futures_coin": get_futures_coin(),
            "margin": get_margin(),
            "isolated_margin": get_isolated_margin(),
            "funding": get_funding(),
            "earn": get_earn(),
            "sub_accounts": get_sub_accounts(),
            "sapi_wallet_balance": get_wallet_balance()
        }

        keys = list(tasks.keys())
        results = await asyncio.gather(*(asyncio.wait_for(tasks[k], timeout=12.0) for k in keys), return_exceptions=True)
        
        for k, res in zip(keys, results):
            if isinstance(res, Exception):
                log_structured("ERROR", f"Parallel fetch task {k} raised: {res}")
                breakdown[k] = {}
            else:
                breakdown[k] = res

        # Calculate combined asset totals across all multi-wallet sources
        asset_totals = {}
        def add_assets(balances_dict):
            for asset, val in balances_dict.items():
                asset_totals[asset] = asset_totals.get(asset, 0.0) + val
                
        # Deduplication Rule: If Earn map contains entries -> Remove all LD... assets from Spot before aggregation.
        spot_clean = dict(breakdown["spot"])
        if breakdown["earn"]:
            spot_clean = {asset: val for asset, val in spot_clean.items() if not asset.startswith("LD")}
            
        add_assets(spot_clean)
        add_assets(breakdown["futures_usdt"])
        add_assets(breakdown["futures_coin"])
        add_assets(breakdown["margin"])
        add_assets(breakdown["isolated_margin"])
        add_assets(breakdown["funding"])
        add_assets(breakdown["earn"])
        
        for sub_email, sub_bal in breakdown["sub_accounts"].items():
            add_assets(sub_bal)

        # Merge SAPI v3 Universal User Assets with max-deduplication
        for asset, val in breakdown.get("user_assets", {}).items():
            if asset.startswith("LD"):
                continue
            if asset in asset_totals:
                asset_totals[asset] = max(asset_totals[asset], val)
            else:
                asset_totals[asset] = val
        
        # Get live prices to compute Net Worth in USD dynamically from the WebSocket cache
        prices = {}
        from backend.app.swarm_instance import swarm
        
        for asset in asset_totals.keys():
            underlying = asset[2:] if (asset.startswith("LD") and len(asset) > 2) else asset
            if underlying in ["USDT", "USDC", "BUSD", "FDUSD", "TUSD", "DAI", "BFUSD", "RWUSD", "USD1", "U"]:
                prices[asset] = 1.0
            else:
                ticker_info = getattr(swarm, "ticker_details", {}).get(underlying)
                if ticker_info:
                    prices[asset] = ticker_info.get("bid") or ticker_info.get("last") or swarm.prices.get(underlying, 0.0)
                else:
                    prices[asset] = swarm.prices.get(underlying, 0.0)
                
                # Fallback to estimated market prices if WebSocket ticker isn't warm yet
                if not prices[asset] or prices[asset] == 0.0:
                    default_estimates = {
                        "BTC": 68500.0, "ETH": 3500.0, "SOL": 185.0, "BNB": 590.0,
                        "XRP": 0.58, "ADA": 0.45, "AVAX": 28.5, "DOGE": 0.12,
                        "DOT": 6.50, "LINK": 14.20, "MATIC": 0.55, "LTC": 75.0
                    }
                    prices[asset] = default_estimates.get(underlying, 1.0)
            
        # ----------------------------------------------------------------
        # AUTHORITATIVE NET WORTH
        # Primary: sapi/v1/asset/wallet/balance (BTC-denominated all wallets)
        # Fallback: sum asset_totals × live prices (spot + whatever else fetched)
        # Validation: if sapi result is lower than known spot USDT value, 
        #             it's incomplete — use the fallback instead.
        # ----------------------------------------------------------------
        sapi_wallet = breakdown.get("sapi_wallet_balance", {})
        btc_price = 0.0
        ticker_info = getattr(swarm, "ticker_details", {}).get("BTC")
        if ticker_info:
            btc_price = ticker_info.get("bid") or ticker_info.get("last") or 0.0
        if not btc_price:
            btc_price = swarm.prices.get("BTC", 0.0)
        if not btc_price:
            btc_price = 75940.0  # safe fallback

        # Calculate spot-only net worth from asset_totals as a sanity floor
        spot_usdt_floor = asset_totals.get("USDT", 0.0)
        spot_btc_floor  = asset_totals.get("BTC", 0.0)
        spot_eth_floor  = asset_totals.get("ETH", 0.0)
        spot_floor_usdt = round(
            spot_usdt_floor +
            (spot_btc_floor * btc_price) +
            (spot_eth_floor * (swarm.prices.get("ETH", 3500.0))),
            2
        )

        total_btc_from_wallets = 0.0
        if sapi_wallet:
            for wallet_name, btc_val in sapi_wallet.items():
                print(f">>> Wallet {wallet_name}: {btc_val:.8f} BTC")
                total_btc_from_wallets += btc_val
            total_usdt_from_wallets = round(total_btc_from_wallets * btc_price, 2)
            print(f">>> Total BTC: {total_btc_from_wallets:.8f} BTC")
            print(f">>> Total USDT: {total_usdt_from_wallets:.2f} USDT")

            # Sanity check: if sapi result is lower than known spot floor,
            # the sapi endpoint returned incomplete data — use fallback instead.
            if total_usdt_from_wallets >= spot_floor_usdt * 0.95:
                net_worth = total_usdt_from_wallets
                if total_btc_from_wallets > 0 and asset_totals.get("BTC", 0) < total_btc_from_wallets:
                    asset_totals["BTC"] = total_btc_from_wallets
                log_structured("INFO", f"[BALANCE SAPI] Net worth: ${net_worth:.2f} (sapi authoritative)")
            else:
                # sapi returned partial data (e.g. only Earn wallet)
                # fall through to asset_totals calculation below
                log_structured("WARN", f"[BALANCE SAPI] sapi result ${total_usdt_from_wallets:.2f} < spot floor ${spot_floor_usdt:.2f} — using fallback")
                sapi_wallet = {}  # force fallback path
        else:
            # Fallback: sum from individual coin balances across all wallets.
            # This path runs when sapi_wallet_balance times out or returns empty.
            # We must get a reliable BTC price first, then price every asset.
            if not btc_price or btc_price == 0.0:
                # Try live swarm prices, then hardcoded recent estimate
                btc_price = swarm.prices.get("BTC", 0.0) or 75940.0
                prices["BTC"] = btc_price

            net_worth = 0.0
            for asset, val in asset_totals.items():
                if val <= 0:
                    continue
                underlying = asset[2:] if (asset.startswith("LD") and len(asset) > 2) else asset
                if underlying in ["USDT", "USDC", "BUSD", "FDUSD", "TUSD", "DAI", "BFUSD", "RWUSD", "USD1"]:
                    net_worth += val
                else:
                    # Refresh price in case it was 0 earlier
                    p = prices.get(asset, 0.0)
                    if not p or p == 0.0:
                        ticker_info = getattr(swarm, "ticker_details", {}).get(underlying)
                        if ticker_info:
                            p = ticker_info.get("bid") or ticker_info.get("last") or 0.0
                        if not p:
                            p = swarm.prices.get(underlying, 0.0)
                        if not p:
                            default_estimates = {
                                "BTC": btc_price, "ETH": 3500.0, "SOL": 185.0,
                                "BNB": 590.0, "XRP": 0.58, "ADA": 0.45,
                                "AVAX": 28.5, "DOGE": 0.12, "DOT": 6.50,
                                "LINK": 14.20, "MATIC": 0.55, "LTC": 75.0
                            }
                            p = default_estimates.get(underlying, 0.0)
                        prices[asset] = p
                    net_worth += val * p

            net_worth = round(net_worth, 2)
            log_structured("INFO", f"[BALANCE FALLBACK] Net worth from asset_totals: ${net_worth:.2f}")

        # Prices dict for frontend
        prices["BTC"] = btc_price

        return {
            "success": True,
            "breakdown": breakdown,
            "asset_totals": asset_totals,
            "net_worth": net_worth,
            "prices": prices
        }

    async def execute_order(self, symbol: str, side: str, order_type: str, amount: float, price: float = None) -> Dict[str, Any]:
        """Place spot order with latency telemetry after performing strict validations."""
        if not self.is_configured:
            raise ValueError("Binance API client is not configured with valid credentials.")
            
        binance_symbol = symbol.replace('/', '')
        
        # 1. Fetch symbol details for limits/filters
        try:
            info = await self.get_symbol_info(binance_symbol)
        except Exception as e:
            return {"success": False, "error": f"Failed to fetch symbol rules: {e}"}
            
        base_asset = info["baseAsset"]
        quote_asset = info["quoteAsset"]
        
        tick_size = None
        step_size = None
        min_notional = None
        min_qty = 0.0
        max_qty = 9999999.0
        
        for filter_item in info.get("filters", []):
            f_type = filter_item.get("filterType")
            if f_type == "PRICE_FILTER":
                tick_size = float(filter_item["tickSize"])
            elif f_type == "LOT_SIZE":
                step_size = float(filter_item["stepSize"])
                min_qty = float(filter_item["minQty"])
                max_qty = float(filter_item["maxQty"])
            elif f_type == "NOTIONAL":
                min_notional = float(filter_item["minNotional"])
                
        # 2. Fetch current user balances
        try:
            balances = await self.fetch_balance()
        except Exception as e:
            return {"success": False, "error": f"Failed to retrieve account balance: {e}"}
            
        # Get price for validation
        if order_type.upper() == "LIMIT":
            if price is None:
                return {"success": False, "error": "Price is required for LIMIT order."}
            order_price = price
        else:
            from backend.app.swarm_instance import swarm
            order_price = swarm.prices.get(base_asset, 0.0)
            if order_price == 0.0:
                try:
                    ticker = await self._request("GET", "/api/v3/ticker/price", {"symbol": binance_symbol})
                    order_price = float(ticker["price"])
                except Exception:
                    return {"success": False, "error": f"Could not determine market price for {symbol}"}
                    
        notional_val = amount * order_price
        
        # Balance Validation
        if side.upper() == "BUY":
            quote_balance = balances.get(quote_asset, 0.0)
            if quote_balance < notional_val:
                return {
                    "success": False, 
                    "error": f"Insufficient {quote_asset} balance: {quote_balance} available, need {notional_val:.2f}"
                }
        else:
            base_balance = balances.get(base_asset, 0.0)
            if base_balance < amount:
                return {
                    "success": False, 
                    "error": f"Insufficient {base_asset} balance: {base_balance} available, need {amount}"
                }
                
        # Quantity validation & precision adjustment
        if step_size:
            if amount < min_qty:
                return {"success": False, "error": f"Amount {amount} is less than minimum quantity {min_qty}"}
            if amount > max_qty:
                return {"success": False, "error": f"Amount {amount} exceeds maximum quantity {max_qty}"}
            precision = int(round(-math.log10(step_size)))
            amount = round(amount - (amount % step_size), precision)
            
        # Price validation & precision adjustment
        if order_type.upper() == "LIMIT" and tick_size:
            precision = int(round(-math.log10(tick_size)))
            price = round(price - (price % tick_size), precision)
            
        # Min notional validation
        if min_notional and notional_val < min_notional:
            return {
                "success": False,
                "error": f"Order notional value {notional_val:.2f} is less than minimum notional {min_notional}"
            }
            
        # 3. Route Order to REST endpoint
        t_start = time.perf_counter()
        
        client_order_id = f"MBOT-{uuid.uuid4().hex[:20]}"
        
        params = {
            "symbol": binance_symbol,
            "side": side.upper(),
            "type": order_type.upper(),
            "quantity": f"{amount:.8f}".rstrip('0').rstrip('.'),
            "newClientOrderId": client_order_id
        }
        if order_type.upper() == "LIMIT":
            params["price"] = f"{price:.8f}".rstrip('0').rstrip('.')
            params["timeInForce"] = "GTC"
        elif order_type.upper() in ["STOP_LOSS_LIMIT", "TAKE_PROFIT_LIMIT"]:
            params["price"] = f"{price:.8f}".rstrip('0').rstrip('.')
            params["stopPrice"] = f"{price:.8f}".rstrip('0').rstrip('.')
            params["timeInForce"] = "GTC"
            
        try:
            order = await self._request("POST", "/api/v3/order", params, signed=True)
            latency_ms = (time.perf_counter() - t_start) * 1000
            log_structured("INFO", f"Binance order filled via REST API. ID: {order.get('orderId')} (took {latency_ms:.1f}ms)")
            
            return {
                "success": True,
                "order_id": str(order.get("orderId")),
                "fill_price": float(order.get("price")) or order_price,
                "fill_amount": float(order.get("executedQty", amount)),
                "status": order.get("status"),
                "latency_ms": latency_ms,
                "slippage_pct": 0.0,
                "raw": order
            }
        except Exception as e:
            latency_ms = (time.perf_counter() - t_start) * 1000
            log_structured("ERROR", f"Binance REST API order placement failed: {e}")
            return {"success": False, "error": str(e), "latency_ms": latency_ms}

    async def cancel_all_orders(self, symbol: str = "BTC/USDT") -> bool:
        """Emergency Kill Switch action: cancels all open orders on Binance Spot."""
        if not self.is_configured:
            return False
            
        binance_symbol = symbol.replace('/', '')
        try:
            log_structured("INFO", f"Canceling all open orders on Binance for {binance_symbol}")
            await self._request("DELETE", "/api/v3/openOrders", {"symbol": binance_symbol}, signed=True)
            return True
        except Exception as e:
            log_structured("ERROR", f"Kill Switch error on Binance: {e}")
            return False

    async def set_leverage(self, symbol: str, leverage: int) -> bool:
        """Set futures leverage."""
        if not self.client:
            return False
        try:
            ccxt_symbol = symbol if "/" in symbol else f"{symbol[:-4]}/{symbol[-4:]}"
            await self.client.set_leverage(leverage, ccxt_symbol)
            return True
        except Exception as e:
            log_structured("ERROR", f"Failed to set leverage: {e}")
            return False

    async def set_margin_type(self, symbol: str, margin_type: str) -> bool:
        """Set margin type (ISOLATED or CROSSED)."""
        if not self.client:
            return False
        try:
            ccxt_symbol = symbol if "/" in symbol else f"{symbol[:-4]}/{symbol[-4:]}"
            await self.client.set_margin_mode(margin_type.lower(), ccxt_symbol)
            return True
        except Exception as e:
            log_structured("ERROR", f"Failed to set margin type: {e}")
            return False


def json_loads(text: str) -> dict:
    import json
    return json.loads(text)
