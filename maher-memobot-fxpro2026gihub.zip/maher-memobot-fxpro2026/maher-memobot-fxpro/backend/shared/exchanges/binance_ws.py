import asyncio
import logging
import ccxt.pro as ccxt
import time
from typing import Dict, Any, Callable
from backend.app.observability import log_structured

logger = logging.getLogger("memobot_fxpro.binance_ws")

class BinanceWebSocketManager:
    """Manages Binance User Data and Market Data Websocket Streams via ccxt.pro"""
    
    def __init__(self, api_key: str = None, api_secret: str = None, testnet: bool = True):
        self.api_key = api_key
        self.api_secret = api_secret
        self.testnet = testnet
        self.client = ccxt.binance({
            'apiKey': self.api_key,
            'secret': self.api_secret,
            'enableRateLimit': True,
            'options': {
                'defaultType': 'spot',
            }
        })
        self.client.set_sandbox_mode(testnet)
        
        self.running = False
        self._tasks = []
        self._callbacks = {
            "balance": [],
            "order": [],
            "ticker": []
        }
        
    def register_callback(self, stream_type: str, callback: Callable):
        if stream_type in self._callbacks:
            self._callbacks[stream_type].append(callback)
            
    async def _emit(self, stream_type: str, data: Any):
        for cb in self._callbacks.get(stream_type, []):
            try:
                if asyncio.iscoroutinefunction(cb):
                    await cb(data)
                else:
                    cb(data)
            except Exception as e:
                logger.error(f"Error in {stream_type} callback: {e}")

    async def _watch_balance_loop(self):
        """User Data Stream: Balances"""
        while self.running:
            try:
                balance = await self.client.watch_balance()
                await self._emit("balance", balance)
            except asyncio.CancelledError:
                break
            except Exception as e:
                log_structured("WARN", f"WS Balance Watch error (reconnecting): {e}")
                await asyncio.sleep(2)  # Exponential backoff can be added here
                
    async def _watch_orders_loop(self):
        """User Data Stream: Orders"""
        while self.running:
            try:
                orders = await self.client.watch_orders()
                for order in orders:
                    await self._emit("order", order)
            except asyncio.CancelledError:
                break
            except Exception as e:
                log_structured("WARN", f"WS Orders Watch error (reconnecting): {e}")
                await asyncio.sleep(2)
                
    async def _watch_ticker_loop(self, symbol: str):
        """Market Data Stream: Ticker"""
        ccxt_symbol = symbol if "/" in symbol else f"{symbol[:-4]}/{symbol[-4:]}"
        while self.running:
            try:
                ticker = await self.client.watch_ticker(ccxt_symbol)
                await self._emit("ticker", ticker)
            except asyncio.CancelledError:
                break
            except Exception as e:
                log_structured("WARN", f"WS Ticker Watch error for {symbol}: {e}")
                await asyncio.sleep(2)

    async def start(self, symbols: list = ["BTC/USDT"]):
        """Start the background tasks for watching streams."""
        if self.running:
            return
            
        self.running = True
        log_structured("INFO", "Starting Binance WebSocket Manager streams")
        
        # Start User Data streams if authenticated
        if self.api_key and self.api_secret:
            self._tasks.append(asyncio.create_task(self._watch_balance_loop()))
            self._tasks.append(asyncio.create_task(self._watch_orders_loop()))
            
        # Start Market Data streams
        for sym in symbols:
            self._tasks.append(asyncio.create_task(self._watch_ticker_loop(sym)))

    async def stop(self):
        """Stop all background tasks."""
        self.running = False
        for task in self._tasks:
            task.cancel()
        await asyncio.gather(*self._tasks, return_exceptions=True)
        self._tasks.clear()
        if self.client:
            await self.client.close()
        log_structured("INFO", "Binance WebSocket Manager stopped")

