from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional
from datetime import datetime

class ExchangeAdapter(ABC):
    @abstractmethod
    async def get_account_state(self, account_id: str) -> dict: ...
    
    @abstractmethod
    async def get_symbol_rules(self, symbol: str) -> dict: ...
    
    @abstractmethod
    async def place_order(self, order_request: dict) -> dict: ...
    
    @abstractmethod
    async def cancel_order(
        self,
        exchange_order_id: Optional[str] = None,
        client_order_id: Optional[str] = None
    ) -> dict: ...
    
    @abstractmethod
    async def get_order_by_client_id(self, symbol: str, client_order_id: str) -> Optional[dict]: ...
    
    @abstractmethod
    async def fetch_open_orders(self, symbol: Optional[str] = None) -> List[dict]: ...
    
    @abstractmethod
    async def fetch_recent_orders(self, symbol: str, since: datetime) -> List[dict]: ...
    
    @abstractmethod
    async def fetch_positions(self) -> List[dict]: ...
    
    @abstractmethod
    async def fetch_fills(self, since: datetime) -> List[dict]: ...
    
    @abstractmethod
    async def reconcile_position(self, symbol: str) -> dict: ...
    
    @abstractmethod
    async def validate_order_request(self, order_request: dict) -> None: ...
    
    @abstractmethod
    async def get_server_time(self) -> datetime: ...
    
    @abstractmethod
    async def ping(self) -> bool: ...
    
    @abstractmethod
    def normalize_exchange_error(self, error: Exception) -> dict: ...
