import logging
import ulid
from datetime import datetime
from sqlalchemy import select, and_, update
from sqlalchemy.ext.asyncio import AsyncSession
from backend.shared.models.domain import TradeIntent, Order, Position, ExecutionJob, ReconciliationRun, ReconciliationIssue, TradeEvent
from backend.shared.models.enums import TradeIntentStatus, OrderStatus, ExecutionJobStatus, ReconciliationStatus, ReconciliationSeverity, ReconciliationIssueStatus, ReconciliationIssueType, ReconciliationScope, PositionStatus, EventSource

logger = logging.getLogger(__name__)


class ReconciliationEngine:
    """Reconcile local order/job/position state against exchange truth."""
    def __init__(self, session: AsyncSession, exchange):
        self.session = session
        self.exchange = exchange

    async def _emit_reconciliation_event(self, account_id, action, details, position_id=None, order_id=None, intent_id=None, reconciliation_id=None):
        event = TradeEvent(event_id=str(ulid.ULID()), event_type="RECONCILIATION_REPAIR", source=EventSource.RECONCILER.value, account_id=str(account_id), position_id=position_id, order_id=order_id, intent_id=intent_id, reconciliation_id=reconciliation_id, payload={"action": action, "details": details}, payload_json={"action": action, "details": details}, idempotency_key=f"RECON:{reconciliation_id}:{action}:{order_id or position_id or 'ACCOUNT'}")
        self.session.add(event)

    async def run_startup_reconciliation(self, account_id: str):
        run_id = str(ulid.ULID())
        run = ReconciliationRun(reconciliation_id=run_id, account_id=str(account_id), scope=ReconciliationScope.STARTUP.value, status=ReconciliationStatus.RUNNING.value, trigger_reason="SYSTEM_STARTUP")
        self.session.add(run)
        await self.session.flush()
        try:
            await self._recover_stuck_jobs()
            await self._recover_in_flight_orders(account_id, run_id)
            await self._reconcile_active_positions(account_id, run_id)
            run.status = ReconciliationStatus.PASSED.value
            run.completed_at = datetime.utcnow()
            await self.session.commit()
        except Exception as exc:
            await self.session.rollback()
            logger.exception("Startup reconciliation failed")
            raise

    async def _recover_stuck_jobs(self):
        now = datetime.utcnow()
        stmt = update(ExecutionJob).where(and_(ExecutionJob.status == ExecutionJobStatus.LEASED.value, ExecutionJob.lease_expires_at.is_not(None), ExecutionJob.lease_expires_at < now)).values(status=ExecutionJobStatus.PENDING.value, lease_owner=None, lease_expires_at=None, next_run_at=now)
        await self.session.execute(stmt)
        await self.session.flush()

    async def _recover_in_flight_orders(self, account_id, run_id):
        result = await self.session.execute(select(Order).where(Order.account_id == str(account_id), Order.status.in_([OrderStatus.SUBMITTED.value, OrderStatus.UNKNOWN.value, OrderStatus.CREATED.value, OrderStatus.ACKNOWLEDGED.value])))
        for order in result.scalars().all():
            try:
                exchange_order = await self.exchange.get_order_by_client_id(order.symbol, order.client_order_id)
                prior = order.status
                if exchange_order:
                    status = str(exchange_order.get("status", "")).upper()
                    mapping = {"NEW": OrderStatus.ACKNOWLEDGED, "OPEN": OrderStatus.ACKNOWLEDGED, "PARTIALLY_FILLED": OrderStatus.PARTIALLY_FILLED, "FILLED": OrderStatus.FILLED, "CANCELED": OrderStatus.CANCELLED, "CANCELLED": OrderStatus.CANCELLED, "REJECTED": OrderStatus.REJECTED, "EXPIRED": OrderStatus.EXPIRED}
                    order.status = mapping.get(status, OrderStatus.UNKNOWN).value
                    order.exchange_order_id = str(exchange_order.get("orderId", order.exchange_order_id or ""))
                    order.exchange_status = status
                    order.last_exchange_update_at = datetime.utcnow()
                    order.raw_exchange_json = exchange_order
                else:
                    order.status = OrderStatus.REJECTED.value
                    self.session.add(ReconciliationIssue(issue_id=str(ulid.ULID()), reconciliation_id=run_id, account_id=str(account_id), symbol=order.symbol, issue_type=ReconciliationIssueType.ORDER_NOT_FOUND_ON_EXCHANGE.value, severity=ReconciliationSeverity.WARN.value, status=ReconciliationIssueStatus.AUTO_RESOLVED.value, details_json={"client_order_id": order.client_order_id, "action": "Marked REJECTED"}))
                if prior != order.status:
                    await self._emit_reconciliation_event(account_id, "ORDER_STATUS_UPDATED", {"client_order_id": order.client_order_id, "old": prior, "new": order.status}, order_id=order.order_id, reconciliation_id=run_id)
            except Exception:
                logger.exception("Failed to reconcile order %s", order.client_order_id)
        await self.session.flush()

    async def _reconcile_active_positions(self, account_id, run_id):
        result = await self.session.execute(select(Position).where(Position.account_id == str(account_id), Position.status.in_([PositionStatus.OPEN.value, PositionStatus.PARTIALLY_FILLED.value, PositionStatus.CLOSING.value])))
        db_positions = result.scalars().all()
        db_map = {p.symbol: p for p in db_positions}
        if not hasattr(self.exchange, "fetch_positions"):
            return
        exchange_positions = await self.exchange.fetch_positions(account_id)
        ex_map = {p["symbol"]: p for p in exchange_positions if float(p.get("positionAmt", 0)) != 0}
        for symbol in set(db_map) | set(ex_map):
            db_pos, ex_pos = db_map.get(symbol), ex_map.get(symbol)
            if db_pos and not ex_pos:
                db_pos.status = PositionStatus.CLOSED.value
                db_pos.is_open = False
                db_pos.closed_at = datetime.utcnow()
                db_pos.metadata_json = dict(db_pos.metadata_json or {}, reconciliation_note="Auto-closed: missing on exchange")
                self.session.add(ReconciliationIssue(issue_id=str(ulid.ULID()), reconciliation_id=run_id, account_id=str(account_id), symbol=symbol, issue_type=ReconciliationIssueType.DB_POSITION_MISSING_ON_EXCHANGE.value, severity=ReconciliationSeverity.WARN.value, status=ReconciliationIssueStatus.AUTO_RESOLVED.value, details_json={"db_qty": db_pos.qty_open, "action": "Marked CLOSED"}))
                await self._emit_reconciliation_event(account_id, "POSITION_AUTO_CLOSED", {"symbol": symbol, "prior_qty": db_pos.qty_open}, position_id=db_pos.position_id, reconciliation_id=run_id)
            elif ex_pos and not db_pos:
                self.session.add(ReconciliationIssue(issue_id=str(ulid.ULID()), reconciliation_id=run_id, account_id=str(account_id), symbol=symbol, issue_type=ReconciliationIssueType.EXCHANGE_POSITION_MISSING_IN_DB.value, severity=ReconciliationSeverity.CRITICAL.value, status=ReconciliationIssueStatus.MANUAL_REVIEW_REQUIRED.value, details_json={"exch_qty": ex_pos.get("positionAmt")}))
            elif db_pos and ex_pos:
                db_qty = -float(db_pos.qty_open) if db_pos.position_side == "SHORT" else float(db_pos.qty_open)
                ex_qty = float(ex_pos.get("positionAmt", 0))
                if abs(db_qty - ex_qty) > 1e-8:
                    self.session.add(ReconciliationIssue(issue_id=str(ulid.ULID()), reconciliation_id=run_id, account_id=str(account_id), symbol=symbol, issue_type=ReconciliationIssueType.QTY_MISMATCH.value, severity=ReconciliationSeverity.ERROR.value, status=ReconciliationIssueStatus.MANUAL_REVIEW_REQUIRED.value, details_json={"db_qty": db_qty, "exch_qty": ex_qty}))
        await self.session.flush()
