import logging
import ulid
from sqlalchemy.ext.asyncio import AsyncSession
from backend.shared.db.repository import TradingRepository
from backend.shared.models.domain import ExecutionJob, Order, TradeIntent
from backend.shared.models.enums import ExecutionJobStatus, OrderStatus, TradeIntentStatus
from backend.shared.exchanges.base import ExchangeAdapter

logger = logging.getLogger(__name__)


class ExecutionJobRunner:
    """Reliable, idempotent exchange order submission."""
    def __init__(self, session: AsyncSession, exchange: ExchangeAdapter):
        self.session = session
        self.repo = TradingRepository(session)
        self.exchange = exchange

    def generate_client_order_id(self, intent_id: str, leg: int = 1) -> str:
        return f"MMB-DEV-U1-{intent_id}-{leg}"

    async def process_job(self, job: ExecutionJob) -> None:
        if job.job_type != "SUBMIT_ORDER":
            logger.warning("Unknown execution job type: %s", job.job_type)
            return
        payload = job.payload_json or {}
        intent_id = payload.get("intent_id") or job.intent_id
        intent = await self.repo.get_trade_intent(intent_id)
        if not intent:
            raise ValueError(f"Intent {intent_id} not found")

        client_order_id = self.generate_client_order_id(intent.intent_id)
        existing = await self.repo.get_order_by_client_order_id(client_order_id)
        if existing and existing.status in {x.value for x in (OrderStatus.SUBMITTED, OrderStatus.ACKNOWLEDGED, OrderStatus.FILLED, OrderStatus.PARTIALLY_FILLED)}:
            return
        if existing and existing.status in {OrderStatus.REJECTED.value, OrderStatus.CANCELLED.value}:
            intent.status = TradeIntentStatus.FAILED.value
            await self.session.flush()
            return

        order = existing or await self.repo.create_order(str(ulid.ULID()), intent.account_id or str(intent.user_id), intent.intent_id, intent.symbol, intent.side, intent.requested_quantity, intent.requested_price, client_order_id)
        intent.status = TradeIntentStatus.SUBMITTING.value
        job.status = ExecutionJobStatus.RUNNING.value
        job.attempt_count = (job.attempt_count or 0) + 1
        await self.session.flush()

        request = {"symbol": intent.symbol, "side": intent.side, "type": intent.order_type, "quantity": intent.requested_quantity, "price": intent.requested_price, "client_order_id": client_order_id}
        try:
            response = await self.exchange.place_order(request)
            if response.get("success"):
                order.status = OrderStatus.ACKNOWLEDGED.value
                order.exchange_order_id = response.get("exchange_order_id") or response.get("orderId")
                order.exchange_status = str(response.get("status", "ACKNOWLEDGED"))
                intent.status = TradeIntentStatus.ACKNOWLEDGED.value
                job.status = ExecutionJobStatus.COMPLETED.value
                job.completed_at = __import__('datetime').datetime.utcnow()
            else:
                order.status = OrderStatus.REJECTED.value
                order.rejection_reason = str(response.get("error", "Exchange rejected order"))
                intent.status = TradeIntentStatus.FAILED.value
                job.status = ExecutionJobStatus.FAILED.value
                job.error_message = order.rejection_reason
        except Exception as exc:
            order.status = OrderStatus.UNKNOWN.value
            intent.status = TradeIntentStatus.RECONCILING.value
            job.status = ExecutionJobStatus.PENDING.value
            job.error_message = str(exc)
            recon_id = str(ulid.ULID())
            await self.repo.create_execution_job(recon_id, intent.intent_id, intent.cycle_id, intent.account_id or str(intent.user_id), intent.symbol, "RECONCILE_ORDER", {"client_order_id": client_order_id})
            await self.session.flush()
            raise
        await self.session.flush()
