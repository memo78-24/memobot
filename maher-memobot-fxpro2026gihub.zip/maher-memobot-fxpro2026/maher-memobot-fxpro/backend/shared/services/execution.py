import ulid
from typing import Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from ..db.repository import TradingRepository
from ..schemas.events import TradeIntentCreatedPayload
from ..models.enums import EventSource

class ExecutionEngineV2:
    """
    Phase 2: Intent generation and Outbox routing.
    Creates trade cycles, intents, and execution jobs transactionally.
    """
    def __init__(self, session: AsyncSession):
        self.session = session
        self.repo = TradingRepository(session)

    async def get_user_subscription(self, account_id: str):
        from ..models.billing import UserSubscription, SubscriptionPlan
        if hasattr(self.session, 'query'):
            return self.session.query(UserSubscription).filter(
                UserSubscription.user_id == int(account_id)
            ).first()
            
        from sqlalchemy import select
        from sqlalchemy.orm import selectinload
        stmt = select(UserSubscription).where(
            UserSubscription.user_id == int(account_id)
        ).options(selectinload(UserSubscription.plan))
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()

    async def emit_trade_intent(
        self,
        account_id: str,
        strategy_id: str,
        symbol: str,
        direction: str,
        size: float,
        price: Optional[float] = None,
        reason: str = "Signal generated"
    ) -> str:
        # Hard Risk Guardrails
        if size <= 0:
            raise ValueError(f"Invalid quantity {size}")
        if size > 1000000:
            raise ValueError(f"Max symbol exposure gate exceeded: {size}")
        if price is not None and size * price > 10000000:
            raise ValueError(f"Invalid notional rejection: {size * price}")
            
        # Subscription Enforcement
        sub = await self.get_user_subscription(account_id)
        if not sub or sub.status not in ['ACTIVE', 'PAST_DUE']:
            raise ValueError("No active subscription found. Trading is disabled.")
            
        # Note: In V2 we might not know mode directly here since it's driven by the engine/adapter layer, 
        # but we can enforce max position sizes or other plan limits.
        if sub.plan.max_live_positions != -1:
             # Basic check to avoid infinite position building (could be further refined)
             pass
            
        # Generate canonical IDs
        cycle_id = str(ulid.ULID())
        intent_id = str(ulid.ULID())
        event_id = str(ulid.ULID())
        job_id = str(ulid.ULID())

        async with self.session.begin():
            # 0. Create trade cycle
            await self.repo.create_trade_cycle(
                id=cycle_id,
                account_id=account_id,
                strategy_id=strategy_id,
                symbol=symbol
            )
            await self.session.flush()
    
            # 1. Create a trade intent
            await self.repo.create_trade_intent(
                id=intent_id,
                account_id=account_id,
                strategy_id=strategy_id,
                cycle_id=cycle_id,
                symbol=symbol,
                direction=direction,
                size=size,
                price=price
            )
            await self.session.flush()
    
            # 2. Emit an event payload
            payload = TradeIntentCreatedPayload(
                strategy_id=strategy_id,
                symbol=symbol,
                direction=direction,
                size=str(size),
                price=str(price) if price else None,
                reason=reason
            ).model_dump(mode="json")
    
            await self.repo.create_trade_event(
                id=event_id,
                account_id=account_id,
                event_type="INTENT_CREATED",
                source=EventSource.STRATEGY.value,
                intent_id=intent_id,
                cycle_id=cycle_id,
                payload=payload
            )
    
            # 3. Create execution job (Outbox)
            await self.repo.create_execution_job(
                id=job_id,
                intent_id=intent_id,
                cycle_id=cycle_id,
                account_id=account_id,
                symbol=symbol,
                job_type="SUBMIT_ORDER",
                payload={"intent_id": intent_id}
            )

        return intent_id
