import logging
import ulid
from datetime import datetime
from typing import Dict, Any, Optional
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession
from backend.shared.db.repository import TradingRepository
from backend.shared.models.domain import Fill, Position, Order, PositionEvent
from backend.shared.models.enums import EventSource, PositionEventType, OrderStatus, PositionStatus

logger = logging.getLogger(__name__)


class PositionProjector:
    """Idempotently converts fills into canonical positions and events."""
    def __init__(self, session: AsyncSession):
        self.session = session
        self.repo = TradingRepository(session)

    async def _emit_position_event(self, position, event_type, qty_delta, price, realized_pnl_delta, fee_delta, fill_id):
        event_id = str(ulid.ULID())
        event = PositionEvent(event_id=event_id, position_event_id=event_id, position_id=position.position_id, account_id=position.account_id, user_id=position.user_id, symbol=position.symbol, event_type=event_type, quantity_delta=qty_delta, qty_delta=qty_delta, price=price, realized_pnl_usdt=realized_pnl_delta, realized_pnl_delta=realized_pnl_delta, fee_usdt=fee_delta, fee_delta=fee_delta, payload={"fill_id": fill_id}, payload_json={"fill_id": fill_id}, idempotency_key=f"{event_type}:{fill_id}:{position.position_id}")
        self.session.add(event)

    async def process_fill(self, payload: Dict[str, Any]) -> Optional[str]:
        exchange_trade_id = payload.get("exchange_trade_id")
        if not exchange_trade_id:
            raise ValueError("Fill payload missing exchange_trade_id")
        existing = await self.repo.get_fill_by_exchange_trade_id(exchange_trade_id)
        if existing:
            return existing.fill_id

        client_order_id = payload.get("client_order_id")
        order = await self.repo.get_order_by_client_order_id_for_update(client_order_id) if client_order_id else None
        intent = await self.repo.get_trade_intent(order.intent_id) if order else None
        account_id = str(payload.get("account_id") or (order.account_id if order else ""))
        symbol = payload.get("symbol") or (order.symbol if order else None)
        if not symbol:
            raise ValueError("Fill payload missing symbol")
        side = str(payload.get("side", "")).upper()
        qty = float(payload.get("qty", payload.get("quantity", 0)))
        price = float(payload.get("price", 0))
        fee_amount = float(payload.get("fee_amount", 0))
        fill_time = payload.get("fill_time") or datetime.utcnow()
        if isinstance(fill_time, str):
            fill_time = datetime.fromisoformat(fill_time.replace("Z", "+00:00")).replace(tzinfo=None)

        position = await self.repo.get_active_position_for_update(account_id, symbol)
        strategy_id = intent.strategy_id if intent else None
        if not position:
            position = await self.repo.create_position(str(ulid.ULID()), account_id, strategy_id, symbol, "LONG" if side == "BUY" else "SHORT", PositionStatus.OPEN.value, qty, price)
            position.fees_total = fee_amount
            position.net_realized_pnl = -fee_amount
            position.last_fill_time = fill_time
            await self.session.flush()
            await self._emit_position_event(position, PositionEventType.POSITION_OPENED.value, qty, price, 0.0, fee_amount, str(exchange_trade_id))
        else:
            same_side = (position.position_side == "LONG" and side == "BUY") or (position.position_side == "SHORT" and side == "SELL")
            if same_side:
                old_qty = float(position.qty_open or 0)
                new_qty = old_qty + qty
                position.avg_entry_price = ((old_qty * float(position.avg_entry_price or 0)) + qty * price) / new_qty
                position.qty_open = new_qty
                position.fees_total = float(position.fees_total or 0) + fee_amount
                position.net_realized_pnl = float(position.gross_realized_pnl or 0) - position.fees_total
                position.last_fill_time = fill_time
                position.version = int(position.version or 1) + 1
                await self.session.flush()
                await self._emit_position_event(position, PositionEventType.POSITION_INCREASED.value, qty, price, 0.0, fee_amount, str(exchange_trade_id))
            else:
                open_qty = float(position.qty_open or 0)
                closed_qty = min(open_qty, qty)
                realized = ((price - float(position.avg_entry_price or 0)) if position.position_side == "LONG" else (float(position.avg_entry_price or 0) - price)) * closed_qty
                residual = qty - closed_qty
                position.gross_realized_pnl = float(position.gross_realized_pnl or 0) + realized
                position.fees_total = float(position.fees_total or 0) + fee_amount
                position.net_realized_pnl = position.gross_realized_pnl - position.fees_total
                position.qty_open = max(0.0, open_qty - closed_qty)
                position.last_fill_time = fill_time
                position.version = int(position.version or 1) + 1
                if position.qty_open <= 1e-8:
                    position.status = PositionStatus.CLOSED.value
                    position.is_open = False
                    position.closed_at = fill_time
                    position.avg_exit_price = price
                    await self._emit_position_event(position, PositionEventType.POSITION_CLOSED.value, closed_qty, price, realized, fee_amount, str(exchange_trade_id))
                else:
                    position.status = PositionStatus.PARTIALLY_FILLED.value
                    await self._emit_position_event(position, PositionEventType.POSITION_REDUCED.value, closed_qty, price, realized, fee_amount, str(exchange_trade_id))
                if residual > 1e-8:
                    position = await self.repo.create_position(str(ulid.ULID()), account_id, strategy_id, symbol, "LONG" if side == "BUY" else "SHORT", PositionStatus.OPEN.value, residual, price)
                    await self._emit_position_event(position, PositionEventType.POSITION_OPENED.value, residual, price, 0.0, 0.0, str(exchange_trade_id))

        fill = await self.repo.create_fill(account_id, symbol, exchange_trade_id, side, qty, price, fill_time, intent_id=order.intent_id if order else None, order_id=order.order_id if order else None, position_id=position.position_id, client_order_id=client_order_id, exchange_order_id=payload.get("exchange_order_id"), fee_amount=fee_amount, fee_asset=payload.get("fee_asset"), raw_exchange_json=payload)
        await self.session.flush()
        if order:
            result = await self.session.execute(select(func.sum(Fill.qty)).where(Fill.order_ref_id == order.order_id))
            cum_qty = float(result.scalar() or 0)
            order.status = OrderStatus.FILLED.value if order.requested_qty and cum_qty >= float(order.requested_qty) else OrderStatus.PARTIALLY_FILLED.value
            order.fill_price = price
            order.fill_quantity = cum_qty
            order.filled_at = fill_time
            order.exchange_order_id = payload.get("exchange_order_id") or order.exchange_order_id
        trade_event = __import__('backend.shared.models.domain', fromlist=['TradeEvent']).TradeEvent(event_id=str(ulid.ULID()), event_type="FILL_PROCESSED", source=EventSource.EXCHANGE.value, account_id=account_id, intent_id=order.intent_id if order else None, fill_id=fill.fill_id, order_id=order.order_id if order else None, position_id=position.position_id, symbol=symbol, payload={"exchange_trade_id": str(exchange_trade_id), "qty": qty, "price": price}, payload_json={"exchange_trade_id": str(exchange_trade_id), "qty": qty, "price": price}, idempotency_key=f"FILL_PROCESSED:{exchange_trade_id}")
        self.session.add(trade_event)
        await self.session.flush()
        return fill.fill_id
