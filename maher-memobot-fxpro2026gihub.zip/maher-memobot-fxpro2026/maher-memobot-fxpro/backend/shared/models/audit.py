"""
Audit and Compliance Models
"""
from sqlalchemy import Column, Integer, String, DateTime, Text, JSON, ForeignKey
from datetime import datetime

from backend.shared.models.base import Base

class AuditLog(Base):
    __tablename__ = "audit_log"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    
    # Action Type
    action_type = Column(String(50), nullable=False, index=True)  # 'order_placed', 'api_key_accessed', 'risk_limit_breached'
    
    # Context
    order_id = Column(Integer, ForeignKey("orders.id"))
    engine_id = Column(Integer, ForeignKey("trading_engines.id"))
    resource_type = Column(String(50))
    resource_id = Column(Integer)
    
    # Details
    action_details = Column(JSON)
    
    # Cryptographic Proof
    event_hash = Column(String(64), index=True)  # SHA-256 of (user_id, action_type, timestamp, details)
    previous_hash = Column(String(64))  # Link to previous log entry (blockchain-like)
    
    created_at = Column(DateTime, default=datetime.utcnow, index=True)

class TradeExecution(Base):
    __tablename__ = "trade_executions"
    
    id = Column(Integer, primary_key=True, index=True)
    order_id = Column(Integer, ForeignKey("orders.id"), nullable=False, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    
    # Execution details
    exchange_name = Column(String(50))
    trading_pair = Column(String(20))
    execution_timestamp = Column(DateTime)
    
    # Proof of execution
    execution_proof = Column(Text)  # JSON-encoded proof from exchange
    cryptographic_signature = Column(String(255))
    
    created_at = Column(DateTime, default=datetime.utcnow)

class ComplianceReport(Base):
    __tablename__ = "compliance_reports"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    # Report metadata
    report_type = Column(String(50))  # "monthly", "quarterly", "annual"
    reporting_period_start = Column(DateTime)
    reporting_period_end = Column(DateTime)
    
    # Report content
    total_trades = Column(Integer)
    total_volume_usdt = Column(String(255))
    total_pnl_usdt = Column(String(255))
    
    # Shariah compliance check
    is_shariah_compliant = Column(String(50), default="compliant")
    violations_found = Column(Integer, default=0)
    
    created_at = Column(DateTime, default=datetime.utcnow)
