"""
Trading Engine and Strategy Models
"""
from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, Text, JSON, ForeignKey, Date, UniqueConstraint
from datetime import datetime

from backend.shared.models.base import Base


class EngineSafetyState(Base):
    """
    Per-user, per-engine, per-day safety tracking. This is the account-level
    guardrail layer that sits ABOVE individual trade risk checks -- it protects
    the user's total capital across an entire trading day, independent of
    what any single strategy wants to do.
    """
    __tablename__ = "engine_safety_state"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    engine_name = Column(String(50), nullable=False, index=True)
    day_date = Column(Date, nullable=False, index=True)

    day_start_balance_usd = Column(Float, nullable=False)
    session_start_balance_usd = Column(Float, nullable=False)
    consecutive_losses = Column(Integer, nullable=False, default=0)

    is_halted = Column(Boolean, nullable=False, default=False)
    halt_reason = Column(Text)
    halted_at = Column(DateTime)

    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    __table_args__ = (
        UniqueConstraint('user_id', 'engine_name', 'day_date', name='idx_safety_state_unique'),
    )

class TradingEngine(Base):
    __tablename__ = "trading_engines"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    
    # Engine Identity
    engine_name = Column(String(64), index=True)  # "Rigel", "Sirius", "Canopus", etc.
    engine_type = Column(String(50), nullable=False)  # "scalper", "swing", "trend", "range", "arbitrage", "custom"
    engine_version = Column(String(20), default="1.0.0")
    
    # Operational Status
    status = Column(String(50), default="stopped", index=True)  # "stopped", "running", "paused", "error"
    is_live = Column(Boolean, default=False, index=True)  # live vs. simulation
    
    # Configuration
    active_strategy_id = Column(Integer, ForeignKey("strategies.id"))
    position_amount_usdt = Column(Float)
    max_concurrent_positions = Column(Integer, default=5)
    
    # Real-time Metrics
    total_trades_lifetime = Column(Integer, default=0)
    win_rate = Column(Float)
    profit_factor = Column(Float)
    current_drawdown_pct = Column(Float)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    started_at = Column(DateTime)
    stopped_at = Column(DateTime)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class Strategy(Base):
    __tablename__ = "strategies"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    
    # Strategy Definition
    name = Column(String(100), nullable=False)
    description = Column(Text)
    
    # Parameters (JSON for flexibility)
    parameters = Column(JSON, nullable=False)  # {"entry_rsi": 30, "exit_profit_pct": 2.5, ...}
    
    # Shariah Compliance
    is_shariah_compliant = Column(Boolean, default=True, index=True)
    shariah_audit_ref = Column(String(100))  # "AAOIFI-2024-Q3"
    
    # Backtesting Results
    backtest_sharpe_ratio = Column(Float)
    backtest_max_drawdown = Column(Float)
    backtest_profit_factor = Column(Float)
    backtest_win_rate = Column(Float)
    backtest_sample_size = Column(Integer)
    
    # Metadata
    is_public = Column(Boolean, default=False)  # Can other users fork?
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class PaperBalance(Base):
    __tablename__ = "paper_balances"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    engine_id = Column(Integer, ForeignKey("trading_engines.id"))
    asset = Column(String(20), nullable=False, default="USDT", index=True)
    free = Column(Float, default=0.0, nullable=False)
    locked = Column(Float, default=0.0, nullable=False)

    # Compatibility/accounting totals
    balance_usdt = Column(Float, default=10000.0)
    initial_balance_usdt = Column(Float, default=10000.0)
    total_pnl_usdt = Column(Float, default=0.0)
    total_pnl_pct = Column(Float, default=0.0)

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    reset_at = Column(DateTime)

class Portfolio(Base):
    __tablename__ = "portfolios"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, unique=True, index=True)
    paper_equity = Column(Float, default=10000.0, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class TradeRecord(Base):
    __tablename__ = "trade_records"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    engine_id = Column(Integer, ForeignKey("trading_engines.id"), nullable=True, index=True)

    # Canonical execution fields used by the execution engine/API.
    order_id = Column(String(100), nullable=False, unique=True, index=True)
    symbol = Column(String(20), nullable=False, index=True)
    side = Column(String(10), nullable=False)
    type = Column(String(50), nullable=False)
    amount = Column(Float, nullable=False)
    price = Column(Float, nullable=False)
    fill_price = Column(Float)
    fill_amount = Column(Float)
    status = Column(String(50), default="NEW", index=True)
    execution_mode = Column(String(20), default="Paper", index=True)
    engine_name = Column(String(64), index=True)
    slippage_pct = Column(Float)
    evaluation_score = Column(Float)
    realized_profit = Column(Float, default=0.0)
    latency_ms = Column(Float)
    error_message = Column(Text)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)

    # Compatibility/accounting fields from the earlier schema.
    trading_pair = Column(String(20), nullable=True, index=True)
    quantity = Column(Float, nullable=True)
    entry_price = Column(Float, nullable=True)
    exit_price = Column(Float)
    realized_pnl_usdt = Column(Float)
    realized_pnl_pct = Column(Float)
    is_closed = Column(Boolean, default=False)
    entry_time = Column(DateTime)
    exit_time = Column(DateTime)
    strategy_id = Column(Integer, ForeignKey("strategies.id"))
    notes = Column(Text)

class StrategyState(Base):
    __tablename__ = "strategy_states"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), index=True)
    engine_id = Column(Integer, ForeignKey("trading_engines.id"), nullable=False, index=True)
    strategy_id = Column(Integer, ForeignKey("strategies.id"), nullable=True)
    name = Column(String(100))
    mode = Column(String(30))
    status = Column(String(30), default="IDLE", index=True)
    config_json = Column(JSON)
    
    # State Information
    current_state = Column(String(50), nullable=True)  # 'analyzing', 'monitoring', 'executing', 'idle'
    last_signal = Column(JSON)  # Store the last trading signal
    last_signal_time = Column(DateTime)
    
    # Performance
    consecutive_wins = Column(Integer, default=0)
    consecutive_losses = Column(Integer, default=0)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
