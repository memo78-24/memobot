from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, JSON, Float, Text
from datetime import datetime

from backend.shared.models.base import Base

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(64), unique=True, nullable=False, index=True)
    email = Column(String(255), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    full_name = Column(String(255))
    first_name = Column(String(100))
    last_name = Column(String(100))
    phone = Column(String(20))
    phone_country_code = Column(String(10))
    phone_number = Column(String(30))
    phone_e164 = Column(String(40), index=True)
    country_code = Column(String(2))

    # Compliance
    kyc_status = Column(String(50), default="pending")
    kyc_verified_at = Column(DateTime)
    aml_status = Column(String(50), default="clean")

    # Account Status
    is_active = Column(Boolean, default=True)
    status = Column(String(50), default="PENDING_VERIFICATION", index=True)
    provider_customer_id = Column(String(100), unique=True, index=True)
    is_email_verified = Column(Boolean, default=False)
    email_verified_at = Column(DateTime)
    is_2fa_enabled = Column(Boolean, default=False)
    subscription_tier = Column(String(50), default="free")
    subscription_expires_at = Column(DateTime)
    role = Column(String(50), default="user")  # admin/user/trader/etc.
    preferred_language = Column(String(10), default="en")
    telegram_chat_id = Column(String(100))
    telegram_username = Column(String(100))
    telegram_linked_at = Column(DateTime)
    encrypted_totp_secret = Column(Text)
    failed_login_attempts = Column(Integer, default=0)
    locked_until = Column(DateTime)

    # Audit
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_login_at = Column(DateTime)
    deleted_at = Column(DateTime)  # Soft delete for compliance

class AuthVerificationChallenge(Base):
    __tablename__ = "auth_verification_challenges"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    challenge_type = Column(String(80), nullable=False)
    channel = Column(String(20), default="EMAIL")
    code = Column(String(10))
    code_hash = Column(String(128))
    attempt_count = Column(Integer, default=0)
    max_attempts = Column(Integer, default=5)
    resend_count = Column(Integer, default=0)
    last_sent_at = Column(DateTime, default=datetime.utcnow)
    expires_at = Column(DateTime, nullable=False)
    is_used = Column(Boolean, default=False)
    consumed_at = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)

class UserSettings(Base):
    __tablename__ = "user_settings"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)

    # UI Preferences
    theme = Column(String(20), default="dark")
    language = Column(String(10), default="en")
    timezone = Column(String(50), default="UTC")

    # Notification Preferences
    email_notifications_enabled = Column(Boolean, default=True)
    telegram_notifications_enabled = Column(Boolean, default=False)
    whatsapp_notifications_enabled = Column(Boolean, default=False)

    # Trading Preferences
    default_position_size_usdt = Column(Float, default=100.0)
    auto_confirm_trades = Column(Boolean, default=False)
    notification_preferences = Column(Text, default="{}")

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class Notification(Base):
    __tablename__ = "notifications"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)

    # Notification Details
    title = Column(String(200), nullable=False)
    message = Column(Text, nullable=False)
    notification_type = Column(String(50), nullable=False)  # order/alert/system/billing
    type = Column(String(50), default="INFO", index=True)
    priority = Column(String(20), default="normal")  # low/normal/high/urgent

    # Status
    is_read = Column(Boolean, default=False)
    read_at = Column(DateTime)

    # Metadata
    action_url = Column(String(500))
    extra_data = Column(JSON)

    created_at = Column(DateTime, default=datetime.utcnow, index=True)

class NotificationQueueItem(Base):
    __tablename__ = "notification_queue"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)

    # Channel
    channel = Column(String(20), nullable=False)  # 'email', 'telegram', 'whatsapp'

    # Content
    subject = Column(String(200))
    title = Column(String(200))
    body = Column(Text)
    message = Column(Text)

    # Status
    status = Column(String(50), default="pending")  # 'pending', 'sent', 'failed'
    retry_count = Column(Integer, default=0)
    last_error = Column(Text)

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    sent_at = Column(DateTime)
    failed_at = Column(DateTime)

class UserSession(Base):
    __tablename__ = "user_sessions"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)

    # Session Details
    session_token = Column(String(255), unique=True, nullable=False, index=True)
    refresh_token = Column(String(255), unique=True)
    refresh_token_jti = Column(String(255), unique=True, index=True)

    # Device Info
    device_type = Column(String(50))  # 'desktop', 'mobile', 'tablet'
    browser = Column(String(100))
    ip_address = Column(String(50))
    user_agent = Column(Text)
    device_info = Column(Text)

    # Status
    is_active = Column(Boolean, default=True)
    is_revoked = Column(Boolean, default=False, index=True)
    expires_at = Column(DateTime, nullable=False)

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    last_activity_at = Column(DateTime, default=datetime.utcnow)
    revoked_at = Column(DateTime)

class TelegramLinkChallenge(Base):
    __tablename__ = "telegram_link_challenges"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)

    # Challenge Details
    challenge_code = Column(String(10), unique=True)
    link_token = Column(String(100), unique=True, index=True)
    telegram_user_id = Column(String(50))
    telegram_username = Column(String(100))

    # Status
    is_verified = Column(Boolean, default=False)
    status = Column(String(30), default="PENDING", index=True)
    linked_chat_id = Column(String(100))
    linked_telegram_username = Column(String(100))
    expires_at = Column(DateTime, nullable=False)

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    verified_at = Column(DateTime)
