"""Compatibility domain export layer for the execution/reconciliation subsystem."""
from sqlalchemy import Column, DateTime, Integer, String, JSON, Text
from datetime import datetime

from backend.shared.models.base import Base
from backend.shared.models.execution import (
    TradeIntent,
    ExecutionJob,
    Fill,
    TradeEvent,
    PositionEvent,
)
from backend.shared.models.orders import Order
from backend.shared.models.portfolio import Position


class TradeCycle(Base):
    __tablename__ = "trade_cycles"

    id = Column(Integer, primary_key=True, index=True)
    cycle_id = Column(String(100), unique=True, nullable=False, index=True)
    account_id = Column(String(100), nullable=False, index=True)
    strategy_id = Column(String(100), nullable=True, index=True)
    symbol = Column(String(20), nullable=False, index=True)
    status = Column(String(30), nullable=False, default="ACTIVE", index=True)
    started_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    completed_at = Column(DateTime)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)


class ReconciliationRun(Base):
    __tablename__ = "reconciliation_runs"

    id = Column(Integer, primary_key=True, index=True)
    reconciliation_id = Column(String(100), unique=True, nullable=False, index=True)
    account_id = Column(String(100), nullable=False, index=True)
    scope = Column(String(30), nullable=False, default="STARTUP")
    status = Column(String(30), nullable=False, default="RUNNING", index=True)
    trigger_reason = Column(String(100))
    summary_json = Column(JSON)
    started_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    completed_at = Column(DateTime)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)


class ReconciliationIssue(Base):
    __tablename__ = "reconciliation_issues"

    id = Column(Integer, primary_key=True, index=True)
    issue_id = Column(String(100), unique=True, nullable=False, index=True)
    reconciliation_id = Column(String(100), nullable=False, index=True)
    account_id = Column(String(100), nullable=False, index=True)
    symbol = Column(String(20), index=True)
    issue_type = Column(String(100), nullable=False, index=True)
    severity = Column(String(30), nullable=False)
    status = Column(String(40), nullable=False, index=True)
    details_json = Column(JSON)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    resolved_at = Column(DateTime)

__all__ = [
    "TradeIntent", "ExecutionJob", "Fill", "TradeEvent", "PositionEvent",
    "Order", "Position", "TradeCycle", "ReconciliationRun", "ReconciliationIssue",
]
