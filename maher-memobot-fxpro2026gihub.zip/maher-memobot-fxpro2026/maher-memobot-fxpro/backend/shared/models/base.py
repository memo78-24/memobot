"""Canonical SQLAlchemy declarative base for all legacy MEMOBOT models."""
from sqlalchemy.orm import DeclarativeBase

class Base(DeclarativeBase):
    pass
