﻿"""
MEMOBOT FX-PRO
Transactional Outbox model.

Database commit -> OutboxEvent -> asynchronous worker.

The outbox guarantees that domain events are persisted transactionally
before external/asynchronous processing is attempted.
"""
from datetime import datetime

from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    Integer,
    String,
    Text,
    JSON,
)

from backend.shared.models.base import Base


class OutboxEvent(Base):
    __tablename__ = "outbox_events"

    id = Column(Integer, primary_key=True, index=True)

    event_id = Column(
        String(100),
        unique=True,
        nullable=False,
        index=True,
    )

    aggregate_type = Column(
        String(50),
        nullable=False,
        index=True,
    )

    aggregate_id = Column(
        String(100),
        nullable=False,
        index=True,
    )

    event_type = Column(
        String(100),
        nullable=False,
        index=True,
    )

    payload = Column(
        JSON,
        nullable=False,
    )

    correlation_id = Column(
        String(100),
        index=True,
    )

    idempotency_key = Column(
        String(150),
        unique=True,
        nullable=False,
        index=True,
    )

    status = Column(
        String(30),
        nullable=False,
        default="PENDING",
        index=True,
    )

    attempts = Column(
        Integer,
        nullable=False,
        default=0,
    )

    max_attempts = Column(
        Integer,
        nullable=False,
        default=10,
    )

    available_at = Column(
        DateTime,
        nullable=False,
        default=datetime.utcnow,
        index=True,
    )

    locked_at = Column(DateTime)

    processed_at = Column(DateTime)

    failed_at = Column(DateTime)

    last_error = Column(Text)

    created_at = Column(
        DateTime,
        nullable=False,
        default=datetime.utcnow,
        index=True,
    )

    updated_at = Column(
        DateTime,
        nullable=False,
        default=datetime.utcnow,
        onupdate=datetime.utcnow,
    )
