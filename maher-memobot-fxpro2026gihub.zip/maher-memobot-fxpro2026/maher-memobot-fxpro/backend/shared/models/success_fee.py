"""
Success Fee Models
"""
from sqlalchemy import Column, Integer, String, Float, DateTime, Boolean, ForeignKey
from datetime import datetime

from backend.shared.models.base import Base

class SuccessDecisionFee(Base):
    __tablename__ = "success_decision_fees"
    
    id = Column(Integer, primary_key=True, index=True)
    order_id = Column(Integer, ForeignKey("orders.id"), nullable=True, index=True)
    trade_id = Column(Integer, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    
    # Fee Calculation
    profit_usdt = Column(Float, nullable=True)
    realized_profit = Column(Float)
    fee_rate = Column(Float, default=0.005)
    fee_percentage = Column(Float, default=0.005)
    fee_amount = Column(Float)
    plan_name = Column(String(100))
    engine_name = Column(String(100))  # 0.5%
    fee_amount_usdt = Column(Float)
    
    # Decision Status
    decision_made = Column(Boolean, default=False)
    decision_type = Column(String(50))  # 'charge', 'waive', 'defer'
    decision_reason = Column(String(255))
    
    # Charge Status
    stripe_charge_id = Column(String(100), index=True)
    is_charged = Column(Boolean, default=False)
    charged_at = Column(DateTime)
    
    created_at = Column(DateTime, default=datetime.utcnow)
