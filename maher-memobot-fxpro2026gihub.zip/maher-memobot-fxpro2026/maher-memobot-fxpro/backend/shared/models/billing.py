"""
Billing and Subscription Models
"""
from sqlalchemy import Column, Integer, String, Float, DateTime, Boolean, ForeignKey, JSON, Text
from sqlalchemy.orm import relationship
from datetime import datetime

from backend.shared.models.base import Base

class SubscriptionPlan(Base):
    __tablename__ = "subscription_plans"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(50), unique=True, nullable=False)  # "free", "daily", "weekly", "monthly"
    price_usd = Column(Float, nullable=False)  # Monthly price
    engines_allowed = Column(Integer, default=1)
    features = Column(String(500))  # JSON-encoded features
    price_monthly = Column(Float, default=0.0)
    api_access = Column(Boolean, default=True)
    live_trading_enabled = Column(Boolean, default=False)
    max_leverage = Column(Float, default=1.0)
    max_live_positions = Column(Integer, default=1)
    max_symbols = Column(Integer, default=5)
    is_active = Column(Boolean, default=True)

class UserSubscription(Base):
    __tablename__ = "user_subscriptions"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    plan_id = Column(Integer, ForeignKey("subscription_plans.id"), nullable=False)
    
    # Subscription Details
    stripe_subscription_id = Column(String(100), unique=True, index=True)
    status = Column(String(50), default="active")  # "active", "canceled", "past_due"
    
    # Billing Period
    current_period_start = Column(DateTime)
    current_period_end = Column(DateTime)
    cancel_at_period_end = Column(Boolean, default=False)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    canceled_at = Column(DateTime)
    auto_renew = Column(Boolean, default=True)
    provider = Column(String(50), default="System")
    created_by = Column(String(100), default="System")
    trial_ends_at = Column(DateTime)
    grace_period_ends_at = Column(DateTime)
    is_free_for_life = Column(Boolean, default=False)
    plan = relationship("SubscriptionPlan", lazy="joined")

class BillingEvent(Base):
    __tablename__ = "billing_events"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    
    # Event Type
    event_type = Column(String(50), nullable=False)  # "subscription_started", "subscription_renewed", "refund", "chargeback", "failed_payment"
    
    # Payment Details
    stripe_invoice_id = Column(String(100), index=True)
    stripe_charge_id = Column(String(100), index=True)
    amount_usd = Column(Float)
    currency = Column(String(3), default="USD")
    
    # Status
    status = Column(String(50), default="pending")  # "pending", "succeeded", "failed"
    
    # Timestamps
    billing_period_start = Column(DateTime)
    billing_period_end = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)

class SuccessFee(Base):
    __tablename__ = "success_fees"
    
    id = Column(Integer, primary_key=True, index=True)
    order_id = Column(Integer, ForeignKey("orders.id"), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    
    # Fee Calculation
    profit_usdt = Column(Float, nullable=False)
    fee_rate = Column(Float, default=0.005)  # 0.5%
    fee_amount_usdt = Column(Float)
    
    # Charge Status
    stripe_charge_id = Column(String(100), index=True)
    is_charged = Column(Boolean, default=False)
    charged_at = Column(DateTime)
    
    created_at = Column(DateTime, default=datetime.utcnow)

class WebhookEvent(Base):
    __tablename__ = "webhook_events"
    
    id = Column(Integer, primary_key=True, index=True)
    
    # Event Details
    event_type = Column(String(100), nullable=False, index=True)
    event_id = Column(String(100), unique=True, nullable=False, index=True)  # Stripe event ID
    
    # Payload
    payload = Column(JSON, nullable=True)
    payload_json = Column(Text)
    provider = Column(String(50), default="Stripe")
    
    # Processing Status
    processed = Column(Boolean, default=False)
    processing_status = Column(String(30), default="PENDING", index=True)
    processed_at = Column(DateTime)
    processing_error = Column(Text)
    
    # Timestamps
    received_at = Column(DateTime, default=datetime.utcnow, index=True)

class PaymentTransaction(Base):
    __tablename__ = "payment_transactions"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    
    # Payment Details
    stripe_payment_intent_id = Column(String(100), unique=True, index=True)
    provider_payment_intent_id = Column(String(100), index=True)
    provider_charge_id = Column(String(100), index=True)
    amount_usdt = Column(Float, nullable=False)
    amount = Column(Float)
    currency = Column(String(3), default="USD")
    
    # Status
    status = Column(String(50), default="pending")  # 'pending', 'succeeded', 'failed', 'canceled'
    
    # Metadata
    description = Column(String(255))
    failure_reason = Column(Text)
    refunded_amount = Column(Float, default=0.0)
    extra_data = Column(JSON)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    completed_at = Column(DateTime)
