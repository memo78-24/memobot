"""
Vault Credentials Models (Encrypted API Keys)
"""
from sqlalchemy import Column, Integer, String, LargeBinary, Boolean, DateTime, ForeignKey, UniqueConstraint
from datetime import datetime

from backend.shared.models.base import Base

class VaultCredentials(Base):
    __tablename__ = "vault_credentials"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    
    # Exchange Type
    exchange_name = Column(String(50), nullable=False, index=True)  # 'binance', 'kraken', etc.
    
    # Encrypted API Keys
    api_key_encrypted = Column(LargeBinary, nullable=False)
    api_secret_encrypted = Column(LargeBinary, nullable=False)
    api_passphrase_encrypted = Column(LargeBinary)
    
    # Metadata
    label = Column(String(100))  # "Main Account", "Backup", etc.
    is_testnet = Column(Boolean, default=False, index=True)
    
    # Key rotation tracking
    created_at = Column(DateTime, default=datetime.utcnow)
    last_rotated_at = Column(DateTime)
    rotation_schedule_days = Column(Integer, default=90)
    
    # Compliance
    is_active = Column(Boolean, default=True)
    verified_at = Column(DateTime)
    verification_status = Column(String(50), default="pending")  # "pending", "verified", "failed"
    
    # Unique constraint: user can have one key per exchange per environment
    __table_args__ = (
        UniqueConstraint('user_id', 'exchange_name', 'is_testnet', name='idx_vault_unique'),
    )

# Alias for compatibility
SecretsVault = VaultCredentials
