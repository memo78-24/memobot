"""Portfolio and risk management models."""
from datetime import datetime
from sqlalchemy import Column, Integer, String, Float, DateTime, Boolean, ForeignKey, JSON
from backend.shared.models.base import Base


class PortfolioSnapshot(Base):
    __tablename__ = "portfolio_snapshots"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    total_balance_usdt = Column(Float, nullable=False)
    available_balance_usdt = Column(Float)
    locked_in_trades_usdt = Column(Float)
    unrealized_pnl_usdt = Column(Float)
    realized_pnl_usdt = Column(Float)
    total_pnl_usdt = Column(Float)
    current_drawdown_pct = Column(Float)
    max_daily_drawdown_pct = Column(Float)
    current_leverage_ratio = Column(Float)
    snapshot_at = Column(DateTime, default=datetime.utcnow, index=True)


class RiskConfiguration(Base):
    __tablename__ = "risk_configurations"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    engine_id = Column(Integer, ForeignKey("trading_engines.id"))
    max_daily_drawdown_pct = Column(Float, default=25.0)
    max_position_size_usdt = Column(Float)
    max_concurrent_positions = Column(Integer, default=5)
    risk_per_trade_pct = Column(Float, default=1.0)
    kelly_fraction = Column(Float, default=0.25)
    auto_stop_loss_enabled = Column(Boolean, default=True)
    auto_stop_loss_trigger_pct = Column(Float)
    emergency_shutdown_enabled = Column(Boolean, default=True)
    emergency_shutdown_trigger_pct = Column(Float)
    avoid_short_selling = Column(Boolean, default=True)
    avoid_leverage = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class DailyPerformance(Base):
    __tablename__ = "daily_performance"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    engine_id = Column(Integer, ForeignKey("trading_engines.id"))
    trading_date = Column(DateTime, nullable=False)
    daily_trades = Column(Integer, default=0)
    daily_win_count = Column(Integer, default=0)
    daily_loss_count = Column(Integer, default=0)
    daily_pnl_usdt = Column(Float)
    daily_pnl_pct = Column(Float)
    cumulative_pnl_usdt = Column(Float)
    cumulative_pnl_pct = Column(Float)
    max_drawdown_pct = Column(Float)
    created_at = Column(DateTime, default=datetime.utcnow)


class Position(Base):
    __tablename__ = "positions"
    id = Column(Integer, primary_key=True, index=True)
    position_id = Column(String(100), unique=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True, index=True)
    account_id = Column(String(100), index=True)
    engine_id = Column(Integer, ForeignKey("trading_engines.id"), nullable=True)
    strategy_id = Column(Integer, ForeignKey("strategies.id"))
    order_id = Column(Integer, ForeignKey("orders.id"))
    trading_pair = Column(String(20), nullable=True)
    symbol = Column(String(20), index=True)
    position_side = Column(String(20))
    status = Column(String(30), default="OPEN", index=True)
    qty_open = Column(Float, default=0.0)
    avg_entry_price = Column(Float)
    quantity = Column(Float, nullable=True)
    entry_price = Column(Float, nullable=True)
    entry_time = Column(DateTime, default=datetime.utcnow)
    opened_at = Column(DateTime, default=datetime.utcnow)
    current_price = Column(Float)
    gross_realized_pnl = Column(Float, default=0.0)
    net_realized_pnl = Column(Float, default=0.0)
    fees_total = Column(Float, default=0.0)
    version = Column(Integer, default=1)
    last_fill_time = Column(DateTime)
    unrealized_pnl_usdt = Column(Float)
    unrealized_pnl_pct = Column(Float)
    exit_price = Column(Float)
    avg_exit_price = Column(Float)
    exit_time = Column(DateTime)
    realized_pnl_usdt = Column(Float)
    is_open = Column(Boolean, default=True, index=True)
    closed_at = Column(DateTime)
    metadata_json = Column(JSON, nullable=False, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
