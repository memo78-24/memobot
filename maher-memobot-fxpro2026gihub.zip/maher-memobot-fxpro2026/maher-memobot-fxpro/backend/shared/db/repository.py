"""Async repository for the canonical execution domain."""
from datetime import datetime
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession
from backend.shared.models.domain import TradeCycle, TradeIntent, ExecutionJob, Order, Position, Fill, TradeEvent
from backend.shared.models.enums import PositionStatus


class TradingRepository:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def create_trade_cycle(self, id, account_id, strategy_id, symbol):
        cycle = TradeCycle(cycle_id=id, account_id=str(account_id), strategy_id=str(strategy_id) if strategy_id is not None else None, symbol=symbol, status="ACTIVE")
        self.session.add(cycle)
        return cycle

    async def create_trade_intent(self, id, account_id, strategy_id, cycle_id, symbol, direction, size, price):
        intent = TradeIntent(intent_id=id, account_id=str(account_id), cycle_id=cycle_id, strategy_id=int(strategy_id) if str(strategy_id).isdigit() else None, symbol=symbol, side=direction.upper(), intent_type="ENTRY", status="PENDING", requested_quantity=size, requested_price=price, order_type="LIMIT" if price is not None else "MARKET")
        self.session.add(intent)
        return intent

    async def create_trade_event(self, id, account_id, event_type, source, intent_id, cycle_id, payload):
        event = TradeEvent(event_id=id, event_type=event_type, source=source, account_id=str(account_id), intent_id=intent_id, payload=payload, payload_json=payload, idempotency_key=f"{event_type}:{id}")
        self.session.add(event)
        return event

    async def create_execution_job(self, id, intent_id, cycle_id, account_id, symbol, job_type, payload):
        job = ExecutionJob(job_id=id, intent_id=intent_id, account_id=str(account_id), cycle_id=cycle_id, symbol=symbol, job_type=job_type, status="PENDING", payload_json=payload, execution_payload=payload, next_run_at=datetime.utcnow())
        if str(account_id).isdigit():
            job.user_id = int(account_id)
        self.session.add(job)
        return job

    async def get_trade_intent(self, intent_id):
        result = await self.session.execute(select(TradeIntent).where(TradeIntent.intent_id == intent_id))
        return result.scalar_one_or_none()

    async def get_order_by_client_order_id(self, client_order_id):
        result = await self.session.execute(select(Order).where(Order.client_order_id == client_order_id))
        return result.scalar_one_or_none()

    async def get_order_by_client_order_id_for_update(self, client_order_id):
        result = await self.session.execute(select(Order).where(Order.client_order_id == client_order_id).with_for_update())
        return result.scalar_one_or_none()

    async def get_active_position(self, account_id, symbol):
        result = await self.session.execute(select(Position).where(Position.account_id == str(account_id), Position.symbol == symbol, Position.status.in_([PositionStatus.OPEN.value, PositionStatus.PARTIALLY_FILLED.value, PositionStatus.OPENING.value])))
        return result.scalars().first()

    async def get_active_position_for_update(self, account_id, symbol):
        result = await self.session.execute(select(Position).where(Position.account_id == str(account_id), Position.symbol == symbol, Position.status.in_([PositionStatus.OPEN.value, PositionStatus.PARTIALLY_FILLED.value, PositionStatus.OPENING.value])).with_for_update())
        return result.scalars().first()

    async def get_fill_by_exchange_trade_id(self, exchange_trade_id):
        result = await self.session.execute(select(Fill).where(Fill.exchange_trade_id == str(exchange_trade_id)))
        return result.scalar_one_or_none()

    async def create_order(self, order_id, account_id, intent_id, symbol, direction, size, price, client_order_id=None):
        order = Order(order_id=order_id, account_id=str(account_id), intent_id=intent_id, symbol=symbol, side=direction.upper(), direction=direction.lower(), order_type="LIMIT" if price is not None else "MARKET", quantity=size, requested_qty=size, requested_price=price, price=price, status="CREATED", client_order_id=client_order_id or order_id)
        self.session.add(order)
        return order

    async def create_position(self, id, account_id, strategy_id, symbol, position_side, status="OPEN", qty_open=0.0, avg_entry_price=0.0):
        pos = Position(position_id=id, account_id=str(account_id), strategy_id=int(strategy_id) if strategy_id is not None and str(strategy_id).isdigit() else None, symbol=symbol, position_side=position_side, status=status, qty_open=qty_open, avg_entry_price=avg_entry_price, entry_price=avg_entry_price, metadata_json={})
        if str(account_id).isdigit():
            pos.user_id = int(account_id)
        self.session.add(pos)
        return pos

    async def create_fill(self, account_id, symbol, exchange_trade_id, side, qty, price, fill_time, intent_id=None, order_id=None, position_id=None, client_order_id=None, exchange_order_id=None, fee_amount=0.0, fee_asset=None, raw_exchange_json=None):
        fill = Fill(fill_id=str(exchange_trade_id) if False else __import__('ulid').ULID().__str__(), account_id=str(account_id), symbol=symbol, exchange_trade_id=str(exchange_trade_id), side=side.upper(), quantity=qty, qty=qty, price=price, filled_at=fill_time, fill_time=fill_time, intent_id=intent_id, order_ref_id=order_id, position_id=position_id, client_order_id=client_order_id, external_order_id=exchange_order_id, fee_amount=fee_amount, fee_asset=fee_asset, raw_exchange_json=raw_exchange_json)
        if str(account_id).isdigit():
            fill.user_id = int(account_id)
        self.session.add(fill)
        return fill

    async def commit(self):
        await self.session.commit()

    async def rollback(self):
        await self.session.rollback()
