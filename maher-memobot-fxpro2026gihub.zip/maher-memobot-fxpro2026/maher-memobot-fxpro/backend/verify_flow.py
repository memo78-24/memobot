import requests
import json
import time
import random
import string
import sys

BASE_URL = "http://localhost:8000"

def rand_string(n=8):
    return ''.join(random.choices(string.ascii_lowercase + string.digits, k=n))

def verify_all():
    # 1. Register a new user
    username = f"testuser_{rand_string()}"
    email = f"{username}@example.com"
    password = "SecurePassword123!"
    
    print(f"--- 1. Registering new user {username} ---")
    resp = requests.post(f"{BASE_URL}/api/auth/register", json={
        "first_name": "Test",
        "last_name": "User",
        "username": username,
        "email": email,
        "phone_country_code": "+1",
        "phone_number": ''.join(random.choices(string.digits, k=10)),
        "password": password,
        "confirm_password": password
    })
    
    if resp.status_code != 200:
        print("Registration failed:", resp.text)
        sys.exit(1)
        
    print("Registration successful:", resp.json())
    
    # 2. Verify OTP (mocked or db accessed? wait, do we need the actual OTP?)
    # Since we don't have the actual OTP from email, we can either extract it from DB or bypass
    # Let's import the DB session directly to get the OTP.
    import psycopg2
    conn = psycopg2.connect("postgresql://postgres:postgres@localhost:5433/memobot_db")
    cursor = conn.cursor()
    cursor.execute("SELECT user_id, challenge_id FROM auth_verification_challenges ORDER BY created_at DESC LIMIT 1;")
    user_id, challenge_id = cursor.fetchone()
    
    # Overwrite the code_hash with hash of '123456'
    import hashlib
    otp = "123456"
    otp_hash = hashlib.sha256(otp.encode('utf-8')).hexdigest()
    cursor.execute(f"UPDATE auth_verification_challenges SET code_hash = '{otp_hash}' WHERE challenge_id = {challenge_id};")
    conn.commit()
    
    print(f"--- 2. Verifying OTP {otp} for user {username} ---")
    resp = requests.post(f"{BASE_URL}/api/auth/verify-email-code", json={
        "username": username,
        "email": email,
        "code": otp
    })
    
    if resp.status_code != 200:
        print("OTP Verification failed:", resp.text)
        sys.exit(1)
        
    data = resp.json()
    token = data.get("token")
    print("OTP Verification successful. Token received.")
    
    # 3. Existing User Login
    print(f"--- 3. Testing Login for {username} ---")
    resp = requests.post(f"{BASE_URL}/api/auth/login", data={
        "username": username,
        "password": password
    })
    if resp.status_code != 200:
        print("Login failed:", resp.text)
        sys.exit(1)
        
    print("Login successful.")
    
    # 4. Check DB for PaperBalance, Portfolio, UserSettings
    print("--- 4. Checking DB for associated records ---")
    
    cursor.execute(f"SELECT COUNT(*) FROM paper_balances WHERE user_id = {user_id};")
    pb_count = cursor.fetchone()[0]
    print(f"PaperBalances count: {pb_count} (Expected: 1)")
    
    cursor.execute(f"SELECT COUNT(*) FROM portfolios WHERE user_id = {user_id};")
    pf_count = cursor.fetchone()[0]
    print(f"Portfolios count: {pf_count} (Expected: 1)")
    
    cursor.execute(f"SELECT COUNT(*) FROM user_settings WHERE user_id = {user_id};")
    us_count = cursor.fetchone()[0]
    print(f"UserSettings count: {us_count} (Expected: 1)")
    
    if pb_count != 1 or pf_count != 1 or us_count != 1:
        print("ERROR: Duplicates or missing records found!")
        sys.exit(1)
    
    # 5. Test WebSocket Connection
    print("--- 5. Testing WebSocket ---")
    import websocket
    import jwt
    print(f"Token: {token}")
    try:
        decoded = jwt.decode(token, options={"verify_signature": False})
        print(f"Decoded token: {decoded}")
    except Exception as e:
        print(f"Token decode error: {e}")
        
    ws = websocket.WebSocket()
    try:
        # Use origin parameter to avoid duplicate origin headers
        ws.connect(f"ws://localhost:8000/api/ws?token={token}", origin="http://localhost:8081")
        print("WebSocket connected successfully!")
        ws.close()
    except Exception as e:
        print(f"WebSocket connection failed: {e}")
        sys.exit(1)

    print("--- ALL VERIFICATIONS PASSED ---")

if __name__ == "__main__":
    verify_all()
