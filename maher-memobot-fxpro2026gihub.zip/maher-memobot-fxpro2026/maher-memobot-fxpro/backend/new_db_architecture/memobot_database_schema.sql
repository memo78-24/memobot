-- ============================================================================
-- MEMOBOT FX-PRO: PRODUCTION-GRADE POSTGRESQL SCHEMA
-- Designed for 5-year resilience, audit compliance, and zero data loss
-- ============================================================================

-- ============================================================================
-- PART 1: CORE IDENTITY & AUTHENTICATION
-- ============================================================================

CREATE TABLE users (
    id BIGSERIAL PRIMARY KEY,
    username VARCHAR(64) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(255),
    phone VARCHAR(20),
    country_code VARCHAR(2),
    
    -- Compliance
    kyc_status ENUM('pending', 'verified', 'rejected', 'expired') DEFAULT 'pending',
    kyc_verified_at TIMESTAMP,
    aml_status ENUM('clean', 'flagged', 'blocked') DEFAULT 'clean',
    
    -- Account Status
    is_active BOOLEAN DEFAULT TRUE,
    is_email_verified BOOLEAN DEFAULT FALSE,
    is_2fa_enabled BOOLEAN DEFAULT FALSE,
    subscription_tier ENUM('free', 'daily', 'weekly', 'monthly') DEFAULT 'free',
    subscription_expires_at TIMESTAMP,
    
    -- Audit
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login_at TIMESTAMP,
    deleted_at TIMESTAMP, -- Soft delete for compliance
    
    CONSTRAINT valid_email CHECK (email ~* '^[^@]+@[^@]+\.[^@]+$')
);

CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_kyc_status ON users(kyc_status);

-- ============================================================================
-- PART 2: VAULT & SECRETS (Encrypted API Keys)
-- ============================================================================

CREATE TABLE vault_credentials (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    
    -- Exchange Type (extensible for future exchanges)
    exchange_name VARCHAR(50) NOT NULL, -- 'binance', 'kraken', etc.
    
    -- Encrypted API Keys (use pgcrypto extension)
    api_key_encrypted BYTEA NOT NULL,
    api_secret_encrypted BYTEA NOT NULL,
    api_passphrase_encrypted BYTEA, -- For some exchanges
    
    -- Metadata
    label VARCHAR(100), -- "Main Account", "Backup", etc.
    is_testnet BOOLEAN DEFAULT FALSE,
    
    -- Key rotation tracking
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_rotated_at TIMESTAMP,
    rotation_schedule_days INT DEFAULT 90,
    
    -- Compliance
    is_active BOOLEAN DEFAULT TRUE,
    verified_at TIMESTAMP,
    verification_status ENUM('pending', 'verified', 'failed') DEFAULT 'pending',
    
    CONSTRAINT unique_vault_key UNIQUE(user_id, exchange_name, is_testnet)
);

CREATE INDEX idx_vault_user ON vault_credentials(user_id);
CREATE INDEX idx_vault_exchange ON vault_credentials(exchange_name);

-- ============================================================================
-- PART 3: TRADING ENGINES (10 engines per user)
-- ============================================================================

CREATE TABLE trading_engines (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    
    -- Engine Identity
    engine_name VARCHAR(64), -- "Rigel", "Sirius", "Canopus", custom names
    engine_type ENUM('scalper', 'swing', 'trend', 'range', 'arbitrage', 'custom') NOT NULL,
    engine_version VARCHAR(20) DEFAULT '1.0.0',
    
    -- Operational Status
    status ENUM('stopped', 'running', 'paused', 'error') DEFAULT 'stopped',
    is_live BOOLEAN DEFAULT FALSE, -- live vs. simulation
    
    -- Configuration
    active_strategy_id BIGINT,
    position_amount_usdt DECIMAL(15, 2),
    max_concurrent_positions INT DEFAULT 5,
    
    -- Real-time Metrics
    total_trades_lifetime BIGINT DEFAULT 0,
    win_rate DECIMAL(5, 2),
    profit_factor DECIMAL(10, 4),
    current_drawdown_pct DECIMAL(5, 2),
    
    -- Timestamps
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    started_at TIMESTAMP,
    stopped_at TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT unique_engine_name UNIQUE(user_id, engine_name)
);

CREATE INDEX idx_engine_user ON trading_engines(user_id);
CREATE INDEX idx_engine_status ON trading_engines(status);
CREATE INDEX idx_engine_live ON trading_engines(is_live);

-- ============================================================================
-- PART 4: STRATEGIES (Templates for engines)
-- ============================================================================

CREATE TABLE strategies (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    
    -- Strategy Definition
    name VARCHAR(100) NOT NULL,
    description TEXT,
    
    -- Parameters (JSON for flexibility)
    parameters JSONB NOT NULL, -- {
                               -- "entry_rsi": 30,
                               -- "exit_profit_pct": 2.5,
                               -- "stop_loss_pct": 1.0,
                               -- ...
                               -- }
    
    -- Shariah Compliance
    is_shariah_compliant BOOLEAN DEFAULT TRUE,
    shariah_audit_ref VARCHAR(100), -- "AAOIFI-2024-Q3"
    
    -- Backtesting Results
    backtest_sharpe_ratio DECIMAL(10, 4),
    backtest_max_drawdown DECIMAL(5, 2),
    backtest_profit_factor DECIMAL(10, 4),
    backtest_win_rate DECIMAL(5, 2),
    backtest_sample_size INT,
    
    -- Metadata
    is_public BOOLEAN DEFAULT FALSE, -- Can other users fork?
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_strategy_user ON strategies(user_id);
CREATE INDEX idx_strategy_shariah ON strategies(is_shariah_compliant);

-- ============================================================================
-- PART 5: ORDERS & EXECUTION (9-Stage Pipeline)
-- ============================================================================

CREATE TYPE order_status AS ENUM (
    'signal_generated',
    'filters_passed',
    'shariah_checked',
    'risk_approved',
    'sized',
    'placed',
    'confirmed',
    'audit_logged',
    'pnl_monitored'
);

CREATE TABLE orders (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    engine_id BIGINT NOT NULL REFERENCES trading_engines(id) ON DELETE CASCADE,
    
    -- Order Identification
    external_order_id VARCHAR(100), -- Binance order ID
    trading_pair VARCHAR(20) NOT NULL, -- "BTCUSDT"
    
    -- Order Details
    side ENUM('buy', 'sell') NOT NULL,
    order_type ENUM('market', 'limit', 'stop-loss') NOT NULL,
    quantity DECIMAL(20, 8) NOT NULL,
    price DECIMAL(20, 8),
    notional_value_usdt DECIMAL(15, 2),
    
    -- 9-Stage Pipeline Status
    pipeline_stage order_status DEFAULT 'signal_generated',
    signal_generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    filters_passed_at TIMESTAMP,
    shariah_checked_at TIMESTAMP,
    risk_approved_at TIMESTAMP,
    sized_at TIMESTAMP,
    placed_at TIMESTAMP,
    confirmed_at TIMESTAMP,
    audit_logged_at TIMESTAMP,
    pnl_monitored_at TIMESTAMP,
    
    -- Execution
    fill_price DECIMAL(20, 8),
    fill_quantity DECIMAL(20, 8),
    filled_at TIMESTAMP,
    
    -- Risk Parameters
    stop_loss_price DECIMAL(20, 8),
    take_profit_price DECIMAL(20, 8),
    
    -- PnL
    realized_pnl_usdt DECIMAL(15, 2),
    realized_pnl_pct DECIMAL(10, 4),
    
    -- Audit Trail
    rejection_reason TEXT,
    audit_signature VARCHAR(255), -- Cryptographic proof
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_orders_user ON orders(user_id);
CREATE INDEX idx_orders_engine ON orders(engine_id);
CREATE INDEX idx_orders_pair ON orders(trading_pair);
CREATE INDEX idx_orders_stage ON orders(pipeline_stage);
CREATE INDEX idx_orders_timestamp ON orders(created_at);

-- ============================================================================
-- PART 6: PORTFOLIO & POSITIONS (Real-time balance)
-- ============================================================================

CREATE TABLE portfolio_snapshots (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    
    -- Balances
    total_balance_usdt DECIMAL(15, 2) NOT NULL,
    available_balance_usdt DECIMAL(15, 2),
    locked_in_trades_usdt DECIMAL(15, 2),
    
    -- PnL
    unrealized_pnl_usdt DECIMAL(15, 2),
    realized_pnl_usdt DECIMAL(15, 2),
    total_pnl_usdt DECIMAL(15, 2),
    
    -- Risk Metrics
    current_drawdown_pct DECIMAL(5, 2),
    max_daily_drawdown_pct DECIMAL(5, 2),
    current_leverage_ratio DECIMAL(10, 4),
    
    -- Timestamp (snapshotted every 5 minutes)
    snapshot_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT valid_balances CHECK (
        total_balance_usdt > 0 AND
        available_balance_usdt >= 0 AND
        locked_in_trades_usdt >= 0
    )
);

CREATE INDEX idx_portfolio_user ON portfolio_snapshots(user_id);
CREATE INDEX idx_portfolio_timestamp ON portfolio_snapshots(snapshot_at);

-- ============================================================================
-- PART 7: RISK MANAGEMENT (Max Drawdown, Position Sizing, etc.)
-- ============================================================================

CREATE TABLE risk_configurations (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    engine_id BIGINT REFERENCES trading_engines(id) ON DELETE CASCADE,
    
    -- Risk Limits
    max_daily_drawdown_pct DECIMAL(5, 2) DEFAULT 25.0,
    max_position_size_usdt DECIMAL(15, 2),
    max_concurrent_positions INT DEFAULT 5,
    
    -- Sizing Rules
    risk_per_trade_pct DECIMAL(5, 2) DEFAULT 1.0,
    kelly_fraction DECIMAL(5, 4) DEFAULT 0.25,
    
    -- Safeguards
    auto_stop_loss_enabled BOOLEAN DEFAULT TRUE,
    auto_stop_loss_trigger_pct DECIMAL(5, 2),
    emergency_shutdown_enabled BOOLEAN DEFAULT TRUE,
    emergency_shutdown_trigger_pct DECIMAL(5, 2),
    
    -- Shariah Compliance
    avoid_short_selling BOOLEAN DEFAULT TRUE,
    avoid_leverage BOOLEAN DEFAULT TRUE,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_risk_user ON risk_configurations(user_id);
CREATE INDEX idx_risk_engine ON risk_configurations(engine_id);

-- ============================================================================
-- PART 8: AUDIT & COMPLIANCE (Immutable Ledger)
-- ============================================================================

CREATE TABLE audit_log (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    
    -- Action Type
    action_type VARCHAR(50) NOT NULL, -- 'order_placed', 'api_key_accessed', 'risk_limit_breached'
    
    -- Context
    order_id BIGINT REFERENCES orders(id),
    engine_id BIGINT REFERENCES trading_engines(id),
    resource_type VARCHAR(50),
    resource_id BIGINT,
    
    -- Details
    action_details JSONB,
    
    -- Cryptographic Proof
    event_hash VARCHAR(64), -- SHA-256 of (user_id, action_type, timestamp, details)
    previous_hash VARCHAR(64), -- Link to previous log entry (blockchain-like)
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_audit_user ON audit_log(user_id);
CREATE INDEX idx_audit_action ON audit_log(action_type);
CREATE INDEX idx_audit_timestamp ON audit_log(created_at);
CREATE INDEX idx_audit_order ON audit_log(order_id);

-- ============================================================================
-- PART 9: BILLING & SUBSCRIPTIONS (Payment tracking)
-- ============================================================================

CREATE TABLE billing_events (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    
    -- Subscription
    subscription_tier ENUM('free', 'daily', 'weekly', 'monthly'),
    
    -- Payment Details
    stripe_invoice_id VARCHAR(100),
    stripe_charge_id VARCHAR(100),
    amount_usd DECIMAL(10, 2),
    currency VARCHAR(3) DEFAULT 'USD',
    
    -- Event
    event_type ENUM('subscription_started', 'subscription_renewed', 'refund', 'chargeback', 'failed_payment') NOT NULL,
    status ENUM('pending', 'succeeded', 'failed') DEFAULT 'pending',
    
    -- Timestamps
    billing_period_start TIMESTAMP,
    billing_period_end TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_billing_user ON billing_events(user_id);
CREATE INDEX idx_billing_stripe_invoice ON billing_events(stripe_invoice_id);

-- ============================================================================
-- PART 10: PERFORMANCE METRICS (Queryable dashboards)
-- ============================================================================

CREATE TABLE daily_performance (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    engine_id BIGINT REFERENCES trading_engines(id),
    
    trading_date DATE NOT NULL,
    
    -- Daily Stats
    daily_trades INT DEFAULT 0,
    daily_win_count INT DEFAULT 0,
    daily_loss_count INT DEFAULT 0,
    daily_pnl_usdt DECIMAL(15, 2),
    daily_pnl_pct DECIMAL(10, 4),
    
    -- Cumulative
    cumulative_pnl_usdt DECIMAL(15, 2),
    cumulative_pnl_pct DECIMAL(10, 4),
    max_drawdown_pct DECIMAL(5, 2),
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT unique_daily_perf UNIQUE(user_id, engine_id, trading_date)
);

CREATE INDEX idx_daily_perf_user ON daily_performance(user_id);
CREATE INDEX idx_daily_perf_date ON daily_performance(trading_date);

-- ============================================================================
-- PART 11: BACKUP & DISASTER RECOVERY METADATA
-- ============================================================================

CREATE TABLE backup_metadata (
    id BIGSERIAL PRIMARY KEY,
    
    backup_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    backup_size_mb BIGINT,
    backup_type ENUM('full', 'incremental') DEFAULT 'full',
    backup_location VARCHAR(255), -- S3 bucket path, etc.
    backup_hash VARCHAR(64), -- Verify integrity
    
    -- Recovery
    is_verified BOOLEAN DEFAULT FALSE,
    last_tested_at TIMESTAMP,
    recovery_time_minutes INT,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- PART 12: APPLICATION METADATA (Schema versioning)
-- ============================================================================

CREATE TABLE schema_metadata (
    id BIGSERIAL PRIMARY KEY,
    schema_version VARCHAR(20) NOT NULL,
    migration_name VARCHAR(255),
    applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    rollback_supported BOOLEAN DEFAULT TRUE
);

INSERT INTO schema_metadata (schema_version, migration_name) 
VALUES ('1.0.0', 'Initial production schema');

-- ============================================================================
-- PERFORMANCE OPTIMIZATIONS
-- ============================================================================

-- Materialized View: User Daily Dashboard
CREATE MATERIALIZED VIEW user_daily_dashboard AS
SELECT 
    u.id as user_id,
    u.username,
    u.subscription_tier,
    COUNT(DISTINCT te.id) as active_engines,
    COUNT(DISTINCT o.id) as total_orders,
    COALESCE(SUM(dp.daily_pnl_usdt), 0) as total_pnl_usdt,
    COALESCE(SUM(dp.daily_pnl_pct), 0) as total_pnl_pct,
    MAX(dp.max_drawdown_pct) as max_drawdown,
    ps.total_balance_usdt,
    CURRENT_DATE as snapshot_date
FROM users u
LEFT JOIN trading_engines te ON u.id = te.user_id AND te.is_live = true
LEFT JOIN orders o ON u.id = o.user_id AND DATE(o.created_at) = CURRENT_DATE
LEFT JOIN daily_performance dp ON u.id = dp.user_id AND dp.trading_date = CURRENT_DATE
LEFT JOIN LATERAL (
    SELECT total_balance_usdt FROM portfolio_snapshots 
    WHERE user_id = u.id 
    ORDER BY snapshot_at DESC LIMIT 1
) ps ON true
WHERE u.is_active = true
GROUP BY u.id, u.username, u.subscription_tier, ps.total_balance_usdt;

CREATE INDEX idx_user_daily_dashboard ON user_daily_dashboard(user_id);

-- ============================================================================
-- SECURITY: Row-Level Security (Tenant Isolation)
-- ============================================================================

-- Enable RLS
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE vault_credentials ENABLE ROW LEVEL SECURITY;
ALTER TABLE trading_engines ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_log ENABLE ROW LEVEL SECURITY;

-- Policies: Users can only see their own data
CREATE POLICY user_isolation ON orders 
    USING (user_id = current_user_id());

-- ============================================================================
-- COMMENTS (Schema Documentation)
-- ============================================================================

COMMENT ON TABLE users IS 'Core user identity and account management with KYC/AML compliance';
COMMENT ON TABLE vault_credentials IS 'Encrypted API keys for exchange connectivity - NEVER log plaintext';
COMMENT ON TABLE trading_engines IS '10 independent trading engines per user with live/sim modes';
COMMENT ON TABLE orders IS '9-stage order execution pipeline with audit trail for regulatory compliance';
COMMENT ON TABLE audit_log IS 'Immutable ledger of all system actions for forensic analysis';
COMMENT ON COLUMN orders.pipeline_stage IS 'Tracks order through 9 mandatory validation stages';
COMMENT ON COLUMN audit_log.event_hash IS 'SHA-256 hash enables detection of tampered records';

-- ============================================================================
-- END OF SCHEMA
-- ============================================================================
