#!/bin/bash
# ============================================================================
# MEMOBOT DATABASE: BACKUP & DISASTER RECOVERY STRATEGY
# For 5-year resilience with ZERO data loss
# ============================================================================

set -e  # Exit on error

BACKUP_DIR="/backups/memobot"
CLOUD_BACKUP_DIR="s3://memobot-backups"  # AWS S3 (or Cloudflare R2)
LOG_FILE="/var/log/memobot_backup.log"
DB_NAME="memobot_db"
DB_USER="postgres"

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# ============================================================================
# PART 1: DAILY BACKUP (Full backup every night at 2 AM)
# ============================================================================

backup_database() {
    local timestamp=$(date +%Y%m%d_%H%M%S)
    local backup_file="$BACKUP_DIR/memobot_${timestamp}.sql"
    local backup_size=0
    
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] Starting database backup..." >> $LOG_FILE
    
    # Full dump with compression
    pg_dump \
        -U $DB_USER \
        -Fc \
        --compress=9 \
        --verbose \
        --no-password \
        $DB_NAME > "${backup_file}.dump" 2>&1
    
    if [ $? -ne 0 ]; then
        echo -e "${RED}[ERROR] Database dump failed${NC}" >> $LOG_FILE
        exit 1
    fi
    
    # Get file size
    backup_size=$(du -sh "${backup_file}.dump" | cut -f1)
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] Backup created: ${backup_file}.dump (${backup_size})" >> $LOG_FILE
    
    # Calculate checksum for integrity verification
    local checksum=$(sha256sum "${backup_file}.dump" | awk '{print $1}')
    echo "$checksum" > "${backup_file}.sha256"
    
    return 0
}

# ============================================================================
# PART 2: UPLOAD TO CLOUD (AWS S3 or Cloudflare R2)
# ============================================================================

upload_to_cloud() {
    local backup_file=$1
    local timestamp=$(date +%Y%m%d_%H%M%S)
    
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] Uploading backup to S3..." >> $LOG_FILE
    
    # AWS S3 (requires aws-cli installed and configured)
    aws s3 cp "${backup_file}.dump" \
        "${CLOUD_BACKUP_DIR}/$(basename ${backup_file}).dump" \
        --storage-class STANDARD_IA \
        --sse AES256 \
        2>&1 >> $LOG_FILE
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}[OK] Cloud backup uploaded${NC}" >> $LOG_FILE
    else
        echo -e "${RED}[ERROR] Cloud upload failed${NC}" >> $LOG_FILE
        return 1
    fi
}

# ============================================================================
# PART 3: REAL-TIME REPLICATION (Hot Standby)
# ============================================================================

setup_replication() {
    echo "Setting up PostgreSQL replication to backup VM..."
    
    # On PRIMARY (local machine):
    # Enable WAL archiving in postgresql.conf
    
    cat >> /etc/postgresql/14/main/postgresql.conf <<EOF
# Enable WAL archiving for replication
wal_level = replica
max_wal_senders = 5
wal_keep_size = 1GB
archive_mode = on
archive_command = 'test ! -f /archive/%f && cp %p /archive/%f'
archive_timeout = 300
EOF

    # Restart PostgreSQL
    systemctl restart postgresql
    
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] Replication enabled on primary" >> $LOG_FILE
}

# ============================================================================
# PART 4: HEALTH CHECK (Verify backups are usable)
# ============================================================================

verify_backup() {
    local backup_file=$1
    
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] Verifying backup integrity..." >> $LOG_FILE
    
    # Checksum verification
    if sha256sum -c "${backup_file}.sha256" >> $LOG_FILE 2>&1; then
        echo -e "${GREEN}[OK] Checksum verified${NC}" >> $LOG_FILE
    else
        echo -e "${RED}[ERROR] Checksum mismatch - backup may be corrupted${NC}" >> $LOG_FILE
        return 1
    fi
    
    # Test restore (optional, runs weekly)
    if [[ $(date +%u) -eq 7 ]]; then  # Sunday = 7
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] Testing restore on test database..." >> $LOG_FILE
        
        # Create test DB
        dropdb --if-exists test_memobot 2>/dev/null || true
        createdb test_memobot
        
        # Restore
        pg_restore -d test_memobot "${backup_file}.dump" >> $LOG_FILE 2>&1
        
        if [ $? -eq 0 ]; then
            echo -e "${GREEN}[OK] Restore test passed${NC}" >> $LOG_FILE
            dropdb test_memobot
        else
            echo -e "${RED}[ERROR] Restore test FAILED - do not rely on this backup${NC}" >> $LOG_FILE
            return 1
        fi
    fi
}

# ============================================================================
# PART 5: RETENTION POLICY (Delete old backups)
# ============================================================================

cleanup_old_backups() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] Cleaning up old backups..." >> $LOG_FILE
    
    # Keep local backups for 30 days
    find $BACKUP_DIR -name "*.dump" -mtime +30 -delete
    
    # S3 backups: set lifecycle policy via AWS CLI
    aws s3api put-bucket-lifecycle-configuration \
        --bucket memobot-backups \
        --lifecycle-configuration '{
            "Rules": [
                {
                    "ID": "Archive60Days",
                    "Status": "Enabled",
                    "Transitions": [
                        {
                            "Days": 60,
                            "StorageClass": "GLACIER"
                        }
                    ],
                    "Expiration": {
                        "Days": 2555
                    }
                }
            ]
        }' >> $LOG_FILE 2>&1
    
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] Cleanup complete" >> $LOG_FILE
}

# ============================================================================
# PART 6: MONITORING & ALERTING
# ============================================================================

send_backup_report() {
    local backup_count=$(ls $BACKUP_DIR/*.dump 2>/dev/null | wc -l)
    local total_size=$(du -sh $BACKUP_DIR | cut -f1)
    local latest_backup=$(ls -t $BACKUP_DIR/*.dump 2>/dev/null | head -1)
    local latest_timestamp=$(stat -c %y "$latest_backup" 2>/dev/null || echo "N/A")
    
    # Send to Telegram bot
    curl -X POST "https://api.telegram.org/botYOUR_BOT_TOKEN/sendMessage" \
        -d "chat_id=YOUR_CHAT_ID" \
        -d "text=📊 Memobot Backup Report%0A%0A✅ Backups: $backup_count%0A📦 Total Size: $total_size%0A⏰ Latest: $latest_timestamp" \
        2>/dev/null || true
}

# ============================================================================
# PART 7: DISASTER RECOVERY RUNBOOK
# ============================================================================

restore_from_backup() {
    local backup_file=$1
    
    if [ -z "$backup_file" ]; then
        echo -e "${RED}Usage: restore_from_backup <backup_file>${NC}"
        return 1
    fi
    
    echo -e "${YELLOW}DISASTER RECOVERY: Restoring from ${backup_file}${NC}"
    read -p "This will overwrite current data. Continue? (y/n) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "Restore cancelled"
        return 1
    fi
    
    # Step 1: Stop all applications
    echo "Stopping Memobot backend..."
    systemctl stop memobot-backend || true
    sleep 2
    
    # Step 2: Drop current database
    echo "Dropping current database..."
    dropdb $DB_NAME 2>/dev/null || true
    createdb $DB_NAME
    
    # Step 3: Restore from backup
    echo "Restoring from backup..."
    pg_restore -d $DB_NAME "$backup_file" --no-owner --role=$DB_USER
    
    if [ $? -ne 0 ]; then
        echo -e "${RED}Restore failed!${NC}"
        return 1
    fi
    
    # Step 4: Verify restore
    echo "Verifying restore..."
    table_count=$(psql -d $DB_NAME -t -c "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='public'")
    echo "Tables restored: $table_count"
    
    # Step 5: Restart application
    echo "Restarting Memobot backend..."
    systemctl start memobot-backend
    sleep 5
    
    echo -e "${GREEN}Disaster recovery complete!${NC}"
}

# ============================================================================
# MAIN EXECUTION
# ============================================================================

main() {
    # Create backup directory if missing
    mkdir -p $BACKUP_DIR
    
    case "${1:-backup}" in
        backup)
            backup_database
            upload_to_cloud "$BACKUP_DIR/memobot_*.dump"
            verify_backup "$BACKUP_DIR/memobot_*.dump"
            cleanup_old_backups
            send_backup_report
            ;;
        restore)
            restore_from_backup "$2"
            ;;
        verify)
            verify_backup "$2"
            ;;
        setup-replication)
            setup_replication
            ;;
        *)
            echo "Usage: $0 {backup|restore <file>|verify <file>|setup-replication}"
            exit 1
            ;;
    esac
}

main "$@"
