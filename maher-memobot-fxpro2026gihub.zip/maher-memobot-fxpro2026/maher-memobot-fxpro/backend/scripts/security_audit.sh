#!/bin/bash
# MemoBot FX-PRO Security Audit Script
# Runs static analysis, dependency checks, and secret scanning

set -e

echo "Starting Security Audit..."

# 1. Dependency Vulnerability Audit
echo "Running safety check for dependency vulnerabilities..."
if command -v safety &> /dev/null; then
    safety check -r requirements.txt --full-report
else
    echo "safety is not installed. Run 'pip install safety' to check dependencies."
fi

# 2. Static Application Security Testing (SAST)
echo "Running bandit for static code analysis..."
if command -v bandit &> /dev/null; then
    bandit -r app/ shared/ -ll -ii
else
    echo "bandit is not installed. Run 'pip install bandit' to perform static analysis."
fi

# 3. Secret Scanning (Optional if trufflehog is installed)
echo "Running secret scanning..."
if command -v trufflehog &> /dev/null; then
    trufflehog filesystem --directory .
else
    echo "trufflehog is not installed. Skipping secret scanning."
fi

echo "Security Audit Complete!"
