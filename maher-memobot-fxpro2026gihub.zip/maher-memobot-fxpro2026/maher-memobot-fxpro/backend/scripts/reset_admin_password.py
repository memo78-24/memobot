from backend.app.database import SessionLocal
from backend.shared.models.user import User
from backend.app.security import get_password_hash

def reset_admin():
    db = SessionLocal()
    try:
        admin = db.query(User).filter(User.username == "admin").first()
        if admin:
            admin.password_hash = get_password_hash("adminpassword")
            db.commit()
            print("Admin password successfully reset to 'adminpassword'")
        else:
            print("Admin user not found!")
    finally:
        db.close()

if __name__ == "__main__":
    reset_admin()
