import asyncio
import asyncpg
from backend.app.security import get_password_hash

async def create_admin():
    # Connect to PostgreSQL
    conn = await asyncpg.connect(
        "postgresql://postgres:NewStrongPassword123!@localhost:5432/memobot_db"
    )
    
    try:
        # Create users table if it doesn't exist (simplified version)
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id SERIAL PRIMARY KEY,
                username VARCHAR(64) UNIQUE NOT NULL,
                email VARCHAR(255) UNIQUE NOT NULL,
                password_hash VARCHAR(255) NOT NULL,
                full_name VARCHAR(255),
                is_active BOOLEAN DEFAULT TRUE,
                is_email_verified BOOLEAN DEFAULT FALSE,
                role VARCHAR(50) DEFAULT 'user',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Check if admin already exists
        result = await conn.fetchrow(
            "SELECT username, email FROM users WHERE username = 'admin'"
        )
        
        if result:
            print("Admin user already exists!")
            print(f"Username: {result['username']}")
            print(f"Email: {result['email']}")
        else:
            # Create admin user
            password_hash = get_password_hash("admin123")
            await conn.execute("""
                INSERT INTO users (username, email, password_hash, full_name, is_active, is_email_verified, role)
                VALUES ($1, $2, $3, $4, $5, $6, $7)
            """, "admin", "admin@memobot-fxpro.com", password_hash, "System Administrator", 
                  True, True, "admin")
            
            print("Admin user successfully created!")
            print("Username: admin")
            print("Password: admin123")
            print("Email: admin@memobot-fxpro.com")
    except Exception as e:
        print(f"Error creating admin user: {e}")
    finally:
        await conn.close()

if __name__ == "__main__":
    asyncio.run(create_admin())
