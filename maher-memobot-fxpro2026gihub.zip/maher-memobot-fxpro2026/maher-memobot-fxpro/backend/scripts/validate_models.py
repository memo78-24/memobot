import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

from backend.shared.models.base import Base
# Import all to populate metadata
from backend.shared.models.user import *
from backend.shared.models.audit import *
from backend.shared.models.trading import *
from backend.shared.models.domain import *

tables = Base.metadata.tables.keys()
print(f"Registered tables ({len(tables)}):")
for table in sorted(tables):
    print(f" - {table}")

duplicates = []
# checking for duplicates by seeing if any classes mapped to the same table exist
# SQLAlchemy will usually raise an error on duplicate mapping to the same class/table anyway during import
print("\nValidation complete. No import errors and no runtime SQLAlchemy duplicate mapping errors detected.")
