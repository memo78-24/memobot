import jwt
import datetime
from bcrypt import hashpw, gensalt, checkpw
from fastapi import Depends, HTTPException, status, Header
from fastapi.security import OAuth2PasswordBearer
from cryptography.fernet import Fernet
from sqlalchemy.orm import Session
from backend.app.config import ENCRYPTION_KEY, JWT_SECRET
from backend.app.database import get_db
from backend.shared.models.user import User
from backend.app.observability import log_structured

# Fernet Vault Init
fernet = Fernet(ENCRYPTION_KEY.encode())

from typing import Union

def encrypt_secret(plain_text: str) -> bytes:
    """Encrypt a secret string for storing in LargeBinary database columns."""
    if not plain_text:
        return b""
    if isinstance(plain_text, bytes):
        plain_text = plain_text.decode('utf-8')
    return fernet.encrypt(plain_text.encode())

def decrypt_secret(cipher_text: Union[str, bytes]) -> str:
    """Decrypt a database secret back to plain text."""
    if not cipher_text:
        return ""
    if isinstance(cipher_text, str):
        cipher_text = cipher_text.encode('utf-8')
    return fernet.decrypt(cipher_text).decode()

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="api/auth/login", auto_error=False)

def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)) -> User:
    """Validate JWT token and return active user model. CRITICAL: Check is_active flag."""
    if not token:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Not authenticated",
            headers={"WWW-Authenticate": "Bearer"},
        )
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=["HS256"])
        username: str = payload.get("sub")
        if username is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Could not validate credentials",
                headers={"WWW-Authenticate": "Bearer"},
            )
    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token has expired",
            headers={"WWW-Authenticate": "Bearer"},
        )
    except jwt.PyJWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    user = db.query(User).filter(User.username == username).first()
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User is inactive",
            headers={"WWW-Authenticate": "Bearer"},
        )
        
    return user

class RoleChecker:
    def __init__(self, allowed_roles: list):
        self.allowed_roles = allowed_roles

    def __call__(self, current_user: User = Depends(get_current_user)):
        if current_user.role not in self.allowed_roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied. Permission denied."
            )
        return current_user

def create_access_token(data: dict, expires_delta: datetime.timedelta = None):
    """Generate JWT session token."""
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.datetime.utcnow() + expires_delta
    else:
        expire = datetime.datetime.utcnow() + datetime.timedelta(hours=8)
    to_encode.update({"exp": expire, "type": "access"})
    encoded_jwt = jwt.encode(to_encode, JWT_SECRET, algorithm="HS256")
    return encoded_jwt

def create_refresh_token(data: dict, expires_delta: datetime.timedelta = None):
    """Generate JWT refresh token."""
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.datetime.utcnow() + expires_delta
    else:
        expire = datetime.datetime.utcnow() + datetime.timedelta(days=7)
    to_encode.update({"exp": expire, "type": "refresh"})
    encoded_jwt = jwt.encode(to_encode, JWT_SECRET, algorithm="HS256")
    return encoded_jwt

def hash_password_secure(password: str) -> str:
    """
    SECURE PASSWORD HASHING WITH BCRYPT + SALT
    Uses bcrypt with 12 rounds for strong security
    """
    if not isinstance(password, str):
        password = str(password)
    salt = gensalt(rounds=12)
    hashed = hashpw(password.encode('utf-8'), salt)
    return hashed.decode('utf-8')

def verify_password(plain_password: str, hashed_password: str) -> bool:
    """
    SECURE PASSWORD VERIFICATION USING BCRYPT
    Replaces SHA-256 which is vulnerable to rainbow tables
    CRITICAL: Distinguish between invalid hash format (potential attack) and wrong password
    IMPORTANT: Always perform full bcrypt check even for non-string inputs to prevent timing attacks
    """
    if not isinstance(plain_password, str):
        log_structured("WARN", "verify_password called with non-string plain_password")
        plain_password = ""
    if not isinstance(hashed_password, str):
        log_structured("WARN", "verify_password called with non-string hashed_password")
        return False
    
    try:
        return checkpw(plain_password.encode('utf-8'), hashed_password.encode('utf-8'))
    except ValueError as ve:
        # Invalid hash format — likely database corruption or attack attempt
        # Return False instead of raising to prevent breaking login flow
        log_structured("ERROR", f"Invalid password hash format detected: {str(ve)[:100]}")
        return False
    except Exception as e:
        log_structured("ERROR", f"Unexpected password verification error: {str(e)[:100]}")
        return False

def get_password_hash(password: str) -> str:
    """Wrapper for backward compatibility"""
    return hash_password_secure(password)
