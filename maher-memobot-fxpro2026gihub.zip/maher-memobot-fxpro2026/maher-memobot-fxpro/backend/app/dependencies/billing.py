from fastapi import Depends, HTTPException, status
from sqlalchemy.orm import Session
from backend.app.database import get_db
from backend.app.security import get_current_user
from backend.shared.models.user import User
from backend.shared.models.billing import UserSubscription

def get_current_subscription(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    sub = db.query(UserSubscription).filter_by(user_id=current_user.id).first()
    if not sub or sub.status not in ['ACTIVE', 'PAST_DUE']:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="No active subscription found. Please contact support."
        )
    return sub

def require_api_access(sub: UserSubscription = Depends(get_current_subscription)):
    if not sub.plan.api_access:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"Your current plan ({sub.plan.name}) does not include API access. Please upgrade."
        )
    return sub

def require_live_trading(sub: UserSubscription = Depends(get_current_subscription)):
    if not sub.plan.live_trading_enabled:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"Your current plan ({sub.plan.name}) does not include live trading. Please upgrade."
        )
    return sub

def get_max_leverage(sub: UserSubscription = Depends(get_current_subscription)):
    return sub.plan.max_leverage

def get_max_live_positions(sub: UserSubscription = Depends(get_current_subscription)):
    return sub.plan.max_live_positions

def get_max_symbols(sub: UserSubscription = Depends(get_current_subscription)):
    return sub.plan.max_symbols
