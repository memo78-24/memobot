import time
import psutil
import logging
import json
from fastapi import Request
from sqlalchemy import text
from backend.app.database import SessionLocal

# Setup structured logger
logger = logging.getLogger("memobot_fxpro")
logger.setLevel(logging.INFO)
ch = logging.StreamHandler()
ch.setFormatter(logging.Formatter('%(message)s'))
logger.addHandler(ch)

def log_structured(level: str, message: str, correlation_id: str = None, extra: dict = None):
    """Prints a structured JSON log message for observability ingestion."""
    log_data = {
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "level": level,
        "message": message,
        "correlation_id": correlation_id,
        **(extra or {})
    }
    logger.info(json.dumps(log_data))

def get_system_metrics():
    """Gathers real-time machine hardware and app performance telemetry."""
    # FIX: use text() wrapper required by SQLAlchemy 2.x; removed walrus operator
    t0 = time.perf_counter()
    db = SessionLocal()
    try:
        db.execute(text("SELECT 1"))
        db_latency = (time.perf_counter() - t0) * 1000  # ms
    except Exception:
        db_latency = -1
    finally:
        db.close()

    return {
        "cpu_usage_pct": psutil.cpu_percent(),
        "ram_usage_pct": psutil.virtual_memory().percent,
        "db_latency_ms": round(db_latency, 2),
        "queue_depth": 0,
        "active_threads": psutil.Process().num_threads()
    }

class CorrelationIdMiddleware:
    """Injects a unique ID to correlate API logs across backend microservices."""
    async def __call__(self, request: Request, call_next):
        correlation_id = request.headers.get("X-Correlation-ID")
        if not correlation_id:
            import uuid
            correlation_id = str(uuid.uuid4())

        request.state.correlation_id = correlation_id
        t0 = time.time()

        log_structured("INFO", f"Request {request.method} {request.url.path}", correlation_id)

        response = await call_next(request)

        latency = (time.time() - t0) * 1000
        response.headers["X-Correlation-ID"] = correlation_id
        response.headers["X-Response-Time-MS"] = f"{latency:.2f}"

        log_structured("INFO", f"Response {response.status_code} (took {latency:.2f}ms)", correlation_id)
        return response


async def send_bilingual_notification(db, user_id: int, text_en: str, text_ar: str):
    """Sends a message in both English and Arabic to Telegram and WhatsApp if configured."""
    import httpx
    from backend.shared.models.vault import SecretsVault
    from backend.app.security import decrypt_secret

    combined_msg = f"{text_en}\n\n{text_ar}"

    tg_vault = db.query(SecretsVault).filter(
        SecretsVault.user_id == user_id,
        SecretsVault.exchange_name == "Telegram"
    ).first()
    if tg_vault:
        try:
            bot_token = decrypt_secret(tg_vault.api_key_encrypted)
            chat_id = decrypt_secret(tg_vault.api_secret_encrypted)
            if bot_token and chat_id and bot_token.strip() and chat_id.strip():
                import os
                logo_path = "frontend/src/logo.png"
                if os.path.exists(logo_path):
                    url = f"https://api.telegram.org/bot{bot_token}/sendPhoto"
                    with open(logo_path, "rb") as f:
                        async with httpx.AsyncClient() as client:
                            await client.post(
                                url,
                                data={"chat_id": chat_id, "caption": combined_msg},
                                files={"photo": f},
                                timeout=10.0
                            )
                else:
                    url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
                    async with httpx.AsyncClient() as client:
                        await client.post(url, json={"chat_id": chat_id, "text": combined_msg}, timeout=5.0)
        except Exception as e:
            log_structured("ERROR", f"Failed to send Telegram notification: {e}")

    wa_vault = db.query(SecretsVault).filter(
        SecretsVault.user_id == user_id,
        SecretsVault.exchange_name == "WhatsApp"
    ).first()
    if wa_vault:
        try:
            access_token = decrypt_secret(wa_vault.api_key_encrypted)
            phone_id = decrypt_secret(wa_vault.api_secret_encrypted)
            if access_token and phone_id and access_token.strip() and phone_id.strip():
                url = f"https://graph.facebook.com/v17.0/{phone_id}/messages"
                headers = {
                    "Authorization": f"Bearer {access_token}",
                    "Content-Type": "application/json"
                }
                json_data = {
                    "messaging_product": "whatsapp",
                    "to": phone_id,
                    "type": "text",
                    "text": {"body": combined_msg}
                }
                async with httpx.AsyncClient() as client:
                    await client.post(url, headers=headers, json=json_data, timeout=5.0)
        except Exception as e:
            log_structured("ERROR", f"Failed to send WhatsApp notification: {e}")
