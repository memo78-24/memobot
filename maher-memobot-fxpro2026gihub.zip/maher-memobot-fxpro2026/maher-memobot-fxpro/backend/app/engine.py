import asyncio
import os
import time
import uuid
from typing import Dict, Any, Optional, Callable
from sqlalchemy.orm import Session

from backend.app.risk import RiskManager
from backend.app.observability import log_structured
from backend.shared.models.trading import TradeRecord, PaperBalance
from backend.shared.models.vault import SecretsVault
from backend.app.database import log_activity
from backend.app.pipeline import pipeline_tracker
from backend.app.services.notifications.notification_manager import NotificationManager


class ExecutionEngine:
    """MEMOBOT FX-PRO multi-engine execution core (Rigel / Sirius / Canopus)."""

    # Engine-specific mission configurations
    ENGINE_MISSIONS = {
        "Rigel": {
            "nickname": "LAMAR",
            "mission": "Scalping/High-frequency trading",
            "timeframe": "1m-5m",
            "risk_profile": "aggressive",
            "max_positions": 5,
            "position_size_pct": 0.02
        },
        "Sirius": {
            "nickname": "HALA",
            "mission": "Macro analysis/Institutional logic",
            "timeframe": "15m-1h",
            "risk_profile": "moderate",
            "max_positions": 3,
            "position_size_pct": 0.05
        },
        "Canopus": {
            "nickname": "MALAK",
            "mission": "Risk/Portfolio balancing",
            "timeframe": "4h-1d",
            "risk_profile": "conservative",
            "max_positions": 2,
            "position_size_pct": 0.10
        },
        "Gemini": {
            "nickname": "TWIN",
            "mission": "Arbitrage/Market making",
            "timeframe": "tick-level",
            "risk_profile": "low",
            "max_positions": 10,
            "position_size_pct": 0.01
        },
        "Halal": {
            "nickname": "SHARIAH",
            "mission": "Shariah-compliant trading",
            "timeframe": "1h-4h",
            "risk_profile": "conservative",
            "max_positions": 3,
            "position_size_pct": 0.05
        }
    }

    def __init__(self):
        self.status = "Stopped"          # Running | Paused | Stopped
        self.mode = "Paper"               # Fail-safe default; Live requires explicit confirmation
        self.live_mode_confirmed = False
        self.broadcast: Optional[Callable] = None
        self.binance_client = None
        self.risk_manager = RiskManager()
        self.compliance_mode = "Islamic" # "Islamic" | "Commercial"

        # Multi-engine statuses and session stats fully tracked in backend
        self.engine_states = {
            name: {
                "status": "Stopped",
                "start_time": None,
                "session_approved": 0,
                "session_rejected": 0,
                "session_running": 0
            } for name in ["Rigel", "Sirius", "Canopus", "Gemini", "Halal"]
        }

        # Balance cache to reduce live API hammering
        self._balance_cache = None
        self._balance_cache_time = 0.0

        # Internal event listeners
        self._listeners: Dict[str, list] = {}

    def increment_session_approved(self, engine_name: str) -> None:
        if engine_name in self.engine_states:
            self.engine_states[engine_name]["session_approved"] += 1
            self.engine_states[engine_name]["session_running"] += 1

    def increment_session_rejected(self, engine_name: str) -> None:
        if engine_name in self.engine_states:
            self.engine_states[engine_name]["session_rejected"] += 1

    def get_engine_state(self, engine_name: str) -> Dict[str, Any]:
        state = self.engine_states.get(engine_name, {
            "status": "Stopped",
            "start_time": None,
            "session_approved": 0,
            "session_rejected": 0,
            "session_running": 0
        })
        uptime = 0
        if state["status"] == "Running" and state["start_time"] is not None:
            uptime = int(time.time() - state["start_time"])
        return {
            "status": state["status"],
            "uptime_seconds": uptime,
            "session_approved": state["session_approved"],
            "session_rejected": state["session_rejected"],
            "session_running": state["session_running"],
            "approved": state["session_approved"],
            "rejected": state["session_rejected"],
            "running": state["session_running"]
        }

    def clear_balance_cache(self) -> None:
        self._balance_cache = None
        self._balance_cache_time = 0.0

    async def close(self) -> None:
        """Close external connections."""
        if self.binance_client:
            await self.binance_client.close()

    # ── Mode / Status control ──────────────────────────────────
    def set_compliance_mode(self, compliance_mode: str) -> None:
        if compliance_mode not in ["Islamic", "Commercial"]:
            raise ValueError(f"Invalid compliance mode '{compliance_mode}'. Must be Islamic or Commercial.")
        self.compliance_mode = compliance_mode
        self.emit_event("compliance_mode_change", {"compliance_mode": compliance_mode})
        log_structured("INFO", f"Engine compliance mode set to: {compliance_mode}")

    def set_mode(self, mode: str) -> None:
        if mode not in ["Paper", "Live"]:
            raise ValueError(f"Invalid mode '{mode}'. Must be Paper or Live.")
        # Any mode transition invalidates a prior live confirmation.
        self.live_mode_confirmed = False
        self.mode = mode
        self.emit_event("mode_change", {"mode": mode})
        log_structured("INFO", f"Engine mode set to: {mode}")

    def confirm_live_mode(self) -> bool:
        if self.mode != "Live":
            return False
        self.live_mode_confirmed = True
        log_structured("WARN", "Live mode safety gate confirmed by user.")
        return True

    async def trigger_kill_switch(self, db: Session, user_id: int = None) -> bool:
        self.status = "Stopped"
        self.live_mode_confirmed = False
        log_activity(db, "Emergency Kill Switch Activated", "WARN", user_id=user_id,
                     details="All trading halted. Live mode locked.")
        log_structured("WARN", "KILL SWITCH ACTIVATED — engine stopped, live mode locked.")
        self.emit_event("kill_switch", {"status": "Stopped"})
        return True

    # ── Live client configuration ──────────────────────────────
    async def configure_live_client(self, db: Session, user_id: int = None) -> None:
        try:
            from backend.app.binance_client import BinanceClientWrapper
            from backend.app.security import decrypt_secret
            from sqlalchemy import func

            vault = None
            if user_id:
                vault = db.query(SecretsVault).filter(
                    SecretsVault.user_id == user_id,
                    func.lower(SecretsVault.exchange_name) == "binance"
                ).first()

            if not vault:
                vault = db.query(SecretsVault).filter(
                    func.lower(SecretsVault.exchange_name) == "binance"
                ).first()

            if not vault:
                log_structured("WARN", "No Binance API key found in vault.")
                return

            api_key = decrypt_secret(vault.api_key_encrypted)
            api_secret = decrypt_secret(vault.api_secret_encrypted)
            if not api_key or not api_secret:
                return

            client = BinanceClientWrapper(
                api_key_encrypted=vault.api_key_encrypted,
                api_secret_encrypted=vault.api_secret_encrypted,
                testnet=False
            )
            self.binance_client = client
            log_structured("INFO", f"Live Binance client configured for vault user {vault.user_id}.")
        except Exception as e:
            log_structured("ERROR", f"Failed to configure live Binance client: {e}")

    def _pipeline_payload(self, engine_name: str, order_id: str, symbol: str = None, side: str = None, amount: float = None) -> Dict[str, Any]:
        pipeline = pipeline_tracker.get_status(engine_name, order_id)
        if not pipeline:
            return {}
        return {
            "engine": engine_name,
            "order_id": order_id,
            "order_id_short": f"#{order_id.split('-')[-1][:4].upper()}",
            "symbol": symbol or pipeline.get("symbol"),
            "side": side or pipeline.get("side"),
            "amount": amount if amount is not None else pipeline.get("amount"),
            "stages": pipeline_tracker.to_stages_array(pipeline),
            "status": pipeline.get("status", "IN_PROGRESS"),
            "error_reason": pipeline.get("error_reason"),
        }

    async def _emit_pipeline(self, engine_name: str, order_id: str) -> None:
        pipeline = pipeline_tracker.get_status(engine_name, order_id)
        if not pipeline or not self.broadcast:
            return
        order_id_short = f"#{order_id.split('-')[-1][:4].upper()}"
        
        # Get engine mission info
        mission = self.ENGINE_MISSIONS.get(engine_name, {})
        
        await self.broadcast({
            "type": "pipeline_event",
            "engine": engine_name,
            "engine_nickname": mission.get("nickname", ""),
            "engine_mission": mission.get("mission", ""),
            "timeframe": mission.get("timeframe", ""),
            "risk_profile": mission.get("risk_profile", ""),
            "order_id": order_id,
            "order_id_short": order_id_short,
            "symbol": pipeline.get("symbol"),
            "side": pipeline.get("side"),
            "amount": pipeline.get("amount"),
            "current_stage": pipeline.get("current_stage"),
            "stages": pipeline_tracker.to_stages_array(pipeline),
            "status": pipeline.get("status", "IN_PROGRESS"),
            "error_reason": pipeline.get("error_reason"),
        })

    async def _advance_pipeline(self, engine_name: str, order_id: str, stage: str) -> None:
        pipeline_tracker.advance_stage(engine_name, order_id, stage)
        await self._emit_pipeline(engine_name, order_id)

    async def _fail_pipeline(self, engine_name: str, order_id: str, reason: str, stage: str) -> None:
        pipeline_tracker.fail_pipeline(engine_name, order_id, reason, failed_stage=stage)
        await self._emit_pipeline(engine_name, order_id)

    def _resolve_asset_holding(self, db: Session, user_id: int, asset: str) -> float:
        if self.mode == "Paper":
            bal = db.query(PaperBalance).filter(
                PaperBalance.user_id == user_id, PaperBalance.asset == asset
            ).first()
            return bal.free if bal else 0.0
        if self.binance_client and self.binance_client.is_configured:
            return 0.0  # live holdings validated inside execute_order
        return 0.0

    def _estimate_slippage_pct(self, asset: str) -> float:
        from backend.app.swarm_instance import swarm
        ticker = getattr(swarm, "ticker_details", {}).get(asset, {})
        bid = ticker.get("bid") or 0.0
        ask = ticker.get("ask") or 0.0
        if bid > 0 and ask > 0:
            return (ask - bid) / ((ask + bid) / 2)
        return 0.001

    # ── Core trade execution ───────────────────────────────────
    async def execute_trade(
        self,
        db: Session,
        user_id: int,
        symbol: str,
        side: str,
        order_type: str,
        amount: float,
        price: Optional[float],
        engine_name: str = "Rigel"
    ) -> Dict[str, Any]:
        order_id = f"MBOT-{uuid.uuid4().hex[:10].upper()}"
        pipeline_tracker.start_pipeline(engine_name, order_id, symbol, side, amount)
        await self._emit_pipeline(engine_name, order_id)

        # Gate 1: Engine must be running (Check sub-engine state or global state)
        await self._advance_pipeline(engine_name, order_id, "2.FI")
        engine_status = self.engine_states.get(engine_name, {}).get("status", "Stopped")
        if engine_status != "Running" and self.status != "Running":
            reason = f"Engine {engine_name} is {engine_status}. Start the engine before trading."
            await self._fail_pipeline(engine_name, order_id, reason, "2.FI")
            self.increment_session_rejected(engine_name)
            payload = {"success": False, "error": reason, "order_id": order_id}
            payload["pipeline"] = self._pipeline_payload(engine_name, order_id, symbol, side, amount)
            return payload

        # Gate 2: Live mode safety confirmation
        if self.mode == "Live" and not self.live_mode_confirmed:
            reason = "Live mode safety gate not confirmed. Confirm live trading first."
            await self._fail_pipeline(engine_name, order_id, reason, "2.FI")
            self.increment_session_rejected(engine_name)
            payload = {"success": False, "error": reason, "order_id": order_id}
            payload["pipeline"] = self._pipeline_payload(engine_name, order_id, symbol, side, amount)
            return payload
            
        # Gate 2.5: Subscription Enforcement (The Final Authority)
        from backend.shared.models.billing import UserSubscription
        sub = db.query(UserSubscription).filter_by(user_id=user_id).first()
        
        # Free for Life accounts bypass subscription checks
        if sub and sub.is_free_for_life:
            log_structured("INFO", f"Free for Life account detected for user {user_id}. Bypassing subscription enforcement.")
        elif not sub or sub.status not in ['ACTIVE', 'PAST_DUE']:
            reason = "No active subscription found. Trading is disabled."
            await self._fail_pipeline(engine_name, order_id, reason, "2.FI")
            payload = {"success": False, "error": reason, "order_id": order_id}
            payload["pipeline"] = self._pipeline_payload(engine_name, order_id, symbol, side, amount)
            return payload
        elif self.mode == "Live" and not sub.plan.live_trading_enabled:
            reason = f"Your {sub.plan.name} plan does not support Live Trading. Please upgrade."
            await self._fail_pipeline(engine_name, order_id, reason, "2.FI")
            payload = {"success": False, "error": reason, "order_id": order_id}
            payload["pipeline"] = self._pipeline_payload(engine_name, order_id, symbol, side, amount)
            return payload

        from backend.app.swarm_instance import swarm
        asset = symbol.replace("/USDT", "").replace("USDT", "")
        current_price = price or swarm.prices.get(asset, 0.0)
        portfolio_usd = float(os.getenv("PAPER_DEFAULT_USDT", "100000"))

        if self.mode == "Paper":
            pb = db.query(PaperBalance).filter(
                PaperBalance.user_id == user_id, PaperBalance.asset == "USDT"
            ).first()
            if pb:
                portfolio_usd = pb.free
        else:
            # LIVE mode: use the real cached account net worth, not the paper default.
            # This was a real bug -- exposure checks were previously validated against
            # a fake $100,000 figure even for live trades.
            try:
                from backend.app.services.balance_cache import get_cached_balances
                cached = await get_cached_balances()
                if cached.get("success") and cached.get("net_worth", 0) > 0:
                    portfolio_usd = cached["net_worth"]
            except Exception as e:
                log_structured("WARN", f"Could not load live balance for risk check, falling back to default: {e}")

        asset_holding = self._resolve_asset_holding(db, user_id, asset)

        # ── SAFETY GUARDIAN GATE ────────────────────────────────────────────────
        # Account-level capital protection: daily/session floor, circuit breaker,
        # and consecutive-loss position shrinking. Sits above per-trade risk checks
        # and is not something a strategy or a single trade can override.
        from backend.app.safety_guardian import SafetyGuardian
        safety_result = SafetyGuardian.check_before_trade(db, user_id, engine_name, portfolio_usd)
        if not safety_result.get("allowed"):
            reason = safety_result.get("reason", "Blocked by account safety guardian.")
            await self._fail_pipeline(engine_name, order_id, reason, "3.SHA")
            self.increment_session_rejected(engine_name)
            record = TradeRecord(
                order_id=order_id, user_id=user_id, symbol=symbol, side=side.upper(),
                type=order_type.upper(), amount=amount, price=current_price,
                status="REJECTED", execution_mode=self.mode, engine_name=engine_name,
                error_message=reason
            )
            db.add(record)
            db.commit()
            payload = {"success": False, "error": reason, "order_id": order_id}
            payload["pipeline"] = self._pipeline_payload(engine_name, order_id, symbol, side, amount)
            return payload

        # Apply consecutive-loss position shrink (never grows size after a loss)
        size_multiplier = safety_result.get("size_multiplier", 1.0)
        if size_multiplier < 1.0:
            amount = round(amount * size_multiplier, 8)
        # ── END SAFETY GUARDIAN GATE ─────────────────────────────────────────────

        await self._advance_pipeline(engine_name, order_id, "3.SHA")

        # ── SHARIAH GATE ────────────────────────────────────────────────────────
        # Only enforce asset/product screening when compliance mode is Islamic.
        # Commercial mode bypasses this gate (user explicitly chose non-Islamic).
        if self.compliance_mode == "Islamic":
            from backend.app.shariyah import shariyah_engine
            sha_valid, sha_reason, sha_details = shariyah_engine.validate_full_trade({
                "symbol":     symbol,
                "side":       side,
                "type":       order_type,
                "amount":     amount,
                "price":      current_price,
                "leverage":   1.0,   # Memobot only allows spot; leverage is always 1
            })
            if not sha_valid:
                await self._fail_pipeline(engine_name, order_id, sha_reason, "3.SHA")
                self.increment_session_rejected(engine_name)
                record = TradeRecord(
                    order_id=order_id, user_id=user_id, symbol=symbol, side=side.upper(),
                    type=order_type.upper(), amount=amount, price=current_price,
                    status="REJECTED", execution_mode=self.mode, engine_name=engine_name,
                    error_message=sha_reason
                )
                db.add(record)
                db.commit()
                log_structured("WARN", f"[SHARIAH] Trade blocked: {sha_reason}")
                NotificationManager.send_trade_alert(
                    db, user_id, symbol, side, amount, current_price, engine_name, "REJECTED"
                )
                payload = {"success": False, "error": sha_reason, "order_id": order_id,
                           "shariah_details": sha_details}
                payload["pipeline"] = self._pipeline_payload(engine_name, order_id, symbol, side, amount)
                return payload
        # ── END SHARIAH GATE ─────────────────────────────────────────────────────

        await self._advance_pipeline(engine_name, order_id, "4.RSK")
        risk_result = self.risk_manager.validate_trade(
            symbol=symbol, side=side, order_type=order_type,
            amount=amount, price=current_price, current_portfolio_usd=portfolio_usd,
            asset_holding=asset_holding
        )

        if not risk_result.get("approved"):
            await self._fail_pipeline(engine_name, order_id, risk_result.get("reason"), "4.RSK")
            self.increment_session_rejected(engine_name)
            record = TradeRecord(
                order_id=order_id, user_id=user_id, symbol=symbol, side=side.upper(),
                type=order_type.upper(), amount=amount, price=current_price,
                status="REJECTED", execution_mode=self.mode, engine_name=engine_name,
                error_message=risk_result.get("reason")
            )
            db.add(record)
            db.commit()
            payload = {"success": False, "error": risk_result.get("reason"), "order_id": order_id}
            payload["pipeline"] = self._pipeline_payload(engine_name, order_id, symbol, side, amount)
            NotificationManager.send_trade_alert(db, user_id, symbol, side, amount, current_price, engine_name, "REJECTED")
            return payload

        await self._advance_pipeline(engine_name, order_id, "5.SIZE")

        # Gate 4: Evaluation score gate
        score = 50.0
        eval_error = None
        try:
            from backend.app.evaluation import compute_market_score
            eval_result = await compute_market_score(
                symbol=symbol, side=side, engine=engine_name,
                user_id=user_id, db=db
            )
            score = eval_result.get("score", 0.0)
        except Exception as e:
            eval_error = str(e)

        if score < 40.0:
            reason = f"Market evaluation score too low ({score:.1f}% < 40% threshold). Trade blocked."
            await self._fail_pipeline(engine_name, order_id, reason, "5.SIZE")
            self.increment_session_rejected(engine_name)
            record = TradeRecord(
                order_id=order_id, user_id=user_id, symbol=symbol, side=side.upper(),
                type=order_type.upper(), amount=amount, price=current_price,
                status="REJECTED", execution_mode=self.mode, engine_name=engine_name,
                error_message=reason, evaluation_score=score
            )
            db.add(record)
            db.commit()
            payload = {"success": False, "error": reason, "order_id": order_id, "score": score}
            payload["pipeline"] = self._pipeline_payload(engine_name, order_id, symbol, side, amount)
            NotificationManager.send_trade_alert(db, user_id, symbol, side, amount, current_price, engine_name, "REJECTED")
            return payload

        await self._advance_pipeline(engine_name, order_id, "6.PLC")
        t0 = time.perf_counter()

        if self.mode == "Paper":
            slippage = self._estimate_slippage_pct(asset)
            result = await self._execute_paper(
                db, user_id, symbol, side, order_type, amount, current_price,
                order_id, engine_name, score, slippage
            )
        else:
            result = await self._execute_live(
                db, user_id, symbol, side, order_type, amount, current_price,
                order_id, engine_name, score
            )

        if not result.get("success"):
            await self._fail_pipeline(engine_name, order_id, result.get("error", "Execution failed"), "6.PLC")
            self.increment_session_rejected(engine_name)
            NotificationManager.send_trade_alert(db, user_id, symbol, side, amount, current_price, engine_name, "FAILED")
            return result

        await self._advance_pipeline(engine_name, order_id, "7.CNF")
        await self._advance_pipeline(engine_name, order_id, "8.REC")
        await self._advance_pipeline(engine_name, order_id, "9.MON")
        self.increment_session_approved(engine_name)

        latency_ms = (time.perf_counter() - t0) * 1000
        result["latency_ms"] = round(latency_ms, 2)
        result["evaluation_score"] = score
        result["order_id"] = order_id

        if result.get("db_record_id"):
            rec = db.query(TradeRecord).filter(TradeRecord.id == result["db_record_id"]).first()
            if rec:
                rec.latency_ms = latency_ms
                db.commit()

        if self.broadcast:
            await self.broadcast({
                "type": "trade_executed",
                "order_id": order_id,
                "symbol": symbol,
                "side": side,
                "amount": amount,
                "price": current_price,
                "mode": self.mode,
                "engine": engine_name,
                "score": score
            })

        pipeline = pipeline_tracker.get_status(engine_name, order_id)
        if pipeline:
            result["pipeline"] = self._pipeline_payload(engine_name, order_id, symbol, side, amount)

        NotificationManager.send_trade_alert(db, user_id, symbol, side, amount, current_price, engine_name, "FILLED")
        return result

    async def _execute_paper(self, db, user_id, symbol, side, order_type,
                             amount, price, order_id, engine_name, score, slippage) -> Dict[str, Any]:
        fill_price = price * (1 + slippage) if side.upper() == "BUY" else price * (1 - slippage)
        asset = symbol.replace("/USDT", "").replace("USDT", "")

        try:
            if side.upper() == "BUY":
                cost = amount * fill_price
                usdt_bal = db.query(PaperBalance).with_for_update().filter(
                    PaperBalance.user_id == user_id, PaperBalance.asset == "USDT"
                ).first()
                if not usdt_bal or usdt_bal.free < cost:
                    return {"success": False, "error": f"Insufficient USDT balance. Need {cost:.2f}, have {usdt_bal.free if usdt_bal else 0:.2f}"}
                usdt_bal.free -= cost

                asset_bal = db.query(PaperBalance).with_for_update().filter(
                    PaperBalance.user_id == user_id, PaperBalance.asset == asset
                ).first()
                if asset_bal:
                    asset_bal.free += amount
                else:
                    db.add(PaperBalance(user_id=user_id, asset=asset, free=amount, locked=0.0))

            else:  # SELL
                asset_bal = db.query(PaperBalance).with_for_update().filter(
                    PaperBalance.user_id == user_id, PaperBalance.asset == asset
                ).first()
                if not asset_bal or asset_bal.free < amount:
                    return {"success": False, "error": f"Insufficient {asset} balance."}
                asset_bal.free -= amount

                proceeds = amount * fill_price
                usdt_bal = db.query(PaperBalance).with_for_update().filter(
                    PaperBalance.user_id == user_id, PaperBalance.asset == "USDT"
                ).first()
                if usdt_bal:
                    usdt_bal.free += proceeds
                else:
                    db.add(PaperBalance(user_id=user_id, asset="USDT", free=proceeds, locked=0.0))

            record = TradeRecord(
                order_id=order_id, user_id=user_id, symbol=symbol, side=side.upper(),
                type=order_type.upper(), amount=amount, price=price,
                fill_price=fill_price, fill_amount=amount,
                status="FILLED", execution_mode="Paper", engine_name=engine_name,
                slippage_pct=slippage * 100, evaluation_score=score
            )
            db.add(record)
            db.commit()
            db.refresh(record)

            # Calculate realized profit for SELL orders (closing positions)
            if side.upper() == "SELL":
                realized_profit = (fill_price - price) * amount
                record.realized_profit = realized_profit
                db.commit()

                # Apply Success Decision Fee if profitable
                if realized_profit > 0:
                    from backend.app.services.success_fee_service import SuccessFeeService
                    from backend.shared.models.billing import UserSubscription
                    sub = db.query(UserSubscription).filter_by(user_id=user_id).first()
                    if sub and sub.plan:
                        try:
                            fee = SuccessFeeService.record(
                                db=db,
                                user_id=user_id,
                                trade_id=record.id,
                                engine_name=engine_name,
                                plan_name=sub.plan.name,
                                realized_profit=realized_profit
                            )
                            log_structured("INFO", f"Success Decision Fee applied: ${fee:.2f} on ${realized_profit:.2f} profit")
                        except Exception as fee_err:
                            log_structured("ERROR", f"Failed to apply success fee: {fee_err}")

            return {"success": True, "order_id": order_id, "status": "FILLED",
                    "symbol": symbol, "side": side.upper(),
                    "fill_price": fill_price, "fill_amount": amount,
                    "slippage_pct": slippage * 100, "db_record_id": record.id}

        except Exception as e:
            db.rollback()
            log_structured("ERROR", f"Paper execution error: {e}")
            return {"success": False, "error": str(e)}

    async def _execute_live(self, db, user_id, symbol, side, order_type,
                            amount, price, order_id, engine_name, score) -> Dict[str, Any]:
        if not self.binance_client or not self.binance_client.is_configured:
            return {"success": False, "error": "Live Binance client not configured. Add API keys in Settings > Vault."}
        try:
            result = await self.binance_client.execute_order(
                symbol=symbol, side=side, order_type=order_type, amount=amount, price=price
            )

            if not result.get("success"):
                raise RuntimeError(result.get("error", "Binance order failed"))

            fill_price = result.get("fill_price", price)
            fill_amount = result.get("fill_amount", amount)
            slippage = abs(fill_price - price) / price * 100 if price else 0.0

            record = TradeRecord(
                order_id=order_id, user_id=user_id, symbol=symbol, side=side.upper(),
                type=order_type.upper(), amount=amount, price=price,
                fill_price=fill_price, fill_amount=fill_amount,
                status="FILLED", execution_mode="Live", engine_name=engine_name,
                slippage_pct=slippage, evaluation_score=score
            )
            db.add(record)
            db.commit()
            db.refresh(record)

            # Calculate realized profit for SELL orders (closing positions)
            if side.upper() == "SELL":
                realized_profit = (fill_price - price) * fill_amount
                record.realized_profit = realized_profit
                db.commit()

                # Apply Success Decision Fee if profitable
                if realized_profit > 0:
                    from backend.app.services.success_fee_service import SuccessFeeService
                    from backend.shared.models.billing import UserSubscription
                    sub = db.query(UserSubscription).filter_by(user_id=user_id).first()
                    if sub and sub.plan:
                        try:
                            fee = SuccessFeeService.record(
                                db=db,
                                user_id=user_id,
                                trade_id=record.id,
                                engine_name=engine_name,
                                plan_name=sub.plan.name,
                                realized_profit=realized_profit
                            )
                            log_structured("INFO", f"Success Decision Fee applied: ${fee:.2f} on ${realized_profit:.2f} profit")
                        except Exception as fee_err:
                            log_structured("ERROR", f"Failed to apply success fee: {fee_err}")

            return {"success": True, "order_id": order_id, "status": "FILLED",
                    "symbol": symbol, "side": side.upper(),
                    "fill_price": fill_price, "fill_amount": fill_amount,
                    "slippage_pct": slippage, "db_record_id": record.id}

        except Exception as e:
            log_structured("ERROR", f"Live execution error: {e}")
            record = TradeRecord(
                order_id=order_id, user_id=user_id, symbol=symbol, side=side.upper(),
                type=order_type.upper(), amount=amount, price=price,
                status="REJECTED", execution_mode="Live", engine_name=engine_name,
                error_message=str(e), evaluation_score=score
            )
            db.add(record)
            db.commit()
            return {"success": False, "error": str(e), "order_id": order_id}

    # ── Event system ───────────────────────────────────────────
    def emit_event(self, event: str, data: dict) -> None:
        for cb in self._listeners.get(event, []):
            try:
                cb(data)
            except Exception:
                pass

    def on(self, event: str, callback) -> None:
        self._listeners.setdefault(event, []).append(callback)
