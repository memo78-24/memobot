from collections import defaultdict
from datetime import datetime, timezone
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from backend.app.database import get_db
from backend.shared.models.user import User
from backend.shared.models.trading import TradeRecord
from backend.app.security import get_current_user
from backend.app.engine_instance import engine

router = APIRouter(prefix="/api/audit", tags=["Auditing Hub"])


@router.get("/charts/{engine_name}")
def get_audit_charts(engine_name: str, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    eng = engine_name.capitalize()
    trades = db.query(TradeRecord).filter(
        TradeRecord.engine_name == eng,
        TradeRecord.execution_mode == engine.mode,
        TradeRecord.status.in_(["FILLED", "CLOSED", "REJECTED"]),
    ).order_by(TradeRecord.timestamp.asc()).all()

    pnl_series = []
    cumulative = 0.0
    wins = losses = 0
    exec_speeds = []
    pair_counts = defaultdict(int)
    hold_buckets = defaultdict(int)

    for t in trades:
        if t.status in ("FILLED", "CLOSED") and t.side == "SELL" and t.fill_price and t.price and t.fill_amount:
            trade_pnl = (t.fill_price - t.price) * t.fill_amount
            cumulative += trade_pnl
            if trade_pnl >= 0:
                wins += 1
            else:
                losses += 1
        if t.timestamp:
            pnl_series.append({
                "ts": t.timestamp.isoformat(),
                "value": round(cumulative, 4),
            })
        if t.latency_ms is not None:
            exec_speeds.append(round(t.latency_ms, 2))
        if t.symbol:
            pair_counts[t.symbol] += 1
        if t.timestamp:
            ts = t.timestamp.replace(tzinfo=timezone.utc) if t.timestamp.tzinfo is None else t.timestamp
            age_h = max(0, (datetime.now(timezone.utc) - ts).total_seconds() / 3600)
            if age_h < 1:
                hold_buckets["<1h"] += 1
            elif age_h < 24:
                hold_buckets["1-24h"] += 1
            else:
                hold_buckets[">24h"] += 1

    approved = sum(1 for t in trades if t.status in ("FILLED", "CLOSED"))
    rejected = sum(1 for t in trades if t.status == "REJECTED")

    return {
        "pnl": pnl_series[-30:],
        "win_loss": {"wins": wins, "losses": losses},
        "exec_speed": exec_speeds[-30:],
        "risk_shield": {"approved": approved, "rejected": rejected},
        "pairs": [{"symbol": k, "count": v} for k, v in pair_counts.items()],
        "shariyah": {"compliant": approved, "blocked": rejected},
        "hold_time": [{"bucket": k, "count": v} for k, v in hold_buckets.items()],
    }
