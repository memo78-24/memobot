from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from backend.app.database import get_db, log_activity
from backend.shared.models.user import User
from backend.app.security import RoleChecker, get_current_user
from backend.app.engine_instance import engine
from backend.app.schemas.engine import EngineStatusUpdate, EngineModeUpdate
from backend.app.safety_guardian import SafetyGuardian
import asyncio

router = APIRouter(prefix="/api/engine", tags=["Engine Control"])

from pydantic import BaseModel, Field

class ComplianceModeUpdate(BaseModel):
    compliance_mode: str = Field(..., description="Compliance mode: Islamic or Commercial")

@router.get("/status")
def get_engine_status(current_user: User = Depends(get_current_user)):
    # Return per-engine status so frontend shows correct state for each card
    per_engine = {}
    for name, state in engine.engine_states.items():
        per_engine[name] = {
            "status": state["status"],
            "session_approved": state.get("session_approved", 0),
            "session_rejected": state.get("session_rejected", 0),
            "session_running": state.get("session_running", 0),
        }
    return {
        "status": engine.status,
        "mode": engine.mode,
        "live_mode_confirmed": engine.live_mode_confirmed,
        "compliance_mode": engine.compliance_mode,
        "engines": per_engine,
    }

@router.post("/compliance-mode")
def update_compliance_mode(
    payload: ComplianceModeUpdate,
    current_user: User = Depends(RoleChecker(["Admin", "Super_Admin", "Trader", "Risk_Officer"])),
    db: Session = Depends(get_db)
):
    new_mode = payload.compliance_mode
    try:
        engine.set_compliance_mode(new_mode)
        log_activity(db, f"Engine compliance mode set to: {new_mode}", "SUCCESS", user_id=current_user.id)
        return {"compliance_mode": engine.compliance_mode}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/status")
async def update_engine_status(
    payload: EngineStatusUpdate,
    current_user: User = Depends(RoleChecker(["Admin", "Super_Admin", "Trader", "Risk_Officer"])),
    db: Session = Depends(get_db)
):
    import time
    from backend.app.autonomous_loops import start_engine_loop, stop_engine_loop

    new_status = payload.status
    if new_status not in ["Running", "Paused", "Stopped"]:
        raise HTTPException(status_code=400, detail="Invalid engine status.")

    # Support both engine_id (ENG-001) and engine_name (Rigel) from frontend
    id_to_name = {"ENG-001": "Rigel", "ENG-002": "Sirius", "ENG-003": "Canopus"}
    raw_target = payload.engine_id or payload.engine_name
    target_engine = id_to_name.get(raw_target, raw_target) if raw_target else None

    if target_engine:
        if target_engine not in engine.engine_states:
            raise HTTPException(status_code=400, detail=f"Unknown engine: {target_engine}")

        if new_status == "Running" and SafetyGuardian.is_halt_pending_acknowledgment(db, current_user.id, target_engine):
            raise HTTPException(
                status_code=403,
                detail=f"{target_engine} has a safety halt awaiting your acknowledgment. "
                       f"Please review and acknowledge the notification before restarting."
            )

        state = engine.engine_states[target_engine]
        state["status"] = new_status

        if new_status == "Running":
            if state["start_time"] is None:
                state["start_time"] = time.time()
            # ── PHASE 2/3/4: Start autonomous loop ──────────────────────────
            asyncio.create_task(
                start_engine_loop(target_engine, current_user.id),
                name=f"start_loop_{target_engine}"
            )
            # ────────────────────────────────────────────────────────────────
        elif new_status == "Stopped":
            state["start_time"] = None
            state["session_approved"] = 0
            state["session_rejected"] = 0
            state["session_running"] = 0
            # ── PHASE 2/3/4: Stop autonomous loop ───────────────────────────
            asyncio.create_task(
                stop_engine_loop(target_engine),
                name=f"stop_loop_{target_engine}"
            )
            # ────────────────────────────────────────────────────────────────

        engine.emit_event("status_change", {"engine": target_engine, "status": new_status})
        log_activity(
            db,
            f"Engine {target_engine} status updated: {new_status}",
            "SUCCESS",
            user_id=current_user.id,
            details=f"User Role: {current_user.role}"
        )
        return {"status": new_status, "engine": target_engine}

    # Fallback: global status update (all engines)
    engine.status = new_status
    for name, state in engine.engine_states.items():
        state["status"] = new_status
        if new_status == "Running":
            if state["start_time"] is None:
                state["start_time"] = time.time()
            asyncio.create_task(
                start_engine_loop(name, current_user.id),
                name=f"start_loop_{name}"
            )
        elif new_status == "Stopped":
            state["start_time"] = None
            state["session_approved"] = 0
            state["session_rejected"] = 0
            state["session_running"] = 0
            asyncio.create_task(
                stop_engine_loop(name),
                name=f"stop_loop_{name}"
            )

    engine.emit_event("status_change", {"status": new_status})
    log_activity(
        db, f"Global Engine status updated: {new_status}",
        "SUCCESS", user_id=current_user.id,
        details=f"User Role: {current_user.role}"
    )
    return {"status": engine.status}

@router.post("/mode")
def update_engine_mode(
    payload: EngineModeUpdate,
    current_user: User = Depends(RoleChecker(["Admin", "Super_Admin", "Trader", "Risk_Officer"])),
    db: Session = Depends(get_db)
):
    new_mode = payload.mode
    try:
        engine.set_mode(new_mode)
        log_activity(db, f"Engine execution mode set: {new_mode}", "SUCCESS", user_id=current_user.id)
        return {"mode": engine.mode, "live_mode_confirmed": engine.live_mode_confirmed}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/confirm-live")
def confirm_live_mode(
    current_user: User = Depends(RoleChecker(["Admin", "Super_Admin", "Trader", "Risk_Officer"])),
    db: Session = Depends(get_db)
):
    unlocked = engine.confirm_live_mode()
    if not unlocked:
        raise HTTPException(status_code=400, detail="Engine must be set to LIVE mode before safety gate confirmation.")

    log_activity(db, "Safety Gate Confirmed: Real Trading Enabled", "WARN", user_id=current_user.id,
                 details="Trader explicitly unlocked live mode.")
    return {"live_mode_confirmed": engine.live_mode_confirmed}

@router.post("/kill")
async def emergency_kill(
    current_user: User = Depends(RoleChecker(["Admin", "Super_Admin", "Trader", "Risk_Officer"])),
    db: Session = Depends(get_db)
):
    from backend.app.autonomous_loops import stop_engine_loop
    for name in ["Rigel", "Sirius", "Canopus"]:
        asyncio.create_task(stop_engine_loop(name), name=f"kill_{name}")
    success = await engine.trigger_kill_switch(db, user_id=current_user.id)
    return {"success": success, "status": engine.status, "live_mode_confirmed": engine.live_mode_confirmed}

@router.post("/{engine_name}/acknowledge-halt")
def acknowledge_engine_halt(
    engine_name: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    id_to_name = {"ENG-001": "Rigel", "ENG-002": "Sirius", "ENG-003": "Canopus"}
    target_engine = id_to_name.get(engine_name, engine_name)

    if target_engine not in engine.engine_states:
        raise HTTPException(status_code=400, detail=f"Unknown engine: {target_engine}")

    acknowledged = SafetyGuardian.acknowledge_halt(db, current_user.id, target_engine)
    if not acknowledged:
        raise HTTPException(status_code=404, detail=f"No pending halt found for {target_engine}.")

    log_activity(
        db, f"Engine {target_engine} safety halt acknowledged by user.",
        "INFO", user_id=current_user.id,
    )
    return {"engine": target_engine, "acknowledged": True, "status": engine.engine_states[target_engine]["status"]}

from pydantic import BaseModel, Field

class ComplianceModeUpdate(BaseModel):
    compliance_mode: str = Field(..., description="Compliance mode: Islamic or Commercial")

@router.get("/status")
def get_engine_status(current_user: User = Depends(get_current_user)):
    return {
        "status": engine.status,
        "mode": engine.mode,
        "live_mode_confirmed": engine.live_mode_confirmed,
        "compliance_mode": engine.compliance_mode
    }

@router.post("/compliance-mode")
def update_compliance_mode(
    payload: ComplianceModeUpdate,
    current_user: User = Depends(RoleChecker(["Admin", "Super_Admin", "Trader", "Risk_Officer"])),
    db: Session = Depends(get_db)
):
    new_mode = payload.compliance_mode
    try:
        engine.set_compliance_mode(new_mode)
        log_activity(db, f"Engine compliance mode set to: {new_mode}", "SUCCESS", user_id=current_user.id)
        return {"compliance_mode": engine.compliance_mode}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

# FIX: added RoleChecker — only Admin and Risk_Officer can start/stop the engine
@router.post("/status")
def update_engine_status(
    payload: EngineStatusUpdate,
    current_user: User = Depends(RoleChecker(["Admin", "Super_Admin", "Trader", "Risk_Officer"])),
    db: Session = Depends(get_db)
):
    import time
    new_status = payload.status
    if new_status not in ["Running", "Paused", "Stopped"]:
        raise HTTPException(status_code=400, detail="Invalid engine status.")

    # Support both engine_id (ENG-001) and engine_name (Rigel) from frontend
    id_to_name = {"ENG-001": "Rigel", "ENG-002": "Sirius", "ENG-003": "Canopus"}
    raw_target = payload.engine_id or payload.engine_name
    target_engine = id_to_name.get(raw_target, raw_target) if raw_target else None
    if target_engine:
        if target_engine not in engine.engine_states:
            raise HTTPException(status_code=400, detail=f"Unknown engine: {target_engine}")

        if new_status == "Running" and SafetyGuardian.is_halt_pending_acknowledgment(db, current_user.id, target_engine):
            raise HTTPException(
                status_code=403,
                detail=f"{target_engine} has a safety halt awaiting your acknowledgment. "
                       f"Please review and acknowledge the notification before restarting."
            )

        state = engine.engine_states[target_engine]
        state["status"] = new_status
        
        if new_status == "Running":
            if state["start_time"] is None:
                state["start_time"] = time.time()
        elif new_status == "Stopped":
            state["start_time"] = None
            state["session_approved"] = 0
            state["session_rejected"] = 0
            state["session_running"] = 0

        engine.emit_event("status_change", {"engine": target_engine, "status": new_status})
        
        log_activity(
            db,
            f"Engine {target_engine} status updated: {new_status}",
            "SUCCESS",
            user_id=current_user.id,
            details=f"User Role: {current_user.role}"
        )
        return {"status": new_status, "engine": target_engine}

    # Fallback to global status update
    engine.status = new_status
    # Sync all sub-engines if updating globally
    for name, state in engine.engine_states.items():
        state["status"] = new_status
        if new_status == "Running":
            if state["start_time"] is None:
                state["start_time"] = time.time()
        elif new_status == "Stopped":
            state["start_time"] = None
            state["session_approved"] = 0
            state["session_rejected"] = 0
            state["session_running"] = 0

    engine.emit_event("status_change", {"status": new_status})
    log_activity(
        db,
        f"Global Engine status updated: {new_status}",
        "SUCCESS",
        user_id=current_user.id,
        details=f"User Role: {current_user.role}"
    )
    return {"status": engine.status}

@router.post("/mode")
def update_engine_mode(
    payload: EngineModeUpdate,
    current_user: User = Depends(RoleChecker(["Admin", "Super_Admin", "Trader", "Risk_Officer"])),
    db: Session = Depends(get_db)
):
    new_mode = payload.mode
    try:
        engine.set_mode(new_mode)
        log_activity(db, f"Engine execution mode set: {new_mode}", "SUCCESS", user_id=current_user.id)
        return {"mode": engine.mode, "live_mode_confirmed": engine.live_mode_confirmed}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/confirm-live")
def confirm_live_mode(
    current_user: User = Depends(RoleChecker(["Admin", "Super_Admin", "Trader", "Risk_Officer"])),
    db: Session = Depends(get_db)
):
    unlocked = engine.confirm_live_mode()
    if not unlocked:
        raise HTTPException(status_code=400, detail="Engine must be set to LIVE mode before safety gate confirmation.")

    log_activity(db, "Safety Gate Confirmed: Real Trading Enabled", "WARN", user_id=current_user.id,
                 details="Trader explicitly unlocked live mode.")
    return {"live_mode_confirmed": engine.live_mode_confirmed}

@router.post("/kill")
async def emergency_kill(
    current_user: User = Depends(RoleChecker(["Admin", "Super_Admin", "Trader", "Risk_Officer"])),
    db: Session = Depends(get_db)
):
    success = await engine.trigger_kill_switch(db, user_id=current_user.id)
    return {"success": success, "status": engine.status, "live_mode_confirmed": engine.live_mode_confirmed}

@router.post("/{engine_name}/acknowledge-halt")
def acknowledge_engine_halt(
    engine_name: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Clears a safety-triggered halt's acknowledgment gate for this engine.
    This does NOT resume trading -- the user must explicitly press Start
    again after acknowledging. Silence is never allowed to be the signal.
    """
    id_to_name = {"ENG-001": "Rigel", "ENG-002": "Sirius", "ENG-003": "Canopus"}
    target_engine = id_to_name.get(engine_name, engine_name)

    if target_engine not in engine.engine_states:
        raise HTTPException(status_code=400, detail=f"Unknown engine: {target_engine}")

    acknowledged = SafetyGuardian.acknowledge_halt(db, current_user.id, target_engine)
    if not acknowledged:
        raise HTTPException(status_code=404, detail=f"No pending halt found for {target_engine}.")

    log_activity(
        db,
        f"Engine {target_engine} safety halt acknowledged by user.",
        "INFO",
        user_id=current_user.id,
    )
    return {"engine": target_engine, "acknowledged": True, "status": engine.engine_states[target_engine]["status"]}
