from fastapi import APIRouter, Depends, HTTPException, Request, Body
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import Dict, Any, List
from datetime import datetime, timedelta
from backend.app.database import get_db, log_activity
from backend.shared.models.user import User
from backend.shared.models.billing import UserSubscription, SubscriptionPlan, PaymentTransaction, WebhookEvent
from backend.shared.models.success_fee import SuccessDecisionFee
from backend.app.security import get_current_user, RoleChecker
from backend.app.services.billing.providers.stripe_provider import StripeProvider
import os

router = APIRouter(prefix="/api/billing", tags=["Billing"])
provider = StripeProvider()

@router.post("/checkout")
def create_checkout_session(
    plan_name: str = Body(..., embed=True),
    success_url: str = Body(..., embed=True),
    cancel_url: str = Body(..., embed=True),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    plan = db.query(SubscriptionPlan).filter_by(name=plan_name).first()
    if not plan:
        raise HTTPException(status_code=400, detail="Invalid plan")

    try:
        url = provider.create_checkout_session(current_user, plan, success_url, cancel_url)
        # We save the customer ID if provider updated it (but provider abstraction just does it via stripe, 
        # so let's rely on webhook or explicit fetch later)
        if not current_user.provider_customer_id:
            # We don't get the newly created customer id back immediately in a clean way from checkout session 
            # unless we retrieve it. Webhook will link it.
            pass
        return {"url": url}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/portal")
def create_portal_session(
    return_url: str = Body(..., embed=True),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    if not current_user.provider_customer_id:
        raise HTTPException(status_code=400, detail="No billing profile found")
        
    try:
        url = provider.create_portal_session(current_user.provider_customer_id, return_url)
        return {"url": url}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/cancel")
def cancel_subscription(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    sub = db.query(UserSubscription).filter_by(user_id=current_user.id).first()
    if not sub or not sub.provider_subscription_id:
        raise HTTPException(status_code=400, detail="No active paid subscription found")

    try:
        canceled_at_end = provider.cancel_subscription(sub.provider_subscription_id)
        sub.cancel_at_period_end = canceled_at_end
        db.commit()
        return {"success": True, "cancel_at_period_end": canceled_at_end}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/history")
def get_billing_history(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    txns = db.query(PaymentTransaction).filter_by(user_id=current_user.id).order_by(PaymentTransaction.created_at.desc()).limit(20).all()
    return [{
        "id": t.id,
        "amount": t.amount,
        "currency": t.currency,
        "status": t.status,
        "created_at": t.created_at,
        "refunded_amount": t.refunded_amount
    } for t in txns]

# --- Admin Endpoints ---

@router.get("/admin/stats")
def get_admin_billing_stats(current_user: User = Depends(RoleChecker(["Admin", "Super Admin"])), db: Session = Depends(get_db)):
    # Total Revenue (sum of all succeeded transactions minus refunds)
    res = db.query(func.sum(PaymentTransaction.amount), func.sum(PaymentTransaction.refunded_amount)).filter_by(status="succeeded").first()
    total_revenue = (res[0] or 0.0) - (res[1] or 0.0)
    
    # Active Subscriptions
    active_subs = db.query(UserSubscription).filter(UserSubscription.status == "ACTIVE").all()
    
    # MRR / ARR calculation
    mrr = 0.0
    for sub in active_subs:
        if sub.plan and sub.plan.price_monthly:
            mrr += sub.plan.price_monthly
            
    arr = mrr * 12
    
    # Failed Payments count
    failed_payments = db.query(PaymentTransaction).filter_by(status="failed").count()
    
    # Refunds count
    refunds = db.query(PaymentTransaction).filter_by(status="refunded").count()
    
    # Churn (e.g. Subscriptions that are PAST_DUE or CANCELLED but not Free)
    free_plan = db.query(SubscriptionPlan).filter_by(name="Free").first()
    free_plan_id = free_plan.id if free_plan else None
    churned = db.query(UserSubscription).filter(
        UserSubscription.status.in_(["CANCELLED", "EXPIRED", "PAST_DUE"]),
        UserSubscription.plan_id != free_plan_id
    ).count()

    return {
        "total_revenue": total_revenue,
        "mrr": mrr,
        "arr": arr,
        "active_subscriptions": len(active_subs),
        "churned_subscriptions": churned,
        "failed_payments": failed_payments,
        "refunds": refunds
    }


@router.get("/admin/success-fees-dashboard")
def get_admin_success_fees_dashboard(
    current_user: User = Depends(RoleChecker(["Admin", "Super Admin"])),
    db: Session = Depends(get_db)
):
    """Admin revenue dashboard for Success Decision Fees"""
    today = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
    month_start = today.replace(day=1)

    # Today's Success Decision Fees
    today_fees = db.query(SuccessDecisionFee).filter(
        SuccessDecisionFee.created_at >= today
    ).all()
    today_total = sum(f.fee_amount for f in today_fees)

    # This Month's Success Decision Fees
    month_fees = db.query(SuccessDecisionFee).filter(
        SuccessDecisionFee.created_at >= month_start
    ).all()
    month_total = sum(f.fee_amount for f in month_fees)

    # Total Collected (all time)
    all_fees = db.query(SuccessDecisionFee).all()
    total_collected = sum(f.fee_amount for f in all_fees)

    # Top AI Engine (by total fees collected)
    engine_totals = {}
    for f in all_fees:
        engine_totals[f.engine_name] = engine_totals.get(f.engine_name, 0.0) + f.fee_amount
    top_engine = max(engine_totals.items(), key=lambda x: x[1]) if engine_totals else ("None", 0.0)

    # Most Profitable Client (by total realized profit)
    client_profits = {}
    for f in all_fees:
        client_profits[f.user_id] = client_profits.get(f.user_id, 0.0) + f.realized_profit
    top_client_id = max(client_profits.items(), key=lambda x: x[1]) if client_profits else (None, 0.0)
    top_client = None
    if top_client_id[0]:
        top_client = db.query(User).filter(User.id == top_client_id[0]).first()

    return {
        "today_fees": round(today_total, 2),
        "month_fees": round(month_total, 2),
        "total_collected": round(total_collected, 2),
        "top_engine": {
            "name": top_engine[0],
            "total_fees": round(top_engine[1], 2)
        },
        "most_profitable_client": {
            "username": top_client.username if top_client else "None",
            "total_profit": round(top_client_id[1], 2)
        },
        "today_decisions": len(today_fees),
        "month_decisions": len(month_fees),
        "total_decisions": len(all_fees)
    }

@router.post("/admin/refund")
def admin_refund_payment(
    transaction_id: int = Body(..., embed=True),
    amount: float = Body(None, embed=True),
    current_user: User = Depends(RoleChecker(["Admin", "Super Admin"])),
    db: Session = Depends(get_db)
):
    txn = db.query(PaymentTransaction).filter_by(id=transaction_id).first()
    if not txn or not txn.provider_charge_id:
        raise HTTPException(status_code=404, detail="Transaction or Charge ID not found")
        
    try:
        success = provider.refund_payment(txn.provider_charge_id, amount)
        if success:
            txn.status = "refunded"
            if amount:
                txn.refunded_amount += amount
            else:
                txn.refunded_amount = txn.amount
            db.commit()
            log_activity(db, "ADMIN_REFUND", "SUCCESS", current_user.id, details=f"Refunded txn {transaction_id}")
            return {"success": True}
        else:
            raise HTTPException(status_code=400, detail="Refund failed at provider")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/admin/create-lifetime")
def admin_create_lifetime_account(
    user_id: int = Body(..., embed=True),
    current_user: User = Depends(RoleChecker(["Admin", "Super Admin"])),
    db: Session = Depends(get_db)
):
    """Create a Free for Life account with premium privileges and billing exemption"""
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Get or create subscription
    sub = db.query(UserSubscription).filter_by(user_id=user_id).first()
    
    # Get Enterprise plan for premium features
    enterprise_plan = db.query(SubscriptionPlan).filter_by(name="Enterprise").first()
    if not enterprise_plan:
        # Fallback to Professional if Enterprise doesn't exist
        enterprise_plan = db.query(SubscriptionPlan).filter_by(name="Professional").first()
    
    if not sub:
        sub = UserSubscription(
            user_id=user_id,
            plan_id=enterprise_plan.id if enterprise_plan else 1,
            status="ACTIVE",
            provider="System",
            created_by=current_user.username,
            is_free_for_life=True
        )
        db.add(sub)
    else:
        sub.plan_id = enterprise_plan.id if enterprise_plan else 1
        sub.status = "ACTIVE"
        sub.is_free_for_life = True
        sub.provider = "System"
        sub.created_by = current_user.username
    
    db.commit()
    log_activity(db, "ADMIN_CREATE_LIFETIME", "SUCCESS", current_user.id, details=f"Created lifetime account for user {user_id}")
    
    return {
        "success": True,
        "user_id": user_id,
        "username": user.username,
        "plan": enterprise_plan.name if enterprise_plan else "Professional",
        "is_free_for_life": True
    }
