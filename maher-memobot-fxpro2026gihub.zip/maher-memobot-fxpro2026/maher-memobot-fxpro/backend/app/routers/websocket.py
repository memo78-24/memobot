from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Depends, Query
from typing import List, Dict
import json
import jwt
from backend.app.config import JWT_SECRET
from backend.app.database import get_db

router = APIRouter(prefix="/api", tags=["WebSocket"])

class ConnectionManager:
    def __init__(self):
        # Maps user_id to a list of active websocket connections
        self.active_connections: Dict[int, List[WebSocket]] = {}

    async def connect(self, websocket: WebSocket, user_id: int):
        await websocket.accept()
        if user_id not in self.active_connections:
            self.active_connections[user_id] = []
        self.active_connections[user_id].append(websocket)

    def disconnect(self, websocket: WebSocket, user_id: int):
        if user_id in self.active_connections:
            if websocket in self.active_connections[user_id]:
                self.active_connections[user_id].remove(websocket)
            if not self.active_connections[user_id]:
                del self.active_connections[user_id]

    async def send_personal_message(self, message: dict, user_id: int):
        if user_id in self.active_connections:
            for connection in self.active_connections[user_id]:
                try:
                    await connection.send_json(message)
                except Exception:
                    pass

    async def broadcast(self, message: dict):
        for user_id, connections in self.active_connections.items():
            for connection in connections:
                try:
                    await connection.send_json(message)
                except Exception:
                    pass

manager = ConnectionManager()

def get_user_from_token(token: str):
    # JWT AUTHENTICATION FROZEN PER DIRECT ORDER
    return "admin"

@router.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket, token: str = Query(None)):
    # JWT AUTHENTICATION FROZEN
    username = "admin"
        
    await manager.connect(websocket, username)
    try:
        while True:
            # We don't expect the client to send much, but we must keep reading to detect disconnects
            data = await websocket.receive_text()
            if data == "ping":
                await websocket.send_text("pong")
    except WebSocketDisconnect:
        manager.disconnect(websocket, username)

# Utility function to be imported by other services (e.g. trading engine)
async def push_to_user(username: str, data: dict):
    await manager.send_personal_message(data, username)

# Bind the WebSocket Manager's broadcast hook to ExecutionEngine and SwarmCoordinator
from backend.app.engine_instance import engine as exec_engine
from backend.app.swarm_instance import swarm as swarm_coordinator

exec_engine.broadcast = manager.broadcast
swarm_coordinator.broadcast = manager.broadcast
