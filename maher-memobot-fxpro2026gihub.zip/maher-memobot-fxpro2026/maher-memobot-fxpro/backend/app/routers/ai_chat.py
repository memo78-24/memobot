import urllib.request
import json
import logging
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session
from backend.app.database import get_db
from backend.shared.models.user import User
from backend.shared.models.vault import SecretsVault
from backend.shared.models.trading import PaperBalance
from backend.app.security import get_current_user, decrypt_secret
from backend.app.swarm_instance import swarm
from backend.app.evaluation import compute_market_score

logger = logging.getLogger("memobot_fxpro")
router = APIRouter(prefix="/api/ai", tags=["AI Advisor"])

class ChatRequest(BaseModel):
    message: str

@router.post("/query")
async def query_ai_advisor(payload: ChatRequest, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    user_msg = payload.message.strip()
    
    # 1. Fetch Gemini API Key from secrets vault
    gemini_entry = db.query(SecretsVault).filter(
        SecretsVault.user_id == current_user.id,
        SecretsVault.service_name == "Gemini"
    ).first()
    
    gemini_key = None
    if gemini_entry:
        try:
            gemini_key = decrypt_secret(gemini_entry.encrypted_api_key)
        except Exception as e:
            logger.error(f"Failed to decrypt Gemini key: {e}")
            
    # Gather live data context
    btc_price = swarm.prices.get("BTC", 68000.0)
    eth_price = swarm.prices.get("ETH", 3500.0)
    sol_price = swarm.prices.get("SOL", 135.0)
    
    # Query paper balances
    paper_bals = db.query(PaperBalance).filter(PaperBalance.user_id == current_user.id).all()
    bal_str = ", ".join([f"{pb.asset}: {pb.free:.4f}" for pb in paper_bals]) if paper_bals else "No balances"
    
    # Calculate a sample evaluation score to provide details
    eval_res = await compute_market_score(
        "BTC/USDT", "BUY", "Sirius",
        user_id=current_user.id, db=db
    )
    
    system_prompt = (
        f"You are MemoBot, an institutional AI Trading Assistant. "
        f"You translate market sentiment and structural charts into actionable intelligence. "
        f"Current Market Data context: BTC/USDT price is ${btc_price:,.2f}, ETH/USDT is ${eth_price:,.2f}, SOL/USDT is ${sol_price:,.2f}. "
        f"Active user sandbox portfolio holdings: {bal_str}. "
        f"Current internal BTC market evaluation score: {eval_res['score']}% (Components: {eval_res['components']}). "
        f"Answer the trader's questions in a professional, concise trading desk manner."
    )
    
    if gemini_key:
        # Call actual Gemini API (gemini-1.5-flash)
        try:
            url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={gemini_key}"
            req_data = {
                "contents": [
                    {
                        "parts": [
                            {"text": f"System Guidelines: {system_prompt}\nUser Query: {user_msg}"}
                        ]
                    }
                ]
            }
            req_body = json.dumps(req_data).encode("utf-8")
            
            req = urllib.request.Request(
                url,
                data=req_body,
                headers={"Content-Type": "application/json"},
                method="POST"
            )
            
            with urllib.request.urlopen(req, timeout=10) as response:
                res_body = response.read().decode("utf-8")
                res_json = json.loads(res_body)
                
                # Parse response text
                candidates = res_json.get("candidates", [])
                if candidates:
                    content = candidates[0].get("content", {})
                    parts = content.get("parts", [])
                    if parts:
                        text_response = parts[0].get("text", "")
                        return {"response": text_response, "mode": "Gemini Live"}
                        
            raise RuntimeError("Empty response from Gemini API.")
        except Exception as e:
            logger.error(f"Gemini API request failed: {e}. Falling back to internal report.")
            
    # Fallback to local rule-based market report if Gemini is missing or fails
    msg_lower = user_msg.lower()
    if "status" in msg_lower or "engine" in msg_lower or "swarm" in msg_lower:
        text_response = (
            f"MemoBot Status Report: All engines (Rigel, Sirius, Canopus) are operational. "
            f"BTC/USDT is currently trading at ${btc_price:,.2f}. "
            f"Current Swarm Consensus index is {swarm.sentiment_score * 100:.1f}%. "
            f"RSI indicator sits at {swarm.rsi_value:.1f}. "
            f"The execution gate is locked securely with the 40% threshold enabled."
        )
    elif "shariah" in msg_lower or "compliant" in msg_lower or "islamic" in msg_lower:
        text_response = (
            "Shariah Guard status: ACTIVE. Spot physical-backed matches are enforced across all channels. "
            "Leverage, margin lending, derivatives, and short-selling channels are strictly blocked to prevent riba. "
            "Verification hash chain is online."
        )
    elif "balance" in msg_lower or "portfolio" in msg_lower or "equity" in msg_lower:
        text_response = (
            f"Your current simulator portfolio holdings are: {bal_str}. "
            f"Live market tickers are running continuously. All funds are backed physically 1:1."
        )
    elif "score" in msg_lower or "evaluation" in msg_lower or "indicator" in msg_lower:
        text_response = (
            f"Internal market evaluation report for BTC/USDT: "
            f"Aggregated Score: {eval_res['score']}%. "
            f"Breakdown: Order Book Pressure: {eval_res['components']['order_book_pressure']}%, "
            f"RSI Factor: {eval_res['components']['rsi_factor']}%, "
            f"MACD Factor: {eval_res['components']['macd_factor']}%, "
            f"Swarm Consensus: {eval_res['components']['swarm_consensus']}%. "
            f"Execution Gate status: {'APPROVED' if eval_res['score'] >= 40.0 else 'REJECTED'} (Threshold: 40%)."
        )
    else:
        text_response = (
            f"Ahlan! I'm MemoBot, your Trading Desk Advisor. "
            f"The internal engine is monitoring Binance live ticker rates. "
            f"BTC/USDT is currently at ${btc_price:,.2f}. "
            f"Current evaluation score is {eval_res['score']}%. "
            f"Please enter your Gemini API Key in Settings > Security tab to activate real Gemini conversational chat."
        )
        
    return {"response": text_response, "mode": "Local Fallback"}


class TranslateRequest(BaseModel):
    text: str
    target_lang: str

@router.post("/translate")
def translate_text(payload: TranslateRequest, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    text_to_translate = payload.text.strip()
    target = payload.target_lang.strip().lower()
    
    # 1. Local translation dictionary (immediate, no API overhead)
    local_mapping = {
        "ar": {
            "rigel (laml000r)": "ريجل (LAML000R)",
            "sirius (l000l)": "سيريوس (L000L)",
            "canopus (000ka)": "كانوبوس (000KA)",
            "start rigel": "بدء ريجل",
            "stop rigel": "إيقاف ريجل",
            "start sirius": "بدء سيريوس",
            "stop sirius": "إيقاف سيريوس",
            "start canopus": "بدء كانوبوس",
            "stop canopus": "إيقاف كانوبوس",
            "stopped": "متوقف",
            "running": "يعمل",
            "approved": "تمت الموافقة",
            "rejected": "مرفوض",
            "order routing pipeline": "مسار توجيه الأوامر",
            "active long positions": "المراكز الطويلة النشطة",
            "active short positions": "المراكز القصيرة النشطة",
            "daily memobot advice": "نصيحة ميموبوت اليومية",
            "system status": "حالة النظام",
            "operational": "يعمل بشكل طبيعي",
            "network": "الشبكة",
            "account equity": "حقوق الحساب",
            "unrealized pnl": "الأرباح والخسائر غير المحققة",
            "locked margin": "الهامش المحجوز",
            "shariyah validated": "معتمد شرعياً",
            "volatility shield": "درع التقلبات",
            "order book buy pressure": "ضغط الشراء في دفتر الطلبات",
            "order book sell pressure": "ضغط البيع في دفتر الطلبات",
            "left wing: buy-side intelligence": "الجناح الأيسر: ذكاء جانب الشراء",
            "right wing: sell-side intelligence": "الجناح الأيمن: ذكاء جانب البيع",
            "live bid depth (buy walls)": "عمق العرض المباشر (جدران الشراء)",
            "live ask depth (sell walls)": "عمق الطلب المباشر (جدران البيع)",
            "buy-side signals ticker": "مؤشر إشارات جانب الشراء",
            "sell-side signals ticker": "مؤشر إشارات جانب البيع",
            "wing sensors audit report": "تقرير تدقيق مستشعرات الجناح",
            "portfolio swarm intelligence": "ذكاء محفظة السرب",
            "observing eye active...": "عين المراقبة نشطة...",
            "swarm observing core...": "نواة مراقبة السرب...",
            "hybrid observing scanner...": "ماسح المراقبة الهجين...",
            "daily advice": "النصيحة اليومية",
            "settings": "الإعدادات",
            "dashboard": "لوحة التحكم",
            "central engine control station": "محطة التحكم المركزية للمحركات",
            "manage order routing pipelines & volatility shield parameters": "إدارة مسارات توجيه الطلبات ومعاملات درع التقلبات",
            "active telemetry sync status": "حالة مزامنة القياس المباشر",
            "reset": "إعادة تعيين",
            "log": "السجل",
            "live": "مباشر",
            "real": "حقيقي",
            "paper": "تجريبي",
            "testnet": "شبكة اختبار",
            "mainnet": "شبكة رئيسية"
        },
        "en": {
            "ريجل (laml000r)": "RIGEL (LAML000R)",
            "سيريوس (l000l)": "SIRIUS (L000L)",
            "كانوبوس (000ka)": "CANOPUS (000KA)",
            "بدء ريجل": "START Rigel",
            "إيقاف ريجل": "STOP Rigel",
            "بدء سيريوس": "START Sirius",
            "إيقاف سيريوس": "STOP Sirius",
            "بدء كانوبوس": "START Canopus",
            "إيقاف كانوبوس": "STOP Canopus",
            "متوقف": "STOPPED",
            "يعمل": "RUNNING",
            "تمت الموافقة": "APPROVED",
            "مرفوض": "REJECTED",
            "مسار توجيه الأوامر": "ORDER ROUTING PIPELINE",
            "المراكز الطويلة النشطة": "ACTIVE LONG POSITIONS",
            "المراكز القصيرة النشطة": "ACTIVE SHORT POSITIONS",
            "نصيحة ميموبوت اليومية": "DAILY MEMOBOT ADVICE",
            "حالة النظام": "SYSTEM STATUS",
            "يعمل بشكل طبيعي": "OPERATIONAL",
            "الشبكة": "NETWORK",
            "حقوق الحساب": "ACCOUNT EQUITY",
            "الأرباح والخسائر غير المحققة": "UNREALIZED PNL",
            "الهامش المحجوز": "LOCKED MARGIN",
            "معتمد شرعياً": "SHARIYAH VALIDATED",
            "درع التقلبات": "VOLATILITY SHIELD",
            "ضغط الشراء في دفتر الطلبات": "ORDER BOOK BUY PRESSURE",
            "ضغط البيع في دفتر الطلبات": "ORDER BOOK SELL PRESSURE",
            "الجناح الأيسر: ذكاء جانب الشراء": "LEFT WING: BUY-SIDE INTELLIGENCE",
            "الجناح الأيمن: ذكاء جانب البيع": "RIGHT WING: SELL-SIDE INTELLIGENCE",
            "عمق العرض المباشر (جدران الشراء)": "LIVE BID DEPTH (BUY WALLS)",
            "عمق الطلب المباشر (جدران البيع)": "LIVE ASK DEPTH (SELL WALLS)",
            "مؤشر إشارات جانب الشراء": "BUY-SIDE SIGNALS TICKER",
            "مؤشر إشارات جانب البيع": "SELL-SIDE SIGNALS TICKER",
            "تقرير تدقيق مستشعرات الجناح": "WING SENSORS AUDIT REPORT",
            "ذكاء محفظة السرب": "PORTFOLIO SWARM INTELLIGENCE",
            "عين المراقبة نشطة...": "OBSERVING EYE ACTIVE...",
            "نواة مراقبة السرب...": "SWARM OBSERVING CORE...",
            "ماسح المراقبة الهجين...": "HYBRID OBSERVING SCANNER..."
        }
    }

    normalized = text_to_translate.lower().strip()
    if normalized in local_mapping.get(target, {}):
        return {"translated_text": local_mapping[target][normalized]}

    # 2. Gemini Live auto-translation fallback
    gemini_entry = db.query(SecretsVault).filter(
        SecretsVault.user_id == current_user.id,
        SecretsVault.service_name == "Gemini"
    ).first()
    
    gemini_key = None
    if gemini_entry:
        try:
            gemini_key = decrypt_secret(gemini_entry.encrypted_api_key)
        except Exception as e:
            logger.error(f"Failed to decrypt Gemini key: {e}")

    if gemini_key:
        try:
            url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={gemini_key}"
            prompt = (
                f"You are a translation microservice for an institutional dark-themed trading platform. "
                f"Translate the following text to Arabic if target_lang is 'ar', or translate to English if target_lang is 'en'. "
                f"Keep it brief, exact, professional, matching financial terms. "
                f"IMPORTANT: Return ONLY the raw translated string. Do not include quotes, conversational text, explanations, or any other wrapper. "
                f"Target Language: {target}\n"
                f"Text: {text_to_translate}"
            )
            req_data = {
                "contents": [
                    {
                        "parts": [
                            {"text": prompt}
                        ]
                    }
                ]
            }
            req_body = json.dumps(req_data).encode("utf-8")
            req = urllib.request.Request(
                url,
                data=req_body,
                headers={"Content-Type": "application/json"},
                method="POST"
            )
            with urllib.request.urlopen(req, timeout=8) as response:
                res_body = response.read().decode("utf-8")
                res_json = json.loads(res_body)
                candidates = res_json.get("candidates", [])
                if candidates:
                    parts = candidates[0].get("content", {}).get("parts", [])
                    if parts:
                        trans_res = parts[0].get("text", "").strip()
                        if (trans_res.startswith('"') and trans_res.endswith('"')) or (trans_res.startswith("'") and trans_res.endswith("'")):
                            trans_res = trans_res[1:-1].strip()
                        return {"translated_text": trans_res}
        except Exception as e:
            logger.error(f"Gemini auto-translation failed: {e}")

    # 3. Basic fallback
    if target == "ar":
        return {"translated_text": f"مترجم: {text_to_translate}"}
    else:
        return {"translated_text": text_to_translate.replace("مترجم: ", "")}
