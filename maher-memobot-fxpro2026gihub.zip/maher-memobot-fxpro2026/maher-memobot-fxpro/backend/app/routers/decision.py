from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from backend.app.database import get_db
from backend.app.security import get_current_user
from backend.shared.models.user import User
from typing import Optional, List
from datetime import datetime

router = APIRouter(prefix="/api/decision", tags=["Decision Kernel"])


class DecisionEvaluation:
    def __init__(self, id: str, symbol: str, side: str, confidence: float, 
                 reasoning: str, shariah_compliant: bool, timestamp: datetime):
        self.id = id
        self.symbol = symbol
        self.side = side
        self.confidence = confidence
        self.reasoning = reasoning
        self.shariah_compliant = shariah_compliant
        self.timestamp = timestamp


class StressTestResult:
    def __init__(self, scenario: str, passed: bool, decision: DecisionEvaluation, 
                 details: str):
        self.scenario = scenario
        self.passed = passed
        self.decision = decision
        self.details = details


# In-memory storage for demo purposes
_current_evaluation: Optional[DecisionEvaluation] = None
_history: List[DecisionEvaluation] = []
_circuit_breaker_active = False


@router.get("/latest")
def get_latest_decisions(current_user: User = Depends(get_current_user)):
    """Get current decision evaluation and history"""
    return {
        "current": _current_evaluation,
        "history": _history,
        "circuit_breaker_active": _circuit_breaker_active
    }


@router.post("/evaluate")
def evaluate_trade_intent(
    intent: dict,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Evaluate a trade intent using the decision kernel"""
    # Demo implementation - in production this would use the actual decision engine
    evaluation = DecisionEvaluation(
        id=f"decision_{datetime.utcnow().timestamp()}",
        symbol=intent.get("symbol", "BTCUSDT"),
        side=intent.get("side", "BUY"),
        confidence=0.75,
        reasoning="Demo evaluation - actual decision engine not connected",
        shariah_compliant=True,
        timestamp=datetime.utcnow()
    )
    
    _current_evaluation = evaluation
    _history.insert(0, evaluation)
    if len(_history) > 50:
        _history.pop()
    
    return evaluation


@router.post("/simulate-stress")
def simulate_stress_test(
    payload: dict,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Run a stress test simulation"""
    scenario = payload.get("scenario")
    
    # Demo implementation
    evaluation = DecisionEvaluation(
        id=f"stress_{datetime.utcnow().timestamp()}",
        symbol="BTCUSDT",
        side="BUY",
        confidence=0.60,
        reasoning=f"Stress test scenario: {scenario}",
        shariah_compliant=True,
        timestamp=datetime.utcnow()
    )
    
    result = StressTestResult(
        scenario=scenario,
        passed=True,
        decision=evaluation,
        details=f"Stress test {scenario} completed successfully"
    )
    
    _current_evaluation = evaluation
    _history.insert(0, evaluation)
    
    return result


@router.post("/circuit-breaker")
def toggle_circuit_breaker(
    payload: dict,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Toggle the circuit breaker"""
    global _circuit_breaker_active
    _circuit_breaker_active = payload.get("active", False)
    
    return {
        "circuit_breaker_active": _circuit_breaker_active
    }
