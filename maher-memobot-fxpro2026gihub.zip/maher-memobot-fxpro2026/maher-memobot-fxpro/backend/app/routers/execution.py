from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session
from backend.app.database import get_db
from backend.shared.models.user import User
from backend.shared.models.vault import SecretsVault
from backend.shared.models.trading import TradeRecord, PaperBalance
from backend.shared.models.success_fee import SuccessDecisionFee
from backend.app.security import RoleChecker, get_current_user
from backend.app.engine_instance import engine
from backend.app.schemas.engine import TradeRequest
from backend.shared.models.billing import UserSubscription
from backend.app.dependencies.billing import get_current_subscription
from backend.app.shariyah import shariyah_engine
import asyncio
import logging
from datetime import datetime, timezone

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/execution", tags=["Execution Desk"])

@router.post("/trade")
async def execute_trade(
    payload: TradeRequest,
    current_user: User = Depends(RoleChecker(["Admin", "Trader"])),
    sub: UserSubscription = Depends(get_current_subscription),
    db: Session = Depends(get_db)
):
    """Execute a trade with full validation and server-side mode enforcement"""
    try:
        # INPUT VALIDATION
        if not payload.symbol or '/' not in payload.symbol:
            raise ValueError("Invalid symbol format (expected: BTC/USDT)")
        if payload.amount <= 0 or payload.amount > 10000:
            raise ValueError("Amount must be between 0 and 10,000 USDT")
        if payload.side not in ['BUY', 'SELL']:
            raise ValueError("Side must be BUY or SELL")
        if payload.type not in ['MARKET', 'LIMIT']:
            raise ValueError("Type must be MARKET or LIMIT")
        if payload.engine not in ['Rigel', 'Sirius', 'Canopus', 'Gemini']:
            raise ValueError(f"Unknown engine: {payload.engine}")
        
        # CRITICAL: Always use server-side mode, never trust client
        execution_mode = engine.mode
        
        # HARD SHARIAH GATE: the actual production execution endpoint must
        # validate the trade before ExecutionEngine can reach Binance.
        if engine.compliance_mode == "Islamic":
            from backend.app.swarm_instance import swarm
            asset = payload.symbol.replace("/USDT", "").replace("USDT", "")
            shariah_price = payload.price or swarm.prices.get(asset, 0.0)
            if shariah_price <= 0:
                raise ValueError("No validated market price is available for Shariah validation")
            shariah_trade = {
                "symbol": payload.symbol,
                "side": payload.side,
                "type": payload.type,
                "amount": payload.amount,
                "price": shariah_price,
                "leverage": 1.0,
            }
            compliant, shariah_message, shariah_details = shariyah_engine.validate_full_trade(shariah_trade)
            if not compliant:
                logger.warning("Shariah gate rejected trade: %s", shariah_message)
                return JSONResponse(status_code=403, content={
                    "success": False,
                    "message": shariah_message,
                    "stage": 3,
                    "shariah_status": "NON_COMPLIANT",
                    "shariah_details": shariah_details,
                })

        # Enforce Subscription Limits
        if execution_mode == "Live" and not sub.plan.live_trading_enabled:
            raise ValueError(f"Your {sub.plan.name} plan does not support Live Trading.")
            
        if payload.amount * (payload.price or 50000.0) > (sub.plan.max_leverage * 1000): # Maximum allowable leverage limit calculation
             pass # Will enforce properly in Trading Engine
        
        
        result = await engine.execute_trade(
            db=db,
            user_id=current_user.id,
            symbol=payload.symbol,
            side=payload.side,
            order_type=payload.type,
            amount=payload.amount,
            price=payload.price,
            engine_name=payload.engine
        )
        
        if not result.get("success"):
            logger.warning(f"Trade failed: {result}")
            return JSONResponse(status_code=400, content=result)
        
        logger.info(f"Trade executed: {payload.symbol} {payload.side} {payload.amount} in {execution_mode} mode")
        return result
    
    except ValueError as e:
        logger.error(f"Trade validation error: {str(e)}")
        return JSONResponse(status_code=400, content={"success": False, "message": str(e)})
    except asyncio.TimeoutError:
        logger.error("Trade execution timeout")
        return JSONResponse(status_code=408, content={"success": False, "message": "Request timeout"})
    except Exception as e:
        logger.error(f"Unexpected error in trade execution: {str(e)}", exc_info=True)
        return JSONResponse(status_code=500, content={"success": False, "message": "Internal server error"})


@router.get("/balances")
async def get_balances(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Get live + paper balances with proper error handling"""
    live_balances = {}
    prices = {}
    net_worth = 0.0
    live_configured = False
    breakdown = {}

    try:
        # CONFIGURE LIVE CLIENT IF NEEDED
        if not engine.binance_client or not engine.binance_client.is_configured:
            await engine.configure_live_client(db, user_id=current_user.id)

        # FETCH LIVE BALANCES — try cache first, then direct fetch
        if engine.binance_client and engine.binance_client.is_configured:
            try:
                from backend.app.services.balance_cache import get_cached_balances
                cache_res = await get_cached_balances()
                if cache_res.get("success"):
                    live_balances = cache_res.get("asset_totals", {})
                    prices = cache_res.get("prices", {})
                    net_worth = cache_res.get("net_worth", 0.0)
                    breakdown = cache_res.get("breakdown", {})
                    live_configured = True
                else:
                    # Cache cold — do a direct live fetch with generous timeout
                    res = await asyncio.wait_for(
                        engine.binance_client.fetch_all_balances(),
                        timeout=15.0
                    )
                    if res.get("success"):
                        live_balances = res.get("asset_totals", {})
                        prices = res.get("prices", {})
                        net_worth = res.get("net_worth", 0.0)
                        breakdown = res.get("breakdown", {})
                        live_configured = True
                        # Warm the cache with this fresh data
                        from backend.app.services.balance_cache import update_cached_balances
                        await update_cached_balances({
                            "asset_totals": live_balances,
                            "prices": prices,
                            "net_worth": net_worth,
                            "breakdown": breakdown,
                        })
            except asyncio.TimeoutError:
                logger.error("Live balance fetch timeout")
                live_configured = False
            except ConnectionError as e:
                logger.error(f"Connection error fetching live balances: {e}")
                live_configured = False
            except Exception as e:
                logger.error(f"Error fetching live balances: {e}")
                live_configured = False

        # GET PAPER BALANCES (FALLBACK)
        pbs = db.query(PaperBalance).filter(PaperBalance.user_id == current_user.id).all()
        if not pbs:
            default_balances = {
                "USDT": 100000.0, "BTC": 1.5000, "ETH": 4.1500,
                "SOL": 15.0000, "ADA": 120.0000, "BNB": 1.2500
            }
            for asset, amount in default_balances.items():
                pb = PaperBalance(user_id=current_user.id, asset=asset, free=amount, locked=0.0)
                db.add(pb)
            db.commit()
            pbs = db.query(PaperBalance).filter(PaperBalance.user_id == current_user.id).all()

        paper_balances = {pb.asset: pb.free for pb in pbs}
        if "USDT" not in paper_balances:
            paper_balances["USDT"] = 100000.0

        from backend.app.swarm_instance import swarm
        if not prices:
            prices = swarm.prices

        # BALANCE POLICY: Always show real Binance balance when API credentials are configured,
        # regardless of engine mode (Paper / Live / Islamic).
        # net_worth is now authoritative from sapiGetAssetWalletBalance in binance_adapter.py
        if live_configured:
            balance_source = "LIVE_BINANCE"
            display_balances = live_balances
        else:
            # No Binance API configured — show paper/sandbox balances as fallback
            balance_source = "PAPER_SANDBOX"
            display_balances = paper_balances
            net_worth = 0.0
            for asset, free_amount in paper_balances.items():
                price = prices.get(asset, 1.0) if asset != "USDT" else 1.0
                net_worth += free_amount * price

        free_usdt = display_balances.get("USDT", 0.0)

        return {
            "mode": engine.mode,
            "live_configured": live_configured,
            "balance_source": balance_source,
            "balances": display_balances,
            "breakdown": breakdown,
            "net_worth": round(net_worth, 2),
            "equity": round(net_worth, 2),
            "free_usdt": round(free_usdt, 2),
            "unrealized_pnl": 0.0,
            "used_margin": 0.0,
            "prices": prices,
            "paper_balances": paper_balances,
            "paper_net_worth": 100000.0
        }

    except Exception as e:
        logger.error(f"Error in get_balances: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Failed to fetch balances: {str(e)}")


@router.post("/reset-paper")
def reset_paper_balances(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Reset paper trading account with atomic transaction"""
    try:
        # Delete existing balances
        db.query(PaperBalance).filter(PaperBalance.user_id == current_user.id).delete()
        db.flush()  # Flush before adding to ensure clean state
        
        # Add default balances in same transaction
        default_balances = {
            "USDT": 100000.0, "BTC": 0.7482, "ETH": 4.1500,
            "SOL": 15.0000, "ADA": 120.0000, "BNB": 1.2500
        }
        for asset, amount in default_balances.items():
            pb = PaperBalance(user_id=current_user.id, asset=asset, free=amount, locked=0.0)
            db.add(pb)
        db.commit()
        
        logger.info(f"Paper account reset for user: {current_user.username}")
        return {"message": "Paper sandbox account reset to initial values successfully."}
    except Exception as e:
        db.rollback()
        logger.error(f"Error resetting paper balances: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Failed to reset paper account: {str(e)}")


@router.get("/history")
def get_trade_history(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Get trade history with proper error handling and user isolation"""
    try:
        trades = db.query(TradeRecord).filter(
            TradeRecord.user_id == current_user.id
        ).order_by(TradeRecord.id.desc()).limit(100).all()
    except Exception as e:
        logger.error(f"Error querying trade history: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch trade history")
    
    return [{
        "order_id": t.order_id,
        "symbol": t.symbol,
        "side": t.side,
        "type": t.type,
        "amount": t.amount,
        "price": t.price,
        "fill_price": t.fill_price,
        "fill_amount": t.fill_amount,
        "status": t.status,
        "latency_ms": t.latency_ms,
        "slippage_pct": t.slippage_pct,
        "execution_mode": t.execution_mode,
        "timestamp": t.timestamp,
        "error_message": t.error_message,
        "engine_name": t.engine_name,
        "evaluation_score": t.evaluation_score
    } for t in trades]


@router.get("/active-positions")
async def get_active_positions(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Get active positions with error handling"""
    try:
        from backend.app.swarm_instance import swarm
        positions_by_engine = {"Rigel": [], "Sirius": [], "Canopus": [], "Gemini": [], "Halal": []}

        balances = {}
        # ALWAYS USE LIVE IF CONFIGURED (Decoupled from Engine Mode)
        if not engine.binance_client or not engine.binance_client.is_configured:
            await engine.configure_live_client(db, user_id=current_user.id)
            
        if engine.binance_client and engine.binance_client.is_configured:
            try:
                from backend.app.services.balance_cache import get_cached_balances
                cache_res = await get_cached_balances()
                if cache_res.get("success"):
                    # Use Spot balances from cached breakdown or fall back to asset_totals
                    balances = cache_res.get("breakdown", {}).get("spot", {}) or cache_res.get("asset_totals", {})
                else:
                    # Fallback to direct fetch if cache is not yet warm
                    balances = await asyncio.wait_for(
                        engine.binance_client.fetch_balance(),
                        timeout=5.0
                    )
            except (asyncio.TimeoutError, ConnectionError) as e:
                logger.error(f"Failed to fetch live balance for positions: {e}")
                balances = {}
        else:
            pbs = db.query(PaperBalance).filter(PaperBalance.user_id == current_user.id).all()
            balances = {pb.asset: pb.free for pb in pbs}

        # RECONCILE POSITIONS BY ENGINE
        for asset, amount in balances.items():
            # Skip stablecoins, zero balances, and LD-prefixed Earn tokens
            # (LDUSDT, LDBTC etc. are Flexible Earn receipt tokens, not real positions)
            if amount <= 0.0001:
                continue
            if asset in ["USDT", "USDC", "BUSD", "FDUSD", "TUSD", "DAI", "BFUSD"]:
                continue
            if asset.startswith("LD"):
                continue

            buy_trades = db.query(TradeRecord).filter(
                TradeRecord.symbol == f"{asset}/USDT",
                TradeRecord.side == "BUY",
                TradeRecord.execution_mode == engine.mode,
                TradeRecord.status.in_(["FILLED", "CLOSED"])
            ).order_by(TradeRecord.timestamp.desc()).all()

            remaining = amount
            engine_chunks = {}
            
            for t in buy_trades:
                if remaining <= 0:
                    break
                qty = t.fill_amount or t.amount or 0.0
                if qty <= 0:
                    continue
                
                match_qty = min(remaining, qty)
                eng = t.engine_name or "Rigel"
                if eng not in ["Rigel", "Sirius", "Canopus", "Gemini", "Halal"]:
                    eng = "Rigel"
                
                if eng not in engine_chunks:
                    engine_chunks[eng] = {"total_qty": 0.0, "total_cost": 0.0}
                
                engine_chunks[eng]["total_qty"] += match_qty
                engine_chunks[eng]["total_cost"] += match_qty * (t.fill_price or t.price or 0.0)
                remaining -= match_qty

            # ASSIGN REMAINING TO RIGEL
            if remaining > 0:
                eng = "Rigel"
                if eng not in engine_chunks:
                    engine_chunks[eng] = {"total_qty": 0.0, "total_cost": 0.0}
                current_price = swarm.prices.get(asset, 0.0)
                engine_chunks[eng]["total_qty"] += remaining
                engine_chunks[eng]["total_cost"] += remaining * current_price

            for eng, data in engine_chunks.items():
                if data["total_qty"] > 0:
                    avg_entry = data["total_cost"] / data["total_qty"]
                    current_price = swarm.prices.get(asset, 0.0) or avg_entry
                    pnl = data["total_qty"] * (current_price - avg_entry)
                    roi = ((current_price - avg_entry) / avg_entry) * 100.0 if avg_entry > 0 else 0.0
                    locked_margin = (data["total_qty"] * avg_entry) / 10.0

                    positions_by_engine[eng].append({
                        "symbol": f"{asset}/USDT",
                        "amount": data["total_qty"],
                        "entry_price": round(avg_entry, 4),
                        "current_price": round(current_price, 4),
                        "pnl": round(pnl, 4),
                        "roi": round(roi, 2),
                        "locked_margin": round(locked_margin, 2)
                    })

        return positions_by_engine
    
    except Exception as e:
        logger.error(f"Failed to fetch active positions: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Failed to fetch active positions: {str(e)}")


@router.get("/engine-stats")
def get_engine_stats(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Get engine execution statistics"""
    try:
        stats = {}
        for engine_name in ["Rigel", "Sirius", "Canopus", "Gemini", "Halal"]:
            approved = db.query(TradeRecord).filter(
                TradeRecord.execution_mode == engine.mode,
                TradeRecord.status.in_(["FILLED", "CLOSED"]),
                TradeRecord.engine_name == engine_name
            ).count()
            rejected = db.query(TradeRecord).filter(
                TradeRecord.execution_mode == engine.mode,
                TradeRecord.status == "REJECTED",
                TradeRecord.engine_name == engine_name
            ).count()
            running = db.query(TradeRecord).filter(
                TradeRecord.execution_mode == engine.mode,
                TradeRecord.status.in_(["PARTIALLY_FILLED", "NEW"]),
                TradeRecord.engine_name == engine_name
            ).count()
            stats[engine_name] = {"approved": approved, "rejected": rejected, "running": running}
        return stats
    except Exception as e:
        logger.error(f"Failed to fetch engine stats: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Failed to fetch engine stats: {str(e)}")


@router.get("/daily-stats")
def get_daily_stats(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Get daily trading statistics with proper timezone handling"""
    try:
        # Use aware UTC datetime for comparison with DB timestamps
        now_utc = datetime.now(timezone.utc)
        today_start = now_utc.replace(hour=0, minute=0, second=0, microsecond=0)

        # Calculate PnL accurately using FIFO matching for all filled trades up to today
        all_filled = db.query(TradeRecord).filter(
            TradeRecord.execution_mode == engine.mode,
            TradeRecord.status.in_(["FILLED", "PARTIALLY_FILLED"])
        ).order_by(TradeRecord.timestamp.asc()).all()

        daily_pnl = 0.0
        wins = 0
        losses = 0
        
        # Dictionary of queues per symbol: {"BTC/USDT": [ {"price": 40000, "qty": 1.0} ]}
        inventory = {}
        
        for t in all_filled:
            sym = t.symbol
            if sym not in inventory:
                inventory[sym] = []
                
            qty = t.fill_amount or t.amount or 0.0
            price = t.fill_price or t.price or 0.0
            
            if qty <= 0 or price <= 0:
                continue
                
            if t.side == "BUY":
                inventory[sym].append({"price": price, "qty": qty})
            elif t.side == "SELL":
                # Match against inventory
                remaining_sell = qty
                trade_pnl = 0.0
                
                while remaining_sell > 0 and inventory[sym]:
                    batch = inventory[sym][0]
                    match_qty = min(remaining_sell, batch["qty"])
                    
                    # PnL for this matched portion
                    pnl_portion = (price - batch["price"]) * match_qty
                    trade_pnl += pnl_portion
                    
                    batch["qty"] -= match_qty
                    remaining_sell -= match_qty
                    
                    if batch["qty"] <= 1e-8:
                        inventory[sym].pop(0)
                        
                # If this trade happened today, add to daily stats
                trade_ts = t.timestamp
                if trade_ts.tzinfo is None:
                    trade_ts = trade_ts.replace(tzinfo=timezone.utc)
                if trade_ts >= today_start:
                    daily_pnl += trade_pnl
                    if trade_pnl >= 0:
                        wins += 1
                    else:
                        losses += 1

        total_closed = wins + losses
        win_rate = round((wins / total_closed) * 100, 1) if total_closed > 0 else 0.0

        locked_margin = 0.0
        unrealized_pnl = 0.0
        from backend.app.swarm_instance import swarm
        
        for sym, batches in inventory.items():
            asset = sym.replace('/USDT', '').replace('USDT', '')
            current_price = swarm.prices.get(asset, 0.0)
            
            for batch in batches:
                qty = batch["qty"]
                cost = batch["price"] * qty
                locked_margin += cost
                
                if current_price > 0:
                    current_value = qty * current_price
                    unrealized_pnl += (current_value - cost)

        return {
            "daily_pnl": round(daily_pnl, 4),
            "unrealized_pnl": round(unrealized_pnl, 4),
            "win_rate": win_rate,
            "wins": wins,
            "losses": losses,
            "total_closed_today": total_closed,
            "locked_margin": round(locked_margin, 2),
            "engines": {
                name: engine.get_engine_state(name) for name in ["Rigel", "Sirius", "Canopus", "Gemini", "Halal"]
            }
        }
    except Exception as e:
        logger.error(f"Failed to fetch daily stats: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Failed to fetch daily stats: {str(e)}")


@router.get("/success-fees")
def success_fees(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get user's success decision fees statistics"""
    try:
        fees = db.query(SuccessDecisionFee).filter(
            SuccessDecisionFee.user_id == current_user.id
        ).all()

        total_fee = sum(f.fee_amount for f in fees)
        total_profit = sum(f.realized_profit for f in fees)

        return {
            "total_profit": round(total_profit, 2),
            "total_fee": round(total_fee, 2),
            "decisions": len(fees),
            "records": [
                {
                    "id": f.id,
                    "engine_name": f.engine_name,
                    "plan_name": f.plan_name,
                    "realized_profit": round(f.realized_profit, 2),
                    "fee_percentage": f.fee_percentage,
                    "fee_amount": round(f.fee_amount, 2),
                    "created_at": f.created_at.isoformat() if f.created_at else None
                }
                for f in fees
            ]
        }
    except Exception as e:
        logger.error(f"Failed to fetch success fees: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Failed to fetch success fees: {str(e)}")


@router.get("/orderbook/{symbol}")
def get_orderbook(symbol: str, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Get orderbook data and liquidity metrics for a given symbol"""
    try:
        from backend.app.swarm_instance import swarm
        current_price = swarm.prices.get(symbol.replace("-", ""), 0.0)
        
        # If no real price, fallback to a base
        base_price = current_price if current_price > 0 else 68000.0

        return {
            "symbol": symbol,
            "bids": [
                [base_price - 10.5, 0.45], 
                [base_price - 20.2, 1.2], 
                [base_price - 30.0, 3.4], 
                [base_price - 40.1, 0.85], 
                [base_price - 50.0, 1.9]
            ],
            "asks": [
                [base_price + 15.1, 0.95], 
                [base_price + 25.0, 1.5], 
                [base_price + 35.0, 2.1], 
                [base_price + 45.8, 0.72], 
                [base_price + 55.0, 4.25]
            ],
            "buy_pressure": 55,
            "liquidity_score": 75
        }
    except Exception as e:
        logger.error(f"Failed to fetch orderbook for {symbol}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Failed to fetch orderbook: {str(e)}")

