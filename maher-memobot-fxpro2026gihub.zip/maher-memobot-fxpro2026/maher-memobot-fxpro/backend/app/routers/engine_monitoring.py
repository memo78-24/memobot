from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func, desc
from datetime import datetime, timedelta
from pydantic import BaseModel
from typing import Optional
from backend.app.database import get_db, log_activity
from backend.app.security import get_current_user, RoleChecker
from backend.shared.models.user import User
from backend.shared.models.trading import TradeRecord, StrategyState, TradingEngine
from backend.app.engine_instance import engine
import json

router = APIRouter(prefix="/api/engine-monitoring", tags=["Engine Monitoring"])


class EngineConfigPayload(BaseModel):
    strategy: Optional[str] = None
    asset: Optional[str] = None
    amount: Optional[float] = None
    leverage: Optional[float] = None


@router.post("/{engine_id}/configure")
def configure_engine(
    engine_id: str,
    payload: EngineConfigPayload,
    current_user: User = Depends(RoleChecker(["Admin", "Super_Admin", "Trader", "Risk_Officer"])),
    db: Session = Depends(get_db),
):
    """Apply configuration updates to a specific engine"""
    # Map engine IDs to strategy state names (ENG-001 -> Rigel, etc.)
    id_to_name = {
        "ENG-001": "Rigel",
        "ENG-002": "Sirius",
        "ENG-003": "Canopus",
    }
    engine_name = id_to_name.get(engine_id, engine_id)

    # Get or create a TradingEngine row for this engine so we have a valid engine_id FK
    trading_engine_row = db.query(TradingEngine).filter(
        TradingEngine.user_id == current_user.id,
        TradingEngine.engine_name == engine_name,
    ).first()

    if not trading_engine_row:
        trading_engine_row = TradingEngine(
            user_id=current_user.id,
            engine_name=engine_name,
            engine_type="custom",
            status="stopped",
            is_live=False,
        )
        db.add(trading_engine_row)
        db.flush()  # get the auto-generated ID without committing yet

    trading_engine_db_id = trading_engine_row.id

    # Find existing StrategyState for this engine
    row = db.query(StrategyState).filter(
        StrategyState.user_id == current_user.id,
        StrategyState.name == engine_name,
    ).first()

    existing_config = {}
    if row and row.config_json:
        existing_config = json.loads(row.config_json) if isinstance(row.config_json, str) else row.config_json

    if payload.strategy is not None:
        existing_config["strategy"] = payload.strategy
    if payload.asset is not None:
        existing_config["asset"] = payload.asset
    if payload.amount is not None:
        existing_config["amount"] = payload.amount
    if payload.leverage is not None:
        existing_config["leverage"] = payload.leverage

    config_json = json.dumps(existing_config)
    if row:
        row.config_json = config_json
        row.engine_id = trading_engine_db_id  # keep in sync
    else:
        db.add(StrategyState(
            name=engine_name,
            user_id=current_user.id,
            engine_id=trading_engine_db_id,
            strategy_id=None,         # optional — set when strategy is assigned
            mode="Sandbox",
            status="Stopped",
            current_state="idle",
            config_json=config_json,
        ))
    db.commit()

    log_activity(db, f"Engine {engine_id} ({engine_name}) configuration updated", "SUCCESS", user_id=current_user.id)
    return {"status": "SUCCESS", "engine": engine_id, "name": engine_name, "config": existing_config}


@router.get("/overview")
def get_engine_overview(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get overview of all AI engines with health metrics"""
    
    # Get engine mission configurations
    engine_missions = engine.ENGINE_MISSIONS
    
    # Calculate statistics for each engine
    engine_stats = {}
    
    for engine_name in engine_missions.keys():
        # Get recent trades for this engine
        recent_trades = db.query(TradeRecord).filter(
            TradeRecord.engine_name == engine_name,
            TradeRecord.user_id == current_user.id,
            TradeRecord.timestamp >= datetime.utcnow() - timedelta(days=7)
        ).all()
        
        # Calculate metrics
        total_trades = len(recent_trades)
        successful_trades = len([t for t in recent_trades if t.status == "FILLED"])
        win_rate = (successful_trades / total_trades * 100) if total_trades > 0 else 0
        
        total_profit = sum(t.realized_profit for t in recent_trades if t.realized_profit)
        avg_latency = sum(t.latency_ms for t in recent_trades if t.latency_ms) / total_trades if total_trades > 0 else 0
        
        engine_stats[engine_name] = {
            "nickname": engine_missions[engine_name]["nickname"],
            "mission": engine_missions[engine_name]["mission"],
            "timeframe": engine_missions[engine_name]["timeframe"],
            "risk_profile": engine_missions[engine_name]["risk_profile"],
            "status": "Running" if engine.status == "Running" else "Stopped",
            "total_trades_7d": total_trades,
            "win_rate_7d": round(win_rate, 2),
            "total_profit_7d": round(total_profit, 2),
            "avg_latency_ms": round(avg_latency, 2),
            "confidence": round(min(win_rate * 1.2, 99.9), 1) if total_trades > 0 else 50.0
        }
    
    return {
        "engines": engine_stats,
        "overall_status": engine.status,
        "last_updated": datetime.utcnow().isoformat()
    }


@router.get("/{engine_name}/details")
def get_engine_details(
    engine_name: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get detailed monitoring data for a specific engine"""
    
    if engine_name not in engine.ENGINE_MISSIONS:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail=f"Engine '{engine_name}' not found")
    
    # Get all trades for this engine
    trades = db.query(TradeRecord).filter(
        TradeRecord.engine_name == engine_name,
        TradeRecord.user_id == current_user.id
    ).order_by(TradeRecord.timestamp.desc()).limit(100).all()
    
    # Calculate detailed statistics
    total_trades = len(trades)
    successful_trades = len([t for t in trades if t.status == "FILLED"])
    rejected_trades = len([t for t in trades if t.status == "REJECTED"])
    
    win_rate = (successful_trades / total_trades * 100) if total_trades > 0 else 0
    rejection_rate = (rejected_trades / total_trades * 100) if total_trades > 0 else 0
    
    total_profit = sum(t.realized_profit for t in trades if t.realized_profit)
    avg_latency = sum(t.latency_ms for t in trades if t.latency_ms) / total_trades if total_trades > 0 else 0
    avg_slippage = sum(t.slippage_pct for t in trades if t.slippage_pct) / total_trades if total_trades > 0 else 0
    
    # Get recent trade history
    recent_trades = [
        {
            "order_id": t.order_id,
            "symbol": t.symbol,
            "side": t.side,
            "amount": t.amount,
            "price": t.fill_price or t.price,
            "status": t.status,
            "realized_profit": t.realized_profit,
            "latency_ms": t.latency_ms,
            "slippage_pct": t.slippage_pct,
            "timestamp": t.timestamp.isoformat() if t.timestamp else None
        }
        for t in trades[:20]
    ]
    
    # Get engine mission info
    mission = engine.ENGINE_MISSIONS[engine_name]
    
    return {
        "engine_name": engine_name,
        "nickname": mission["nickname"],
        "mission": mission["mission"],
        "timeframe": mission["timeframe"],
        "risk_profile": mission["risk_profile"],
        "max_positions": mission["max_positions"],
        "position_size_pct": mission["position_size_pct"],
        "status": "Running" if engine.status == "Running" else "Stopped",
        "statistics": {
            "total_trades": total_trades,
            "successful_trades": successful_trades,
            "rejected_trades": rejected_trades,
            "win_rate": round(win_rate, 2),
            "rejection_rate": round(rejection_rate, 2),
            "total_profit": round(total_profit, 2),
            "avg_latency_ms": round(avg_latency, 2),
            "avg_slippage_pct": round(avg_slippage, 2)
        },
        "recent_trades": recent_trades,
        "confidence": round(min(win_rate * 1.2, 99.9), 1) if total_trades > 0 else 50.0,
        "learning_status": "Active" if total_trades > 10 else "Calibrating"
    }


@router.get("/health")
def get_engine_health(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get overall engine health status"""
    
    # Check if engine is running
    is_running = engine.status == "Running"
    
    # Get recent trade activity
    recent_activity = db.query(TradeRecord).filter(
        TradeRecord.user_id == current_user.id,
        TradeRecord.timestamp >= datetime.utcnow() - timedelta(minutes=5)
    ).count()
    
    # Calculate health score
    health_score = 100.0 if is_running and recent_activity > 0 else (75.0 if is_running else 50.0)
    
    return {
        "overall_status": engine.status,
        "is_running": is_running,
        "health_score": health_score,
        "recent_activity_5m": recent_activity,
        "mode": engine.mode,
        "live_mode_confirmed": engine.live_mode_confirmed,
        "last_updated": datetime.utcnow().isoformat()
    }
