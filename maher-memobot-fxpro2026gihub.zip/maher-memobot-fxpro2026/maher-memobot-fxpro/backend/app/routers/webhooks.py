import os
import json
import logging
from datetime import datetime, timezone, timedelta
from fastapi import APIRouter, Request, Depends, HTTPException, status
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from backend.app.database import get_db, log_activity
from backend.shared.models.user import User
from backend.shared.models.billing import UserSubscription, SubscriptionPlan, WebhookEvent, PaymentTransaction
from backend.app.services.billing.providers.stripe_provider import StripeProvider
from backend.app.services.notifications.notification_manager import NotificationManager

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/webhooks", tags=["Webhooks"])

stripe_provider = StripeProvider()
webhook_secret = os.getenv("STRIPE_WEBHOOK_SECRET", "")

@router.post("/stripe")
async def stripe_webhook(request: Request, db: Session = Depends(get_db)):
    payload = await request.body()
    sig_header = request.headers.get("stripe-signature")

    if not sig_header:
        raise HTTPException(status_code=400, detail="Missing signature")

    # 1. Verify Signature
    try:
        event = stripe_provider.verify_webhook_signature(payload, sig_header, webhook_secret)
    except ValueError as e:
        logger.error(f"Webhook signature verification failed: {e}")
        raise HTTPException(status_code=400, detail=str(e))
        
    event_id = event.get("id")
    event_type = event.get("type")
    
    # 2. Idempotency Check
    existing_event = db.query(WebhookEvent).filter_by(event_id=event_id).first()
    if existing_event:
        if existing_event.processing_status == "SUCCESS":
            logger.info(f"Ignoring duplicate webhook {event_id}")
            return {"status": "success", "message": "Already processed"}
        else:
            # Retry
            existing_event.processing_status = "PROCESSING"
            existing_event.processed_at = datetime.now(timezone.utc)
            db.commit()
    else:
        new_event = WebhookEvent(
            event_id=event_id,
            provider="Stripe",
            event_type=event_type,
            processing_status="PROCESSING",
            payload_json=json.dumps(event)
        )
        db.add(new_event)
        db.commit()

    # 3. Process Event safely
    try:
        process_stripe_event(db, event)
        
        # Mark as success
        ev = db.query(WebhookEvent).filter_by(event_id=event_id).first()
        ev.processing_status = "SUCCESS"
        db.commit()
        return {"status": "success"}
    except Exception as e:
        db.rollback()
        logger.error(f"Error processing webhook {event_id}: {e}", exc_info=True)
        # Mark as failed for retry
        ev = db.query(WebhookEvent).filter_by(event_id=event_id).first()
        if ev:
            ev.processing_status = "FAILED"
            ev.processing_error = str(e)
            db.commit()
        raise HTTPException(status_code=400, detail="Processing failed")


def process_stripe_event(db: Session, event: dict):
    event_type = event.get("type")
    data = event.get("data", {}).get("object", {})

    if event_type == "checkout.session.completed":
        handle_checkout_completed(db, data)
    elif event_type in ["customer.subscription.created", "customer.subscription.updated"]:
        handle_subscription_updated(db, data)
    elif event_type == "customer.subscription.deleted":
        handle_subscription_deleted(db, data)
    elif event_type in ["invoice.paid", "invoice.payment_succeeded"]:
        handle_invoice_paid(db, data)
    elif event_type in ["invoice.payment_failed", "invoice.payment_action_required"]:
        handle_invoice_failed(db, data)
    elif event_type == "charge.refunded":
        handle_charge_refunded(db, data)
    elif event_type == "customer.deleted":
        handle_customer_deleted(db, data)
    else:
        logger.info(f"Unhandled Stripe event type: {event_type}")

def handle_checkout_completed(db: Session, data: dict):
    customer_id = data.get("customer")
    subscription_id = data.get("subscription")
    metadata = data.get("metadata", {})
    user_id = metadata.get("user_id")
    
    if not user_id and customer_id:
        user = db.query(User).filter_by(provider_customer_id=customer_id).first()
        if user:
            user_id = user.id
            
    if not user_id:
        logger.warning(f"Could not link checkout {data.get('id')} to a user")
        return
        
    user = db.query(User).filter_by(id=user_id).first()
    if user and not user.provider_customer_id:
        user.provider_customer_id = customer_id
        
    log_activity(db, "CHECKOUT_COMPLETED", "SUCCESS", user_id, details=f"Checkout {data.get('id')} complete.")
    db.commit()

def handle_subscription_updated(db: Session, data: dict):
    customer_id = data.get("customer")
    subscription_id = data.get("id")
    status = data.get("status") # active, past_due, canceled, unpaid
    
    # Get plan name from Stripe Price ID
    # In a real app we might fetch the line items, here we check the first item
    items = data.get("items", {}).get("data", [])
    if not items:
        return
    price_id = items[0].get("price", {}).get("id")
    
    user = db.query(User).filter_by(provider_customer_id=customer_id).first()
    if not user:
        return
        
    # Reverse map price ID to our plan
    plan_name = "Pro" if "pro" in price_id.lower() else ("Elite" if "elite" in price_id.lower() else "Free")
    plan = db.query(SubscriptionPlan).filter_by(name=plan_name).first()
    if not plan:
        return
        
    sub = db.query(UserSubscription).filter_by(user_id=user.id).first()
    if not sub:
        return # Shouldn't happen since Free is auto-provisioned
        
    sub.plan_id = plan.id
    sub.provider = "Stripe"
    sub.provider_subscription_id = subscription_id
    sub.status = "ACTIVE" if status in ["active", "trialing"] else "PAST_DUE"
    sub.cancel_at_period_end = data.get("cancel_at_period_end", False)
    
    # Timestamps
    current_period_end = data.get("current_period_end")
    if current_period_end:
        sub.current_period_end = datetime.fromtimestamp(current_period_end, timezone.utc)
        
    sub.grace_period_ends_at = None
    sub.updated_at = datetime.now(timezone.utc)
    
    db.commit()
    NotificationManager.send_notification(
        db, user.id, "Subscription Updated",
        f"Your subscription is now {plan.name} and expires {sub.current_period_end.strftime('%Y-%m-%d')}.",
        "SUCCESS"
    )

def handle_subscription_deleted(db: Session, data: dict):
    customer_id = data.get("customer")
    user = db.query(User).filter_by(provider_customer_id=customer_id).first()
    if not user:
        return
        
    free_plan = db.query(SubscriptionPlan).filter_by(name="Free").first()
    sub = db.query(UserSubscription).filter_by(user_id=user.id).first()
    
    if sub and sub.plan_id != free_plan.id:
        sub.plan_id = free_plan.id
        sub.status = "ACTIVE"
        sub.provider_subscription_id = None
        sub.current_period_end = datetime.now(timezone.utc) + timedelta(days=3650)
        sub.cancel_at_period_end = False
        db.commit()
        
        NotificationManager.send_notification(
            db, user.id, "Subscription Cancelled",
            "Your paid subscription has ended. You are now on the Free plan. Live positions can no longer be opened.",
            "ALERT"
        )

def handle_invoice_paid(db: Session, data: dict):
    customer_id = data.get("customer")
    amount = data.get("amount_paid", 0) / 100.0 # cents to dollars
    currency = data.get("currency", "usd")
    
    user = db.query(User).filter_by(provider_customer_id=customer_id).first()
    if not user:
        return
        
    txn = PaymentTransaction(
        user_id=user.id,
        provider_payment_intent_id=data.get("payment_intent"),
        provider_charge_id=data.get("charge"),
        amount=amount,
        amount_usdt=amount,
        currency=currency,
        status="succeeded"
    )
    db.add(txn)
    
    log_activity(db, "INVOICE_PAID", "SUCCESS", user.id, details=f"Paid {amount} {currency}")
    db.commit()

def handle_invoice_failed(db: Session, data: dict):
    customer_id = data.get("customer")
    amount = data.get("amount_due", 0) / 100.0
    currency = data.get("currency", "usd")
    
    user = db.query(User).filter_by(provider_customer_id=customer_id).first()
    if not user:
        return
        
    txn = PaymentTransaction(
        user_id=user.id,
        provider_payment_intent_id=data.get("payment_intent"),
        provider_charge_id=data.get("charge"),
        amount=amount,
        amount_usdt=amount,
        currency=currency,
        status="failed",
        failure_reason="Payment action required or failed"
    )
    db.add(txn)
    
    sub = db.query(UserSubscription).filter_by(user_id=user.id).first()
    if sub:
        sub.status = "PAST_DUE"
        # Start a 3-day grace period
        sub.grace_period_ends_at = datetime.now(timezone.utc) + timedelta(days=3)
        
    NotificationManager.send_notification(
        db, user.id, "Payment Failed",
        "Your recent subscription payment failed. Please update your payment method to avoid interruption.",
        "ERROR"
    )
    db.commit()

def handle_charge_refunded(db: Session, data: dict):
    charge_id = data.get("id")
    amount_refunded = data.get("amount_refunded", 0) / 100.0
    
    logger.info(f"Handling charge.refunded for {charge_id}, amount {amount_refunded}")
    txn = db.query(PaymentTransaction).filter(PaymentTransaction.provider_charge_id == charge_id).first()
    if txn:
        logger.info(f"Found txn {txn.id}, updating to refunded")
        txn.status = "refunded"
        txn.refunded_amount = amount_refunded
        log_activity(db, "PAYMENT_REFUNDED", "SUCCESS", txn.user_id, details=f"Refunded {amount_refunded} {txn.currency}")
        db.commit()
    else:
        logger.warning(f"Txn {charge_id} not found for refund")

def handle_customer_deleted(db: Session, data: dict):
    customer_id = data.get("id")
    user = db.query(User).filter_by(provider_customer_id=customer_id).first()
    if user:
        user.provider_customer_id = None
        db.commit()
