from fastapi import APIRouter, Depends, HTTPException, status, Request, Response, Body
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from backend.app.database import get_db, log_activity
from backend.shared.models.user import User
from backend.shared.models.trading import PaperBalance
from backend.app.security import create_access_token, verify_password, get_current_user, hash_password_secure, RoleChecker
from backend.app.schemas.auth import (
    Token, UserResponse, UserCreate, ChangePasswordRequest,
    VerifyEmailCodeRequest, ResendEmailCodeRequest, VerifyUserRequest, LoginRequest,
    ForgotPasswordRequest, ResetPasswordRequest, RefreshTokenRequest, Enable2FAResponse, Verify2FARequest
)
from backend.app.rate_limiting import limiter

# Import the new service modules
from backend.app.services.auth.register_service import register_new_user
from backend.app.services.auth.email_verification_service import verify_email_code, resend_email_code
from backend.app.services.auth.login_service import verify_user_exists, login_user
from backend.app.services.auth.telegram_link_service import start_telegram_link, get_telegram_link_status
from backend.app.services.auth.password_reset_service import request_password_reset, reset_password_with_code
import jwt
import datetime
from backend.app.config import JWT_SECRET
from backend.app.security import create_access_token

router = APIRouter(prefix="/api/auth", tags=["Authentication"])

@router.post("/register")
@limiter.limit("10/minute")
def register(request: Request, payload: UserCreate, db: Session = Depends(get_db)):
    try:
        return register_new_user(db, payload.model_dump())
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/verify-email-code")
@limiter.limit("5/minute")
def verify_email_code_route(request: Request, payload: VerifyEmailCodeRequest, db: Session = Depends(get_db)):
    try:
        return verify_email_code(db, payload.username, payload.email, payload.code)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/resend-email-code")
@limiter.limit("2/minute")
def resend_email_code_route(request: Request, payload: ResendEmailCodeRequest, db: Session = Depends(get_db)):
    try:
        return resend_email_code(db, payload.username, payload.email)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/verify-user")
@limiter.limit("10/minute")
def verify_user_route(request: Request, payload: VerifyUserRequest, db: Session = Depends(get_db)):
    return verify_user_exists(db, payload.username)

@router.post("/login")
@limiter.limit("10/minute")
def login(request: Request, form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    # Fallback to OAuth2 form data to not break Swagger UI / old integrations if they still use standard form login
    try:
        return login_user(db, form_data.username, form_data.password)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=str(e),
            headers={"WWW-Authenticate": "Bearer"},
        )

@router.post("/login-json")
@limiter.limit("50/minute")
def login_json(request: Request, payload: LoginRequest, response: Response, db: Session = Depends(get_db)):
    # New endpoint for JSON based username-first login step 2
    try:
        user_agent = request.headers.get("user-agent", "")
        ip_address = request.client.host if request.client else ""
        result = login_user(db, payload.username, payload.password, payload.totp_code, ip_address, user_agent)
        
        if result.get("refresh_token"):
            response.set_cookie(
                key="refresh_token",
                value=result["refresh_token"],
                httponly=True,
                secure=True,
                samesite="lax",
                max_age=7 * 24 * 60 * 60 # 7 days
            )
            del result["refresh_token"]
            
        return result
    except ValueError as e:
        raise HTTPException(status_code=401, detail=str(e))

@router.post("/refresh")
@limiter.limit("10/minute")
def refresh_token(request: Request, response: Response, payload: RefreshTokenRequest, db: Session = Depends(get_db)):
    from backend.shared.models.user import UserSession
    import uuid
    import secrets
    from backend.app.security import create_refresh_token
    import datetime
    
    token_str = request.cookies.get("refresh_token") or payload.refresh_token
    if not token_str:
        raise HTTPException(status_code=401, detail="Refresh token missing")
        
    try:
        token_payload = jwt.decode(token_str, JWT_SECRET, algorithms=["HS256"])
        username = token_payload.get("sub")
        token_type = token_payload.get("type")
        jti = token_payload.get("jti")
        
        if not username or token_type != "refresh" or not jti:
            raise HTTPException(status_code=401, detail="Invalid refresh token")
            
        user = db.query(User).filter(User.username == username, User.is_active == True).first()
        if not user:
            raise HTTPException(status_code=401, detail="User not found or inactive")
            
        session = db.query(UserSession).filter_by(refresh_token_jti=jti).first()
        if not session:
            raise HTTPException(status_code=401, detail="Session not found")
            
        if session.is_revoked:
            db.query(UserSession).filter_by(user_id=user.id).update({"is_revoked": True})
            db.commit()
            raise HTTPException(status_code=401, detail="Token reuse detected. All sessions revoked.")
            
        session.is_revoked = True
        
        new_jti = str(uuid.uuid4())
        new_refresh = create_refresh_token(data={"sub": user.username, "role": user.role, "jti": new_jti})
        
        user_agent = request.headers.get("user-agent", "")
        ip_address = request.client.host if request.client else ""
        
        new_session = UserSession(
            user_id=user.id,
            session_token=secrets.token_urlsafe(32),
            refresh_token=new_refresh,
            refresh_token_jti=new_jti,
            device_info=user_agent,
            user_agent=user_agent,
            ip_address=ip_address,
            expires_at=datetime.datetime.utcnow() + datetime.timedelta(days=7)
        )
        db.add(new_session)
        db.commit()
        
        response.set_cookie(
            key="refresh_token",
            value=new_refresh,
            httponly=True,
            secure=True,
            samesite="lax",
            max_age=7 * 24 * 60 * 60
        )
            
        access_token = create_access_token(data={"sub": user.username, "role": user.role})
        return {"success": True, "token": access_token}
    except jwt.PyJWTError:
        raise HTTPException(status_code=401, detail="Invalid refresh token")

@router.post("/logout")
@limiter.limit("10/minute")
def logout_user(request: Request, response: Response, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    from backend.shared.models.user import UserSession
    log_activity(db, "LOGOUT", "SUCCESS", current_user.id)
    
    token_str = request.cookies.get("refresh_token")
    if token_str:
        try:
            token_payload = jwt.decode(token_str, JWT_SECRET, algorithms=["HS256"])
            jti = token_payload.get("jti")
            if jti:
                db.query(UserSession).filter_by(refresh_token_jti=jti).update({"is_revoked": True, "revoked_at": datetime.datetime.utcnow()})
                db.commit()
        except jwt.PyJWTError:
            pass
            
    response.delete_cookie("refresh_token")
    return {"success": True, "message": "Logged out successfully"}

@router.post("/enable-2fa", response_model=Enable2FAResponse)
@limiter.limit("5/minute")
def enable_2fa(request: Request, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    import pyotp
    from backend.app.security import encrypt_secret
    if current_user.is_2fa_enabled:
        raise HTTPException(status_code=400, detail="2FA is already enabled")
        
    secret = pyotp.random_base32()
    uri = pyotp.totp.TOTP(secret).provisioning_uri(name=current_user.email, issuer_name="MemoBot FX-PRO")
    
    current_user.encrypted_totp_secret = encrypt_secret(secret)
    db.commit()
    
    return {"secret": secret, "provisioning_uri": uri}

@router.post("/verify-2fa")
@limiter.limit("5/minute")
def verify_2fa(request: Request, payload: Verify2FARequest, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    import pyotp
    from backend.app.security import decrypt_secret
    
    if not current_user.encrypted_totp_secret:
        raise HTTPException(status_code=400, detail="2FA not initiated")
        
    secret = decrypt_secret(current_user.encrypted_totp_secret)
    totp = pyotp.TOTP(secret)
    
    if not totp.verify(payload.totp_code):
        raise HTTPException(status_code=400, detail="Invalid 2FA code")
        
    current_user.is_2fa_enabled = True
    db.commit()
    log_activity(db, "2FA_ENABLED", "SUCCESS", current_user.id)
    
    return {"success": True, "message": "2FA successfully verified and enabled"}

@router.post("/forgot-password")
@limiter.limit("5/minute")
def forgot_password(request: Request, payload: ForgotPasswordRequest, db: Session = Depends(get_db)):
    return request_password_reset(db, payload.email)

@router.post("/reset-password")
@limiter.limit("5/minute")
def reset_password(request: Request, payload: ResetPasswordRequest, db: Session = Depends(get_db)):
    try:
        return reset_password_with_code(db, payload.email, payload.code, payload.new_password)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/telegram/start-link")
@limiter.limit("3/minute")
def telegram_start_link(request: Request, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return start_telegram_link(db, current_user)

@router.get("/telegram/link-status")
def telegram_link_status(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return get_telegram_link_status(db, current_user)

@router.get("/me", response_model=UserResponse)
def read_users_me(current_user: User = Depends(get_current_user)):
    return current_user

@router.post("/change-password")
def change_password(
    payload: ChangePasswordRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    if not verify_password(payload.old_password, current_user.password_hash):
        raise HTTPException(status_code=400, detail="Incorrect old password")

    current_user.password_hash = hash_password_secure(payload.new_password)
    db.commit()
    log_activity(db, "Password changed", "SUCCESS", user_id=current_user.id,
                 details=f"User: {current_user.username}")
    return {"message": "Password updated successfully"}


# --- Admin User Management Endpoints ---

@router.get("/admin/users")
def get_all_users(
    current_user: User = Depends(RoleChecker(["Admin", "Super Admin"])),
    db: Session = Depends(get_db)
):
    """Get all users for admin management"""
    users = db.query(User).all()
    return {
        "users": [
            {
                "id": u.id,
                "username": u.username,
                "email": u.email,
                "role": u.role,
                "is_active": u.is_active,
                "created_at": u.created_at.isoformat() if u.created_at else None,
                "last_login": u.last_login_at.isoformat() if u.last_login_at else None
            }
            for u in users
        ]
    }

@router.post("/admin/users/{user_id}/suspend")
def suspend_user(
    user_id: int,
    current_user: User = Depends(RoleChecker(["Admin", "Super Admin"])),
    db: Session = Depends(get_db)
):
    """Suspend a user account"""
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    user.is_active = False
    db.commit()
    log_activity(db, "ADMIN_SUSPEND_USER", "SUCCESS", current_user.id, details=f"Suspended user {user_id}")
    return {"message": f"User {user.username} suspended successfully"}

@router.post("/admin/users/{user_id}/activate")
def activate_user(
    user_id: int,
    current_user: User = Depends(RoleChecker(["Admin", "Super Admin"])),
    db: Session = Depends(get_db)
):
    """Activate a suspended user account"""
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    user.is_active = True
    db.commit()
    log_activity(db, "ADMIN_ACTIVATE_USER", "SUCCESS", current_user.id, details=f"Activated user {user_id}")
    return {"message": f"User {user.username} activated successfully"}

@router.post("/admin/users/{user_id}/reset-password")
def admin_reset_password(
    user_id: int,
    new_password: str = Body(..., embed=True),
    current_user: User = Depends(RoleChecker(["Admin", "Super Admin"])),
    db: Session = Depends(get_db)
):
    """Reset a user's password (admin only)"""
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    user.password_hash = hash_password_secure(new_password)
    db.commit()
    log_activity(db, "ADMIN_RESET_PASSWORD", "SUCCESS", current_user.id, details=f"Reset password for user {user_id}")
    return {"message": f"Password reset for user {user.username}"}

@router.post("/admin/users/{user_id}/reset-api")
def admin_reset_api_keys(
    user_id: int,
    current_user: User = Depends(RoleChecker(["Admin", "Super Admin"])),
    db: Session = Depends(get_db)
):
    """Reset a user's API keys (admin only)"""
    from backend.shared.models.vault import SecretsVault
    
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Delete all API keys for this user
    db.query(SecretsVault).filter(SecretsVault.user_id == user_id).delete()
    db.commit()
    log_activity(db, "ADMIN_RESET_API", "SUCCESS", current_user.id, details=f"Reset API keys for user {user_id}")
    return {"message": f"API keys reset for user {user.username}"}

@router.post("/admin/users/{user_id}/promote")
def promote_user(
    user_id: int,
    new_role: str = Body(..., embed=True),
    current_user: User = Depends(RoleChecker(["Super Admin"])),
    db: Session = Depends(get_db)
):
    """Promote/demote user role (Super Admin only)"""
    valid_roles = ["User", "Trader", "Admin", "Super Admin"]
    if new_role not in valid_roles:
        raise HTTPException(status_code=400, detail=f"Invalid role. Must be one of: {valid_roles}")
    
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    old_role = user.role
    user.role = new_role
    db.commit()
    log_activity(db, "ADMIN_PROMOTE_USER", "SUCCESS", current_user.id, 
                details=f"Changed user {user_id} role from {old_role} to {new_role}")
    return {"message": f"User {user.username} role changed to {new_role}"}
