import json
from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy.orm import Session

from backend.app.database import get_db
from backend.shared.models.user import User
from backend.shared.models.trading import StrategyState
from backend.app.security import get_current_user

router = APIRouter(prefix="/api/risk", tags=["Risk Configuration"])


class RiskMatrixUpdate(BaseModel):
    max_drawdown: float
    leverage_limit: float


@router.get("/config/{engine_name}")
def get_risk_config(engine_name: str, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    row = db.query(StrategyState).filter(
        StrategyState.user_id == current_user.id,
        StrategyState.name == engine_name.capitalize(),
    ).first()
    if row and row.config_json:
        config = json.loads(row.config_json) if isinstance(row.config_json, str) else row.config_json
        return {
            "max_drawdown": float(config.get("max_drawdown", 25.0)),
            "leverage_limit": float(config.get("leverage_limit", 1.0)),
        }
    return {"max_drawdown": 25.0, "leverage_limit": 1.0}


@router.post("/config/{engine_name}")
def update_risk_config(
    engine_name: str,
    payload: RiskMatrixUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    config_json = json.dumps({
        "max_drawdown": payload.max_drawdown,
        "leverage_limit": payload.leverage_limit,
    })
    row = db.query(StrategyState).filter(
        StrategyState.user_id == current_user.id,
        StrategyState.name == engine_name.capitalize(),
    ).first()
    if row:
        row.config_json = config_json
    else:
        db.add(StrategyState(
            name=engine_name.capitalize(),
            user_id=current_user.id,
            mode="Sandbox",
            status="Stopped",
            config_json=config_json,
        ))
    db.commit()
    return {"status": "SUCCESS", "message": f"Risk limits updated for {engine_name}."}


@router.get("/settings")
def get_all_risk_settings(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Get aggregated risk settings for all engines (frontend compatibility)"""
    settings = {}
    for engine_name in ["Rigel", "Sirius", "Canopus"]:
        row = db.query(StrategyState).filter(
            StrategyState.user_id == current_user.id,
            StrategyState.name == engine_name,
        ).first()
        if row and row.config_json:
            config = json.loads(row.config_json) if isinstance(row.config_json, str) else row.config_json
        else:
            config = {}
        settings[engine_name] = {
            "max_drawdown": float(config.get("max_drawdown", 25.0)),
            "leverage_limit": float(config.get("leverage_limit", 1.0)),
            "stealth_mode": bool(config.get("stealth_mode", False)),
            "auto_kill_switch_enabled": bool(config.get("auto_kill_switch_enabled", True)),
            "shariah_guard_enabled": bool(config.get("shariah_guard_enabled", True)),
        }
    return settings


class GlobalRiskSettings(BaseModel):
    max_drawdown_pct: float = 25.0
    max_leverage: float = 1.0
    stealth_mode: bool = False
    auto_kill_switch_enabled: bool = True
    shariah_guard_enabled: bool = True


@router.post("/settings")
def save_all_risk_settings(
    payload: GlobalRiskSettings,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Save global risk settings for all engines (frontend compatibility)"""
    for engine_name in ["Rigel", "Sirius", "Canopus"]:
        config_json = json.dumps({
            "max_drawdown": payload.max_drawdown_pct,
            "leverage_limit": payload.max_leverage,
            "stealth_mode": payload.stealth_mode,
            "auto_kill_switch_enabled": payload.auto_kill_switch_enabled,
            "shariah_guard_enabled": payload.shariah_guard_enabled,
        })
        row = db.query(StrategyState).filter(
            StrategyState.user_id == current_user.id,
            StrategyState.name == engine_name,
        ).first()
        if row:
            row.config_json = config_json
        else:
            db.add(StrategyState(
                name=engine_name,
                user_id=current_user.id,
                mode="Sandbox",
                status="Stopped",
                config_json=config_json,
            ))
    db.commit()
    return {"status": "SUCCESS", "message": "Global risk settings saved for all engines."}
