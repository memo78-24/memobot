from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from backend.app.database import get_db
from backend.shared.models.user import User
from backend.app.security import get_current_user
from backend.app.services.notifications.notification_manager import NotificationManager

router = APIRouter(prefix="/api/notifications", tags=["Notifications"])

@router.get("/")
def get_unread_notifications(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Fetch unread dashboard notifications"""
    notifs = NotificationManager.get_unread_notifications(db, current_user.id)
    return [{
        "id": n.id,
        "title": n.title,
        "message": n.message,
        "type": n.type,
        "created_at": n.created_at
    } for n in notifs]

@router.post("/{notification_id}/read")
def mark_notification_read(notification_id: int, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Mark a notification as read"""
    success = NotificationManager.mark_as_read(db, notification_id, current_user.id)
    if not success:
        raise HTTPException(status_code=404, detail="Notification not found")
    return {"success": True, "message": "Notification marked as read"}
