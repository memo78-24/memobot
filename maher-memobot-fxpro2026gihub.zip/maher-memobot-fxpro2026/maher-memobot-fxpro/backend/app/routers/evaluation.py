from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from typing import Dict, Any
from backend.app.evaluation import compute_market_score
from backend.app.database import get_db
from backend.shared.models.user import User
from backend.app.security import get_current_user

router = APIRouter(prefix="/api/evaluation", tags=["Evaluation System"])

class EvaluationRequest(BaseModel):
    symbol: str
    side: str
    engine: str

@router.post("/market-score")
async def get_market_score(payload: EvaluationRequest, current_user: User = Depends(get_current_user), db=Depends(get_db)):
    try:
        symbol = payload.symbol.upper()
        if "USDT" in symbol and "/" not in symbol:
            symbol = symbol.replace("USDT", "/USDT")

        result = await compute_market_score(
            symbol=symbol,
            side=payload.side.upper(),
            engine=payload.engine,
            user_id=current_user.id,
            db=db,
        )
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Market score evaluation error: {str(e)}")

@router.get("/order-book")
async def get_live_order_book(symbol: str = "BTC/USDT", current_user: User = Depends(get_current_user)):
    try:
        symbol = symbol.upper()
        if "USDT" in symbol and "/" not in symbol:
            symbol = symbol.replace("USDT", "/USDT")
            
        from backend.app.market_data import market_data
        ob = await market_data.get_order_book(symbol)
        return ob or {"bids": [], "asks": []}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch live order book: {str(e)}")
