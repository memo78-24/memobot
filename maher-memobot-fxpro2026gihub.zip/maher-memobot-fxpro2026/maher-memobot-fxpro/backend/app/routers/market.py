from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from backend.app.database import get_db
from backend.app.security import get_current_user
from backend.shared.models.user import User
from typing import List, Optional
from datetime import datetime, timedelta

router = APIRouter(prefix="/api/market", tags=["Market Data"])

# Alternative router for frontend compatibility with /api/market-intel path
market_intel_router = APIRouter(prefix="/api/market-intel", tags=["Market Intel"])


@router.get("/prices")
def get_market_prices(current_user: User = Depends(get_current_user)):
    """Get live market ticker prices"""
    # Demo implementation - in production this would fetch from exchange API
    return {
        "BTCUSDT": {
            "price": 43250.50,
            "change_24h": 2.5,
            "volume_24h": 12500000000
        },
        "ETHUSDT": {
            "price": 2280.75,
            "change_24h": 1.8,
            "volume_24h": 8500000000
        },
        "SOLUSDT": {
            "price": 98.45,
            "change_24h": -0.5,
            "volume_24h": 1200000000
        }
    }


@router.get("/candles")
def get_market_candles(
    symbol: str = "BTCUSDT",
    tf: str = "1h",
    limit: int = 100,
    current_user: User = Depends(get_current_user)
):
    """Get OHLCV candle data for a symbol"""
    # Demo implementation - in production this would fetch from exchange API
    candles = []
    base_price = 43250.50 if symbol == "BTCUSDT" else 2280.75
    
    for i in range(limit):
        timestamp = datetime.utcnow() - timedelta(hours=i)
        open_price = base_price + (i * 10)
        close_price = open_price + (5 if i % 2 == 0 else -5)
        high_price = max(open_price, close_price) + 2
        low_price = min(open_price, close_price) - 2
        
        candles.append({
            "timestamp": timestamp.isoformat(),
            "open": open_price,
            "high": high_price,
            "low": low_price,
            "close": close_price,
            "volume": 1000000 + (i * 10000)
        })
    
    return {
        "symbol": symbol,
        "timeframe": tf,
        "candles": candles
    }


@router.get("/intel/top50")
def get_market_intel_top50(current_user: User = Depends(get_current_user)):
    """Get top 50 market intelligence items"""
    # Demo implementation - in production this would fetch from market data service
    intel_items = []
    
    for i in range(50):
        intel_items.append({
            "id": f"intel_{i}",
            "symbol": ["BTCUSDT", "ETHUSDT", "SOLUSDT"][i % 3],
            "type": ["BREAKOUT", "TREND", "VOLATILITY"][i % 3],
            "confidence": 0.7 + (i % 3) * 0.1,
            "timestamp": (datetime.utcnow() - timedelta(minutes=i)).isoformat(),
            "details": f"Market intelligence item {i} - demo data"
        })
    
    return {
        "data": intel_items,
        "count": 50
    }


@market_intel_router.get("/top50")
def get_market_intel_top50_alt(current_user: User = Depends(get_current_user)):
    """Get top 50 market intelligence items (alternative path for frontend compatibility)"""
    assets = []
    symbols = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "BNBUSDT", "ADAUSDT", "XRPUSDT", "DOGEUSDT", "DOTUSDT", "MATICUSDT", "LINKUSDT"]
    
    for i in range(50):
        symbol = symbols[i % len(symbols)]
        assets.append({
            "rank": i + 1,
            "symbol": symbol,
            "name": symbol.replace("USDT", ""),
            "status": "COMPLIANT" if i % 3 != 0 else "NON-COMPLIANT",
            "group": "MAJOR" if i < 10 else "ALT",
            "vol24h": f"{(1000000000 + i * 100000000):,}",
            "audit": "APPROVED" if i % 2 == 0 else "PENDING",
            "volatility": ["LOW", "MEDIUM", "HIGH"][i % 3],
            "price": 43250.50 + (i * 100) if symbol == "BTCUSDT" else 2280.75 + (i * 10),
            "change24h": 2.5 + (i % 5) * 0.5
        })
    
    return {
        "data": assets,
        "count": 50
    }


# Gateway status endpoint for frontend compatibility
gateway_router = APIRouter(prefix="/api/gateway", tags=["Gateway"])

@gateway_router.get("/status")
def get_gateway_status(current_user: User = Depends(get_current_user)):
    """Get gateway status"""
    return {
        "status": "operational",
        "connections": {
            "binance": "connected",
            "telegram": "connected",
            "whatsapp": "disconnected",
            "gemini": "connected"
        },
        "last_updated": datetime.utcnow().isoformat()
    }
