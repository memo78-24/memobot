from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from backend.app.database import get_db, log_activity
from backend.shared.models.user import User
from backend.shared.models.vault import VaultCredentials, SecretsVault
from backend.app.security import RoleChecker, encrypt_secret, decrypt_secret
from backend.app.schemas.vault import VaultCredentialsUpdate
import logging

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/vault", tags=["Secrets Vault"])

@router.post("/credentials")
async def update_credentials(payload: VaultCredentialsUpdate, current_user: User = Depends(RoleChecker(["Admin", "Trader", "user", "User"])), db: Session = Depends(get_db)):
    new_key = (payload.api_key or "").strip()
    new_secret = (payload.api_secret or "").strip()

    logger.info(f"Vault save request: service={payload.service} key_len={len(new_key)} secret_len={len(new_secret)}")

    # CLEAR command
    if new_key == "CLEAR" or new_secret == "CLEAR":
        vault_entry = db.query(SecretsVault).filter(
            SecretsVault.user_id == current_user.id,
            SecretsVault.exchange_name == payload.service
        ).first()
        if vault_entry:
            db.delete(vault_entry)
            db.commit()
            log_activity(db, f"API credentials cleared for {payload.service}", "SUCCESS", user_id=current_user.id)
        return {"message": "Credentials successfully cleared from vault."}

    # Nothing provided at all
    if not new_key and not new_secret:
        return {"message": f"Existing credentials for {payload.service} kept in vault (nothing provided)."}

    # Load or create the vault entry
    vault_entry = db.query(SecretsVault).filter(
        SecretsVault.user_id == current_user.id,
        SecretsVault.exchange_name == payload.service
    ).first()

    if vault_entry:
        # Only update the fields that were actually provided
        if new_key:
            vault_entry.api_key_encrypted = encrypt_secret(new_key)
            logger.info(f"Updated API key for {payload.service} (starts: {new_key[:10]}...)")
        if new_secret:
            vault_entry.api_secret_encrypted = encrypt_secret(new_secret)
            logger.info(f"Updated API secret for {payload.service} (starts: {new_secret[:6]}...)")
    else:
        if not new_key or not new_secret:
            return {"message": "Please provide both API Key and Secret for a new entry."}
        vault_entry = SecretsVault(
            user_id=current_user.id, exchange_name=payload.service,
            api_key_encrypted=encrypt_secret(new_key),
            api_secret_encrypted=encrypt_secret(new_secret)
        )
        db.add(vault_entry)
        logger.info(f"Created new vault entry for {payload.service}")

    db.commit()
    log_activity(db, f"API credentials updated for {payload.service}", "SUCCESS", user_id=current_user.id)

    # If Binance credentials were just saved, force client re-init and immediately refresh live balance cache
    if payload.service.lower() == "binance":
        try:
            from backend.app.engine_instance import engine as exec_engine
            exec_engine.binance_client = None  # Reset client so it re-decrypts new keys on next request
            from backend.app.services.balance_cache import refresh_balances_from_binance
            # This endpoint is now async and runs on the real event loop, so we can just
            # await the refresh directly instead of scheduling it on a loop that may
            # never run (the old get_event_loop()/ensure_future() approach silently no-op'd
            # when this handler executed in FastAPI's sync threadpool).
            await refresh_balances_from_binance()
            logger.info("Immediate balance refresh completed after credential save.")
        except Exception as refresh_err:
            logger.warning(f"Could not trigger immediate balance refresh: {refresh_err}")

    return {"message": "Credentials successfully encrypted and saved to vault."}


@router.post("/test-connection")
async def test_vault_connection(payload: VaultCredentialsUpdate,
    current_user: User = Depends(RoleChecker(["Admin", "Trader"])),
    db: Session = Depends(get_db)):
    import ccxt.async_support as ccxt
    from backend.app.binance_client import BinanceClientWrapper

    if payload.service.capitalize() != "Binance":
        raise HTTPException(status_code=400, detail="Only Binance connectivity testing is currently supported.")

    api_key = payload.api_key
    api_secret = payload.api_secret
    if not api_key or not api_secret:
        vault_entry = db.query(SecretsVault).filter(
            SecretsVault.user_id == current_user.id,
            SecretsVault.exchange_name == payload.service
        ).first()
        if not vault_entry:
            raise HTTPException(status_code=400, detail="No stored credentials found in vault to test.")
        try:
            api_key = decrypt_secret(vault_entry.api_key_encrypted)
            api_secret = decrypt_secret(vault_entry.api_secret_encrypted)
        except Exception:
            raise HTTPException(status_code=500, detail="Failed to decrypt stored credentials.")

    connected_net = None
    client_wrapper = None
    success = False

    for testnet in [False]:  # ONLY TEST MAINNET (Live Mode Enforcement)
        wrapper = None
        try:
            wrapper = BinanceClientWrapper(testnet=testnet)
            wrapper.api_key = api_key
            wrapper.api_secret = api_secret
            wrapper.client = ccxt.binance({
                'apiKey': api_key, 'secret': api_secret,
                'enableRateLimit': True, 'options': {'defaultType': 'spot'}
            })
            wrapper.client.set_sandbox_mode(testnet)
            wrapper.is_configured = True
            await wrapper.client.fetch_balance({'type': 'spot'})
            client_wrapper = wrapper
            connected_net = "Mainnet"
            success = True
            break
        except Exception as e:
            logger.debug(f"Connection attempt failed for Mainnet: {str(e)[:100]}")
            if wrapper and wrapper.client:
                try:
                    await wrapper.client.close()
                except Exception as cleanup_err:
                    logger.debug(f"Cleanup error: {cleanup_err}")

    if not success:
        raise HTTPException(status_code=401, detail="Authentication failed: Invalid credentials or connectivity error.")

    try:
        res = await client_wrapper.fetch_all_balances()
        if not res.get("success"):
            raise Exception("Balance fetch failed")
        
        # Check API key permissions for user transparency
        permissions_summary = "Spot & Reading Active"
        try:
            perms = await client_wrapper._request("GET", "/sapi/v1/account/apiRestrictions", signed=True)
            active_perms = []
            if perms.get("enableReading"): active_perms.append("Reading")
            if perms.get("enableSpotAndMarginTrading"): active_perms.append("Spot Trading")
            if perms.get("enableFutures"): active_perms.append("Futures")
            if perms.get("enableMargin"): active_perms.append("Margin")
            if active_perms:
                permissions_summary = ", ".join(active_perms)
        except Exception as p_err:
            logger.debug(f"Could not fetch apiRestrictions: {p_err}")

        return {
            "success": True,
            "message": f"Binance {connected_net} Connection Successful. [{permissions_summary}]",
            "network": connected_net,
            "permissions": permissions_summary,
            "net_worth": res["net_worth"],
            "breakdown": res["breakdown"],
            "asset_totals": res["asset_totals"]
        }
    except Exception as e:
        logger.error(f"Balance fetch failed: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Connection failed during balance retrieval: {str(e)}")
    finally:
        # Always close the client connection properly
        if client_wrapper and client_wrapper.client:
            try:
                await client_wrapper.client.close()
            except Exception as cleanup_err:
                logger.debug(f"Final cleanup error: {cleanup_err}")

@router.post("/test-telegram")
async def test_telegram_connection(payload: VaultCredentialsUpdate,
    current_user: User = Depends(RoleChecker(["Admin", "Trader"])),
    db: Session = Depends(get_db)):
    import httpx, os
    bot_token = payload.api_key
    chat_id = payload.api_secret
    if not bot_token or not chat_id:
        vault_token = db.query(SecretsVault).filter(
            SecretsVault.user_id == current_user.id, SecretsVault.exchange_name == "Telegram"
        ).first()
        if vault_token:
            try:
                bot_token = decrypt_secret(vault_token.api_key_encrypted)
                chat_id = decrypt_secret(vault_token.api_secret_encrypted)
            except Exception:
                raise HTTPException(status_code=500, detail="Failed to decrypt stored Telegram credentials.")
    if not bot_token or not chat_id or bot_token.strip() == "" or chat_id.strip() == "":
        raise HTTPException(status_code=400, detail="Telegram Bot Token and Chat ID must be configured in vault.")

    text_content = (
        "🔴 MEMOBOT | FX-PRO A Premium AI TRADING PLATFORM\n"
        "🪙we not just give signals!!! we \"PROTECT YOUR CAPITAL FIRST\"🪙\n\n"
        "🔴 ميمو بوت | إف إكس برو\n🪙نحن نحمي رأس مالك أولاً🪙"
    )
    try:
        logo_path = "frontend/src/logo.png"
        if os.path.exists(logo_path):
            url = f"https://api.telegram.org/bot{bot_token}/sendPhoto"
            with open(logo_path, "rb") as f:
                async with httpx.AsyncClient() as client:
                    resp = await client.post(url, data={"chat_id": chat_id, "caption": text_content},
                                             files={"photo": f}, timeout=10.0)
        else:
            url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
            async with httpx.AsyncClient() as client:
                resp = await client.post(url, json={"chat_id": chat_id, "text": text_content}, timeout=10.0)
        data = resp.json()
        if resp.status_code == 200 and data.get("ok"):
            return {"success": True, "message": "Telegram connection verified and test message dispatched."}
        raise HTTPException(status_code=400, detail=f"Telegram API Error: {data.get('description', 'Unknown error')}")
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to connect to Telegram API: {str(e)}")

@router.post("/test-whatsapp")
async def test_whatsapp_connection(payload: VaultCredentialsUpdate,
    current_user: User = Depends(RoleChecker(["Admin", "Trader"])),
    db: Session = Depends(get_db)):
    import httpx
    access_token = payload.api_key
    phone_id = payload.api_secret
    if not access_token or not phone_id:
        vault_token = db.query(SecretsVault).filter(
            SecretsVault.user_id == current_user.id, SecretsVault.exchange_name == "WhatsApp"
        ).first()
        if vault_token:
            try:
                access_token = decrypt_secret(vault_token.api_key_encrypted)
                phone_id = decrypt_secret(vault_token.api_secret_encrypted)
            except Exception:
                raise HTTPException(status_code=500, detail="Failed to decrypt stored WhatsApp credentials.")
    if not access_token or not phone_id:
        raise HTTPException(status_code=400, detail="WhatsApp Access Token and Phone ID must be configured in vault.")
    url = f"https://graph.facebook.com/v17.0/{phone_id}/messages"
    headers = {"Authorization": f"Bearer {access_token}", "Content-Type": "application/json"}
    json_data = {"messaging_product": "whatsapp", "to": phone_id, "type": "text",
                 "text": {"body": "🟢 MEMOBOT | FX-PRO — Connection Test Successful."}}
    try:
        async with httpx.AsyncClient() as client:
            resp = await client.post(url, headers=headers, json=json_data, timeout=10.0)
        data = resp.json()
        if resp.status_code in [200, 201] and not data.get("error"):
            return {"success": True, "message": "WhatsApp connection verified."}
        raise HTTPException(status_code=400, detail=f"WhatsApp Error: {data.get('error', {}).get('message', 'Unknown error')}")
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to connect to WhatsApp API: {str(e)}")

@router.post("/test-gemini")
async def test_gemini_connection(payload: VaultCredentialsUpdate,
    current_user: User = Depends(RoleChecker(["Admin", "Trader"])),
    db: Session = Depends(get_db)):
    import httpx
    gemini_key = payload.api_key
    if not gemini_key:
        vault_token = db.query(SecretsVault).filter(
            SecretsVault.user_id == current_user.id, SecretsVault.exchange_name == "Gemini"
        ).first()
        if vault_token:
            try:
                gemini_key = decrypt_secret(vault_token.api_key_encrypted)
            except Exception:
                raise HTTPException(status_code=500, detail="Failed to decrypt stored Gemini API credentials.")
    if not gemini_key or gemini_key.strip() == "":
        raise HTTPException(status_code=400, detail="Gemini API Key must be configured in vault.")
    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={gemini_key}"
    try:
        async with httpx.AsyncClient() as client:
            resp = await client.post(url, json={"contents": [{"parts": [{"text": "Hello"}]}]}, timeout=10.0)
        data = resp.json()
        if resp.status_code == 200 and not data.get("error"):
            return {"success": True, "message": "Gemini API connection verified successfully."}
        raise HTTPException(status_code=400, detail=f"Gemini Error: {data.get('error', {}).get('message', 'Invalid key')}")
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to connect to Gemini API: {str(e)}")

@router.get("/status")
def get_vault_status(current_user: User = Depends(RoleChecker(["Admin", "Trader", "Risk_Officer", "Compliance_Officer"])),
    db: Session = Depends(get_db)):
    entries = db.query(SecretsVault).filter(SecretsVault.user_id == current_user.id).all()
    result = {
        "binance": False, "telegram": False, "whatsapp": False, "gemini": False,
        "Binance": False, "Telegram": False, "WhatsApp": False, "Gemini": False,
    }
    hints = {}
    for entry in entries:
        name = entry.exchange_name
        result[name] = True
        result[name.lower()] = True
        try:
            key = decrypt_secret(entry.api_key_encrypted)
            secret = decrypt_secret(entry.api_secret_encrypted)
            hints[name] = {
                "key_hint": key[:10] + "•" * max(0, len(key) - 10) if key else "",
                "secret_hint": secret[:6] + "•" * max(0, len(secret) - 6) if secret else "",
                "key_length": len(key),
                "secret_length": len(secret),
            }
        except Exception:
            hints[name] = {"key_hint": "••••••••••", "secret_hint": "••••••", "key_length": 0, "secret_length": 0}
    result["hints"] = hints
    return result