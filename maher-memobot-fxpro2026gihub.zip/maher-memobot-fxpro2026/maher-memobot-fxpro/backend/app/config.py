import os
from pathlib import Path
from cryptography.fernet import Fernet
from dotenv import load_dotenv
from sqlalchemy.engine import make_url

_PROJECT_ROOT = Path(__file__).resolve().parents[2]
_ENV_FILE = _PROJECT_ROOT / ".env"
load_dotenv(_ENV_FILE, override=True)

# Accept both historical ENV and the documented ENVIRONMENT name.
ENV = os.getenv("ENVIRONMENT") or os.getenv("ENV") or "development"
ENV = ENV.lower().strip()

_raw_database_url = os.getenv("DATABASE_URL")
if not _raw_database_url:
    if ENV == "development":
        _raw_database_url = "sqlite:///./dev.db"
    else:
        raise ValueError("DATABASE_URL environment variable is required in production.")

# The current legacy ORM is synchronous. Normalize the driver while retaining
# the original async URL for V2 services.
ASYNC_DATABASE_URL = _raw_database_url

if _raw_database_url.startswith("postgresql+psycopg2://"):
    DATABASE_URL = _raw_database_url.replace(
        "postgresql+psycopg2://",
        "postgresql+psycopg2://",
        1,
    )
    ASYNC_DATABASE_URL = _raw_database_url.replace(
        "postgresql+psycopg2://",
        "postgresql+asyncpg://",
        1,
    )
elif _raw_database_url.startswith("postgresql+asyncpg://"):
    DATABASE_URL = _raw_database_url.replace(
        "postgresql+asyncpg://",
        "postgresql+psycopg2://",
        1,
    )
else:
    DATABASE_URL = _raw_database_url

if _raw_database_url.startswith("sqlite://"):
    ASYNC_DATABASE_URL = _raw_database_url.replace(
        "sqlite://",
        "sqlite+aiosqlite://",
        1,
    )

if ENV == "production" and DATABASE_URL.startswith("sqlite"):
    raise ValueError("SQLite is not supported in production. Configure PostgreSQL only.")

ENCRYPTION_KEY = os.getenv("ENCRYPTION_KEY")
if not ENCRYPTION_KEY:
    if ENV == "production":
        raise ValueError("ENCRYPTION_KEY is mandatory in production mode.")
    ENCRYPTION_KEY = Fernet.generate_key().decode()

JWT_SECRET = os.getenv("JWT_SECRET") or os.getenv("SECRET_KEY")
if not JWT_SECRET:
    if ENV == "production":
        raise ValueError("JWT_SECRET (or SECRET_KEY) is mandatory in production mode.")
    import secrets
    JWT_SECRET = secrets.token_hex(32)

PORT = int(os.getenv("PORT", 8000))

CORS_ORIGINS = ["http://localhost:5173"]

ENABLE_NEW_EXECUTION_ENGINE = (
    os.getenv("ENABLE_NEW_EXECUTION_ENGINE", "false").lower() == "true"
)
ENABLE_RECONCILER = (
    os.getenv("ENABLE_RECONCILER", "false").lower() == "true"
)
ENABLE_REDIS_LOCKS = (
    os.getenv("ENABLE_REDIS_LOCKS", "false").lower() == "true"
)
