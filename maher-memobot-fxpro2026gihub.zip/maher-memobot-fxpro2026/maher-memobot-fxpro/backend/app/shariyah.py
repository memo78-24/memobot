"""
SHARIYAH COMPLIANCE AUDIT ENGINE
Islamic Finance Compliance Validation Module
Enforces Shariah-compliant trading protocols
"""

from enum import Enum
from typing import Dict, List, Tuple

class ShariyahStatus(Enum):
    COMPLIANT = "COMPLIANT"
    NON_COMPLIANT = "NON_COMPLIANT"
    QUESTIONABLE = "QUESTIONABLE"

class ShariyahComplianceEngine:
    """
    Validates trades against Islamic finance principles:
    1. RIB'A (Interest) - FORBIDDEN
    2. GHARAR (Uncertainty) - FORBIDDEN
    3. MAYSIR (Gambling) - FORBIDDEN
    4. HARAM ASSETS - FORBIDDEN
    5. SPOT SETTLEMENT ONLY - REQUIRED
    """
    
    # APPROVED ASSETS (Shariah-Compliant)
    APPROVED_ASSETS = {
        'BTC': {'status': 'COMPLIANT', 'reason': 'Spot commodity trading'},
        'ETH': {'status': 'COMPLIANT', 'reason': 'Spot commodity trading'},
        'SOL': {'status': 'COMPLIANT', 'reason': 'Spot commodity trading'},
        'ADA': {'status': 'COMPLIANT', 'reason': 'Spot commodity trading'},
        'BNB': {'status': 'COMPLIANT', 'reason': 'Spot commodity trading'},
        'DOT': {'status': 'COMPLIANT', 'reason': 'Spot commodity trading'},
        'LINK': {'status': 'COMPLIANT', 'reason': 'Spot commodity trading'},
        'UNI': {'status': 'COMPLIANT', 'reason': 'Spot commodity trading'},
        'LTC': {'status': 'COMPLIANT', 'reason': 'Spot commodity trading'},
    }
    
    # FORBIDDEN ASSETS (Non-Shariah Compliant)
    FORBIDDEN_ASSETS = {
        'XRP': {'status': 'NON_COMPLIANT', 'reason': 'Centralized governance violates Islamic principles'},
        'USDT': {'status': 'QUESTIONABLE', 'reason': 'Stablecoin with interest-bearing components'},
    }
    
    # FORBIDDEN TRADING PRODUCTS
    FORBIDDEN_PRODUCTS = {
        'MARGIN': 'Riba (interest-bearing lending)',
        'FUTURES': 'Gharar (uncertainty/speculation)',
        'OPTIONS': 'Maysir (gambling/gambling-like)',
        'SHORTS': 'Violates Islamic contract principles',
        'LEVERAGE': 'Riba through margin lending',
        'SWAPS': 'Riba (interest on overnight positions)',
    }
    
    def __init__(self):
        self.compliance_log = []
        self.rejection_count = 0
        self.approval_count = 0
    
    # ====== CORE VALIDATION METHODS ======
    
    def validate_symbol(self, symbol: str) -> Tuple[bool, str]:
        """
        STAGE 3: SHARIAH CHECK
        Validate if symbol is Shariah-compliant
        Returns: (is_valid, reason)
        """
        asset = symbol.split('/')[0] if '/' in symbol else symbol
        
        if asset in self.FORBIDDEN_ASSETS:
            reason = f"🚫 HARAM ASSET: {self.FORBIDDEN_ASSETS[asset]['reason']}"
            self.compliance_log.append(f"[SHARIAH] REJECTED: {asset} - {reason}")
            self.rejection_count += 1
            return False, reason
        
        if asset not in self.APPROVED_ASSETS:
            reason = f"🚫 UNKNOWN ASSET: {asset} not in approved list"
            self.compliance_log.append(f"[SHARIAH] REJECTED: {asset} - {reason}")
            self.rejection_count += 1
            return False, reason
        
        reason = f"✅ COMPLIANT: {asset} - {self.APPROVED_ASSETS[asset]['reason']}"
        self.compliance_log.append(f"[SHARIAH] APPROVED: {asset}")
        self.approval_count += 1
        return True, reason
    
    def validate_order_type(self, order_type: str) -> Tuple[bool, str]:
        """
        STAGE 3: SHARIAH CHECK
        Validate order type is Shariah-compliant (SPOT ONLY)
        """
        forbidden_types = ['MARGIN', 'FUTURES', 'OPTIONS', 'SHORT', 'LEVERAGE']
        
        if order_type.upper() in forbidden_types:
            reason = f"🚫 {order_type} is forbidden: {self.FORBIDDEN_PRODUCTS.get(order_type.upper(), 'Unknown reason')}"
            self.compliance_log.append(f"[SHARIAH] REJECTED: {order_type} - {reason}")
            self.rejection_count += 1
            return False, reason
        
        if order_type.upper() not in ['MARKET', 'LIMIT', 'BUY', 'SELL']:
            reason = f"🚫 {order_type} not a spot trading type"
            self.compliance_log.append(f"[SHARIAH] REJECTED: {order_type}")
            self.rejection_count += 1
            return False, reason
        
        reason = "✅ COMPLIANT: Spot market order"
        self.compliance_log.append(f"[SHARIAH] APPROVED: {order_type}")
        self.approval_count += 1
        return True, reason
    
    def validate_settlement(self, settlement_type: str) -> Tuple[bool, str]:
        """
        STAGE 3: SHARIAH CHECK
        Validate immediate spot settlement (NO overnight holding = NO RIBA)
        """
        if settlement_type.upper() not in ['SPOT', 'IMMEDIATE', 'PHYSICAL']:
            reason = f"🚫 Settlement type '{settlement_type}' violates spot settlement requirement"
            self.compliance_log.append(f"[SHARIAH] REJECTED: Settlement - {reason}")
            self.rejection_count += 1
            return False, reason
        
        reason = "✅ COMPLIANT: Immediate spot settlement"
        self.compliance_log.append(f"[SHARIAH] APPROVED: Settlement")
        self.approval_count += 1
        return True, reason
    
    def validate_no_interest_accrual(self, leverage: float, holding_time_hours: float = 0) -> Tuple[bool, str]:
        """
        STAGE 3: SHARIAH CHECK
        Validate no interest accrual (RIB'A) or leverage (which IS riba)
        """
        if leverage > 1.0:
            reason = f"🚫 Leverage {leverage}x violates Riba prohibition (leverage = lending with interest)"
            self.compliance_log.append(f"[SHARIAH] REJECTED: Leverage - {reason}")
            self.rejection_count += 1
            return False, reason
        
        if holding_time_hours > 24:
            reason = "🚫 Holding position for 24+ hours may accrue interest (Riba)"
            self.compliance_log.append(f"[SHARIAH] REJECTED: Hold time - {reason}")
            self.rejection_count += 1
            return False, reason
        
        reason = "✅ COMPLIANT: No leverage, no interest accrual"
        self.compliance_log.append(f"[SHARIAH] APPROVED: No Riba")
        self.approval_count += 1
        return True, reason
    
    def validate_no_gharar(self, stop_loss: float, take_profit: float, price: float) -> Tuple[bool, str]:
        """
        STAGE 3: SHARIAH CHECK
        Validate GHARAR (uncertainty) is minimized
        - SL/TP must be reasonable
        - Spread must be < 0.5%
        """
        if not stop_loss or not take_profit or not price or price <= 0:
            reason = "🚫 GHARAR: Missing stop loss or take profit parameters"
            self.compliance_log.append(f"[SHARIAH] REJECTED: Gharar - {reason}")
            self.rejection_count += 1
            return False, reason
        
        sl_distance = abs(price - stop_loss) / price * 100 if price != 0 else 0
        tp_distance = abs(take_profit - price) / price * 100 if price != 0 else 0
        
        if sl_distance > 50:  # SL too far = gharar
            reason = f"🚫 GHARAR: Stop loss {sl_distance:.1f}% away is too uncertain"
            self.compliance_log.append(f"[SHARIAH] REJECTED: SL distance - {reason}")
            self.rejection_count += 1
            return False, reason
        
        if tp_distance > 100:  # TP too far = gharar
            reason = f"🚫 GHARAR: Take profit {tp_distance:.1f}% away is too uncertain"
            self.compliance_log.append(f"[SHARIAH] REJECTED: TP distance - {reason}")
            self.rejection_count += 1
            return False, reason
        
        reason = "✅ COMPLIANT: SL/TP parameters eliminate Gharar"
        self.compliance_log.append(f"[SHARIAH] APPROVED: No Gharar")
        self.approval_count += 1
        return True, reason
    
    def validate_physical_backing(self, order_type: str, counterparty: str = "SPOT_EXCHANGE") -> Tuple[bool, str]:
        """
        STAGE 3: SHARIAH CHECK
        Validate 100% physical backing (No synthetic/fractional trading)
        """
        if counterparty.upper() not in ['SPOT_EXCHANGE', 'BINANCE', 'BYBIT', 'GEMINI']:
            reason = f"🚫 Counterparty '{counterparty}' not verified as physical asset exchange"
            self.compliance_log.append(f"[SHARIAH] REJECTED: Physical backing - {reason}")
            self.rejection_count += 1
            return False, reason
        
        reason = "✅ COMPLIANT: 100% physical asset backing verified"
        self.compliance_log.append(f"[SHARIAH] APPROVED: Physical backing")
        self.approval_count += 1
        return True, reason
    
    def validate_full_trade(self, trade_dict: Dict) -> Tuple[bool, str, List[str]]:
        """
        COMPREHENSIVE SHARIAH VALIDATION
        Returns: (is_compliant, summary, [validation_details])
        """
        validations = []
        symbol = trade_dict.get('symbol', 'UNKNOWN')
        side = trade_dict.get('side', 'UNKNOWN')
        order_type = trade_dict.get('type', 'MARKET')
        leverage = float(trade_dict.get('leverage', 1.0))
        amount = float(trade_dict.get('amount', 0))
        price = float(trade_dict.get('price', 0))
        
        # 1. Symbol validation
        valid, msg = self.validate_symbol(symbol)
        validations.append(msg)
        if not valid:
            return False, f"🚫 SHARIAH REJECTION: {symbol}", validations
        
        # 2. Order type validation
        valid, msg = self.validate_order_type(order_type)
        validations.append(msg)
        if not valid:
            return False, f"🚫 SHARIAH REJECTION: {order_type}", validations
        
        # 3. Settlement validation
        valid, msg = self.validate_settlement('SPOT')
        validations.append(msg)
        if not valid:
            return False, "🚫 SHARIAH REJECTION: Non-spot settlement", validations
        
        # 4. No interest accrual (leverage check)
        valid, msg = self.validate_no_interest_accrual(leverage)
        validations.append(msg)
        if not valid:
            return False, "🚫 SHARIAH REJECTION: Riba (interest/leverage)", validations
        
        # 5. No gharar
        sl_price = price * 0.98  # 2% SL
        tp_price = price * 1.02  # 2% TP
        valid, msg = self.validate_no_gharar(sl_price, tp_price, price)
        validations.append(msg)
        if not valid:
            return False, "🚫 SHARIAH REJECTION: Gharar (uncertainty)", validations
        
        # 6. Physical backing
        valid, msg = self.validate_physical_backing(order_type)
        validations.append(msg)
        if not valid:
            return False, "🚫 SHARIAH REJECTION: No physical backing", validations
        
        return True, "✅ 🕌 SHARIAH COMPLIANT - All validations passed", validations
    
    def get_compliance_report(self) -> Dict:
        """Generate compliance audit report"""
        total = self.approval_count + self.rejection_count
        approval_rate = (self.approval_count / total * 100) if total > 0 else 0
        
        return {
            "total_validations": total,
            "approvals": self.approval_count,
            "rejections": self.rejection_count,
            "approval_rate": round(approval_rate, 1),
            "compliant_assets": list(self.APPROVED_ASSETS.keys()),
            "forbidden_assets": list(self.FORBIDDEN_ASSETS.keys()),
            "recent_logs": self.compliance_log[-10:]
        }


# GLOBAL INSTANCE
shariyah_engine = ShariyahComplianceEngine()
