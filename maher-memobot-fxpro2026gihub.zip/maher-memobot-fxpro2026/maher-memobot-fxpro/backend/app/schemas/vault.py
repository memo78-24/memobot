from pydantic import BaseModel, Field
from typing import Optional

class VaultCredentialsUpdate(BaseModel):
    api_key: Optional[str] = Field(None, description="Binance Exchange API Key")
    api_secret: Optional[str] = Field(None, description="Binance Exchange API Secret")
    service: str = Field("Binance", description="Service identifier")
