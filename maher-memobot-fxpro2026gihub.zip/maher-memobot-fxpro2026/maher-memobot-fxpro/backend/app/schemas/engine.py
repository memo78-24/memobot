from pydantic import BaseModel, Field
from typing import Optional

class EngineStatusUpdate(BaseModel):
    status: str = Field(..., description="Engine status: Running, Paused, or Stopped")
    engine_name: Optional[str] = Field(None, description="Target sub-engine name (e.g. Rigel, Sirius) or ID (e.g. ENG-001)")
    engine_id: Optional[str] = Field(None, description="Alias for engine_name for frontend compatibility")

class EngineModeUpdate(BaseModel):
    mode: str = Field(..., description="Engine mode: Paper or Live")

class TradeRequest(BaseModel):
    symbol: str = Field("BTC/USDT", description="Trading asset pair")
    side: str = Field(..., description="Trade direction: BUY or SELL")
    type: str = Field("LIMIT", description="Order type: LIMIT, MARKET, or STOP_LOSS")
    amount: float = Field(..., gt=0, description="Order quantity")
    price: Optional[float] = Field(None, description="Limit price (mandatory for LIMIT orders)")
    engine: Optional[str] = Field("Rigel", description="Active Engine Name")

class RiskProfileUpdate(BaseModel):
    max_slippage: float = Field(0.5, gt=0, description="Max allowed slippage percentage")
    max_exposure: float = Field(50000.0, gt=0, description="Max allowed USD allocation per trade")
