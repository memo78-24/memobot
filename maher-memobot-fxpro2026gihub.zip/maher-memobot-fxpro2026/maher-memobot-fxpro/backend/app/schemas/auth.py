from pydantic import BaseModel, Field
from typing import Optional

class UserBase(BaseModel):
    username: str

class UserCreate(BaseModel):
    first_name: str
    last_name: str
    username: str
    email: str
    phone_country_code: str
    phone_number: str
    password: str
    confirm_password: str
    preferred_language: Optional[str] = "en"

class VerifyEmailCodeRequest(BaseModel):
    username: str
    email: str
    code: str

class ResendEmailCodeRequest(BaseModel):
    username: str
    email: str

class VerifyUserRequest(BaseModel):
    username: str

class LoginRequest(BaseModel):
    username: str
    password: str
    totp_code: Optional[str] = None

class UserResponse(UserBase):
    id: int
    role: str
    is_active: bool

    class Config:
        from_attributes = True

class Token(BaseModel):
    access_token: str
    token_type: str
    role: str

class TokenData(BaseModel):
    username: Optional[str] = None

class ChangePasswordRequest(BaseModel):
    """Typed schema for password change endpoint"""
    old_password: str = Field(..., min_length=1, description="Current password")
    new_password: str = Field(..., min_length=8, description="New password (min 8 chars)")

class ForgotPasswordRequest(BaseModel):
    email: str

class ResetPasswordRequest(BaseModel):
    email: str
    code: str
    new_password: str = Field(..., min_length=8)

class RefreshTokenRequest(BaseModel):
    refresh_token: Optional[str] = None

class Enable2FAResponse(BaseModel):
    secret: str
    provisioning_uri: str

class Verify2FARequest(BaseModel):
    totp_code: str
