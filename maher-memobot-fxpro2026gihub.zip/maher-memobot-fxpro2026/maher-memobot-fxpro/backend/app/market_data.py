import os
import time
import asyncio
import logging
from typing import Any, Dict, List, Optional, Tuple
import ccxt.async_support as ccxt
from backend.app.observability import log_structured

logger = logging.getLogger("memobot_fxpro.market_data")

# Cache TTLs (seconds)
ORDERBOOK_CACHE_TTL = int(os.environ.get("EVAL_ORDERBOOK_TTL", "3"))
CANDLES_CACHE_TTL = int(os.environ.get("EVAL_CANDLES_TTL", "30"))
CCXT_TIMEOUT_MS = int(os.environ.get("CCXT_TIMEOUT_MS", "10000"))
ORDERBOOK_DEPTH = 20

class MarketDataClient:
    """
    Managed ccxt client with caching. Single instance shared across
    all evaluation calls. Caches order books and candles independently.
    """
    def __init__(self):
        self._client: Optional[ccxt.binance] = None
        self._lock = asyncio.Lock()
        self._ob_cache: Dict[str, Tuple[Dict, float]] = {}
        self._candles_cache: Dict[str, Tuple[List, float]] = {}

    async def _ensure_client(self) -> ccxt.binance:
        if self._client is None:
            async with self._lock:
                if self._client is None:
                    self._client = ccxt.binance({
                        "enableRateLimit": True,
                        "timeout": CCXT_TIMEOUT_MS,
                        "options": {"defaultType": "spot"},
                    })
        return self._client

    async def close(self) -> None:
        if self._client:
            try:
                await self._client.close()
            except Exception:
                pass
            self._client = None

    def _normalize_symbol(self, symbol: str) -> str:
        """Convert any format to ccxt standard: BASE/QUOTE."""
        s = symbol.upper().strip()
        if "/" in s:
            return s
        quotes = ["USDT", "USDC", "BUSD", "FDUSD", "BTC", "ETH", "BNB"]
        for q in quotes:
            if s.endswith(q) and len(s) > len(q):
                base = s[: -len(q)]
                return f"{base}/{q}"
        return f"{s}/USDT"

    async def get_order_book(self, symbol: str) -> Optional[Dict[str, Any]]:
        """Fetch order book with caching."""
        ccxt_symbol = self._normalize_symbol(symbol)
        now = time.time()
        cached = self._ob_cache.get(ccxt_symbol)
        if cached and (now - cached[1]) < ORDERBOOK_CACHE_TTL:
            return cached[0]

        try:
            client = await self._ensure_client()
            ob = await asyncio.wait_for(
                client.fetch_order_book(ccxt_symbol, limit=ORDERBOOK_DEPTH),
                timeout=CCXT_TIMEOUT_MS / 1000.0,
            )
            self._ob_cache[ccxt_symbol] = (ob, now)
            return ob
        except asyncio.TimeoutError:
            logger.warning(f"Order book timeout for {ccxt_symbol}")
            return cached[0] if cached else None
        except Exception as e:
            logger.warning(f"Order book fetch failed for {ccxt_symbol}: {e}")
            return cached[0] if cached else None

    async def get_candles(
        self,
        symbol: str,
        timeframe: str = "15m",
        limit: int = 50,
    ) -> List[List[float]]:
        """Fetch OHLCV candles with caching."""
        ccxt_symbol = self._normalize_symbol(symbol)
        cache_key = f"{ccxt_symbol}:{timeframe}"
        now = time.time()
        cached = self._candles_cache.get(cache_key)
        if cached and (now - cached[1]) < CANDLES_CACHE_TTL:
            return cached[0]

        try:
            client = await self._ensure_client()
            candles = await asyncio.wait_for(
                client.fetch_ohlcv(ccxt_symbol, timeframe=timeframe, limit=limit),
                timeout=CCXT_TIMEOUT_MS / 1000.0,
            )
            if candles:
                self._candles_cache[cache_key] = (candles, now)
                return candles
            return cached[0] if cached else []
        except asyncio.TimeoutError:
            logger.warning(f"Candles timeout for {ccxt_symbol}")
            return cached[0] if cached else []
        except Exception as e:
            logger.warning(f"Candles fetch failed for {ccxt_symbol}: {e}")
            return cached[0] if cached else []

    def clear_cache(self) -> None:
        self._ob_cache.clear()
        self._candles_cache.clear()

# Global singleton
market_data = MarketDataClient()
