"""
SafetyGuardian: account-level capital protection layer.

Philosophy (per product intent): this app exists so people who depend on
this money for daily/weekly needs don't lose it. Individual trade checks
(RiskManager) validate ONE trade in isolation. SafetyGuardian protects the
WHOLE account across a trading day/session, and it is not something a
strategy or the user can quietly override from inside a running engine.

Core rules:
  1. CAPITAL FLOOR - the engine will never let the account drop below
     (1 - MAX_DRAWDOWN_PCT) of the day's starting balance. Hit it -> halt.
  2. DAILY LOSS CIRCUIT BREAKER - if daily loss reaches DAILY_LOSS_LIMIT_PCT,
     halt for the day regardless of floor.
  3. CONSECUTIVE-LOSS SHRINKING - position size multiplier shrinks after
     losing streaks (opposite of martingale/revenge-trading).
  4. NOTIFICATION-GATED HALT - any halt triggers a required-acknowledgment
     notification. The engine will NOT resume on its own. Acknowledging
     the notification only clears the gate; the user must still press
     Start again themselves.
"""
import logging
from datetime import datetime, date
from typing import Dict, Any, Optional
from sqlalchemy.orm import Session

from backend.shared.models.trading import EngineSafetyState
from backend.shared.models.user import Notification
from backend.app.services.notifications.notification_manager import NotificationManager

logger = logging.getLogger(__name__)

# ── Tunable safety constants ────────────────────────────────────────────────
MAX_DAILY_DRAWDOWN_PCT = 0.10      # Halt if the account falls 10% below today's starting balance
MAX_SESSION_DRAWDOWN_PCT = 0.20    # Hard floor: never let ANY session lose more than 20% total
DAILY_LOSS_CIRCUIT_BREAKER_PCT = 0.10  # Same as floor today; kept separate so they can diverge later
CONSECUTIVE_LOSS_SHRINK_STEP = 0.20    # Shrink position size 20% per consecutive loss
CONSECUTIVE_LOSS_SHRINK_FLOOR = 0.20   # Never shrink below 20% of normal size
MAX_CONSECUTIVE_LOSSES_BEFORE_HALT = 4  # Losing streak that triggers a full stop regardless of $ amount


class SafetyGuardian:

    @staticmethod
    def _get_or_create_today(db: Session, user_id: int, engine_name: str, current_balance_usd: float) -> EngineSafetyState:
        today = date.today()
        row = db.query(EngineSafetyState).filter(
            EngineSafetyState.user_id == user_id,
            EngineSafetyState.engine_name == engine_name,
            EngineSafetyState.day_date == today,
        ).first()

        if row:
            return row

        # New day (or first ever run for this engine): reset the baseline.
        # session_start_balance_usd persists the ORIGINAL session baseline if one
        # exists from a prior day's row; otherwise this balance becomes it.
        prior = db.query(EngineSafetyState).filter(
            EngineSafetyState.user_id == user_id,
            EngineSafetyState.engine_name == engine_name,
        ).order_by(EngineSafetyState.day_date.desc()).first()

        session_start = prior.session_start_balance_usd if prior else current_balance_usd

        row = EngineSafetyState(
            user_id=user_id,
            engine_name=engine_name,
            day_date=today,
            day_start_balance_usd=current_balance_usd,
            session_start_balance_usd=session_start,
            consecutive_losses=0,
            is_halted=False,
        )
        db.add(row)
        db.commit()
        db.refresh(row)
        return row

    @staticmethod
    def is_halt_pending_acknowledgment(db: Session, user_id: int, engine_name: str) -> bool:
        """True if there's a halt notification for this engine the user hasn't read yet."""
        unread = db.query(Notification).filter(
            Notification.user_id == user_id,
            Notification.is_read == False,
            Notification.notification_type == "engine_halt",
        ).all()
        for n in unread:
            if n.extra_data and n.extra_data.get("engine_name") == engine_name:
                return True
        return False

    @classmethod
    def check_before_trade(
        cls, db: Session, user_id: int, engine_name: str, current_balance_usd: float
    ) -> Dict[str, Any]:
        """
        Call this before every autonomous trade decision (and ideally before
        manual trades too). Returns:
          {"allowed": bool, "reason": str|None, "size_multiplier": float}
        """
        # An unacknowledged halt is an absolute block, independent of fresh math.
        if cls.is_halt_pending_acknowledgment(db, user_id, engine_name):
            return {
                "allowed": False,
                "reason": "Engine is halted and awaiting your acknowledgment. Check your notifications.",
                "size_multiplier": 0.0,
            }

        state = cls._get_or_create_today(db, user_id, engine_name, current_balance_usd)

        if state.is_halted:
            return {
                "allowed": False,
                "reason": state.halt_reason or "Engine is halted.",
                "size_multiplier": 0.0,
            }

        # Rule 1: daily drawdown floor
        if state.day_start_balance_usd > 0:
            daily_drawdown_pct = (state.day_start_balance_usd - current_balance_usd) / state.day_start_balance_usd
            if daily_drawdown_pct >= MAX_DAILY_DRAWDOWN_PCT:
                cls._halt(db, user_id, engine_name, state,
                          f"Daily capital floor reached: account is down "
                          f"{daily_drawdown_pct:.1%} today (limit {MAX_DAILY_DRAWDOWN_PCT:.0%}). "
                          f"Trading paused to protect your funds.")
                return {"allowed": False, "reason": "Daily capital floor reached.", "size_multiplier": 0.0}

        # Rule 2: hard session floor (never lose more than X% of original session balance, ever)
        if state.session_start_balance_usd > 0:
            session_drawdown_pct = (state.session_start_balance_usd - current_balance_usd) / state.session_start_balance_usd
            if session_drawdown_pct >= MAX_SESSION_DRAWDOWN_PCT:
                cls._halt(db, user_id, engine_name, state,
                          f"Session capital floor reached: account is down "
                          f"{session_drawdown_pct:.1%} since this engine started (hard limit "
                          f"{MAX_SESSION_DRAWDOWN_PCT:.0%}). Trading paused to protect your funds.")
                return {"allowed": False, "reason": "Session capital floor reached.", "size_multiplier": 0.0}

        # Rule 3: consecutive-loss streak halt
        if state.consecutive_losses >= MAX_CONSECUTIVE_LOSSES_BEFORE_HALT:
            cls._halt(db, user_id, engine_name, state,
                      f"{state.consecutive_losses} losing trades in a row. Trading paused so you can "
                      f"review what's happening before any more capital is risked.")
            return {"allowed": False, "reason": "Consecutive loss limit reached.", "size_multiplier": 0.0}

        # Rule 4: shrink position size after losses (never grow after a loss)
        shrink = max(
            CONSECUTIVE_LOSS_SHRINK_FLOOR,
            1.0 - (state.consecutive_losses * CONSECUTIVE_LOSS_SHRINK_STEP)
        )

        return {"allowed": True, "reason": None, "size_multiplier": round(shrink, 2)}

    @classmethod
    def record_trade_result(cls, db: Session, user_id: int, engine_name: str, pnl_usd: float, current_balance_usd: float):
        """Call this after a trade's outcome is known (closed position / realized P&L)."""
        state = cls._get_or_create_today(db, user_id, engine_name, current_balance_usd)
        if pnl_usd < 0:
            state.consecutive_losses += 1
        else:
            state.consecutive_losses = 0
        db.commit()

    @classmethod
    def _halt(cls, db: Session, user_id: int, engine_name: str, state: EngineSafetyState, reason: str):
        state.is_halted = True
        state.halt_reason = reason
        state.halted_at = datetime.utcnow()
        db.commit()

        try:
            from backend.app.engine_instance import engine as exec_engine
            if engine_name in exec_engine.engine_states:
                exec_engine.engine_states[engine_name]["status"] = "Halted-AwaitingAck"
        except Exception as e:
            logger.warning(f"Could not update in-memory engine state during halt: {e}")

        NotificationManager.send_notification(
            db, user_id,
            title=f"⚠️ {engine_name} Trading Paused",
            message=reason,
            notification_type="ERROR",
            category="engine_halt",
            extra_data={"engine_name": engine_name, "gate": "halt_ack_required"},
            priority="urgent",
        )

        logger.warning(f"[SAFETY HALT] user={user_id} engine={engine_name} reason={reason}")

    @classmethod
    def acknowledge_halt(cls, db: Session, user_id: int, engine_name: str) -> bool:
        """
        Clears the acknowledgment gate so the engine CAN be started again.
        Does NOT resume trading by itself -- the user must press Start.
        """
        notifs = db.query(Notification).filter(
            Notification.user_id == user_id,
            Notification.is_read == False,
            Notification.notification_type == "engine_halt",
        ).all()
        found = False
        for n in notifs:
            if n.extra_data and n.extra_data.get("engine_name") == engine_name:
                n.is_read = True
                n.read_at = datetime.utcnow()
                found = True

        state = db.query(EngineSafetyState).filter(
            EngineSafetyState.user_id == user_id,
            EngineSafetyState.engine_name == engine_name,
            EngineSafetyState.day_date == date.today(),
        ).first()
        if state:
            state.is_halted = False
            state.halt_reason = None

        db.commit()

        try:
            from backend.app.engine_instance import engine as exec_engine
            if engine_name in exec_engine.engine_states:
                exec_engine.engine_states[engine_name]["status"] = "Stopped"
        except Exception as e:
            logger.warning(f"Could not clear in-memory engine state after ack: {e}")

        return found
