import asyncio
import time
import json
from typing import Dict, Any, Callable
import ccxt.async_support as ccxt
import websockets
from backend.app.observability import log_structured

class SwarmCoordinator:
    """Manages background agent loop using live streaming price data from Binance Spot WebSocket."""
    def __init__(self, broadcast_callback: Callable[[Dict[str, Any]], None] = None):
        self.broadcast = broadcast_callback
        self.is_running = False
        self._main_task = None
        self.client = ccxt.binance({
            'enableRateLimit': True,
            'options': {
                'defaultType': 'spot',
            }
        })
        self.client.set_sandbox_mode(False) # Use production mode for public tickers
        
        # State indicators
        self.sentiment_score = 0.52  # 0 to 1
        self.rsi_value = 54.2
        self.slippage_threshold = 0.05
        self.is_shariah_compliant = True
        
        # Base prices for 50 spot assets
        self.prices = {
            "BTC": 68450.00, "ETH": 3520.00, "SOL": 132.00, "ADA": 0.48, "BNB": 580.00, "DOT": 5.80,
            "LINK": 14.50, "UNI": 7.20, "LTC": 78.00, "XRP": 0.49, "AVAX": 28.00,
            "MATIC": 0.58, "TRX": 0.11, "TON": 7.40, "NEAR": 5.20, "BCH": 380.00,
            "ICP": 8.10, "ETC": 23.40, "IMX": 1.50, "FIL": 4.20, "LDO": 1.80,
            "APT": 6.90, "RNDR": 7.80, "HBAR": 0.07, "STX": 1.60, "GRT": 0.18,
            "THETA": 1.40, "MKR": 2400.00, "INJ": 21.00, "VET": 0.026, "OP": 1.75,
            "EGLD": 29.00, "RUNE": 5.10, "FTM": 0.55, "ALGO": 0.13, "FLOW": 0.82,
            "SAND": 0.32, "MANA": 0.34, "AXS": 5.40, "AAVE": 89.00, "MINA": 0.52,
            "GALA": 0.028, "CHZ": 0.075, "EOS": 0.54, "XTZ": 0.78, "KCS": 8.20,
            "CAKE": 1.85, "CRV": 0.28, "LRC": 0.17, "BAT": 0.19, "ZIL": 0.016
        }
        
        # WebSocket live details cache for bid/ask tracking
        self.ticker_details = {}
        self.ws_state = "DISCONNECTED"
        self.ws_connected = False
        self.last_msg_time = 0.0

    def start(self):
        if not self.is_running:
            self.is_running = True
            self._main_task = asyncio.create_task(self._main_loop())
            log_structured("INFO", "SwarmCoordinator started.")

    async def stop(self):
        self.is_running = False
        if self._main_task:
            self._main_task.cancel()
            try:
                await self._main_task
            except asyncio.CancelledError:
                pass
            self._main_task = None
        
        try:
            await self.client.close()
        except Exception:
            pass
        log_structured("INFO", "SwarmCoordinator stopped.")

    async def _main_loop(self):
        """Runs the WebSocket listener and the telemetry broadcaster concurrently using asyncio.gather."""
        try:
            await asyncio.gather(
                self._websocket_listener_loop(),
                self._telemetry_broadcast_loop()
            )
        except asyncio.CancelledError:
            pass
        except Exception as e:
            log_structured("ERROR", f"SwarmCoordinator main loop exception: {e}")

    async def _websocket_listener_loop(self):
        url = "wss://stream.binance.com:9443/ws"
        backoff = 1.0
        while self.is_running:
            self.ws_state = "RECONNECTING" if backoff > 1.0 else "CONNECTING"
            self.ws_connected = False
            log_structured("INFO", f"Connecting to Binance Spot WebSocket API... (State: {self.ws_state})")
            
            t_connect_start = time.time()
            try:
                # websockets.connect includes automatic ping-pong frames
                async with websockets.connect(
                    url,
                    ping_interval=20,
                    ping_timeout=20
                ) as ws:
                    self.ws_state = "CONNECTED"
                    self.ws_connected = True
                    log_structured("INFO", "Connected to Binance Spot WebSocket. Subscribing to tickers...")
                    
                    # If we stayed connected for 5+ seconds, reset the backoff factor
                    if time.time() - t_connect_start > 5.0:
                        backoff = 1.0
                        
                    # Build and send subscription request
                    symbols_sub = [f"{asset.lower()}usdt@ticker" for asset in self.prices]
                    sub_payload = {
                        "method": "SUBSCRIBE",
                        "params": symbols_sub,
                        "id": int(time.time() * 1000)
                    }
                    await ws.send(json.dumps(sub_payload))
                    
                    async for msg in ws:
                        if not self.is_running:
                            break
                        
                        data = json.loads(msg)
                        
                        # Check for subscription confirmation
                        if isinstance(data, dict) and "result" in data and data["result"] is None:
                            log_structured("INFO", f"Binance WebSocket subscription acknowledged. (ID: {data.get('id')})")
                            continue
                            
                        # Process ticker updates
                        if isinstance(data, dict) and data.get("e") == "24hrTicker":
                            symbol = data.get("s", "")
                            if symbol.endswith("USDT"):
                                base_asset = symbol[:-4]
                                if base_asset in self.prices:
                                    last_price = float(data.get("c", 0.0))
                                    bid_price = float(data.get("b", 0.0))
                                    ask_price = float(data.get("a", 0.0))
                                    change_pct = float(data.get("P", 0.0))

                                    if last_price > 0:
                                        self.prices[base_asset] = last_price

                                    self.ticker_details[base_asset] = {
                                        "last": last_price,
                                        "bid": bid_price,
                                        "ask": ask_price,
                                        "change_pct": change_pct,
                                        "timestamp": time.time()
                                    }
                        
                        self.last_msg_time = time.time()
                        
            except asyncio.CancelledError:
                break
            except Exception as e:
                self.ws_state = "DISCONNECTED"
                self.ws_connected = False
                log_structured("ERROR", f"Binance WebSocket error: {e}. Reconnecting in {backoff:.1f}s...")
                await asyncio.sleep(backoff)
                backoff = min(60.0, backoff * 2.0)

    async def _telemetry_broadcast_loop(self):
        while self.is_running:
            try:
                self._refresh_indicators_from_market()

                btc_ticker = self.ticker_details.get("BTC", {})
                bid = btc_ticker.get("bid") or 0.0
                ask = btc_ticker.get("ask") or 0.0
                spread_pct = ((ask - bid) / ((ask + bid) / 2) * 100) if bid > 0 and ask > 0 else 0.02
                depth_ratio = 1.0
                if bid > 0 and ask > 0 and btc_ticker.get("last"):
                    depth_ratio = round(ask / bid, 2)

                telemetry = {
                    "type": "telemetry",
                    "timestamp": time.time(),
                    "price_feed": {f"{asset}_USDT": self.prices[asset] for asset in self.prices},
                    "change_feed": {
                        f"{asset}_USDT": self.ticker_details.get(asset, {}).get("change_pct", 0.0)
                        for asset in self.prices
                    },
                    "ws_status": {
                        "connected": self.ws_connected,
                        "state": self.ws_state,
                        "last_msg_latency": round(time.time() - self.last_msg_time, 2) if self.last_msg_time > 0 else -1
                    },
                    "agents": {
                        "sentiment_analyst": {
                            "name": "Sentiment Swarm",
                            "status": "ACTIVE",
                            "sentiment_score": round(self.sentiment_score, 2),
                            "alert": "Neutral Momentum" if 0.4 <= self.sentiment_score <= 0.6 else ("Bullish Surge" if self.sentiment_score > 0.6 else "Bearish Drop")
                        },
                        "micro_scalper": {
                            "name": "Micro-Scalp Executor",
                            "status": "ACTIVE",
                            "rsi": round(self.rsi_value, 2),
                            "action": "BUY_SIGNAL" if self.rsi_value < 30 else ("SELL_SIGNAL" if self.rsi_value > 70 else "HOLD")
                        },
                        "risk_shield": {
                            "name": "Holographic Risk Shield",
                            "status": "ACTIVE",
                            "drawdown_limit": "2.0%",
                            "max_exposure": "10.0 ETH",
                            "buffer_active": self.rsi_value < 20 or self.rsi_value > 80
                        },
                        "liquidity_scout": {
                            "name": "Ledger & Liquidity Scout",
                            "status": "ACTIVE",
                            "spread": round(spread_pct, 4),
                            "depth_ask_bid_ratio": depth_ratio
                        }
                    }
                }

                if self.broadcast:
                    await self.broadcast(telemetry)

                await asyncio.sleep(2.0)
            except asyncio.CancelledError:
                break
            except Exception as e:
                log_structured("ERROR", f"Error in Swarm telemetry broadcast loop: {e}")
                await asyncio.sleep(2.0)

    def _refresh_indicators_from_market(self):
        """Derive swarm indicators from live Binance 24h ticker data."""
        changes = [
            d.get("change_pct", 0.0)
            for d in self.ticker_details.values()
            if d.get("change_pct") is not None
        ]
        if changes:
            avg_change = sum(changes) / len(changes)
            self.sentiment_score = max(0.0, min(1.0, (avg_change + 5.0) / 10.0))
            self.rsi_value = max(10.0, min(90.0, 50.0 + avg_change * 5.0))
