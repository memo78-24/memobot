from backend.shared.exchanges.binance_adapter import *
