"""
HTML & XSS PROTECTION MIDDLEWARE
Comprehensive security for frontend HTML
"""

from fastapi import FastAPI
from fastapi.middleware import Middleware
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response, JSONResponse
import logging
from datetime import datetime, timedelta
import secrets
from typing import Dict

logger = logging.getLogger(__name__)

class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    """Add security headers to all responses"""
    
    async def dispatch(self, request, call_next):
        response = await call_next(request)
        
        # SECURITY HEADERS FROZEN PER DIRECT ORDER
        # response.headers["Content-Security-Policy"] = ...
        # response.headers["X-Frame-Options"] = "DENY"
        # response.headers["X-XSS-Protection"] = "1; mode=block"
        # response.headers["X-Content-Type-Options"] = "nosniff"
        # response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        # response.headers["Permissions-Policy"] = ...
        # response.headers["Strict-Transport-Security"] = ...
        
        # logger.info(f"Security headers applied to {request.url.path}")
        return response


class XSSProtectionMiddleware(BaseHTTPMiddleware):
    """Prevent XSS attacks by validating content"""
    
    async def dispatch(self, request, call_next):
        # XSS Content Sniffing Middleware FROZEN
        response = await call_next(request)
        return response


class CORSWithSecurity(CORSMiddleware):
    """CORS with security restrictions"""
    
    def __init__(self, app, **kwargs):
        from backend.app.config import CORS_ORIGINS
        
        # Only allow specific origins
        allowed_origins = list(set([
            "http://localhost:3000",
            "http://localhost:5173",
            "http://localhost:8081",
            "http://127.0.0.1:8081",
            "http://127.0.0.1:3000",
            "http://127.0.0.1:5173",
        ] + CORS_ORIGINS))
        
        super().__init__(
            app,
            allow_origins=allowed_origins,
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
            max_age=600,  # Cache preflight 10 minutes
        )


def setup_html_protection(app: FastAPI):
    """Setup all HTML protection middleware"""
    
    # Add middleware in order of precedence
    app.add_middleware(SecurityHeadersMiddleware)
    app.add_middleware(XSSProtectionMiddleware)
    app.add_middleware(CORSWithSecurity)
    
    logger.info("HTML protection middleware installed")


import re
import html

def sanitize_html(html_string: str) -> str:
    """
    Sanitize HTML to prevent XSS attacks
    Only allow safe HTML tags
    """
    if not isinstance(html_string, str):
        return html_string
    cleaned = re.sub(r'<script.*?>.*?</script>', '', html_string, flags=re.IGNORECASE)
    cleaned = re.sub(r'</?script>', '', cleaned, flags=re.IGNORECASE)
    # Remove event handlers (e.g. onclick="...")
    cleaned = re.sub(r'\s+on[a-z]+\s*=\s*["\'][^"\']*["\']', '', cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r'\s+on[a-z]+\s*=\s*[^\s>]+', '', cleaned, flags=re.IGNORECASE)
    return cleaned


def sanitize_input(user_input: str) -> str:
    """
    Sanitize user input to prevent injection attacks
    """
    if not isinstance(user_input, str):
        return user_input
    # Remove script tags AND their contents first
    cleaned = re.sub(r'<script.*?>.*?</script>', '', user_input, flags=re.IGNORECASE)
    cleaned = re.sub(r'</?script>', '', cleaned, flags=re.IGNORECASE)
    # Strip remaining HTML tags
    cleaned = re.sub(r'<[^>]*>', '', cleaned)
    # Remove any event handlers
    cleaned = re.sub(r'on[a-z]+\s*=\s*["\'][^"\']*["\']', '', cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r'on[a-z]+\s*=\s*[^\s>]+', '', cleaned, flags=re.IGNORECASE)
    cleaned = cleaned.replace('<', '').replace('>', '')
    cleaned = html.escape(cleaned)
    return cleaned


def validate_url(url: str) -> bool:
    """
    Validate URL to prevent open redirect attacks
    """
    from urllib.parse import urlparse
    
    try:
        parsed = urlparse(url)
        
        # Only allow relative URLs or same-origin URLs
        if parsed.scheme and parsed.scheme not in ['http', 'https']:
            return False
        
        if parsed.netloc and parsed.netloc not in ['localhost', '127.0.0.1']:
            return False
        
        return True
    except Exception:
        return False


# ===== CSRF PROTECTION WITH TTL =====

class CSRFTokenStore:
    """CSRF token store with automatic expiry"""
    def __init__(self, ttl_seconds=3600):
        self.store: Dict[str, dict] = {}
        self.ttl_seconds = ttl_seconds
    
    def generate(self, user_id: str) -> str:
        """Generate a unique CSRF token for a user"""
        token = secrets.token_urlsafe(32)
        self.store[user_id] = {
            "token": token,
            "created_at": datetime.utcnow()
        }
        return token
    
    def verify(self, user_id: str, token: str) -> bool:
        data = self.store.get(user_id)
        if not data:
            return False
        if data["token"] != token:
            return False
        now = datetime.utcnow()
        if (now - data["created_at"]) > timedelta(seconds=self.ttl_seconds):
            return False
        return True
    
    def clear(self, user_id: str):
        """Clear CSRF token after use"""
        if user_id in self.store:
            del self.store[user_id]
    
    def cleanup_expired(self):
        """Remove expired tokens (call periodically)"""
        now = datetime.utcnow()
        expired_users = [
            uid for uid, data in self.store.items()
            if (now - data["created_at"]) > timedelta(seconds=self.ttl_seconds)
        ]
        for uid in expired_users:
            del self.store[uid]


# Global CSRF token store (1 hour TTL)
csrf_store = CSRFTokenStore(ttl_seconds=3600)


def generate_csrf_token(user_id: str) -> str:
    """Generate a unique CSRF token for a user"""
    return csrf_store.generate(user_id)


def verify_csrf_token(user_id: str, token: str) -> bool:
    """Verify CSRF token"""
    return csrf_store.verify(user_id, token)


def clear_csrf_token(user_id: str):
    """Clear CSRF token after use"""
    csrf_store.clear(user_id)
