import math
from typing import Dict, Any, Optional


class RiskManager:
    """Hedge-fund risk engine validating trade parameters and portfolio exposure limits."""
    def __init__(self, max_exposure_usd: float = 50000.0, max_slippage_pct: float = 1.0):
        self.max_exposure_usd = max_exposure_usd
        self.max_slippage_pct = max_slippage_pct
        self.compliance_gate_enabled = True

    def calculate_position_size(self, balance_usd: float, price: float, volatility_atr: float) -> float:
        """Calculates volatility-adjusted position size using simple ATR scaling."""
        if volatility_atr <= 0 or price <= 0:
            return 0.0

        risk_amount = balance_usd * 0.01
        raw_size = risk_amount / volatility_atr
        max_size = (balance_usd * 0.10) / price
        final_size = min(raw_size, max_size)
        return round(final_size, 4)

    def _get_live_spread_pct(self, symbol: str) -> float:
        from backend.app.swarm_instance import swarm
        asset = symbol.replace("/USDT", "").replace("USDT", "")
        ticker = getattr(swarm, "ticker_details", {}).get(asset, {})
        bid = ticker.get("bid") or 0.0
        ask = ticker.get("ask") or 0.0
        if bid > 0 and ask > 0:
            return (ask - bid) / ((ask + bid) / 2) * 100
        last = ticker.get("last") or swarm.prices.get(asset, 0.0)
        if last > 0:
            return 0.05  # conservative default when bid/ask unavailable
        return 0.1

    def validate_trade(
        self,
        symbol: str,
        side: str,
        order_type: str,
        amount: float,
        price: float,
        current_portfolio_usd: float,
        asset_holding: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Validates risk limits, leverage bounds, and shariah compliance."""
        compliance_active = self.compliance_gate_enabled
        try:
            from backend.app.engine_instance import engine
            compliance_active = getattr(engine, "compliance_mode", "Islamic") == "Islamic"
        except Exception:
            pass

        if compliance_active:
            if order_type.lower() in ["margin", "futures", "leverage"]:
                return {
                    "approved": False,
                    "reason": "Shariah Compliance violation: Margin/leverage instruments are forbidden. Spot execution only."
                }
            if side.upper() == "SELL":
                if asset_holding is not None:
                    if amount > asset_holding + 1e-8:
                        return {
                            "approved": False,
                            "reason": f"Shariah Compliance violation: Cannot sell {amount} {symbol.split('/')[0]} — only {asset_holding:.8f} held."
                        }
                elif price > 0 and amount > current_portfolio_usd / price:
                    return {
                        "approved": False,
                        "reason": "Shariah Compliance violation: Short selling is forbidden. Spot-only selling requires possession of asset."
                    }

        trade_value_usd = amount * price
        if trade_value_usd > self.max_exposure_usd:
            return {
                "approved": False,
                "reason": f"Exposure Limit Exceeded: Order value (${trade_value_usd:,.2f}) exceeds max allocation (${self.max_exposure_usd:,.2f})."
            }

        spread_pct = self._get_live_spread_pct(symbol)
        if spread_pct > self.max_slippage_pct:
            return {
                "approved": False,
                "reason": f"High Slippage Risk: Market spread ({spread_pct:.3f}%) exceeds safety slippage buffer ({self.max_slippage_pct}%)."
            }

        return {
            "approved": True,
            "estimated_slippage": round(spread_pct, 3),
            "estimated_fees_usd": round(trade_value_usd * 0.001, 2)
        }

    def perform_stress_test(self, portfolio_assets: dict, current_prices: dict) -> dict:
        """Stress-test portfolio against predefined shock scenarios."""
        results = {}
        scenarios = {
            "crypto_crash_20": -0.20,
            "crypto_crash_40": -0.40,
            "flash_crash": -0.50
        }

        total_value = 0.0
        for asset, qty in portfolio_assets.items():
            price = current_prices.get(asset, 0.0)
            total_value += qty * price

        for name, price_shift in scenarios.items():
            shocked_value = 0.0
            for asset, qty in portfolio_assets.items():
                price = current_prices.get(asset, 0.0)
                shocked_value += qty * (price * (1 + price_shift))
            drawdown = total_value - shocked_value
            results[name] = {
                "portfolio_value": round(shocked_value, 2),
                "drawdown": round(drawdown, 2),
                "drawdown_pct": round(price_shift * 100, 2)
            }

        return {
            "initial_value": round(total_value, 2),
            "scenarios": results
        }
