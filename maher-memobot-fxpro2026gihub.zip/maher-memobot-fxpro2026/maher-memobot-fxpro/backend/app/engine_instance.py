from backend.app.engine import ExecutionEngine

# Global singleton instance of the execution engine
engine = ExecutionEngine()
