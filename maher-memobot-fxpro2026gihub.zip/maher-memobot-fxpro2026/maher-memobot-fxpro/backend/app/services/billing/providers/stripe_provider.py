import os
import stripe
from typing import Dict, Any, List, Optional
from backend.app.services.billing.providers.base import PaymentProvider
from backend.shared.models.user import User
from backend.shared.models.billing import SubscriptionPlan

# Set Stripe API key from environment
stripe.api_key = os.getenv("STRIPE_SECRET_KEY", "")

class StripeProvider(PaymentProvider):
    """Implementation of PaymentProvider using the Stripe SDK."""

    def __init__(self):
        # We assume the caller has set the environment variables properly, but we map internal plans to Stripe Price IDs
        self.price_mapping = {
            "Pro": os.getenv("STRIPE_PRICE_PRO", ""),
            "Elite": os.getenv("STRIPE_PRICE_ELITE", "")
        }

    def create_customer(self, user: User) -> str:
        customer = stripe.Customer.create(
            email=user.email,
            name=f"{user.first_name} {user.last_name}",
            metadata={"user_id": user.id}
        )
        return customer.id

    def update_customer(self, customer_id: str, email: str, name: str) -> None:
        stripe.Customer.modify(
            customer_id,
            email=email,
            name=name
        )

    def create_checkout_session(self, user: User, plan: SubscriptionPlan, success_url: str, cancel_url: str) -> str:
        price_id = self.price_mapping.get(plan.name)
        if not price_id:
            raise ValueError(f"No Stripe Price ID configured for plan {plan.name}")
            
        customer_id = user.provider_customer_id
        if not customer_id:
            customer_id = self.create_customer(user)
            # It's up to the caller to save this customer_id back to the User model

        session = stripe.checkout.Session.create(
            customer=customer_id,
            payment_method_types=["card"],
            line_items=[{
                "price": price_id,
                "quantity": 1,
            }],
            mode="subscription",
            success_url=success_url,
            cancel_url=cancel_url,
            metadata={
                "user_id": user.id,
                "plan_id": plan.id,
                "plan_name": plan.name
            }
        )
        return session.url

    def create_portal_session(self, customer_id: str, return_url: str) -> str:
        session = stripe.billing_portal.Session.create(
            customer=customer_id,
            return_url=return_url
        )
        return session.url

    def cancel_subscription(self, provider_subscription_id: str) -> bool:
        # Cancel at the end of the billing period to respect the paid time
        sub = stripe.Subscription.modify(
            provider_subscription_id,
            cancel_at_period_end=True
        )
        return sub.cancel_at_period_end

    def resume_subscription(self, provider_subscription_id: str) -> bool:
        sub = stripe.Subscription.modify(
            provider_subscription_id,
            cancel_at_period_end=False
        )
        return not sub.cancel_at_period_end

    def get_subscription(self, provider_subscription_id: str) -> Dict[str, Any]:
        sub = stripe.Subscription.retrieve(provider_subscription_id)
        return sub

    def sync_subscription(self, provider_subscription_id: str) -> Dict[str, Any]:
        return self.get_subscription(provider_subscription_id)

    def refund_payment(self, provider_charge_id: str, amount: Optional[float] = None) -> bool:
        kwargs = {"charge": provider_charge_id}
        if amount is not None:
            # Stripe expects amounts in cents
            kwargs["amount"] = int(amount * 100)
            
        refund = stripe.Refund.create(**kwargs)
        return refund.status == "succeeded"

    def verify_webhook_signature(self, payload: bytes, signature: str, secret: str) -> Dict[str, Any]:
        try:
            stripe.Webhook.construct_event(
                payload, signature, secret
            )
            import json
            return json.loads(payload)
        except ValueError as e:
            raise ValueError("Invalid payload") from e
        except stripe.error.SignatureVerificationError as e:
            raise ValueError("Invalid signature") from e

    def get_invoices(self, customer_id: str, limit: int = 10) -> List[Dict[str, Any]]:
        invoices = stripe.Invoice.list(customer=customer_id, limit=limit)
        return invoices.data
