from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional
from backend.shared.models.user import User
from backend.shared.models.billing import SubscriptionPlan

class PaymentProvider(ABC):
    """Abstract base class for payment providers to keep the billing system provider-agnostic."""

    @abstractmethod
    def create_customer(self, user: User) -> str:
        """Create a customer profile in the provider's system and return the customer ID."""
        pass

    @abstractmethod
    def update_customer(self, customer_id: str, email: str, name: str) -> None:
        """Update an existing customer profile."""
        pass

    @abstractmethod
    def create_checkout_session(self, user: User, plan: SubscriptionPlan, success_url: str, cancel_url: str) -> str:
        """Create a checkout session/URL for a subscription plan."""
        pass

    @abstractmethod
    def create_portal_session(self, customer_id: str, return_url: str) -> str:
        """Create a customer portal session/URL for managing billing methods and subscriptions."""
        pass

    @abstractmethod
    def cancel_subscription(self, provider_subscription_id: str) -> bool:
        """Cancel an active subscription at the end of the billing period."""
        pass

    @abstractmethod
    def resume_subscription(self, provider_subscription_id: str) -> bool:
        """Resume a canceled (but not yet expired) subscription."""
        pass

    @abstractmethod
    def get_subscription(self, provider_subscription_id: str) -> Dict[str, Any]:
        """Fetch subscription details from the provider."""
        pass

    @abstractmethod
    def sync_subscription(self, provider_subscription_id: str) -> Dict[str, Any]:
        """Synchronize the latest subscription status."""
        pass

    @abstractmethod
    def refund_payment(self, provider_charge_id: str, amount: Optional[float] = None) -> bool:
        """Refund a specific payment."""
        pass

    @abstractmethod
    def verify_webhook_signature(self, payload: bytes, signature: str, secret: str) -> Dict[str, Any]:
        """Verify the authenticity of a webhook event and return the parsed event."""
        pass

    @abstractmethod
    def get_invoices(self, customer_id: str, limit: int = 10) -> List[Dict[str, Any]]:
        """Fetch recent invoices for a customer."""
        pass
