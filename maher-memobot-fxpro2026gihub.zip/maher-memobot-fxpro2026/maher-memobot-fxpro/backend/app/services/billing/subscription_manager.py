import logging
from datetime import datetime, timezone, timedelta
from sqlalchemy.orm import Session
from sqlalchemy import select, update
from backend.shared.models.billing import SubscriptionPlan, UserSubscription
from backend.shared.models.user import User
from backend.app.services.notifications.notification_manager import NotificationManager

logger = logging.getLogger(__name__)

class SubscriptionManager:
    @staticmethod
    def provision_default_free_tier(db: Session, user_id: int):
        plan = db.query(SubscriptionPlan).filter_by(name='Free').first()
        if not plan:
            raise ValueError("Free plan not found in database")
            
        sub = UserSubscription(
            user_id=user_id,
            plan_id=plan.id,
            status='ACTIVE',
            current_period_start=datetime.now(timezone.utc),
            current_period_end=datetime.now(timezone.utc) + timedelta(days=3650), # 10 years default
            auto_renew=True,
            provider='System',
            created_by='System'
        )
        db.add(sub)
        db.commit()
        db.refresh(sub)
        return sub

    @staticmethod
    def upgrade_subscription(db: Session, user_id: int, plan_name: str, duration_days: int, admin_id: int = None, trial_days: int = 0):
        plan = db.query(SubscriptionPlan).filter_by(name=plan_name).first()
        if not plan:
            raise ValueError(f"Plan {plan_name} not found")
            
        sub = db.query(UserSubscription).filter_by(user_id=user_id).first()
        if not sub:
            sub = SubscriptionManager.provision_default_free_tier(db, user_id)
            
        sub.plan_id = plan.id
        sub.status = 'ACTIVE'
        sub.current_period_start = datetime.now(timezone.utc)
        sub.current_period_end = datetime.now(timezone.utc) + timedelta(days=duration_days)
        
        if trial_days > 0:
            sub.trial_ends_at = datetime.now(timezone.utc) + timedelta(days=trial_days)
        else:
            sub.trial_ends_at = None
            
        sub.grace_period_ends_at = None
        sub.created_by = f"Admin {admin_id}" if admin_id else "System Upgrade"
        sub.updated_at = datetime.now(timezone.utc)
        
        db.commit()
        
        # Log and Notify
        NotificationManager.send_notification(
            db=db,
            user_id=user_id,
            title="Subscription Upgraded",
            message=f"Your account has been upgraded to the {plan_name} plan until {sub.current_period_end.strftime('%Y-%m-%d')}.",
            notification_type="SUCCESS"
        )
        
        return sub
        
    @staticmethod
    def downgrade_subscription(db: Session, user_id: int, target_plan_name: str = 'Free', admin_id: int = None):
        plan = db.query(SubscriptionPlan).filter_by(name=target_plan_name).first()
        if not plan:
            raise ValueError(f"Plan {target_plan_name} not found")
            
        sub = db.query(UserSubscription).filter_by(user_id=user_id).first()
        if not sub:
            return None
            
        sub.plan_id = plan.id
        sub.status = 'ACTIVE'
        # Assume downgrades are indefinite unless handled by a new payment cycle
        sub.current_period_end = datetime.now(timezone.utc) + timedelta(days=3650)
        sub.trial_ends_at = None
        sub.grace_period_ends_at = None
        sub.created_by = f"Admin {admin_id}" if admin_id else "System Downgrade"
        sub.updated_at = datetime.now(timezone.utc)
        
        db.commit()
        
        NotificationManager.send_notification(
            db=db,
            user_id=user_id,
            title="Subscription Downgraded",
            message=f"Your account has been downgraded to the {target_plan_name} plan.",
            notification_type="ALERT"
        )
        
        return sub

    @staticmethod
    def check_expired_subscriptions(db: Session):
        now = datetime.now(timezone.utc)
        
        # 1. Find ACTIVE subscriptions that have passed their end date
        # If auto_renew is true, typically the payment webhook would extend it.
        # If we reach here and it's expired, payment failed or auto_renew is false.
        # We apply a 3-day grace period.
        expired_active = db.query(UserSubscription).filter(
            UserSubscription.status == 'ACTIVE',
            UserSubscription.current_period_end < now,
            UserSubscription.grace_period_ends_at.is_(None)
        ).all()
        
        free_plan = db.query(SubscriptionPlan).filter_by(name='Free').first()
        
        for sub in expired_active:
            # Don't expire the Free plan ever
            if sub.plan_id == free_plan.id:
                sub.current_period_end = now + timedelta(days=3650)
                continue
                
            # Start Grace Period
            sub.status = 'PAST_DUE'
            sub.grace_period_ends_at = now + timedelta(days=3)
            NotificationManager.send_notification(
                db=db,
                user_id=sub.user_id,
                title="Subscription Payment Overdue",
                message="Your subscription has expired. You have a 3-day grace period before downgrade.",
                notification_type="ALERT"
            )
        
        db.commit()
        
        # 2. Find PAST_DUE subscriptions whose grace period has expired
        expired_grace = db.query(UserSubscription).filter(
            UserSubscription.status == 'PAST_DUE',
            UserSubscription.grace_period_ends_at < now
        ).all()
        
        for sub in expired_grace:
            if sub.plan_id == free_plan.id:
                sub.status = 'ACTIVE'
                sub.current_period_end = now + timedelta(days=3650)
                sub.grace_period_ends_at = None
                continue
                
            # Downgrade to Free
            old_plan_id = sub.plan_id
            sub.plan_id = free_plan.id
            sub.status = 'ACTIVE'
            sub.current_period_end = now + timedelta(days=3650)
            sub.grace_period_ends_at = None
            
            NotificationManager.send_notification(
                db=db,
                user_id=sub.user_id,
                title="Subscription Downgraded",
                message="Your grace period has ended. Your account has been downgraded to the Free plan. New live positions cannot be opened.",
                notification_type="ERROR"
            )
            
        db.commit()

        # 3. Process Trial expirations (Trials can also be downgraded immediately or put in grace)
        expired_trials = db.query(UserSubscription).filter(
            UserSubscription.status == 'ACTIVE',
            UserSubscription.trial_ends_at != None,
            UserSubscription.trial_ends_at < now
        ).all()
        
        for sub in expired_trials:
            sub.plan_id = free_plan.id
            sub.status = 'ACTIVE'
            sub.current_period_end = now + timedelta(days=3650)
            sub.trial_ends_at = None
            sub.grace_period_ends_at = None
            NotificationManager.send_notification(
                db=db,
                user_id=sub.user_id,
                title="Trial Ended",
                message="Your trial has ended. Your account has been reverted to the Free plan.",
                notification_type="INFO"
            )
            
        db.commit()
