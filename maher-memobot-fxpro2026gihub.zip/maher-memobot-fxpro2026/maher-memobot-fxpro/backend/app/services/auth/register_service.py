import random
import datetime
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from backend.shared.models.user import User, AuthVerificationChallenge
from backend.app.database import log_activity
from backend.app.security import hash_password_secure
from backend.app.services.auth.password_policy import validate_password_policy
from backend.app.services.notifications.email_service import send_verification_email
from backend.app.services.billing.subscription_manager import SubscriptionManager
import hashlib

def generate_otp() -> str:
    return str(random.randint(100000, 999999))

def register_new_user(db: Session, payload: dict) -> dict:
    first_name = payload.get("first_name")
    last_name = payload.get("last_name")
    username = payload.get("username")
    email = payload.get("email")
    phone_country_code = payload.get("phone_country_code")
    phone_number = payload.get("phone_number")
    password = payload.get("password")
    confirm_password = payload.get("confirm_password")
    preferred_language = payload.get("preferred_language", "en")
    
    if not all([first_name, last_name, username, email, phone_country_code, phone_number, password, confirm_password]):
        raise ValueError("Missing required fields")
        
    if password != confirm_password:
        raise ValueError("Passwords do not match")
        
    if not validate_password_policy(password):
        raise ValueError("Password does not meet minimum policy requirements")
        
    phone_e164 = f"{phone_country_code}{phone_number}".replace(" ", "")
    
    try:
        # 1. Create User
        new_user = User(
            first_name=first_name,
            last_name=last_name,
            username=username,
            email=email,
            phone_country_code=phone_country_code,
            phone_number=phone_number,
            phone_e164=phone_e164,
            password_hash=hash_password_secure(password),
            role="Trader",
            is_active=True,
            status="PENDING_VERIFICATION",
            preferred_language=preferred_language
        )
        db.add(new_user)
        db.flush() # get new_user.id
        
        # Provision default Free subscription
        SubscriptionManager.provision_default_free_tier(db, new_user.id)
        
        # 2. Create OTP Challenge
        otp = generate_otp()
        otp_hash = hashlib.sha256(otp.encode('utf-8')).hexdigest()
        
        expires_at = datetime.datetime.utcnow() + datetime.timedelta(minutes=10)
        
        challenge = AuthVerificationChallenge(
            user_id=new_user.id,
            channel="EMAIL",
            challenge_type="REGISTER_EMAIL_VERIFICATION",
            code_hash=otp_hash,
            expires_at=expires_at,
            attempt_count=0,
            max_attempts=5,
            resend_count=0
        )
        db.add(challenge)
        
        # 3. Log event
        log_activity(db, "USER_REGISTERED", "SUCCESS", user_id=new_user.id, details=f"Registered email: {email}")
        
        # 4. Commit transaction
        db.commit()
        
        # 5. Dispatch email (fire and forget / celery in prod, synchronous here)
        send_verification_email(email, otp, preferred_language)
        log_activity(db, "EMAIL_VERIFICATION_CODE_SENT", "SUCCESS", user_id=new_user.id, details=f"OTP sent to {email}")
        
        return {
            "success": True,
            "user_id": new_user.id,
            "status": new_user.status,
            "verification_required": True,
            "masked_email": f"{email[0]}***@{email.split('@')[1]}"
        }

    except IntegrityError as e:
        db.rollback()
        raise ValueError("Username, email, or phone number already in use")
    except Exception as e:
        db.rollback()
        raise ValueError(f"Registration failed: {str(e)}")
