import re

def validate_password_policy(password: str) -> bool:
    """
    Validates a password against production policy:
    - Minimum length 8
    - At least one letter
    - At least one number
    """
    if len(password) < 8:
        return False
    
    if not re.search(r'[A-Za-z]', password):
        return False
        
    if not re.search(r'[0-9]', password):
        return False
        
    return True

def get_password_policy_message() -> str:
    return "Password must be at least 8 characters long and contain at least one letter and one number."
