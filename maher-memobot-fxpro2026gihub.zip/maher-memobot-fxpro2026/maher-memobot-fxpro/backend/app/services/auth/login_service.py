import datetime
import secrets
from sqlalchemy.orm import Session
from backend.shared.models.user import User, UserSession
from backend.app.security import verify_password, create_access_token, create_refresh_token
from backend.app.database import log_activity

MAX_LOGIN_ATTEMPTS = 5
LOCKOUT_DURATION_MINUTES = 15


def verify_user_exists(db: Session, username: str) -> dict:
    user = db.query(User).filter(User.username == username).first()
    if not user:
        return {"success": False, "status": "NOT_FOUND"}
    return {
        "success": True,
        "auth_method": "password",
        "requires_2fa": bool(user.is_2fa_enabled),
        "status": user.status or ("ACTIVE" if user.is_active else "INACTIVE"),
    }


def login_user(db: Session, username: str, password: str, totp_code: str = None,
               request_ip: str = None, user_agent: str = None) -> dict:
    """Authenticate a real database user; never fabricate an admin account."""
    user = db.query(User).filter(User.username == username).first()
    if not user:
        raise ValueError("Invalid username or password")

    now = datetime.datetime.utcnow()
    if user.locked_until and user.locked_until > now:
        raise ValueError("Account temporarily locked. Please try again later.")

    if not user.is_active:
        raise ValueError("Account is inactive")

    if user.status == "PENDING_VERIFICATION" or not user.is_email_verified:
        raise ValueError("User email verification is pending")

    if not verify_password(password, user.password_hash):
        user.failed_login_attempts = (user.failed_login_attempts or 0) + 1
        if user.failed_login_attempts >= MAX_LOGIN_ATTEMPTS:
            user.locked_until = now + datetime.timedelta(minutes=LOCKOUT_DURATION_MINUTES)
            user.failed_login_attempts = 0
        db.commit()
        raise ValueError("Invalid username or password")

    if user.is_2fa_enabled:
        if not totp_code:
            return {"success": True, "requires_2fa": True, "user_id": user.id}
        import pyotp
        from backend.app.security import decrypt_secret
        if not user.encrypted_totp_secret:
            raise ValueError("2FA is enabled but no authenticator secret is configured")
        secret = decrypt_secret(user.encrypted_totp_secret)
        if not pyotp.TOTP(secret).verify(totp_code):
            raise ValueError("Invalid 2FA code")

    user.failed_login_attempts = 0
    user.locked_until = None
    user.last_login_at = now

    access_token = create_access_token(
        data={"sub": user.username, "role": user.role},
        expires_delta=datetime.timedelta(minutes=30),
    )
    refresh_token_jti = secrets.token_urlsafe(32)
    refresh_token = create_refresh_token(
        data={"sub": user.username, "role": user.role, "jti": refresh_token_jti}
    )

    # Store opaque session metadata, not a reusable bearer token.
    session = UserSession(
        user_id=user.id,
        session_token=secrets.token_urlsafe(32),
        refresh_token=refresh_token,
        refresh_token_jti=refresh_token_jti,
        device_info=user_agent,
        user_agent=user_agent,
        ip_address=request_ip,
        expires_at=now + datetime.timedelta(days=7),
    )
    db.add(session)
    log_activity(db, "LOGIN_SUCCESS", "SUCCESS", user.id)
    db.commit()

    return {
        "success": True,
        "requires_2fa": False,
        "token": access_token,
        "refresh_token": refresh_token,
        "user": {
            "username": user.username,
            "role": user.role,
            "preferred_language": user.preferred_language or "en",
            "telegram_linked": bool(user.telegram_chat_id),
            "is_2fa_enabled": user.is_2fa_enabled,
        },
    }
