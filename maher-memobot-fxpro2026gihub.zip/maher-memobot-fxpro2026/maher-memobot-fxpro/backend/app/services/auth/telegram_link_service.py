import uuid
import datetime
from sqlalchemy.orm import Session
from backend.shared.models.user import User, TelegramLinkChallenge
from backend.app.database import log_activity
from backend.app.services.notifications.telegram_service import send_welcome_telegram

def start_telegram_link(db: Session, user: User) -> dict:
    if user.telegram_chat_id:
        return {
            "success": False,
            "error": "Account is already linked to Telegram"
        }
        
    # Expire old ones
    db.query(TelegramLinkChallenge).filter(
        TelegramLinkChallenge.user_id == user.id,
        TelegramLinkChallenge.status == "PENDING"
    ).update({"status": "CANCELLED"})
    
    token = str(uuid.uuid4()).replace("-", "")[:16]
    expires_at = datetime.datetime.utcnow() + datetime.timedelta(minutes=30)
    
    challenge = TelegramLinkChallenge(
        user_id=user.id,
        link_token=token,
        status="PENDING",
        expires_at=expires_at
    )
    db.add(challenge)
    
    log_activity(db, "TELEGRAM_LINK_STARTED", "SUCCESS", user.id)
    db.commit()
    
    # In production this URL would be from config, e.g. os.getenv("TELEGRAM_BOT_USERNAME")
    # For now we use a generic placeholder that will trigger the bot logic
    bot_username = "MemoBotFxPro_Bot" 
    telegram_link_url = f"https://t.me/{bot_username}?start={token}"
    
    return {
        "success": True,
        "telegram_link_url": telegram_link_url,
        "link_token": token,
        "expires_at": expires_at.isoformat()
    }

def get_telegram_link_status(db: Session, user: User) -> dict:
    if user.telegram_chat_id:
        return {
            "linked": True,
            "telegram_username": user.telegram_username,
            "linked_at": user.telegram_linked_at.isoformat() if user.telegram_linked_at else None
        }
    return {
        "linked": False
    }

# Webhook handler for when the bot receives /start <token>
def process_telegram_bot_start(db: Session, token: str, chat_id: str, telegram_username: str) -> bool:
    challenge = db.query(TelegramLinkChallenge).filter(
        TelegramLinkChallenge.link_token == token,
        TelegramLinkChallenge.status == "PENDING"
    ).first()
    
    if not challenge or datetime.datetime.utcnow() > challenge.expires_at:
        if challenge:
            challenge.status = "EXPIRED"
            db.commit()
        return False
        
    user = db.query(User).filter(User.id == challenge.user_id).first()
    if not user:
        return False
        
    user.telegram_chat_id = chat_id
    user.telegram_username = telegram_username
    user.telegram_linked_at = datetime.datetime.utcnow()
    
    challenge.status = "LINKED"
    challenge.linked_chat_id = chat_id
    challenge.linked_telegram_username = telegram_username
    
    log_activity(db, "TELEGRAM_LINK_COMPLETED", "SUCCESS", user.id, f"Linked to @{telegram_username}")
    
    db.commit()
    
    send_welcome_telegram(chat_id, user.preferred_language)
    log_activity(db, "WELCOME_TELEGRAM_SENT", "SUCCESS", user.id)
    
    return True
