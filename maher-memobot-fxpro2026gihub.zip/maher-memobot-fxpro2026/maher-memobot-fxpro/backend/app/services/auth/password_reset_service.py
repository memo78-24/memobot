import datetime
import hashlib
from sqlalchemy.orm import Session
from backend.shared.models.user import User, AuthVerificationChallenge
from backend.app.database import log_activity
from backend.app.services.notifications.email_service import send_verification_email
from backend.app.services.auth.register_service import generate_otp
from backend.app.security import hash_password_secure

def request_password_reset(db: Session, email: str) -> dict:
    user = db.query(User).filter(User.email == email).first()
    if not user:
        # Prevent email enumeration by returning generic success
        return {"success": True, "message": "If that email exists, a reset code was sent."}
        
    if user.status not in ("ACTIVE", "VERIFIED", "PENDING_VERIFICATION"):
        return {"success": True, "message": "If that email exists, a reset code was sent."}
        
    # Cancel old challenges
    db.query(AuthVerificationChallenge).filter_by(
        user_id=user.id, 
        challenge_type="PASSWORD_RESET"
    ).filter(
        AuthVerificationChallenge.consumed_at == None,
        AuthVerificationChallenge.expires_at > datetime.datetime.utcnow()
    ).update({"consumed_at": datetime.datetime.utcnow()})
    
    otp = generate_otp()
    code_hash = hashlib.sha256(otp.encode('utf-8')).hexdigest()
    expires_at = datetime.datetime.utcnow() + datetime.timedelta(minutes=15)
    
    challenge = AuthVerificationChallenge(
        user_id=user.id,
        channel="EMAIL",
        challenge_type="PASSWORD_RESET",
        code_hash=code_hash,
        expires_at=expires_at
    )
    db.add(challenge)
    
    # Send email
    send_verification_email(email, otp, user.preferred_language)
    
    log_activity(db, "PASSWORD_RESET_REQUESTED", "SUCCESS", user.id)
    db.commit()
    
    return {"success": True, "message": "If that email exists, a reset code was sent."}

def reset_password_with_code(db: Session, email: str, code: str, new_password: str) -> dict:
    user = db.query(User).filter(User.email == email).first()
    if not user:
        log_activity(db, "PASSWORD_RESET_FAILED", "FAILED", details=f"Unknown email: {email}")
        raise ValueError("Invalid reset code")
        
    challenge = db.query(AuthVerificationChallenge).filter_by(
        user_id=user.id,
        challenge_type="PASSWORD_RESET",
        consumed_at=None
    ).filter(
        AuthVerificationChallenge.expires_at > datetime.datetime.utcnow()
    ).order_by(AuthVerificationChallenge.created_at.desc()).first()
    
    if not challenge:
        log_activity(db, "PASSWORD_RESET_FAILED", "FAILED", user.id, "No active challenge")
        raise ValueError("Invalid or expired reset code")
        
    challenge.attempt_count += 1
    
    if challenge.attempt_count > challenge.max_attempts:
        challenge.consumed_at = datetime.datetime.utcnow()
        db.commit()
        log_activity(db, "PASSWORD_RESET_FAILED", "FAILED", user.id, "Max attempts reached")
        raise ValueError("Too many failed attempts. Request a new code.")
        
    code_hash = hashlib.sha256(code.encode('utf-8')).hexdigest()
    if code_hash != challenge.code_hash:
        db.commit()
        log_activity(db, "PASSWORD_RESET_FAILED", "FAILED", user.id, "Invalid code")
        raise ValueError("Invalid reset code")
        
    # Success
    challenge.consumed_at = datetime.datetime.utcnow()
    user.password_hash = hash_password_secure(new_password)
    
    log_activity(db, "PASSWORD_RESET_SUCCESS", "SUCCESS", user.id)
    db.commit()
    
    return {"success": True, "message": "Password reset successfully"}
