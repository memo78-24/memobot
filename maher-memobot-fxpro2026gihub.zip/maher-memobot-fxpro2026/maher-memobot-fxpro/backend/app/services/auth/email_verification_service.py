import datetime
import hashlib
from sqlalchemy.orm import Session
from backend.shared.models.user import User, AuthVerificationChallenge, UserSettings
from backend.shared.models.trading import PaperBalance, Portfolio
from backend.app.database import log_activity
from backend.app.services.notifications.email_service import send_verification_email, send_welcome_email
from backend.app.services.auth.register_service import generate_otp
from backend.app.security import create_access_token

def verify_email_code(db: Session, username: str, email: str, code: str) -> dict:
    user = db.query(User).filter(User.username == username, User.email == email).first()
    if not user:
        raise ValueError("Invalid user details")
        
    challenge = db.query(AuthVerificationChallenge).filter(
        AuthVerificationChallenge.user_id == user.id,
        AuthVerificationChallenge.challenge_type == "REGISTER_EMAIL_VERIFICATION",
        AuthVerificationChallenge.consumed_at.is_(None)
    ).order_by(AuthVerificationChallenge.created_at.desc()).first()
    
    if not challenge:
        raise ValueError("No active verification challenge found")
        
    if datetime.datetime.utcnow() > challenge.expires_at:
        log_activity(db, "EMAIL_VERIFICATION_FAILED", "FAILED", user.id, "Code expired")
        raise ValueError("Verification code expired")
        
    if challenge.attempt_count >= challenge.max_attempts:
        log_activity(db, "EMAIL_VERIFICATION_FAILED", "FAILED", user.id, "Too many attempts")
        raise ValueError("Too many attempts. Please request a new code.")
        
    code_hash = hashlib.sha256(code.encode('utf-8')).hexdigest()
    challenge.attempt_count += 1
    
    if challenge.code_hash != code_hash:
        db.commit()
        log_activity(db, "EMAIL_VERIFICATION_FAILED", "FAILED", user.id, "Invalid code")
        raise ValueError("Invalid verification code")
        
    # Success
    challenge.consumed_at = datetime.datetime.utcnow()
    user.status = "ACTIVE"
    user.is_email_verified = True
    user.email_verified_at = datetime.datetime.utcnow()
    
    # Provision User Ecosystem
    user_settings = UserSettings(user_id=user.id)
    db.add(user_settings)
    
    portfolio = Portfolio(user_id=user.id, paper_equity=10000.0)
    db.add(portfolio)
    
    paper_balance = PaperBalance(user_id=user.id, asset="USDT", free=10000.0, locked=0.0)
    db.add(paper_balance)
    
    log_activity(db, "EMAIL_VERIFIED", "SUCCESS", user.id)
    send_welcome_email(user.email, user.preferred_language)
    log_activity(db, "WELCOME_EMAIL_SENT", "SUCCESS", user.id)
    
    # Auto-login
    access_token_expires = datetime.timedelta(minutes=3000)
    access_token = create_access_token(
        data={"sub": user.username, "role": user.role},
        expires_delta=access_token_expires
    )
    
    db.commit()
    
    return {
        "success": True,
        "status": "ACTIVE",
        "token": access_token,
        "telegram_link_required": True
    }

def resend_email_code(db: Session, username: str, email: str) -> dict:
    user = db.query(User).filter(User.username == username, User.email == email).first()
    if not user:
        raise ValueError("Invalid user details")
        
    # Cooldown check on the latest challenge
    latest = db.query(AuthVerificationChallenge).filter(
        AuthVerificationChallenge.user_id == user.id,
        AuthVerificationChallenge.challenge_type == "REGISTER_EMAIL_VERIFICATION"
    ).order_by(AuthVerificationChallenge.created_at.desc()).first()
    
    if latest:
        delta = datetime.datetime.utcnow() - latest.last_sent_at
        if delta.total_seconds() < 60:
            raise ValueError(f"Please wait {int(60 - delta.total_seconds())} seconds before requesting a new code")
            
    # Expire old active challenges
    db.query(AuthVerificationChallenge).filter(
        AuthVerificationChallenge.user_id == user.id,
        AuthVerificationChallenge.consumed_at.is_(None)
    ).update({"consumed_at": datetime.datetime.utcnow()})
    
    # Create new challenge
    otp = generate_otp()
    otp_hash = hashlib.sha256(otp.encode('utf-8')).hexdigest()
    expires_at = datetime.datetime.utcnow() + datetime.timedelta(minutes=10)
    
    challenge = AuthVerificationChallenge(
        user_id=user.id,
        channel="EMAIL",
        challenge_type="REGISTER_EMAIL_VERIFICATION",
        code_hash=otp_hash,
        expires_at=expires_at,
        attempt_count=0,
        max_attempts=5,
        resend_count=0
    )
    db.add(challenge)
    
    send_verification_email(user.email, otp, user.preferred_language)
    log_activity(db, "EMAIL_VERIFICATION_RESENT", "SUCCESS", user.id)
    
    db.commit()
    
    return {
        "success": True,
        "cooldown_seconds": 60
    }
