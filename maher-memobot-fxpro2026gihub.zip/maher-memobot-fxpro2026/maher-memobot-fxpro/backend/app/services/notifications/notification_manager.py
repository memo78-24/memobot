import logging
import json
from sqlalchemy.orm import Session
from backend.shared.models.user import User, UserSettings, Notification, NotificationQueueItem

logger = logging.getLogger(__name__)

class NotificationManager:
    @staticmethod
    def send_notification(db: Session, user_id: int, title: str, message: str, notification_type: str = 'INFO',
                           category: str = 'system', extra_data: dict = None, priority: str = 'normal'):
        """
        Sends a notification to the user via Dashboard (always active) and places non-blocking
        dispatch requests inside the database outbox queue.

        notification_type: display/severity level shown in UI ('INFO', 'SUCCESS', 'ERROR', 'engine_halt', ...)
        category: the model's required classification column ('order', 'alert', 'system', 'billing', 'engine_halt')
        """
        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            logger.error(f"Cannot send notification to unknown user_id {user_id}")
            return
            
        # 1. Dashboard Alert (Always save to DB)
        notif = Notification(
            user_id=user_id,
            title=title,
            message=message,
            type=notification_type,
            notification_type=category,
            extra_data=extra_data,
            priority=priority,
            is_read=False
        )
        db.add(notif)
        db.commit()
        db.refresh(notif)
        
        # 2. Check Preferences
        preferences = {"email": True, "telegram": True, "whatsapp": True}
        settings = db.query(UserSettings).filter(UserSettings.user_id == user_id).first()
        if settings and settings.notification_preferences:
            try:
                prefs = json.loads(settings.notification_preferences)
                if isinstance(prefs, dict):
                    preferences.update(prefs)
            except Exception as e:
                logger.warning(f"Failed to parse notification preferences for user {user_id}: {e}")
                
        # 3. Queue Email Dispatch
        if preferences.get("email") and user.email:
            email_item = NotificationQueueItem(
                user_id=user_id,
                channel="email",
                title=title,
                message=message,
                status="PENDING"
            )
            db.add(email_item)
            
        # 4. Queue Telegram Dispatch
        if preferences.get("telegram") and user.telegram_chat_id:
            formatted_message = f"⚠️ *{title}*\n\n{message}"
            telegram_item = NotificationQueueItem(
                user_id=user_id,
                channel="telegram",
                title=title,
                message=formatted_message,
                status="PENDING"
            )
            db.add(telegram_item)

        # 5. Queue WhatsApp Dispatch (Placeholder/New channel support)
        if preferences.get("whatsapp") and getattr(user, "phone_number", None):
            whatsapp_item = NotificationQueueItem(
                user_id=user_id,
                channel="whatsapp",
                title=title,
                message=message,
                status="PENDING"
            )
            db.add(whatsapp_item)

        db.commit()
        return notif

    @staticmethod
    def send_trade_alert(db: Session, user_id: int, symbol: str, side: str, amount: float, price: float, engine_name: str, status: str):
        """
        Specific helper for trading alerts. Queues high-speed notifications instantly.
        """
        title = f"Trade {status}: {side} {symbol}"
        message = f"Engine {engine_name} executed {side} {amount} {symbol} @ {price}"
        
        ntype = 'SUCCESS' if status in ['FILLED', 'OPEN'] else 'INFO'
        if status in ['REJECTED', 'FAILED', 'ERROR']:
            ntype = 'ERROR'
            
        # Write to Dashboard Notification & check base preferences
        notif = NotificationManager.send_notification(db, user_id, title, message, ntype)
        
        # Specific formatted Telegram Trade Alert
        user = db.query(User).filter(User.id == user_id).first()
        if user and user.telegram_chat_id:
            settings = db.query(UserSettings).filter(UserSettings.user_id == user_id).first()
            if settings and settings.notification_preferences:
                try:
                    prefs = json.loads(settings.notification_preferences)
                    if isinstance(prefs, dict) and prefs.get("telegram"):
                        # Format message using specific Markdown Trade layout
                        emoji = "✅" if status in ["FILLED", "OPEN"] else "❌"
                        formatted_telegram = (
                            f"{emoji} *Trade {status}*\n\n"
                            f"🤖 Engine: {engine_name}\n"
                            f"💱 Symbol: {symbol}\n"
                            f"📊 Side: {side}\n"
                            f"💰 Amount: {amount}\n"
                            f"💲 Price: ${price:.2f}"
                        )
                        telegram_trade_item = NotificationQueueItem(
                            user_id=user_id,
                            channel="telegram",
                            title=title,
                            message=formatted_telegram,
                            status="PENDING"
                        )
                        db.add(telegram_trade_item)
                        db.commit()
                except Exception as e:
                    logger.warning(f"Failed to queue Telegram trade alert: {e}")
        
        return notif

    @staticmethod
    def get_unread_notifications(db: Session, user_id: int):
        return db.query(Notification).filter(
            Notification.user_id == user_id,
            Notification.is_read == False
        ).order_by(Notification.created_at.desc()).limit(50).all()

    @staticmethod
    def mark_as_read(db: Session, notification_id: int, user_id: int):
        notif = db.query(Notification).filter(
            Notification.id == notification_id,
            Notification.user_id == user_id
        ).first()
        
        if notif:
            notif.is_read = True
            db.commit()
            return True
        return False
