import os
import logging
from twilio.rest import Client
from twilio.base.exceptions import TwilioRestException

logger = logging.getLogger(__name__)

# Twilio Credentials
TWILIO_ACCOUNT_SID = os.getenv("TWILIO_ACCOUNT_SID")
TWILIO_AUTH_TOKEN = os.getenv("TWILIO_AUTH_TOKEN")
TWILIO_WHATSAPP_NUMBER = os.getenv("TWILIO_WHATSAPP_NUMBER") # e.g. 'whatsapp:+14155238886'

client = None
if TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN:
    try:
        client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
    except Exception as e:
        logger.error(f"Failed to initialize Twilio Client: {e}")

def send_whatsapp_message(to_number: str, message: str) -> bool:
    """
    Send a message via Twilio WhatsApp API
    """
    if not client or not TWILIO_WHATSAPP_NUMBER:
        logger.warning("Twilio credentials not set. Skipping WhatsApp notification.")
        return False
        
    try:
        # Format the number for WhatsApp
        if not to_number.startswith('whatsapp:'):
            to_number = f"whatsapp:{to_number}"
            
        message = client.messages.create(
            body=message,
            from_=TWILIO_WHATSAPP_NUMBER,
            to=to_number
        )
        logger.info(f"WhatsApp message sent successfully to {to_number} (SID: {message.sid})")
        return True
    except TwilioRestException as e:
        logger.error(f"Failed to send WhatsApp message: {e}")
        return False
    except Exception as e:
        logger.error(f"Unexpected error sending WhatsApp message: {e}")
        return False
