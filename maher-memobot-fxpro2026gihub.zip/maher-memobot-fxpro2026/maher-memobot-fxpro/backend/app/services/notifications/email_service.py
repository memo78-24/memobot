import logging
import smtplib
from email.message import EmailMessage
import os

logger = logging.getLogger(__name__)

def _send_email(to_email: str, subject: str, body: str):
    smtp_server = os.getenv("SMTP_SERVER")
    smtp_port = int(os.getenv("SMTP_PORT", "587"))
    smtp_user = os.getenv("SMTP_USER")
    smtp_password = os.getenv("SMTP_PASSWORD")
    
    if not smtp_server or not smtp_user or not smtp_password:
        logger.warning(f"SMTP credentials not configured. Skipping email to {to_email}")
        return
        
    try:
        msg = EmailMessage()
        msg.set_content(body)
        msg['Subject'] = subject
        msg['From'] = smtp_user
        msg['To'] = to_email

        with smtplib.SMTP(smtp_server, smtp_port) as server:
            server.starttls()
            server.login(smtp_user, smtp_password)
            server.send_message(msg)
        logger.info(f"Email sent successfully to {to_email}")
    except Exception as e:
        logger.error(f"Failed to send email to {to_email}: {e}")

def send_verification_email(to_email: str, code: str, language: str = 'en'):
    """
    Sends an email verification OTP.
    Supports English and Arabic.
    """
    if language == 'ar':
        subject = "MemoBot FX-PRO — رمز التحقق لحساب"
        body = f"مرحباً،\n\nرمز التحقق الخاص بك هو: {code}\n\nصالح لمدة 10 دقائق."
    else:
        subject = "MemoBot FX-PRO — Verify your email"
        body = f"Hello,\n\nYour verification code is: {code}\n\nIt expires in 10 minutes."
        
    _send_email(to_email, subject, body)

def send_welcome_email(to_email: str, language: str = 'en'):
    """
    Sends a welcome email after successful activation.
    """
    if language == 'ar':
        subject = "مرحباً بك في MemoBot FX-PRO"
        body = "تم تفعيل حسابك بنجاح. يمكنك الآن ربط تيليجرام ومنصات التداول الخاصة بك."
    else:
        subject = "Welcome to MemoBot FX-PRO"
        body = "Your account has been activated. You can now connect Telegram and your exchange APIs."
        
    _send_email(to_email, subject, body)
