import logging
import requests
import os

logger = logging.getLogger(__name__)

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_API_URL = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}"

def send_telegram_message(chat_id: str, message: str, parse_mode: str = "Markdown") -> bool:
    """
    Send a message via Telegram Bot API
    """
    if not TELEGRAM_BOT_TOKEN:
        logger.warning("TELEGRAM_BOT_TOKEN not set. Skipping Telegram notification.")
        return False

    try:
        response = requests.post(
            f"{TELEGRAM_API_URL}/sendMessage",
            json={
                "chat_id": chat_id,
                "text": message,
                "parse_mode": parse_mode
            },
            timeout=10
        )
        response.raise_for_status()
        logger.info(f"Telegram message sent successfully to chat_id {chat_id}")
        return True
    except requests.exceptions.RequestException as e:
        logger.error(f"Failed to send Telegram message: {e}")
        return False

def send_welcome_telegram(chat_id: str, language: str = 'en'):
    """
    Sends a welcome message to the user via Telegram bot once linked.
    """
    if language == 'ar':
        message = (
            "مرحباً بك في MemoBot FX-PRO\n"
            "تم ربط حسابك مع تيليجرام بنجاح\n"
            "ستصلك هنا تنبيهات النظام والإشعارات والتحديثات"
        )
    else:
        message = (
            "Welcome to MemoBot FX-PRO\n"
            "Your account is now connected to Telegram\n"
            "You’ll receive alerts, confirmations, and system notifications here"
        )
    
    return send_telegram_message(chat_id, message)

def send_trade_alert(chat_id: str, symbol: str, side: str, amount: float, price: float, engine_name: str, status: str) -> bool:
    """
    Send trade alert notification via Telegram
    """
    emoji = "✅" if status in ["FILLED", "OPEN"] else "❌"
    message = (
        f"{emoji} *Trade {status}*\n\n"
        f"🤖 Engine: {engine_name}\n"
        f"💱 Symbol: {symbol}\n"
        f"📊 Side: {side}\n"
        f"💰 Amount: {amount}\n"
        f"💲 Price: ${price:.2f}"
    )
    return send_telegram_message(chat_id, message)

def send_system_alert(chat_id: str, title: str, message: str) -> bool:
    """
    Send system alert notification via Telegram
    """
    formatted_message = f"⚠️ *{title}*\n\n{message}"
    return send_telegram_message(chat_id, formatted_message)
