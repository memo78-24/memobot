import asyncio
import logging
import json
import time
from typing import Dict, Any
from backend.app.engine_instance import engine as exec_engine
from backend.app.database import SessionLocal

logger = logging.getLogger(__name__)

# Thread-safe In-Memory Cache representing current spot asset balances, net worth, prices, and breakdown
_balance_cache: Dict[str, Any] = {
    "success": False,
    "asset_totals": {},
    "prices": {},
    "net_worth": 0.0,
    "breakdown": {},
    "last_updated": 0
}

_cache_lock = asyncio.Lock()
_redis_client = None

# Initialize Optional Redis Integration
try:
    import redis
    import os
    redis_url = os.getenv("REDIS_URL")
    if redis_url:
        _redis_client = redis.from_url(redis_url, decode_responses=True)
        logger.info("Connected to Redis cache client successfully.")
except Exception as e:
    logger.debug(f"Redis initialization bypassed/failed (falling back to memory-only caching): {e}")


async def get_cached_balances() -> Dict[str, Any]:
    """Retrieve the cached balances instantly.
    Checks Redis first, falling back to local thread-safe In-Memory Cache.
    """
    global _balance_cache
    if _redis_client:
        try:
            data = _redis_client.get("memobot:balances")
            if data:
                return json.loads(data)
        except Exception as e:
            logger.error(f"Redis cache fetch failure: {e}")

    async with _cache_lock:
        return _balance_cache.copy()


async def update_cached_balances(data: Dict[str, Any]):
    """Thread-safely update cached balances inside local memory and Redis."""
    global _balance_cache
    async with _cache_lock:
        _balance_cache.update(data)
        _balance_cache["last_updated"] = int(time.time())
        _balance_cache["success"] = True

    if _redis_client:
        try:
            _redis_client.set("memobot:balances", json.dumps(_balance_cache), ex=60)
        except Exception as e:
            logger.error(f"Redis cache write failure: {e}")


async def refresh_balances_from_binance():
    """Execute live CCXT REST fetch to update local and Redis balance caches."""
    db = SessionLocal()
    try:
        from backend.shared.models.vault import VaultCredentials
        from sqlalchemy import func

        vault = db.query(VaultCredentials).filter(
            func.lower(VaultCredentials.exchange_name) == "binance"
        ).first()

        if not vault:
            logger.debug("No Binance credentials found in vault for background refresh.")
            return

        if not exec_engine.binance_client or not exec_engine.binance_client.is_configured:
            await exec_engine.configure_live_client(db, user_id=vault.user_id)

        if exec_engine.binance_client and exec_engine.binance_client.is_configured:
            logger.info("Background thread refreshing Binance balances...")
            res = await exec_engine.binance_client.fetch_all_balances()
            if res.get("success"):
                await update_cached_balances({
                    "asset_totals": res.get("asset_totals", {}),
                    "prices": res.get("prices", {}),
                    "net_worth": res.get("net_worth", 0.0),
                    "breakdown": res.get("breakdown", {})
                })
                logger.info("Binance balances successfully cached.")
            else:
                logger.warning(f"Binance fetch result indicates unsuccessful update: {res}")
        else:
            logger.debug("Binance adapter client not yet configured for live balances.")
    except Exception as e:
        logger.error(f"Error in Binance background refresh iteration: {e}", exc_info=True)
    finally:
        db.close()


async def start_balance_cacher():
    """Continuous async loop to refresh Binance cache metrics every 30 seconds."""
    logger.info("Initializing zero-latency background cacher loop...")
    while True:
        try:
            await refresh_balances_from_binance()
        except asyncio.CancelledError:
            logger.info("Binance background cacher loop stopped.")
            break
        except Exception as e:
            logger.error(f"Unexpected error in background cacher loop: {e}", exc_info=True)
        await asyncio.sleep(30)


async def get_cached_net_worth(db, user_id: int) -> float:
    """Return net worth in USDT from the balance cache. Used by autonomous loops."""
    try:
        balances = await get_cached_balances()
        return float(balances.get("net_worth", 0.0))
    except Exception:
        return 0.0
