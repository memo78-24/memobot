from backend.shared.models.success_fee import SuccessDecisionFee

SUCCESS_DECISION_FEES = {
    "Free": 0.00,
    "Starter": 0.05,
    "Professional": 0.10,
    "Institutional": 0.05,
    "Enterprise": 0.03,
    "Lifetime": 0.00,
}


class SuccessFeeService:

    @staticmethod
    def calculate(plan_name: str, realized_profit: float):

        if realized_profit <= 0:
            return 0.0

        percentage = SUCCESS_DECISION_FEES.get(plan_name, 0.0)

        return round(realized_profit * percentage, 2)

    @staticmethod
    def record(
        db,
        user_id,
        trade_id,
        engine_name,
        plan_name,
        realized_profit,
    ):

        fee = SuccessFeeService.calculate(plan_name, realized_profit)

        record = SuccessDecisionFee(
            user_id=user_id,
            trade_id=trade_id,
            engine_name=engine_name,
            plan_name=plan_name,
            realized_profit=realized_profit,
            fee_percentage=SUCCESS_DECISION_FEES.get(plan_name, 0),
            fee_amount=fee,
        )

        db.add(record)
        db.commit()

        return fee
