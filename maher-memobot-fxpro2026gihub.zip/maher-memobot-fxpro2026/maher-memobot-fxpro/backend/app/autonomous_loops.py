"""
backend/app/autonomous_loops.py

Phase 2 — Rigel (Manual Engine)
Phase 3 — Sirius (Full Auto Engine)
Phase 4 — Canopus (Hybrid Engine)

Each loop reads its configuration from StrategyState in the database,
runs through the full safety-gated execute_trade() pipeline, and manages
its own start/stop lifecycle.
"""

import asyncio
import logging
from datetime import datetime
from typing import Dict, Any, Optional
from sqlalchemy.orm import Session

from backend.app.database import SessionLocal
from backend.app.engine_instance import engine
from backend.app.market_data import MarketDataClient
from backend.app.safety_guardian import SafetyGuardian
from backend.app.strategies.base_strategy import (
    ScalpingStrategy, TrendFollowingStrategy, MeanReversionStrategy,
    GridStrategy, DCAStrategy
)

logger = logging.getLogger(__name__)

# ──────────────────────────────────────────────────────────────────────────────
# STRATEGY REGISTRY
# Maps strategy names (from frontend config) to strategy class instances
# ──────────────────────────────────────────────────────────────────────────────

STRATEGY_REGISTRY = {
    "FAST SCALPER":     ScalpingStrategy,
    "FAST_SCALPER":     ScalpingStrategy,
    "SCALPER":          ScalpingStrategy,
    "TREND BALANCER":   TrendFollowingStrategy,
    "TREND_BALANCER":   TrendFollowingStrategy,
    "TREND":            TrendFollowingStrategy,
    "MEAN REVERSION":   MeanReversionStrategy,
    "MEAN_REVERSION":   MeanReversionStrategy,
    "REVERSION":        MeanReversionStrategy,
    "GRID":             GridStrategy,
    "DCA":              DCAStrategy,
    "AI SWARM CONSENSUS": TrendFollowingStrategy,  # uses trend logic until Swarm AI is wired
    "AI_SWARM":         TrendFollowingStrategy,
}

# Active background tasks: engine_name -> asyncio.Task
_active_loops: Dict[str, asyncio.Task] = {}

# Market data client (shared across loops)
_market_data: Optional[MarketDataClient] = None


def _get_market_data() -> MarketDataClient:
    global _market_data
    if _market_data is None:
        _market_data = MarketDataClient()
    return _market_data


def _get_engine_config(db: Session, user_id: int, engine_name: str) -> Dict[str, Any]:
    """Read engine configuration from StrategyState table."""
    from backend.shared.models.trading import StrategyState
    import json

    row = db.query(StrategyState).filter_by(
        user_id=user_id,
        name=engine_name
    ).first()

    defaults = {
        "Rigel":   {"strategy": "FAST SCALPER",      "asset": "BTCUSDT", "amount": 10.0,  "timeframe": "5m"},
        "Sirius":  {"strategy": "AI SWARM CONSENSUS", "asset": "ETHUSDT", "amount": 50.0,  "timeframe": "15m"},
        "Canopus": {"strategy": "TREND BALANCER",     "asset": "SOLUSDT", "amount": 25.0,  "timeframe": "1h"},
    }

    if not row or not row.config_json:
        return defaults.get(engine_name, defaults["Rigel"])

    config = json.loads(row.config_json) if isinstance(row.config_json, str) else row.config_json
    base = defaults.get(engine_name, {})
    return {**base, **config}


def _normalize_symbol(symbol: str) -> str:
    """Ensure symbol has / separator for CCXT (BTCUSDT → BTC/USDT)."""
    symbol = symbol.upper().replace("-", "").replace("/", "").replace("_", "")
    stable = ["USDT", "BUSD", "USDC", "FDUSD"]
    for s in stable:
        if symbol.endswith(s):
            return f"{symbol[:-len(s)]}/{s}"
    return symbol


async def _run_rigel_loop(user_id: int):
    """
    Phase 2 — Rigel: Manual-trigger scalper.
    Rigel is already armed via 'Start'. It polls every 30 seconds just to
    keep stats alive and check if it should auto-exit open positions.
    Manual trades come through POST /execution/trade with engine_name=Rigel.
    This loop only manages auto-exit of open positions when stop-loss/take-profit
    is reached, so users don't have to manually close every trade.
    """
    logger.info("[Rigel] Loop started — armed for manual trades + auto-exit")

    while engine.engine_states["Rigel"]["status"] == "Running":
        try:
            db: Session = SessionLocal()
            try:
                config = _get_engine_config(db, user_id, "Rigel")
                symbol = _normalize_symbol(config.get("asset", "BTCUSDT"))
                amount = float(config.get("amount", 10.0))

                # Get current price
                md = _get_market_data()
                candles = await md.get_candles(symbol, timeframe="1m", limit=5)
                if not candles:
                    await asyncio.sleep(15)
                    continue

                current_price = float(candles[-1][4])  # close price

                # Check open positions for Rigel — auto-exit if stop-loss hit
                from backend.shared.models.trading import TradeRecord
                open_trades = db.query(TradeRecord).filter_by(
                    user_id=user_id,
                    engine_name="Rigel",
                    status="FILLED"
                ).all()

                for trade in open_trades:
                    if trade.entry_price and trade.entry_price > 0:
                        pnl_pct = ((current_price - trade.entry_price) / trade.entry_price) * 100
                        # Auto-exit: take profit at +1.5% or stop loss at -1%
                        should_exit = pnl_pct >= 1.5 or pnl_pct <= -1.0
                        if should_exit:
                            reason = "take-profit" if pnl_pct > 0 else "stop-loss"
                            logger.info(f"[Rigel] Auto-exit {trade.symbol} at {pnl_pct:.2f}% ({reason})")
                            result = await engine.execute_trade(
                                db=db,
                                user_id=user_id,
                                symbol=symbol,
                                side="sell",
                                order_type="market",
                                amount=float(trade.amount or amount),
                                price=None,
                                engine_name="Rigel"
                            )
                            if result.get("success"):
                                trade.status = "CLOSED"
                                trade.exit_price = current_price
                                trade.pnl_pct = pnl_pct
                                db.commit()
                                logger.info(f"[Rigel] Closed trade — PnL: {pnl_pct:.2f}%")

                engine.engine_states["Rigel"]["session_running"] = len(open_trades)

            finally:
                db.close()

        except asyncio.CancelledError:
            break
        except Exception as e:
            logger.error(f"[Rigel] Loop error: {e}")

        await asyncio.sleep(30)  # Rigel checks every 30 seconds

    logger.info("[Rigel] Loop stopped")


async def _run_sirius_loop(user_id: int):
    """
    Phase 3 — Sirius: Full autonomous trading loop.
    Polls market data every 15 minutes, evaluates strategy signals,
    runs through full safety gates, executes if signal is strong.
    """
    logger.info("[Sirius] Autonomous loop started")
    consecutive_errors = 0

    while engine.engine_states["Sirius"]["status"] == "Running":
        try:
            db: Session = SessionLocal()
            try:
                config = _get_engine_config(db, user_id, "Sirius")
                symbol = _normalize_symbol(config.get("asset", "ETHUSDT"))
                amount = float(config.get("amount", 50.0))
                timeframe = config.get("timeframe", "15m")
                strategy_name = config.get("strategy", "AI SWARM CONSENSUS").upper()

                # Get candle data
                md = _get_market_data()
                candles = await md.get_candles(symbol, timeframe=timeframe, limit=50)
                if not candles or len(candles) < 10:
                    logger.warning(f"[Sirius] Insufficient candle data for {symbol}")
                    await asyncio.sleep(60)
                    continue

                current_price = float(candles[-1][4])

                # Build market data dict for strategy
                closes = [float(c[4]) for c in candles]
                highs  = [float(c[2]) for c in candles]
                lows   = [float(c[3]) for c in candles]
                vols   = [float(c[5]) for c in candles]

                market_dict = {
                    "closes": closes,
                    "highs":  highs,
                    "lows":   lows,
                    "volumes": vols,
                    "current_price": current_price,
                    "symbol": symbol,
                    "timeframe": timeframe,
                }

                # Evaluate strategy signal
                StrategyClass = STRATEGY_REGISTRY.get(strategy_name, TrendFollowingStrategy)
                strategy = StrategyClass()
                should_enter, enter_reason = strategy.should_enter(symbol, current_price, market_dict)

                if should_enter:
                    logger.info(f"[Sirius] ENTRY SIGNAL: {symbol} @ {current_price} — {enter_reason}")

                    # SafetyGuardian check before executing
                    from backend.app.services.balance_cache import get_cached_net_worth
                    balance = await get_cached_net_worth(db, user_id) or 100.0

                    safety_ok, safety_reason = SafetyGuardian.check_before_trade(
                        db=db,
                        user_id=user_id,
                        engine_name="Sirius",
                        trade_size_usd=amount,
                        current_balance_usd=balance
                    )

                    if not safety_ok:
                        logger.warning(f"[Sirius] SafetyGuardian blocked: {safety_reason}")
                    else:
                        result = await engine.execute_trade(
                            db=db,
                            user_id=user_id,
                            symbol=symbol,
                            side="buy",
                            order_type="market",
                            amount=amount,
                            price=None,
                            engine_name="Sirius"
                        )

                        if result.get("success"):
                            logger.info(f"[Sirius] Trade executed: {result}")
                            SafetyGuardian.record_trade_result(
                                db=db, user_id=user_id,
                                engine_name="Sirius",
                                pnl_usd=0.0,  # will be updated when trade closes
                                current_balance_usd=balance
                            )
                        else:
                            logger.warning(f"[Sirius] Trade rejected: {result.get('error')}")
                else:
                    logger.debug(f"[Sirius] No signal for {symbol} @ {current_price}")

                consecutive_errors = 0

            finally:
                db.close()

        except asyncio.CancelledError:
            break
        except Exception as e:
            consecutive_errors += 1
            logger.error(f"[Sirius] Loop error #{consecutive_errors}: {e}")
            if consecutive_errors >= 5:
                logger.error("[Sirius] Too many errors — halting autonomous loop")
                engine.engine_states["Sirius"]["status"] = "Stopped"
                break

        # Sirius polls every 15 minutes (900 seconds)
        # But checks status every 30s so Stop is responsive
        for _ in range(30):
            if engine.engine_states["Sirius"]["status"] != "Running":
                break
            await asyncio.sleep(30)

    logger.info("[Sirius] Autonomous loop stopped")


async def _run_canopus_loop(user_id: int):
    """
    Phase 4 — Canopus: Hybrid engine (user sets amount + window, engine auto-picks).
    Longer timeframe (1h-4h), conservative positioning, portfolio balancing logic.
    Polls every 1 hour, picks best opportunity within user's configured bounds.
    """
    logger.info("[Canopus] Hybrid loop started")
    consecutive_errors = 0

    # Canopus auto-scans multiple pairs and picks the best signal
    CANOPUS_SCAN_PAIRS = ["BTC/USDT", "ETH/USDT", "SOL/USDT", "BNB/USDT"]

    while engine.engine_states["Canopus"]["status"] == "Running":
        try:
            db: Session = SessionLocal()
            try:
                config = _get_engine_config(db, user_id, "Canopus")
                amount = float(config.get("amount", 25.0))
                timeframe = config.get("timeframe", "1h")
                strategy_name = config.get("strategy", "TREND BALANCER").upper()
                StrategyClass = STRATEGY_REGISTRY.get(strategy_name, TrendFollowingStrategy)

                md = _get_market_data()
                best_signal = None
                best_symbol = None

                # Scan all pairs and pick strongest signal
                for pair in CANOPUS_SCAN_PAIRS:
                    candles = await md.get_candles(pair, timeframe=timeframe, limit=50)
                    if not candles or len(candles) < 10:
                        continue

                    current_price = float(candles[-1][4])
                    closes = [float(c[4]) for c in candles]
                    highs  = [float(c[2]) for c in candles]
                    lows   = [float(c[3]) for c in candles]
                    vols   = [float(c[5]) for c in candles]

                    market_dict = {
                        "closes": closes, "highs": highs, "lows": lows,
                        "volumes": vols, "current_price": current_price,
                        "symbol": pair, "timeframe": timeframe,
                    }

                    strategy = StrategyClass()
                    should_enter, reason = strategy.should_enter(pair, current_price, market_dict)
                    if should_enter:
                        best_signal = (current_price, reason)
                        best_symbol = pair
                        break  # Take first strong signal (conservative)

                if best_signal and best_symbol:
                    current_price, reason = best_signal
                    logger.info(f"[Canopus] SIGNAL: {best_symbol} @ {current_price} — {reason}")

                    from backend.app.services.balance_cache import get_cached_net_worth
                    balance = await get_cached_net_worth(db, user_id) or 100.0

                    safety_ok, safety_reason = SafetyGuardian.check_before_trade(
                        db=db, user_id=user_id, engine_name="Canopus",
                        trade_size_usd=amount, current_balance_usd=balance
                    )

                    if not safety_ok:
                        logger.warning(f"[Canopus] SafetyGuardian blocked: {safety_reason}")
                    else:
                        result = await engine.execute_trade(
                            db=db, user_id=user_id, symbol=best_symbol,
                            side="buy", order_type="market",
                            amount=amount, price=None, engine_name="Canopus"
                        )
                        if result.get("success"):
                            logger.info(f"[Canopus] Trade executed: {result}")
                        else:
                            logger.warning(f"[Canopus] Trade rejected: {result.get('error')}")
                else:
                    logger.info("[Canopus] No signal across all pairs")

                consecutive_errors = 0

            finally:
                db.close()

        except asyncio.CancelledError:
            break
        except Exception as e:
            consecutive_errors += 1
            logger.error(f"[Canopus] Loop error #{consecutive_errors}: {e}")
            if consecutive_errors >= 5:
                logger.error("[Canopus] Too many errors — halting hybrid loop")
                engine.engine_states["Canopus"]["status"] = "Stopped"
                break

        # Canopus checks every 1 hour. Polls status every 60s for responsiveness.
        for _ in range(60):
            if engine.engine_states["Canopus"]["status"] != "Running":
                break
            await asyncio.sleep(60)

    logger.info("[Canopus] Hybrid loop stopped")


# ──────────────────────────────────────────────────────────────────────────────
# PUBLIC API — called from engine router when status changes to Running/Stopped
# ──────────────────────────────────────────────────────────────────────────────

async def start_engine_loop(engine_name: str, user_id: int):
    """Start the autonomous loop for a given engine. Called when status → Running."""
    global _active_loops

    # Cancel existing loop if somehow still running
    if engine_name in _active_loops and not _active_loops[engine_name].done():
        _active_loops[engine_name].cancel()
        try:
            await _active_loops[engine_name]
        except asyncio.CancelledError:
            pass

    loop_fn = {
        "Rigel":   _run_rigel_loop,
        "Sirius":  _run_sirius_loop,
        "Canopus": _run_canopus_loop,
    }.get(engine_name)

    if loop_fn is None:
        logger.warning(f"No autonomous loop defined for engine: {engine_name}")
        return

    task = asyncio.create_task(loop_fn(user_id), name=f"loop_{engine_name}")
    _active_loops[engine_name] = task
    logger.info(f"[{engine_name}] Autonomous loop task created")


async def stop_engine_loop(engine_name: str):
    """Stop the autonomous loop for a given engine. Called when status → Stopped."""
    global _active_loops

    task = _active_loops.get(engine_name)
    if task and not task.done():
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass
        logger.info(f"[{engine_name}] Loop cancelled")
    _active_loops.pop(engine_name, None)
