"""MEMOBOT FX-PRO FastAPI application entrypoint."""
import asyncio
import mimetypes
import os
import sys
from contextlib import asynccontextmanager

# Windows fix: the default ProactorEventLoop has long-standing, well-documented
# DNS resolution bugs with aiohttp (intermittent/consistent "Could not contact
# DNS servers" errors even when the OS's own DNS resolution works fine).
# SelectorEventLoop does not have this problem. Must be set before any asyncio
# loop is created, so this goes before any other imports run.
if sys.platform.startswith("win"):
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

backend_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
parent_dir = os.path.dirname(backend_dir)

if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

mimetypes.add_type("text/css", ".css")
mimetypes.add_type("application/javascript", ".js")

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import text
from prometheus_fastapi_instrumentator import Instrumentator

from backend.app.config import CORS_ORIGINS
from backend.app.database import SessionLocal
from backend.app.engine_instance import engine as exec_engine
from backend.app.html_protection import setup_html_protection
from backend.app.rate_limiting import setup_rate_limiting
from backend.app.routers import (
    auth,
    vault,
    engine,
    execution,
    evaluation,
    risk_config,
    audit,
    ai_chat,
    observability,
    notifications,
    websocket,
    webhooks,
    billing,
    strategies,
    engine_monitoring,
    decision,
    market,
)
from backend.app.workers.outbox import outbox_worker
from backend.app.services.balance_cache import start_balance_cacher


@asynccontextmanager
async def lifespan(app: FastAPI):
    outbox_task = asyncio.create_task(
        outbox_worker.start(),
        name="memobot-outbox-worker",
    )

    # Start Binance balance background cacher (refreshes every 30s automatically)
    balance_cacher_task = asyncio.create_task(
        start_balance_cacher(),
        name="memobot-balance-cacher",
    )

    try:
        yield
    finally:
        await outbox_worker.stop()
        outbox_task.cancel()
        balance_cacher_task.cancel()

        try:
            await outbox_task
        except asyncio.CancelledError:
            pass

        try:
            await balance_cacher_task
        except asyncio.CancelledError:
            pass

        await exec_engine.close()


app = FastAPI(
    title="MEMOBOT FX-PRO API",
    description="Islamic-Compliant AI Trading Platform",
    version="2.1.0",
    lifespan=lifespan,
)

setup_rate_limiting(app)

Instrumentator().instrument(app).expose(
    app,
    include_in_schema=False,
    tags=["Diagnostics"],
)

setup_html_protection(app)

for router in (
    auth.router,
    vault.router,
    engine.router,
    execution.router,
    evaluation.router,
    risk_config.router,
    audit.router,
    ai_chat.router,
    observability.router,
    notifications.router,
    websocket.router,
    webhooks.router,
    billing.router,
    strategies.router,
    engine_monitoring.router,
    decision.router,
    market.router,
):
    app.include_router(router)

# Include alternative market intel router for frontend compatibility
from backend.app.routers.market import market_intel_router
app.include_router(market_intel_router)

# Include gateway router for frontend compatibility
from backend.app.routers.market import gateway_router
app.include_router(gateway_router)


@app.get("/api/health")
async def health_check():
    return {
        "status": "operational",
        "version": "2.1.0",
        "security": [
            "Content Security Policy (CSP)",
            "XSS/HTML protection middleware",
            "Clickjacking Protection",
            "Rate Limiting",
            "Input Sanitization",
        ],
    }


@app.get("/api/ready")
def readiness_check():
    db = SessionLocal()

    try:
        db.execute(text("SELECT 1"))
        db.rollback()
        return {
            "status": "ready",
            "database": "ok",
        }

    except Exception:
        db.rollback()
        raise HTTPException(
            status_code=503,
            detail="Database not ready",
        )

    finally:
        db.close()


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8000,
        log_level="info",
    )