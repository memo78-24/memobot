from datetime import datetime
from typing import Dict, Any, List, Optional
import logging

logger = logging.getLogger("memobot_fxpro.pipeline")

# The 9 pipeline stages
STAGES = [
    "1.SG",   # Signal Generation
    "2.FI",   # Filter & Pre-checks
    "3.SHA",  # Shariah Compliance Audit
    "4.RSK",  # Risk Management Gate
    "5.SIZE", # Sizing Verification
    "6.PLC",  # Placement / Order Routing
    "7.CNF",  # Order Confirmation / Fill
    "8.REC",  # Audit Ledger Recording
    "9.MON"   # Post-Trade Tracking & PnL Monitoring
]

class OrderPipelineTracker:
    """Manages 9-stage pipeline state progression for trading orders."""
    def __init__(self):
        self.active_pipelines: Dict[str, List[Dict[str, Any]]] = {}

    def start_pipeline(self, engine_name: str, order_id: str, symbol: str, side: str, amount: float) -> str:
        pipeline = {
            "order_id": order_id,
            "symbol": symbol,
            "side": side,
            "amount": amount,
            "current_stage": "1.SG",
            "stages_completed": ["1.SG"],
            "timestamp": datetime.utcnow().isoformat(),
            "status": "IN_PROGRESS"
        }
        if engine_name not in self.active_pipelines:
            self.active_pipelines[engine_name] = []
        self.active_pipelines[engine_name].append(pipeline)
        logger.info(f"[{engine_name}] Pipeline started for order {order_id} at stage 1.SG")
        return "1.SG"

    def advance_stage(self, engine_name: str, order_id: str, next_stage: str) -> bool:
        if next_stage not in STAGES:
            logger.warning(f"Invalid stage name: {next_stage}")
            return False
            
        pipelines = self.active_pipelines.get(engine_name, [])
        for p in pipelines:
            if p["order_id"] == order_id:
                p["current_stage"] = next_stage
                if next_stage not in p["stages_completed"]:
                    p["stages_completed"].append(next_stage)
                logger.info(f"[{engine_name}] Order {order_id} advanced to stage {next_stage}")
                if next_stage == "9.MON":
                    p["status"] = "COMPLETED"
                return True
        return False

    def fail_pipeline(self, engine_name: str, order_id: str, reason: str, failed_stage: str = None):
        pipelines = self.active_pipelines.get(engine_name, [])
        for p in pipelines:
            if p["order_id"] == order_id:
                p["status"] = "FAILED"
                p["error_reason"] = reason
                p["failed_stage"] = failed_stage or p.get("current_stage")
                if p["failed_stage"] and p["failed_stage"] not in p["stages_completed"]:
                    p["stages_completed"].append(p["failed_stage"])
                logger.error(f"[{engine_name}] Order {order_id} failed at {p['failed_stage']}: {reason}")
                return True
        return False

    def get_status(self, engine_name: str, order_id: str) -> Optional[Dict[str, Any]]:
        pipelines = self.active_pipelines.get(engine_name, [])
        for p in pipelines:
            if p["order_id"] == order_id:
                return p
        return None

    def to_stages_array(self, pipeline: Dict[str, Any]) -> List[int]:
        """Convert pipeline state to frontend segment array: 1=done, -1=failed, 0=pending."""
        stages = [0] * len(STAGES)
        failed = pipeline.get("status") == "FAILED"
        fail_stage = pipeline.get("failed_stage") or pipeline.get("current_stage")
        for i, stage_name in enumerate(STAGES):
            if stage_name not in pipeline.get("stages_completed", []):
                continue
            if failed and stage_name == fail_stage:
                stages[i] = -1
            else:
                stages[i] = 1
        return stages


# Global pipeline tracker
pipeline_tracker = OrderPipelineTracker()
