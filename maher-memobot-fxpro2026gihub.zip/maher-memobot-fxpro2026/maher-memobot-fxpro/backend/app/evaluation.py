# backend/app/evaluation.py
# ═══════════════════════════════════════════════════════════════════════════
# MEMOBOT FX-PRO — Market Evaluation Engine
# ═══════════════════════════════════════════════════════════════════════════
#
# Computes multi-factor market score for trade approval/rejection.
#
# Indicators computed (all from real market data):
#   1. Order Book Pressure (buy/sell wall imbalance)
#   2. RSI (Wilder's smoothed, 14-period)
#   3. MACD (12/26/9 standard)
#   4. Bollinger Bands (20-period, 2σ)
#   5. Volatility (ATR-based, continuous)
#   6. Spread Analysis (bid-ask tightness)
#   7. Swarm Consensus (multi-agent sentiment)
#   8. Risk Alignment (user-configured DB limits)
#
# Safety invariants:
#   - Cached market data with configurable TTL (no redundant API calls)
#   - Graceful degradation: missing indicators → neutral score, not failure
#   - Continuous scoring (0–100), never binary
#   - Weights validated to sum to 1.0
#   - All ccxt calls have timeout protection
#
# ═══════════════════════════════════════════════════════════════════════════

import os
import time
import asyncio
import logging
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import asyncpg
import ccxt.async_support as ccxt

from backend.app.swarm_instance import swarm
from backend.app.observability import log_structured

logger = logging.getLogger("memobot_fxpro.evaluation")


# ═══════════════════════════════════════════════════════════════════════════
# Configuration
# ═══════════════════════════════════════════════════════════════════════════

# Cache TTLs (seconds)
ORDERBOOK_CACHE_TTL = int(os.environ.get("EVAL_ORDERBOOK_TTL", "3"))
CANDLES_CACHE_TTL = int(os.environ.get("EVAL_CANDLES_TTL", "30"))

# API timeout
CCXT_TIMEOUT_MS = int(os.environ.get("CCXT_TIMEOUT_MS", "10000"))

# Indicator parameters
RSI_PERIOD = 14
MACD_FAST = 12
MACD_SLOW = 26
MACD_SIGNAL = 9
BOLLINGER_PERIOD = 20
BOLLINGER_STD_DEV = 2.0
ATR_PERIOD = 14

# Neutral score (returned when data is unavailable)
NEUTRAL_SCORE = 50.0

# Order book depth levels
ORDERBOOK_DEPTH = 20
PRESSURE_DEPTH = 10

# Per-engine weight profiles (MUST sum to 1.0)
ENGINE_WEIGHTS = {
    "Rigel": {
        "pressure": 0.15,
        "rsi": 0.15,
        "macd": 0.10,
        "bollinger": 0.10,
        "volatility": 0.05,
        "spread": 0.05,
        "swarm": 0.10,
        "risk": 0.30,
    },
    "Sirius": {
        "pressure": 0.10,
        "rsi": 0.12,
        "macd": 0.12,
        "bollinger": 0.08,
        "volatility": 0.08,
        "spread": 0.05,
        "swarm": 0.30,
        "risk": 0.15,
    },
    "Canopus": {
        "pressure": 0.15,
        "rsi": 0.12,
        "macd": 0.12,
        "bollinger": 0.10,
        "volatility": 0.08,
        "spread": 0.08,
        "swarm": 0.20,
        "risk": 0.15,
    },
}

# Validate all weight profiles sum to 1.0
for _engine, _weights in ENGINE_WEIGHTS.items():
    _total = sum(_weights.values())
    assert abs(_total - 1.0) < 0.001, f"{_engine} weights sum to {_total}, not 1.0"


# ═══════════════════════════════════════════════════════════════════════════
# Market Data Client (Imported from backend.app.market_data)
# ═══════════════════════════════════════════════════════════════════════════

from backend.app.market_data import market_data



# ═══════════════════════════════════════════════════════════════════════════
# Indicator Functions (Pure Math, No Side Effects)
# ═══════════════════════════════════════════════════════════════════════════

def compute_order_book_pressure(ob: Dict[str, Any], side: str) -> float:
    """
    Calculate buy/sell pressure from order book depth.
    Returns 0–100 continuous score (higher = more favorable for the given side).
    """
    try:
        bids = ob.get("bids", [])
        asks = ob.get("asks", [])

        bid_vol = sum(b[1] for b in bids[:PRESSURE_DEPTH])
        ask_vol = sum(a[1] for a in asks[:PRESSURE_DEPTH])

        total = bid_vol + ask_vol
        if total == 0:
            return NEUTRAL_SCORE

        buy_pressure = (bid_vol / total) * 100.0

        if side.upper() == "BUY":
            return round(buy_pressure, 2)
        else:
            return round(100.0 - buy_pressure, 2)
    except Exception:
        return NEUTRAL_SCORE


def compute_spread_score(ob: Dict[str, Any]) -> float:
    """
    Score bid-ask spread tightness.
    Tighter spread → higher score (better for execution).

    Returns 0–100:
      < 0.01% spread → 95 (excellent)
      0.01–0.05% → 80 (good)
      0.05–0.15% → 60 (acceptable)
      0.15–0.50% → 35 (wide)
      > 0.50% → 15 (dangerous)
    """
    try:
        bids = ob.get("bids", [])
        asks = ob.get("asks", [])

        if not bids or not asks:
            return NEUTRAL_SCORE

        best_bid = bids[0][0]
        best_ask = asks[0][0]
        mid_price = (best_bid + best_ask) / 2.0

        if mid_price <= 0:
            return NEUTRAL_SCORE

        spread_pct = ((best_ask - best_bid) / mid_price) * 100.0

        if spread_pct < 0.01:
            return 95.0
        elif spread_pct < 0.05:
            return 80.0 + (0.05 - spread_pct) / 0.04 * 15.0
        elif spread_pct < 0.15:
            return 60.0 + (0.15 - spread_pct) / 0.10 * 20.0
        elif spread_pct < 0.50:
            return 35.0 + (0.50 - spread_pct) / 0.35 * 25.0
        else:
            return max(5.0, 15.0 - (spread_pct - 0.50) * 10.0)
    except Exception:
        return NEUTRAL_SCORE


def _ema(data: np.ndarray, period: int) -> np.ndarray:
    """Calculate Exponential Moving Average."""
    alpha = 2.0 / (period + 1.0)
    result = np.empty_like(data, dtype=float)
    result[0] = data[0]
    for i in range(1, len(data)):
        result[i] = alpha * data[i] + (1.0 - alpha) * result[i - 1]
    return result


def compute_rsi(candles: List[List[float]], side: str) -> float:
    """
    Calculate RSI (Wilder's smoothed, 14-period).
    Returns 0–100 continuous score (higher = more favorable for the given side).

    BUY logic:  RSI < 30 oversold → strong buy signal (high score)
                RSI > 70 overbought → weak buy signal (low score)
    SELL logic: RSI > 70 overbought → strong sell signal (high score)
                RSI < 30 oversold → weak sell signal (low score)
    """
    try:
        if len(candles) < RSI_PERIOD + 2:
            return NEUTRAL_SCORE

        closes = np.array([c[4] for c in candles], dtype=float)
        diffs = np.diff(closes)

        gains = np.where(diffs > 0, diffs, 0.0)
        losses = np.where(diffs < 0, -diffs, 0.0)

        # Wilder's smoothing
        avg_gain = np.mean(gains[:RSI_PERIOD])
        avg_loss = np.mean(losses[:RSI_PERIOD])

        for i in range(RSI_PERIOD, len(diffs)):
            avg_gain = (avg_gain * (RSI_PERIOD - 1) + gains[i]) / RSI_PERIOD
            avg_loss = (avg_loss * (RSI_PERIOD - 1) + losses[i]) / RSI_PERIOD

        if avg_loss == 0:
            rsi = 100.0
        else:
            rs = avg_gain / avg_loss
            rsi = 100.0 - (100.0 / (1.0 + rs))

        # Continuous scoring (not binary thresholds)
        if side.upper() == "BUY":
            # Lower RSI = better buy opportunity
            # RSI 20 → 90, RSI 50 → 50, RSI 80 → 10
            score = 100.0 - rsi
        else:
            # Higher RSI = better sell opportunity
            score = rsi

        return float(round(np.clip(score, 5.0, 95.0), 2))
    except Exception as e:
        logger.debug(f"RSI computation error: {e}")
        return NEUTRAL_SCORE


def compute_macd(candles: List[List[float]], side: str) -> float:
    """
    Calculate MACD alignment (12/26/9).
    Returns 0–100 continuous score.
    """
    try:
        if len(candles) < MACD_SLOW + MACD_SIGNAL:
            return NEUTRAL_SCORE

        closes = np.array([c[4] for c in candles], dtype=float)

        ema_fast = _ema(closes, MACD_FAST)
        ema_slow = _ema(closes, MACD_SLOW)
        macd_line = ema_fast - ema_slow
        signal_line = _ema(macd_line, MACD_SIGNAL)
        histogram = macd_line - signal_line

        # Current and previous histogram values
        h_current = histogram[-1]
        h_prev = histogram[-2] if len(histogram) >= 2 else 0.0

        # Normalize histogram to a score
        # Use recent histogram range for dynamic normalization
        recent_hist = histogram[-20:]
        h_range = np.max(np.abs(recent_hist))
        if h_range == 0:
            return NEUTRAL_SCORE

        # Normalize to -1..+1
        normalized = h_current / h_range

        # Direction bonus: accelerating momentum
        direction_bonus = 0.0
        if h_current > 0 and h_current > h_prev:
            direction_bonus = 10.0  # Bullish momentum accelerating
        elif h_current < 0 and h_current < h_prev:
            direction_bonus = 10.0  # Bearish momentum accelerating

        if side.upper() == "BUY":
            score = 50.0 + (normalized * 40.0) + (direction_bonus if normalized > 0 else 0)
        else:
            score = 50.0 - (normalized * 40.0) + (direction_bonus if normalized < 0 else 0)

        return float(round(np.clip(score, 5.0, 95.0), 2))
    except Exception as e:
        logger.debug(f"MACD computation error: {e}")
        return NEUTRAL_SCORE


def compute_bollinger_bands(candles: List[List[float]], side: str) -> float:
    """
    Bollinger Bands (20-period, 2σ).
    Returns 0–100 score based on price position relative to bands.

    BUY:  Price near lower band → high score (oversold bounce opportunity)
    SELL: Price near upper band → high score (overbought reversal opportunity)
    """
    try:
        if len(candles) < BOLLINGER_PERIOD + 1:
            return NEUTRAL_SCORE

        closes = np.array([c[4] for c in candles], dtype=float)
        current_price = closes[-1]

        # Calculate bands from recent data
        window = closes[-BOLLINGER_PERIOD:]
        sma = np.mean(window)
        std = np.std(window)

        upper_band = sma + (BOLLINGER_STD_DEV * std)
        lower_band = sma - (BOLLINGER_STD_DEV * std)
        band_width = upper_band - lower_band

        if band_width <= 0:
            return NEUTRAL_SCORE

        # Position within bands (0 = lower band, 1 = upper band)
        position = (current_price - lower_band) / band_width
        position = np.clip(position, -0.5, 1.5)  # Allow slight overshoot

        if side.upper() == "BUY":
            # Lower position = better buy (near support)
            score = (1.0 - position) * 90.0 + 5.0
        else:
            # Higher position = better sell (near resistance)
            score = position * 90.0 + 5.0

        # Bandwidth bonus: narrow bands = potential breakout
        bandwidth_pct = (band_width / sma) * 100.0 if sma > 0 else 0
        if bandwidth_pct < 2.0:
            # Very narrow bands — squeeze incoming
            score = min(score + 5.0, 95.0)

        return float(round(np.clip(score, 5.0, 95.0), 2))
    except Exception as e:
        logger.debug(f"Bollinger computation error: {e}")
        return NEUTRAL_SCORE


def compute_volatility_score(candles: List[List[float]]) -> float:
    """
    ATR-based volatility scoring (continuous, not binary).

    Returns 0–100:
      Very low vol → 30 (not enough movement for profit)
      Low vol → 55 (cautious)
      Medium vol → 85 (ideal for trading)
      High vol → 60 (risky but tradeable)
      Extreme vol → 25 (too dangerous)
    """
    try:
        if len(candles) < ATR_PERIOD + 1:
            return NEUTRAL_SCORE

        highs = np.array([c[2] for c in candles], dtype=float)
        lows = np.array([c[3] for c in candles], dtype=float)
        closes = np.array([c[4] for c in candles], dtype=float)

        # True Range
        tr_values = []
        for i in range(1, len(candles)):
            tr = max(
                highs[i] - lows[i],
                abs(highs[i] - closes[i - 1]),
                abs(lows[i] - closes[i - 1]),
            )
            tr_values.append(tr)

        if not tr_values:
            return NEUTRAL_SCORE

        atr = np.mean(tr_values[-ATR_PERIOD:])
        current_price = closes[-1]

        if current_price <= 0:
            return NEUTRAL_SCORE

        # ATR as percentage of price
        atr_pct = (atr / current_price) * 100.0

        # Continuous scoring curve
        if atr_pct < 0.1:
            score = 30.0  # Dead market
        elif atr_pct < 0.3:
            # Ramp up: 30 → 55
            score = 30.0 + (atr_pct - 0.1) / 0.2 * 25.0
        elif atr_pct < 0.8:
            # Sweet spot: 55 → 85
            score = 55.0 + (atr_pct - 0.3) / 0.5 * 30.0
        elif atr_pct < 1.5:
            # Ramp down: 85 → 60
            score = 85.0 - (atr_pct - 0.8) / 0.7 * 25.0
        elif atr_pct < 3.0:
            # Getting dangerous: 60 → 35
            score = 60.0 - (atr_pct - 1.5) / 1.5 * 25.0
        else:
            score = max(10.0, 35.0 - (atr_pct - 3.0) * 5.0)

        return float(round(score, 2))
    except Exception as e:
        logger.debug(f"Volatility computation error: {e}")
        return NEUTRAL_SCORE


def compute_swarm_consensus(side: str) -> float:
    """
    Read consensus from verified swarm memory.
    Returns 0–100 continuous score.
    """
    try:
        raw_sentiment = getattr(swarm, "sentiment_score", 0.5)
        percentage = float(raw_sentiment) * 100.0
        percentage = np.clip(percentage, 0.0, 100.0)

        if side.upper() == "BUY":
            return float(round(percentage, 2))
        else:
            return float(round(100.0 - percentage, 2))
    except Exception:
        return NEUTRAL_SCORE


# ═══════════════════════════════════════════════════════════════════════════
# Risk Alignment (Database-Backed)
# ═══════════════════════════════════════════════════════════════════════════

async def compute_risk_alignment(
    user_id: Optional[int],
    engine_name: str,
    db=None,
) -> float:
    """
    Compute risk alignment score from user's configured risk matrix (strategy_states).
    Returns 0–100 (higher = safer configuration).
    """
    if db is None or user_id is None:
        return NEUTRAL_SCORE

    try:
        import json
        from backend.shared.models.trading import StrategyState

        row = db.query(StrategyState).filter(
            StrategyState.user_id == user_id,
            StrategyState.name == engine_name.capitalize(),
        ).first()

        if not row or not row.config_json:
            return 60.0

        config = json.loads(row.config_json) if isinstance(row.config_json, str) else row.config_json
        max_dd = float(config.get("max_drawdown", 25.0))
        lev_limit = float(config.get("leverage_limit", 1.0))

        dd_score = max(0.0, 100.0 - max_dd)

        if lev_limit <= 1:
            lev_score = 100.0
        elif lev_limit <= 5:
            lev_score = 100.0 - (lev_limit - 1) * 10.0
        elif lev_limit <= 20:
            lev_score = 60.0 - (lev_limit - 5) * 4.0
        else:
            lev_score = max(0.0, 40.0 - (lev_limit - 20) * 2.0)

        return float(round((dd_score * 0.6) + (lev_score * 0.4), 2))
    except Exception as e:
        logger.debug(f"Risk alignment computation error: {e}")
        return NEUTRAL_SCORE


# ═══════════════════════════════════════════════════════════════════════════
# MAIN: Market Score Computation
# ═══════════════════════════════════════════════════════════════════════════

async def compute_market_score(
    symbol: str,
    side: str,
    engine: str,
    user_id: Optional[int] = None,
    db=None,
) -> Dict[str, Any]:
    """
    Compute multi-factor market score for trade approval.

    Returns:
        {
            "score": 0-100 (float),
            "components": { ... per-indicator scores },
            "weights": { ... engine-specific weights },
            "data_quality": { ... which data sources were available },
            "recommendation": "APPROVE" | "REJECT" | "CAUTION"
        }
    """
    side_upper = side.upper()
    engine_cap = engine.capitalize()

    # Get weight profile for this engine
    weights = ENGINE_WEIGHTS.get(engine_cap, ENGINE_WEIGHTS["Canopus"])

    # Track which data sources succeeded
    data_quality = {
        "order_book": False,
        "candles": False,
        "swarm": False,
        "risk_db": False,
    }

    # ─── Fetch Market Data (single download, reused across all indicators)
    try:
        async with asyncio.timeout(5):  # 5-second timeout to prevent hanging
            ob = await market_data.get_order_book(symbol)
            candles = await market_data.get_candles(symbol, timeframe="15m", limit=50)
    except asyncio.TimeoutError:
        log_structured("WARN", f"Market data timeout for {symbol}")
        ob, candles = None, []

    data_quality["order_book"] = ob is not None and len(ob.get("bids", [])) > 0
    data_quality["candles"] = len(candles) >= MACD_SLOW + MACD_SIGNAL

    # ─── Compute All Indicators ──────────────────────────────────────

    # 1. Order Book Pressure
    if ob:
        pressure_score = compute_order_book_pressure(ob, side_upper)
        spread_score = compute_spread_score(ob)
    else:
        pressure_score = NEUTRAL_SCORE
        spread_score = NEUTRAL_SCORE

    # 2. Technical Indicators (all use the same candles download)
    rsi_score = compute_rsi(candles, side_upper)
    macd_score = compute_macd(candles, side_upper)
    bollinger_score = compute_bollinger_bands(candles, side_upper)
    volatility_score = compute_volatility_score(candles)

    # 3. Swarm Consensus
    try:
        swarm_score = compute_swarm_consensus(side_upper)
        data_quality["swarm"] = True
    except Exception:
        swarm_score = NEUTRAL_SCORE

    # 4. Risk Alignment (database query)
    try:
        risk_score = await compute_risk_alignment(user_id, engine_cap, db=db)
        data_quality["risk_db"] = user_id is not None and db is not None
    except Exception:
        risk_score = NEUTRAL_SCORE

    # ─── Weighted Score ──────────────────────────────────────────────

    components = {
        "pressure": pressure_score,
        "rsi": rsi_score,
        "macd": macd_score,
        "bollinger": bollinger_score,
        "volatility": volatility_score,
        "spread": spread_score,
        "swarm": swarm_score,
        "risk": risk_score,
    }

    final_score = sum(
        weights[indicator] * components[indicator]
        for indicator in weights
    )

    final_score = float(round(np.clip(final_score, 0.0, 100.0), 2))

    # ─── Recommendation ─────────────────────────────────────────────

    if final_score >= 65.0:
        recommendation = "APPROVE"
    elif final_score >= 40.0:
        recommendation = "CAUTION"
    else:
        recommendation = "REJECT"

    # ─── Data Quality Penalty ────────────────────────────────────────
    # If critical data is missing, reduce score to be conservative
    missing_sources = sum(1 for v in data_quality.values() if not v)
    if missing_sources >= 2:
        # Multiple data sources missing — penalize score
        penalty = missing_sources * 5.0
        final_score = max(10.0, final_score - penalty)
        if recommendation == "APPROVE" and missing_sources >= 3:
            recommendation = "CAUTION"

    return {
        "score": final_score,
        "components": components,
        "weights": weights,
        "data_quality": data_quality,
        "recommendation": recommendation,
        "side": side_upper,
        "engine": engine_cap,
        "symbol": symbol,
    }


# ═══════════════════════════════════════════════════════════════════════════
# Standalone Indicator Endpoints (for Wings Intelligence Panel)
# ═══════════════════════════════════════════════════════════════════════════

async def get_wings_intelligence(symbol: str) -> Dict[str, Any]:
    """
    Fetch all indicators for the Buy/Sell Wings panel on
    the Central Engines page. Returns both sides' data.
    """
    try:
        async with asyncio.timeout(5):
            ob = await market_data.get_order_book(symbol)
            candles = await market_data.get_candles(symbol, timeframe="15m", limit=50)
    except asyncio.TimeoutError:
        log_structured("WARN", f"Wings intelligence timeout for {symbol}")
        ob, candles = None, []

    buy_pressure = compute_order_book_pressure(ob, "BUY") if ob else NEUTRAL_SCORE
    sell_pressure = compute_order_book_pressure(ob, "SELL") if ob else NEUTRAL_SCORE
    spread = compute_spread_score(ob) if ob else NEUTRAL_SCORE

    rsi_buy = compute_rsi(candles, "BUY")
    rsi_sell = compute_rsi(candles, "SELL")
    macd_buy = compute_macd(candles, "BUY")
    macd_sell = compute_macd(candles, "SELL")
    bb_buy = compute_bollinger_bands(candles, "BUY")
    bb_sell = compute_bollinger_bands(candles, "SELL")
    vol = compute_volatility_score(candles)

    return {
        "symbol": symbol,
        "buy_side": {
            "pressure": buy_pressure,
            "rsi": rsi_buy,
            "macd": macd_buy,
            "bollinger": bb_buy,
            "spread": spread,
            "volatility": vol,
        },
        "sell_side": {
            "pressure": sell_pressure,
            "rsi": rsi_sell,
            "macd": macd_sell,
            "bollinger": bb_sell,
            "spread": spread,
            "volatility": vol,
        },
        "order_book": {
            "bids": ob.get("bids", [])[:10] if ob else [],
            "asks": ob.get("asks", [])[:10] if ob else [],
        },
    }


async def get_depth_data(symbol: str) -> Dict[str, Any]:
    """Fetch order book depth for the Paper Trade depth table."""
    try:
        async with asyncio.timeout(3):
            ob = await market_data.get_order_book(symbol)
    except asyncio.TimeoutError:
        ob = None
    if not ob:
        return {"bids": [], "asks": []}
    return {
        "bids": ob.get("bids", [])[:ORDERBOOK_DEPTH],
        "asks": ob.get("asks", [])[:ORDERBOOK_DEPTH],
    }


# ═══════════════════════════════════════════════════════════════════════════
# Cleanup (call on app shutdown)
# ═══════════════════════════════════════════════════════════════════════════

async def shutdown_market_data():
    """Close the market data client. Call during app shutdown."""
    await market_data.close()
    log_structured("INFO", "Market data client closed.")