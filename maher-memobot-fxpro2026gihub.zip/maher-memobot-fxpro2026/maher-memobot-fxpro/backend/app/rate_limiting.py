"""
RATE LIMITING MIDDLEWARE
Prevents DOS attacks and API abuse
"""

from slowapi import Limiter
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
from fastapi import FastAPI
from fastapi.responses import JSONResponse

# Initialize rate limiter
limiter = Limiter(key_func=get_remote_address)

def setup_rate_limiting(app: FastAPI):
    """Setup rate limiting middleware on FastAPI app"""
    
    app.state.limiter = limiter
    
    # Exception handler for rate limit exceeded
    @app.exception_handler(RateLimitExceeded)
    async def rate_limit_exceeded_handler(request, exc):
        return JSONResponse(
            status_code=429,
            content={"error": "Rate limit exceeded. Please try again later."}
        )

# Rate Limit Decorators for Different Endpoints
class RateLimits:
    """Rate limit constants"""
    
    # AUTH ENDPOINTS
    LOGIN = "5/minute"              # 5 login attempts per minute
    REGISTER = "2/minute"            # 2 registrations per minute
    CHANGE_PASSWORD = "3/minute"     # 3 password changes per minute
    
    # TRADING ENDPOINTS
    EXECUTE_TRADE = "10/minute"      # 10 trades per minute
    GET_BALANCES = "60/minute"       # 60 balance checks per minute
    GET_POSITIONS = "30/minute"      # 30 position checks per minute
    RESET_PAPER = "5/minute"         # 5 paper resets per minute
    
    # ENGINE ENDPOINTS
    ENGINE_START_STOP = "20/minute"  # 20 start/stop per minute
    ENGINE_KILL = "3/minute"         # 3 kill switch uses per minute
    
    # VAULT ENDPOINTS
    VAULT_TEST = "10/minute"         # 10 connection tests per minute
    VAULT_UPDATE = "5/minute"        # 5 credential updates per minute
    
    # RISK ENDPOINTS
    UPDATE_RISK = "10/minute"        # 10 risk config updates per minute
    
    # MARKET DATA
    GET_MARKET_DATA = "100/minute"   # 100 market data requests per minute
    GET_ORDER_BOOK = "60/minute"     # 60 order book requests per minute
    
    # AI ENDPOINTS
    AI_QUERY = "20/minute"           # 20 AI queries per minute
    AI_TRANSLATE = "30/minute"       # 30 translation requests per minute
    
    # AUDIT ENDPOINTS
    GET_AUDIT_LOGS = "10/minute"     # 10 audit log requests per minute
    GET_AUDIT_CHARTS = "10/minute"   # 10 chart requests per minute
    
    # OBSERVABILITY
    GET_METRICS = "60/minute"        # 60 metric requests per minute
