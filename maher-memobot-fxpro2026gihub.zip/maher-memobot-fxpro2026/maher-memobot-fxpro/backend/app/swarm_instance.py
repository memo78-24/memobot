from backend.app.swarm import SwarmCoordinator

# Global shared instance of the swarm coordinator
swarm = SwarmCoordinator()
