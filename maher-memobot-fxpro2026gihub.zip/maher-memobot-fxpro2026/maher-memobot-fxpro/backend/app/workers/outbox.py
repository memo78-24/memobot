"""Transactional outbox worker with retry/backoff semantics."""
import asyncio
import logging
from datetime import datetime, timedelta
from sqlalchemy import select
from backend.app.database import SessionLocal
from backend.shared.models.outbox import OutboxEvent

logger = logging.getLogger(__name__)


class OutboxWorker:
    def __init__(self, poll_interval: float = 1.0, batch_size: int = 25):
        self.poll_interval = poll_interval
        self.batch_size = batch_size
        self._running = False

    async def start(self):
        if self._running:
            return
        self._running = True
        logger.info("outbox_worker_started", extra={"poll_interval": self.poll_interval, "batch_size": self.batch_size})
        try:
            while self._running:
                try:
                    processed = await self.process_batch()
                    if processed == 0:
                        await asyncio.sleep(self.poll_interval)
                except asyncio.CancelledError:
                    raise
                except Exception:
                    logger.exception("outbox_worker_cycle_failed")
                    await asyncio.sleep(self.poll_interval)
        finally:
            self._running = False
            logger.info("outbox_worker_stopped")

    async def stop(self):
        self._running = False

    async def process_batch(self) -> int:
        db = SessionLocal()
        try:
            now = datetime.utcnow()
            events = db.execute(
                select(OutboxEvent)
                .where(OutboxEvent.status == "PENDING", OutboxEvent.available_at <= now)
                .order_by(OutboxEvent.created_at.asc())
                .limit(self.batch_size)
            ).scalars().all()
            if not events:
                return 0
            processed = 0
            for event in events:
                try:
                    self._claim(event)
                    await self._dispatch(event)
                    event.status = "PROCESSED"
                    event.processed_at = datetime.utcnow()
                    event.locked_at = None
                    event.last_error = None
                    processed += 1
                except Exception as exc:
                    self._schedule_retry(event, exc)
            db.commit()
            return processed
        except Exception:
            db.rollback()
            raise
        finally:
            db.close()

    def _claim(self, event: OutboxEvent):
        event.attempts = int(event.attempts or 0) + 1
        event.locked_at = datetime.utcnow()
        if event.attempts > int(event.max_attempts or 10):
            raise RuntimeError("outbox retry limit exceeded")

    async def _dispatch(self, event: OutboxEvent):
        # Internal boundary. Domain-specific handlers can be attached here.
        logger.info(
            "outbox_event_dispatched",
            extra={
                "event_id": event.event_id,
                "event_type": event.event_type,
                "aggregate_type": event.aggregate_type,
                "aggregate_id": event.aggregate_id,
            },
        )

    def _schedule_retry(self, event: OutboxEvent, error: Exception):
        attempts = int(event.attempts or 0)
        if attempts >= int(event.max_attempts or 10):
            event.status = "FAILED"
            event.failed_at = datetime.utcnow()
            event.locked_at = None
            event.last_error = str(error)
            logger.error("outbox_event_permanently_failed", extra={"event_id": event.event_id, "attempts": attempts})
            return
        delay_seconds = min(300, 2 ** min(attempts, 8))
        event.status = "PENDING"
        event.available_at = datetime.utcnow() + timedelta(seconds=delay_seconds)
        event.locked_at = None
        event.last_error = str(error)
        logger.warning("outbox_event_retry_scheduled", extra={"event_id": event.event_id, "attempts": attempts, "retry_in_seconds": delay_seconds})


outbox_worker = OutboxWorker()
