import asyncio
import logging
import datetime
from sqlalchemy.orm import Session
from backend.app.database import SessionLocal
from backend.shared.models.user import User, NotificationQueueItem
from backend.app.services.notifications.telegram_service import send_telegram_message
from backend.app.services.notifications.email_service import _send_email
from backend.app.services.notifications.whatsapp_service import send_whatsapp_message

logger = logging.getLogger(__name__)

async def process_telegram_queue():
    """Polls and processes Telegram notifications from the database queue."""
    db: Session = SessionLocal()
    try:
        # Fetch up to 10 pending Telegram notification items
        items = db.query(NotificationQueueItem).filter(
            NotificationQueueItem.channel == "telegram",
            NotificationQueueItem.status == "PENDING"
        ).limit(10).all()

        for item in items:
            logger.info(f"[TELEGRAM_WORKER] Processing item {item.id} to user_id {item.user_id}")
            user = db.query(User).filter(User.id == item.user_id).first()
            if not user or not user.telegram_chat_id:
                item.status = "FAILED"
                item.last_error = "User has no Telegram chat ID linked."
                logger.warning(f"[TELEGRAM_WORKER] Item {item.id} failed: User has no Telegram chat ID linked.")
                continue

            try:
                # Attempt live API call
                success = send_telegram_message(user.telegram_chat_id, item.message)
                if success:
                    item.status = "SENT"
                    item.attempts += 1
                    logger.info(f"[TELEGRAM_WORKER] Item {item.id} sent successfully.")
                else:
                    item.attempts += 1
                    if item.attempts >= 3:
                        item.status = "FAILED"
                    item.last_error = "API request returned false status."
                    logger.error(f"[TELEGRAM_WORKER] Item {item.id} failed sending attempt {item.attempts}.")
            except Exception as e:
                item.attempts += 1
                if item.attempts >= 3:
                    item.status = "FAILED"
                item.last_error = str(e)
                logger.error(f"[TELEGRAM_WORKER] Exception sending telegram {item.id}: {e}")

            item.updated_at = datetime.datetime.utcnow()
            db.commit()
    except Exception as e:
        logger.error(f"[TELEGRAM_WORKER] Fatal error in loop iteration: {e}", exc_info=True)
    finally:
        db.close()


async def process_email_queue():
    """Polls and processes Email notifications from the database queue."""
    db: Session = SessionLocal()
    try:
        items = db.query(NotificationQueueItem).filter(
            NotificationQueueItem.channel == "email",
            NotificationQueueItem.status == "PENDING"
        ).limit(10).all()

        for item in items:
            logger.info(f"[EMAIL_WORKER] Processing item {item.id} to user_id {item.user_id}")
            user = db.query(User).filter(User.id == item.user_id).first()
            if not user or not user.email:
                item.status = "FAILED"
                item.last_error = "User has no email address."
                logger.warning(f"[EMAIL_WORKER] Item {item.id} failed: No email.")
                continue

            try:
                # Dispatch real email
                logger.info(f"[EMAIL_WORKER] Dispatching email to {user.email}: {item.title}")
                _send_email(user.email, item.title, item.message)
                item.status = "SENT"
                item.attempts += 1
            except Exception as e:
                item.attempts += 1
                if item.attempts >= 3:
                    item.status = "FAILED"
                item.last_error = str(e)
                logger.error(f"[EMAIL_WORKER] Exception sending email {item.id}: {e}")

            item.updated_at = datetime.datetime.utcnow()
            db.commit()
    except Exception as e:
        logger.error(f"[EMAIL_WORKER] Fatal error in loop iteration: {e}", exc_info=True)
    finally:
        db.close()


async def process_whatsapp_queue():
    """Polls and processes WhatsApp notifications from the database queue."""
    db: Session = SessionLocal()
    try:
        items = db.query(NotificationQueueItem).filter(
            NotificationQueueItem.channel == "whatsapp",
            NotificationQueueItem.status == "PENDING"
        ).limit(10).all()

        for item in items:
            logger.info(f"[WHATSAPP_WORKER] Processing item {item.id} to user_id {item.user_id}")
            user = db.query(User).filter(User.id == item.user_id).first()
            phone = getattr(user, "phone_number", None)
            if not user or not phone:
                item.status = "FAILED"
                item.last_error = "User has no phone number listed."
                logger.warning(f"[WHATSAPP_WORKER] Item {item.id} failed: No phone number.")
                continue

            try:
                # Dispatch WhatsApp message via Twilio
                logger.info(f"[WHATSAPP_WORKER] Dispatching WhatsApp message to {phone}: {item.title}")
                success = send_whatsapp_message(phone, f"*{item.title}*\n{item.message}")
                if success:
                    item.status = "SENT"
                    item.attempts += 1
                else:
                    item.attempts += 1
                    if item.attempts >= 3:
                        item.status = "FAILED"
                    item.last_error = "Twilio API returned false"
                    logger.error(f"[WHATSAPP_WORKER] Item {item.id} failed sending attempt {item.attempts}.")
            except Exception as e:
                item.attempts += 1
                if item.attempts >= 3:
                    item.status = "FAILED"
                item.last_error = str(e)
                logger.error(f"[WHATSAPP_WORKER] Exception sending whatsapp {item.id}: {e}")

            item.updated_at = datetime.datetime.utcnow()
            db.commit()
    except Exception as e:
        logger.error(f"[WHATSAPP_WORKER] Fatal error in loop iteration: {e}", exc_info=True)
    finally:
        db.close()


async def start_telegram_dispatcher():
    """Continuous loop running every 2 seconds for Telegram notifications."""
    logger.info("Telegram background dispatch worker starting...")
    while True:
        try:
            await process_telegram_queue()
        except asyncio.CancelledError:
            logger.info("Telegram background dispatch worker stopping...")
            break
        except Exception as e:
            logger.error(f"Error in telegram worker thread: {e}")
        await asyncio.sleep(2.0)


async def start_email_dispatcher():
    """Continuous loop running every 5 seconds for Email notifications."""
    logger.info("Email background dispatch worker starting...")
    while True:
        try:
            await process_email_queue()
        except asyncio.CancelledError:
            logger.info("Email background dispatch worker stopping...")
            break
        except Exception as e:
            logger.error(f"Error in email worker thread: {e}")
        await asyncio.sleep(5.0)


async def start_whatsapp_dispatcher():
    """Continuous loop running every 5 seconds for WhatsApp notifications."""
    logger.info("WhatsApp background dispatch worker starting...")
    while True:
        try:
            await process_whatsapp_queue()
        except asyncio.CancelledError:
            logger.info("WhatsApp background dispatch worker stopping...")
            break
        except Exception as e:
            logger.error(f"Error in whatsapp worker thread: {e}")
        await asyncio.sleep(5.0)
