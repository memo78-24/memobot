from abc import ABC, abstractmethod
from typing import Dict, Any, Optional
from sqlalchemy.orm import Session


class BaseStrategy(ABC):
    """Base class for all trading strategies"""
    
    def __init__(self, name: str, description: str):
        self.name = name
        self.description = description
    
    @abstractmethod
    def should_enter(self, symbol: str, current_price: float, market_data: Dict[str, Any]) -> tuple[bool, str]:
        """
        Determine if strategy should enter a position
        Returns: (should_enter, reason)
        """
        pass
    
    @abstractmethod
    def should_exit(self, symbol: str, entry_price: float, current_price: float, 
                    position_data: Dict[str, Any]) -> tuple[bool, str]:
        """
        Determine if strategy should exit a position
        Returns: (should_exit, reason)
        """
        pass
    
    @abstractmethod
    def calculate_position_size(self, account_balance: float, risk_per_trade: float) -> float:
        """Calculate position size based on risk management"""
        pass
    
    def get_parameters(self) -> Dict[str, Any]:
        """Get strategy parameters"""
        return {}
    
    def set_parameters(self, params: Dict[str, Any]) -> None:
        """Set strategy parameters"""
        pass


class GridStrategy(BaseStrategy):
    """Grid trading strategy - places buy/sell orders at regular intervals"""
    
    def __init__(self):
        super().__init__("Grid", "Places buy/sell orders at regular price intervals")
        self.grid_spacing = 0.01  # 1% spacing
        self.grid_levels = 10
        self.position_size_pct = 0.02
    
    def should_enter(self, symbol: str, current_price: float, market_data: Dict[str, Any]) -> tuple[bool, str]:
        # Grid strategy always enters at grid levels
        return True, "Grid level reached"
    
    def should_exit(self, symbol: str, entry_price: float, current_price: float, 
                    position_data: Dict[str, Any]) -> tuple[bool, str]:
        # Exit when next grid level is reached
        if abs(current_price - entry_price) / entry_price >= self.grid_spacing:
            return True, f"Grid level reached: {current_price}"
        return False, "Grid level not reached"
    
    def calculate_position_size(self, account_balance: float, risk_per_trade: float) -> float:
        return account_balance * self.position_size_pct
    
    def get_parameters(self) -> Dict[str, Any]:
        return {
            "grid_spacing": self.grid_spacing,
            "grid_levels": self.grid_levels,
            "position_size_pct": self.position_size_pct
        }


class DCAStrategy(BaseStrategy):
    """Dollar Cost Averaging strategy - accumulates position over time"""
    
    def __init__(self):
        super().__init__("DCA", "Accumulates position through regular purchases")
        self.interval_hours = 24
        self.position_size_pct = 0.05
        self.max_entries = 10
    
    def should_enter(self, symbol: str, current_price: float, market_data: Dict[str, Any]) -> tuple[bool, str]:
        # DCA enters based on time intervals
        return True, "Scheduled DCA entry"
    
    def should_exit(self, symbol: str, entry_price: float, current_price: float, 
                    position_data: Dict[str, Any]) -> tuple[bool, str]:
        # Exit when target profit is reached
        entries = position_data.get("entries", 0)
        if entries >= self.max_entries:
            return True, "Maximum DCA entries reached"
        return False, "Continue DCA accumulation"
    
    def calculate_position_size(self, account_balance: float, risk_per_trade: float) -> float:
        return account_balance * self.position_size_pct


class ScalpingStrategy(BaseStrategy):
    """High-frequency scalping strategy - quick in/out trades"""
    
    def __init__(self):
        super().__init__("Scalping", "Quick in/out trades for small profits")
        self.target_profit_pct = 0.005  # 0.5%
        self.stop_loss_pct = 0.002  # 0.2%
        self.position_size_pct = 0.01
    
    def should_enter(self, symbol: str, current_price: float, market_data: Dict[str, Any]) -> tuple[bool, str]:
        # Enter on momentum signals
        rsi = market_data.get("rsi", 50)
        if rsi < 30:
            return True, "Oversold condition detected"
        elif rsi > 70:
            return True, "Overbought condition detected"
        return False, "No scalping signal"
    
    def should_exit(self, symbol: str, entry_price: float, current_price: float, 
                    position_data: Dict[str, Any]) -> tuple[bool, str]:
        profit_pct = (current_price - entry_price) / entry_price
        
        if profit_pct >= self.target_profit_pct:
            return True, f"Target profit reached: {profit_pct:.2%}"
        elif profit_pct <= -self.stop_loss_pct:
            return True, f"Stop loss triggered: {profit_pct:.2%}"
        return False, "Hold position"
    
    def calculate_position_size(self, account_balance: float, risk_per_trade: float) -> float:
        return account_balance * self.position_size_pct


class TrendFollowingStrategy(BaseStrategy):
    """Trend following strategy - trades in direction of major trend"""
    
    def __init__(self):
        super().__init__("Trend", "Follows major market trends")
        self.ma_short = 20
        self.ma_long = 50
        self.position_size_pct = 0.05
    
    def should_enter(self, symbol: str, current_price: float, market_data: Dict[str, Any]) -> tuple[bool, str]:
        ma_short = market_data.get(f"ma_{self.ma_short}", current_price)
        ma_long = market_data.get(f"ma_{self.ma_long}", current_price)
        
        if ma_short > ma_long:
            return True, "Uptrend detected (short MA above long MA)"
        elif ma_short < ma_long:
            return True, "Downtrend detected (short MA below long MA)"
        return False, "No clear trend"
    
    def should_exit(self, symbol: str, entry_price: float, current_price: float, 
                    position_data: Dict[str, Any]) -> tuple[bool, str]:
        ma_short = position_data.get("ma_short", current_price)
        ma_long = position_data.get("ma_long", current_price)
        
        # Exit when trend reverses
        if ma_short < ma_long:
            return True, "Trend reversal detected"
        return False, "Trend continues"
    
    def calculate_position_size(self, account_balance: float, risk_per_trade: float) -> float:
        return account_balance * self.position_size_pct


class MeanReversionStrategy(BaseStrategy):
    """Mean reversion strategy - trades price deviations from mean"""
    
    def __init__(self):
        super().__init__("Mean Reversion", "Trades price deviations from mean")
        self.lookback_period = 20
        self.std_dev_threshold = 2.0
        self.position_size_pct = 0.04
    
    def should_enter(self, symbol: str, current_price: float, market_data: Dict[str, Any]) -> tuple[bool, str]:
        mean = market_data.get("mean", current_price)
        std_dev = market_data.get("std_dev", 0)
        
        if std_dev == 0:
            return False, "Insufficient data"
        
        z_score = (current_price - mean) / std_dev
        
        if z_score > self.std_dev_threshold:
            return True, f"Price overextended: z-score {z_score:.2f}"
        elif z_score < -self.std_dev_threshold:
            return True, f"Price oversold: z-score {z_score:.2f}"
        return False, "Price within normal range"
    
    def should_exit(self, symbol: str, entry_price: float, current_price: float, 
                    position_data: Dict[str, Any]) -> tuple[bool, str]:
        mean = position_data.get("mean", current_price)
        
        # Exit when price returns to mean
        if abs(current_price - mean) / mean < 0.01:
            return True, "Price returned to mean"
        return False, "Price still deviating from mean"
    
    def calculate_position_size(self, account_balance: float, risk_per_trade: float) -> float:
        return account_balance * self.position_size_pct


# Strategy registry
STRATEGIES = {
    "grid": GridStrategy,
    "dca": DCAStrategy,
    "scalping": ScalpingStrategy,
    "trend": TrendFollowingStrategy,
    "mean_reversion": MeanReversionStrategy
}


def get_strategy(strategy_name: str) -> Optional[BaseStrategy]:
    """Get strategy instance by name"""
    strategy_class = STRATEGIES.get(strategy_name.lower())
    if strategy_class:
        return strategy_class()
    return None


def list_strategies() -> list[Dict[str, str]]:
    """List all available strategies"""
    return [
        {
            "name": name,
            "description": strategy_class().description
        }
        for name, strategy_class in STRATEGIES.items()
    ]
