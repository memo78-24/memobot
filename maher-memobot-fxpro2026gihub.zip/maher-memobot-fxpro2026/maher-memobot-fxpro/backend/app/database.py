"""Database session management.

The application codebase currently uses SQLAlchemy's synchronous ORM API in its
legacy routers/services.  We therefore expose a synchronous SessionLocal for
those paths, while retaining an AsyncSessionLocal for the newer V2 event/outbox
services that explicitly use AsyncSession.
"""
import logging
from sqlalchemy import create_engine, text
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker, Session
from backend.app.config import DATABASE_URL, ASYNC_DATABASE_URL

logger = logging.getLogger(__name__)

# Legacy application path: synchronous ORM API.
SYNC_DATABASE_URL = DATABASE_URL
engine = create_engine(
    SYNC_DATABASE_URL,
    echo=False,
    pool_pre_ping=True,
)
SessionLocal = sessionmaker(
    bind=engine,
    class_=Session,
    expire_on_commit=False,
    autoflush=False,
)

# New V2/event-driven path: explicit async sessions only.
async_engine = None
AsyncSessionLocal = None
try:
    # Production PostgreSQL uses asyncpg. SQLite development does not require
    # the V2 async stack, so don't make aiosqlite an import-time hard failure.
    async_engine = create_async_engine(
        ASYNC_DATABASE_URL,
        echo=False,
        pool_pre_ping=True,
    )
    AsyncSessionLocal = sessionmaker(
        bind=async_engine,
        class_=AsyncSession,
        expire_on_commit=False,
        autoflush=False,
    )
except ModuleNotFoundError as exc:
    if "aiosqlite" not in str(exc):
        raise
    logger.warning("Async V2 database adapter unavailable in local SQLite environment; legacy sync ORM remains available.")


def get_db():
    """FastAPI dependency for the synchronous legacy ORM path."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db():
    logger.info("Database initialization is migration-controlled; no implicit DDL is performed.")


def log_activity(db=None, action=None, level="INFO", user_id=None, details=""):
    """Backward-compatible audit/log adapter.

    Historical call sites used both ``log_activity(user_id, action, details)``
    and ``log_activity(db, action, level, user_id, details)``.  Normalize both
    forms without silently dropping the user id or detail payload.
    """
    # New/legacy simple signature: log_activity(user_id, action, details)
    if not isinstance(db, Session):
        if user_id is None and isinstance(db, int):
            user_id, action, details = db, action, level
            level = "INFO"
        else:
            # Called with no DB object but keyword user_id/action.
            pass
    else:
        # Existing call style: log_activity(db, action, level, user_id, details)
        pass

    logger.info(
        "[AUDIT] user_id=%s action=%s level=%s details=%s",
        user_id,
        action,
        level,
        details,
    )
