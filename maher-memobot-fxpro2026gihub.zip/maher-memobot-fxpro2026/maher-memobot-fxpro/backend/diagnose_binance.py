"""
Standalone Binance diagnostic script.

Bypasses ALL app aggregation logic. Pulls your saved API key/secret straight
from the vault, decrypts them the same way the app does, then calls Binance
directly and prints the RAW, untouched JSON responses. This tells us exactly
what Binance thinks this key can see -- no app code in between to blame.

Run this from the `backend` folder (same place you run uvicorn from):
    python diagnose_binance.py
"""
import asyncio
import hmac
import hashlib
import time
import urllib.parse
import json
import sys
import os

_backend_dir = os.path.dirname(os.path.abspath(__file__))
_parent_dir = os.path.dirname(_backend_dir)
if _parent_dir not in sys.path:
    sys.path.insert(0, _parent_dir)

import aiohttp
from backend.app.database import SessionLocal
from backend.app.security import decrypt_secret
from backend.shared.models.vault import VaultCredentials


def sign(secret: str, params: dict) -> str:
    query_string = urllib.parse.urlencode(params)
    return hmac.new(secret.encode("utf-8"), query_string.encode("utf-8"), hashlib.sha256).hexdigest()


async def signed_get(session, base_url, path, api_key, api_secret, extra_params=None):
    params = dict(extra_params or {})
    params["timestamp"] = int(time.time() * 1000)
    params["recvWindow"] = 10000
    params["signature"] = sign(api_secret, params)
    headers = {"X-MBX-APIKEY": api_key}
    url = f"{base_url}{path}"
    async with session.get(url, params=params, headers=headers) as resp:
        text = await resp.text()
        print(f"\n{'='*70}\nGET {path}  ->  HTTP {resp.status}\n{'='*70}")
        try:
            parsed = json.loads(text)
            print(json.dumps(parsed, indent=2)[:4000])
        except Exception:
            print(text[:2000])


async def main():
    db = SessionLocal()
    try:
        vault = db.query(VaultCredentials).filter(
            VaultCredentials.exchange_name.ilike("binance")
        ).first()

        if not vault:
            print("!! No Binance credentials found in vault. Save your API key first.")
            return

        api_key = decrypt_secret(vault.api_key_encrypted)
        api_secret = decrypt_secret(vault.api_secret_encrypted)

        if not api_key or not api_secret:
            print("!! Decryption returned empty key/secret. Encryption key mismatch.")
            return

        print(f"Loaded key from vault. Key starts with: {api_key[:8]}... (length {len(api_key)})")
        print(f"Vault entry label: {vault.label}  |  is_testnet: {vault.is_testnet}  |  is_active: {vault.is_active}")

        base_url = "https://api.binance.com"

        async with aiohttp.ClientSession() as session:
            # 1. Who / what account is this key actually attached to, and what can it do?
            await signed_get(session, base_url, "/sapi/v1/account/apiRestrictions", api_key, api_secret)

            # 2. Raw spot account -- this is the ground truth for Spot balances.
            await signed_get(session, base_url, "/api/v3/account", api_key, api_secret)

            # 3. Raw multi-wallet balance (BTC-denominated across every wallet type).
            await signed_get(session, base_url, "/sapi/v1/asset/wallet/balance", api_key, api_secret)

            # 4. Is this account a sub-account, and does it have any sub-accounts of its own?
            await signed_get(session, base_url, "/sapi/v1/sub-account/list", api_key, api_secret)

    finally:
        db.close()


if __name__ == "__main__":
    asyncio.run(main())