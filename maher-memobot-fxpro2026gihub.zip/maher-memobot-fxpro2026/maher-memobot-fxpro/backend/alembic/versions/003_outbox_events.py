﻿"""Create transactional outbox_events table."""

from alembic import op
import sqlalchemy as sa


revision = "003_outbox_events"
down_revision = "002_execution_reliability"
branch_labels = None
depends_on = None


def upgrade():
    bind = op.get_bind()
    inspector = sa.inspect(bind)

    if "outbox_events" not in inspector.get_table_names():
        op.create_table(
            "outbox_events",
            sa.Column("id", sa.Integer(), primary_key=True),
            sa.Column(
                "event_id",
                sa.String(100),
                nullable=False,
                unique=True,
            ),
            sa.Column(
                "aggregate_type",
                sa.String(50),
                nullable=False,
            ),
            sa.Column(
                "aggregate_id",
                sa.String(100),
                nullable=False,
            ),
            sa.Column(
                "event_type",
                sa.String(100),
                nullable=False,
            ),
            sa.Column(
                "payload",
                sa.JSON(),
                nullable=False,
            ),
            sa.Column(
                "correlation_id",
                sa.String(100),
            ),
            sa.Column(
                "idempotency_key",
                sa.String(150),
                nullable=False,
                unique=True,
            ),
            sa.Column(
                "status",
                sa.String(30),
                nullable=False,
                server_default="PENDING",
            ),
            sa.Column(
                "attempts",
                sa.Integer(),
                nullable=False,
                server_default="0",
            ),
            sa.Column(
                "max_attempts",
                sa.Integer(),
                nullable=False,
                server_default="10",
            ),
            sa.Column(
                "available_at",
                sa.DateTime(),
                nullable=False,
                server_default=sa.text("CURRENT_TIMESTAMP"),
            ),
            sa.Column(
                "locked_at",
                sa.DateTime(),
            ),
            sa.Column(
                "processed_at",
                sa.DateTime(),
            ),
            sa.Column(
                "failed_at",
                sa.DateTime(),
            ),
            sa.Column(
                "last_error",
                sa.Text(),
            ),
            sa.Column(
                "created_at",
                sa.DateTime(),
                nullable=False,
                server_default=sa.text("CURRENT_TIMESTAMP"),
            ),
            sa.Column(
                "updated_at",
                sa.DateTime(),
                nullable=False,
                server_default=sa.text("CURRENT_TIMESTAMP"),
            ),
        )

        op.create_index(
            "ix_outbox_events_event_id",
            "outbox_events",
            ["event_id"],
            unique=True,
        )

        op.create_index(
            "ix_outbox_events_aggregate_type",
            "outbox_events",
            ["aggregate_type"],
        )

        op.create_index(
            "ix_outbox_events_aggregate_id",
            "outbox_events",
            ["aggregate_id"],
        )

        op.create_index(
            "ix_outbox_events_event_type",
            "outbox_events",
            ["event_type"],
        )

        op.create_index(
            "ix_outbox_events_correlation_id",
            "outbox_events",
            ["correlation_id"],
        )

        op.create_index(
            "ix_outbox_events_status",
            "outbox_events",
            ["status"],
        )

        op.create_index(
            "ix_outbox_events_available_at",
            "outbox_events",
            ["available_at"],
        )

        op.create_index(
            "ix_outbox_events_created_at",
            "outbox_events",
            ["created_at"],
        )


def downgrade():
    bind = op.get_bind()
    inspector = sa.inspect(bind)

    if "outbox_events" in inspector.get_table_names():
        op.drop_table("outbox_events")
