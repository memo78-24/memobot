"""Add execution-domain compatibility fields and reconciliation tables."""
from alembic import op
import sqlalchemy as sa

revision = "002_execution_reliability"
down_revision = "001_schema_reconciliation"
branch_labels = None
depends_on = None


def _columns(bind, table):
    return {c["name"] for c in sa.inspect(bind).get_columns(table)}


def _add(bind, table, column):
    if table in sa.inspect(bind).get_table_names() and column.name not in _columns(bind, table):
        op.add_column(table, column)


def upgrade():
    bind = op.get_bind()
    # New compatibility columns used by the completed execution services.
    for name, col in [
        ("account_id", sa.Column("account_id", sa.String(100))),
        ("cycle_id", sa.Column("cycle_id", sa.String(100))),
        ("intent_type", sa.Column("intent_type", sa.String(30))),
    ]:
        _add(bind, "trade_intents", col)
    for name, col in [
        ("account_id", sa.Column("account_id", sa.String(100))),
        ("cycle_id", sa.Column("cycle_id", sa.String(100))),
        ("symbol", sa.Column("symbol", sa.String(20))),
        ("job_type", sa.Column("job_type", sa.String(50))),
        ("lease_owner", sa.Column("lease_owner", sa.String(100))),
        ("lease_expires_at", sa.Column("lease_expires_at", sa.DateTime())),
        ("next_run_at", sa.Column("next_run_at", sa.DateTime())),
        ("payload_json", sa.Column("payload_json", sa.JSON())),
    ]:
        _add(bind, "execution_jobs", col)
    for name, col in [
        ("account_id", sa.Column("account_id", sa.String(100))),
        ("order_ref_id", sa.Column("order_ref_id", sa.String(100))),
        ("client_order_id", sa.Column("client_order_id", sa.String(100))),
        ("position_id", sa.Column("position_id", sa.String(100))),
        ("qty", sa.Column("qty", sa.Float())),
        ("exchange_trade_id", sa.Column("exchange_trade_id", sa.String(100))),
        ("fill_time", sa.Column("fill_time", sa.DateTime())),
        ("raw_exchange_json", sa.Column("raw_exchange_json", sa.JSON())),
    ]:
        _add(bind, "fills", col)
    for name, col in [
        ("exchange_order_id", sa.Column("exchange_order_id", sa.String(100))),
        ("exchange_status", sa.Column("exchange_status", sa.String(50))),
        ("last_exchange_update_at", sa.Column("last_exchange_update_at", sa.DateTime())),
        ("raw_exchange_json", sa.Column("raw_exchange_json", sa.JSON())),
    ]:
        _add(bind, "orders", col)
    for name, col in [
        ("account_id", sa.Column("account_id", sa.String(100))),
        ("position_event_id", sa.Column("position_event_id", sa.String(100))),
        ("qty_delta", sa.Column("qty_delta", sa.Float())),
        ("realized_pnl_delta", sa.Column("realized_pnl_delta", sa.Float())),
        ("fee_delta", sa.Column("fee_delta", sa.Float())),
        ("payload_json", sa.Column("payload_json", sa.JSON())),
    ]:
        _add(bind, "position_events", col)
    for name, col in [
        ("source", sa.Column("source", sa.String(30))),
        ("account_id", sa.Column("account_id", sa.String(100))),
        ("order_id", sa.Column("order_id", sa.String(100))),
        ("position_id", sa.Column("position_id", sa.String(100))),
        ("reconciliation_id", sa.Column("reconciliation_id", sa.String(100))),
        ("payload_json", sa.Column("payload_json", sa.JSON())),
    ]:
        _add(bind, "trade_events", col)
    _add(bind, "positions", sa.Column("metadata_json", sa.JSON()))

    op.create_table(
        "trade_cycles",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("cycle_id", sa.String(100), nullable=False, unique=True),
        sa.Column("account_id", sa.String(100), nullable=False),
        sa.Column("strategy_id", sa.String(100)),
        sa.Column("symbol", sa.String(20), nullable=False),
        sa.Column("status", sa.String(30), nullable=False),
        sa.Column("started_at", sa.DateTime(), nullable=False),
        sa.Column("completed_at", sa.DateTime()),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
    ) if "trade_cycles" not in sa.inspect(bind).get_table_names() else None
    op.create_table(
        "reconciliation_runs",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("reconciliation_id", sa.String(100), nullable=False, unique=True),
        sa.Column("account_id", sa.String(100), nullable=False),
        sa.Column("scope", sa.String(30), nullable=False),
        sa.Column("status", sa.String(30), nullable=False),
        sa.Column("trigger_reason", sa.String(100)),
        sa.Column("summary_json", sa.JSON()),
        sa.Column("started_at", sa.DateTime(), nullable=False),
        sa.Column("completed_at", sa.DateTime()),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    ) if "reconciliation_runs" not in sa.inspect(bind).get_table_names() else None
    op.create_table(
        "reconciliation_issues",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("issue_id", sa.String(100), nullable=False, unique=True),
        sa.Column("reconciliation_id", sa.String(100), nullable=False),
        sa.Column("account_id", sa.String(100), nullable=False),
        sa.Column("symbol", sa.String(20)),
        sa.Column("issue_type", sa.String(100), nullable=False),
        sa.Column("severity", sa.String(30), nullable=False),
        sa.Column("status", sa.String(40), nullable=False),
        sa.Column("details_json", sa.JSON()),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("resolved_at", sa.DateTime()),
    ) if "reconciliation_issues" not in sa.inspect(bind).get_table_names() else None


def downgrade():
    # Deliberately non-destructive; production rollback requires a reviewed migration.
    pass
