"""Establish/repair the canonical MEMOBOT SQLAlchemy schema.

This is a transitional reconciliation migration for the pre-ECO codebase. It
creates missing tables from the canonical metadata and adds missing columns to
existing tables. It intentionally does not drop or rename existing data.
"""
from alembic import op
from sqlalchemy import inspect
from backend.shared.models.base import Base
import backend.shared.models  # register all models

revision = "001_schema_reconciliation"
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    bind = op.get_bind()
    # Safe for an existing database: SQLAlchemy only creates absent tables.
    Base.metadata.create_all(bind=bind, checkfirst=True)

    inspector = inspect(bind)
    existing_tables = set(inspector.get_table_names())
    for table_name, table in Base.metadata.tables.items():
        if table_name not in existing_tables:
            continue
        existing_columns = {c["name"] for c in inspector.get_columns(table_name)}
        for column in table.columns:
            if column.name in existing_columns:
                continue
            # New compatibility columns are deliberately added as nullable in
            # the migration. The ORM owns the stricter application contract;
            # future hardening migrations can enforce NOT NULL after backfill.
            new_column = column.copy()
            new_column.nullable = True
            op.add_column(table_name, new_column)


def downgrade():
    # No destructive downgrade: this migration is a safety reconciliation for
    # production data. Use an explicit, reviewed migration for any rollback.
    pass
