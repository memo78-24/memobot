"""Create missing canonical execution-domain tables."""

from alembic import op
import sqlalchemy as sa

from backend.shared.models.base import Base
import backend.shared.models  # noqa: F401


revision = "004_execution_domain_tables"
down_revision = "003_outbox_events"
branch_labels = None
depends_on = None


EXECUTION_TABLES = (
    "trade_intents",
    "execution_jobs",
    "trade_events",
    "fills",
    "position_events",
)


def upgrade():
    bind = op.get_bind()
    inspector = sa.inspect(bind)
    existing = set(inspector.get_table_names())

    for table_name in EXECUTION_TABLES:
        if table_name not in Base.metadata.tables:
            raise RuntimeError(
                f"Canonical ORM table '{table_name}' "
                "is not registered in Base.metadata."
            )

        if table_name not in existing:
            Base.metadata.tables[table_name].create(
                bind=bind,
                checkfirst=True,
            )


def downgrade():
    # Deliberately non-destructive.
    pass
