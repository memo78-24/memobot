# Memobot FX-Pro Backend Architecture

## 1. Shop Drawing (Folder Map)

```text
backend/
├── .env                          # Local environment variables
├── execute_matrix.py             # Sandbox testing matrix execution script
├── requirements.txt              # Python package dependencies
├── __init__.py                   # Package initializer
├── tests/                        # Automated testing suite
│   └── test_backend.py           # Core backend functionality tests
└── app/                          # Main Application Directory
    ├── main.py                   # FastAPI Master Entry Point & Bootloader
    ├── config.py                 # Pydantic Settings & Global Configuration
    ├── database.py               # Database Engine (PostgreSQL Pools)
    ├── models.py                 # Pydantic Schemas for raw PostgreSQL mapping
    ├── security.py               # Authentication, JWT handling, and password hashing
    ├── engine.py                 # Core algorithmic engine execution logic
    ├── engine_instance.py        # Individual active engine lifecycle managers
    ├── engine_runtime.py         # Real background execution loop trigger
    ├── pipeline.py               # 9-stage order execution tracker state machine
    ├── risk.py                   # Risk management matrices & margin controls
    ├── evaluation.py             # Market scoring & indicator wing assessment logic
    ├── market_data.py            # CCXT market data client with caching layer
    ├── exchange_client.py        # Vault-decrypted CCXT client wrapper
    ├── portfolio_service.py      # Real spot balance net worth calculation
    ├── ai_client.py              # Gemini & OpenAI API request dispatchers
    ├── notification_service.py   # Telegram & WhatsApp message dispatchers
    ├── observability.py          # System telemetry metrics and audit logger
    ├── swarm.py                  # Swarm AI logic coordinator
    ├── swarm_instance.py         # Swarm AI bot instantiator
    ├── __init__.py               
    ├── routers/                  # API Endpoint Controllers (14 REST/WS Routers)
    │   ├── auth.py               # Registration, Login, and OTP Verification routes
    │   ├── vault.py              # Exchange API credentials secure endpoints
    │   ├── engine.py             # Engine state commands (Start/Stop/Kill) routes
    │   ├── execution.py          # Balance queries & active position endpoints
    │   ├── market.py             # Live ticker price feeds
    │   ├── evaluation.py         # Order book & Market score endpoints
    │   ├── strategies.py         # Trading engine profile config options
    │   ├── risk_config.py        # Custom user risk margin limits
    │   ├── notifications.py      # Dispatch notification channel test endpoints
    │   ├── audit.py              # CSV/PDF ledger log exporters
    │   ├── proof.py              # Cryptographic cohesion sync verification proofs
    │   ├── ai_chat.py            # AI assistant NLP parser & response endpoints
    │   ├── analytics.py          # Real-time charting & historical data endpoints
    │   ├── observability.py      # Health checks & system metrics routes
    │   └── __init__.py           
    └── schemas/                  # Pydantic Input/Output Validation Models
        ├── auth.py               # Input/Output validation for Users
        ├── engine.py             # Input/Output validation for Engines
        ├── vault.py              # Input/Output validation for Secrets
        └── __init__.py           
```

## 2. Element Technical & Feature Details

### Core Application (`app/`)
- **`main.py`**:
  - **Feature**: Master entry point for the Memobot FastAPI backend.
  - **Technical**: Initializes the ASGI application server, hooks CORS middleware, mounts WebSocket endpoints (`/ws/portfolio`), and registers all 14 sub-routers dynamically.
- **`database.py` & `models.py`**:
  - **Feature**: Pure PostgreSQL raw-SQL connection pools.
  - **Technical**: Uses dual-pool setup (`asyncpg` for asynchronous Websocket pipelines and `psycopg2` SimpleConnectionPool for synchronous REST endpoints). Contains no SQLite/SQLAlchemy.
- **`security.py`**:
  - **Feature**: Session validation and OTP manager.
  - **Technical**: Encodes and decodes JWT tokens. Handles secure, cryptographically random 6-digit OTP email activation codes expiring in 10 minutes.

### Modular Core Components (`app/`)
- **`engine_runtime.py`**:
  - **Feature**: Background execution loop manager.
  - **Technical**: Spawns and manages asynchronous background tasks for trade reconciliation and engine status heartbeats.
- **`pipeline.py`**:
  - **Feature**: 9-stage order execution state machine.
  - **Technical**: Tracks trade orders through 9 granular milestones (Signal Gen, Filters, Shariah Compliance, Risk Manager, Sizing, Placement, Confirmation, Audit Ledger, PnL Monitor).
- **`market_data.py`**:
  - **Feature**: Cached market ticker and candlestick data fetcher.
  - **Technical**: Wraps asynchronous CCXT calls to Binance with strict cache TTLs (3s for order book, 30s for candles) to optimize request limits.
- **`exchange_client.py`**:
  - **Feature**: Vault-decrypted exchange connector.
  - **Technical**: Safely retrieves and decrypts user API credentials from PostgreSQL, initiating a secure CCXT binance client.
- **`portfolio_service.py`**:
  - **Feature**: Accurate spot asset valuation engine.
  - **Technical**: Reconciles current spot balances against active price feeds to determine absolute portfolio net worth.
- **`ai_client.py`**:
  - **Feature**: Unified AI dispatcher wrapper.
  - **Technical**: Connects to the Gemini and OpenAI models using httpx async calls with strict timeout constraints.
- **`notification_service.py`**:
  - **Feature**: Real-time alarm and alert dispatcher.
  - **Technical**: Sends system events and warning notifications instantly through Telegram Bot API and WhatsApp Cloud API.

### API Controllers (`app/routers/`)
- **`auth.py`**:
  - **Feature**: User signups and verification.
  - **Technical**: Controls register, login, and verify-otp routes.
- **`vault.py`**:
  - **Feature**: Secure credential console.
  - **Technical**: Allows viewing, editing, testing, and deleting encrypted secrets from the database vault.
- **`execution.py` & `analytics.py`**:
  - **Feature**: Live balances and trade ledger charts.
  - **Technical**: Delivers wallet balances and formats historical PnL logs for Chart.js rendering.
- **`market.py` & `evaluation.py`**:
  - **Feature**: Real-time asset metrics.
  - **Technical**: Serves current ticker prices and computes wing indicators (Consensus, Spread, Shariah, Volatility).
- **`risk_config.py` & `notifications.py`**:
  - **Feature**: System parameters modification.
  - **Technical**: Updates drawdown limits, margin boundaries, and tests external alerts.
- **`audit.py` & `proof.py`**:
  - **Feature**: Institutional audit export and cohesion logging.
  - **Technical**: Generates csv spreadsheets and signs integrity proofs verifying cross-wing safety.
