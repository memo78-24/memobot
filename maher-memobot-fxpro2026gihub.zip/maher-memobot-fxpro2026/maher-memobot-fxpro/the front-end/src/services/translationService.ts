import { translationStore, TranslationItem } from "./translationStore";
import { 
  ARABIC_DICTIONARY, 
  loadCustomPermanentTranslations, 
  savePermanentTranslation, 
  removePermanentTranslation 
} from "../config/arabicDictionary";
import { ApiClient } from "./api";

export class TranslationService {
  public static init() {
    this.refreshStats();
    this.syncFromBackend();
    if (typeof window !== "undefined") {
      window.addEventListener("memobot:translation_updated", () => {
        this.refreshStats();
      });
    }
  }

  public static async syncFromBackend() {
    try {
      const res = await ApiClient.get<{ success: boolean; data: Record<string, string> }>("/translations");
      if (res && res.data && typeof res.data === "object") {
        for (const [en, ar] of Object.entries(res.data)) {
          savePermanentTranslation(en, ar);
        }
        this.refreshStats();
      }
    } catch (e) {
      // Offline fallback: localStorage is primary
    }
  }

  public static openStudio(initialSearch?: string, initialItem?: TranslationItem) {
    translationStore.setState({
      isOpen: true,
      searchQuery: initialSearch || "",
      selectedItem: initialItem || null,
      isInspectorActive: false
    });
  }

  public static closeStudio() {
    translationStore.setState({ isOpen: false, isInspectorActive: false });
  }

  public static toggleInspector(active?: boolean) {
    const next = active !== undefined ? active : !translationStore.getState().isInspectorActive;
    translationStore.setState({ isInspectorActive: next });
  }

  public static setInspectedText(text: string | null) {
    translationStore.setState({ inspectedElementText: text });
  }

  public static refreshStats() {
    const customs = loadCustomPermanentTranslations();
    translationStore.setState({
      customCount: Object.keys(customs).length,
      totalCount: Object.keys(ARABIC_DICTIONARY).length,
      lastUpdated: Date.now()
    });
  }

  public static getAllTranslations(): TranslationItem[] {
    const customs = loadCustomPermanentTranslations();
    const items: TranslationItem[] = [];

    for (const [english, arabic] of Object.entries(ARABIC_DICTIONARY)) {
      const isCustom = Boolean(customs[english]);
      let category: TranslationItem["category"] = "system";
      const lowerEn = english.toLowerCase();

      if (isCustom) category = "custom";
      else if (lowerEn.includes("vault") || lowerEn.includes("key") || lowerEn.includes("passcode") || lowerEn.includes("stealth")) category = "vault";
      else if (lowerEn.includes("engine") || lowerEn.includes("hft") || lowerEn.includes("trade") || lowerEn.includes("spot")) category = "engines";
      else if (lowerEn.includes("risk") || lowerEn.includes("audit") || lowerEn.includes("drawdown") || lowerEn.includes("shariah")) category = "risk";
      else if (lowerEn.includes("setting") || lowerEn.includes("theme") || lowerEn.includes("font") || lowerEn.includes("color")) category = "settings";

      items.push({
        id: "tr-" + Math.abs(this.hashCode(english)),
        english,
        arabic,
        isCustom,
        category
      });
    }

    return items;
  }

  public static saveTranslation(english: string, arabic: string): boolean {
    const cleanEn = english.trim();
    const cleanAr = arabic.trim();
    if (!cleanEn || !cleanAr) return false;

    const saved = savePermanentTranslation(cleanEn, cleanAr);
    if (saved) {
      this.refreshStats();
      // Async sync to server
      ApiClient.post("/translations", { english: cleanEn, arabic: cleanAr }).catch(() => {});
    }
    return saved;
  }

  public static deleteTranslation(english: string): boolean {
    const cleanEn = english.trim();
    const removed = removePermanentTranslation(cleanEn);
    if (removed) {
      this.refreshStats();
      ApiClient.delete(`/translations/${encodeURIComponent(cleanEn)}`).catch(() => {});
    }
    return removed;
  }

  public static exportAsJson(): string {
    const customs = loadCustomPermanentTranslations();
    const payload = {
      app: "MEMOBOT FX-PRO",
      version: "7.1",
      exportedAt: new Date().toISOString(),
      customTranslationsCount: Object.keys(customs).length,
      customTranslations: customs,
      masterDictionary: ARABIC_DICTIONARY
    };
    return JSON.stringify(payload, null, 2);
  }

  public static importFromJson(jsonString: string): { success: boolean; count: number; error?: string } {
    try {
      const parsed = JSON.parse(jsonString);
      const toImport = parsed.customTranslations || parsed.masterDictionary || parsed;
      if (typeof toImport !== "object" || toImport === null) {
        return { success: false, count: 0, error: "Invalid JSON format" };
      }

      let count = 0;
      for (const [k, v] of Object.entries(toImport)) {
        if (typeof k === "string" && typeof v === "string" && k.trim() && v.trim()) {
          savePermanentTranslation(k.trim(), v.trim());
          count++;
        }
      }

      this.refreshStats();
      // Sync batch to backend
      ApiClient.post("/translations/import", { translations: toImport }).catch(() => {});
      return { success: true, count };
    } catch (e: any) {
      return { success: false, count: 0, error: e.message || "Failed to parse JSON" };
    }
  }

  public static resetCustomOverrides(): boolean {
    try {
      localStorage.removeItem("memobot_custom_permanent_translations");
      window.dispatchEvent(new CustomEvent("memobot:translation_updated", { detail: { reset: true } }));
      this.refreshStats();
      ApiClient.post("/translations/reset", {}).catch(() => {});
      return true;
    } catch (e) {
      return false;
    }
  }

  private static hashCode(str: string): number {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      hash = (hash << 5) - hash + str.charCodeAt(i);
      hash |= 0;
    }
    return hash;
  }
}

// Auto init on import
if (typeof window !== "undefined") {
  TranslationService.init();
}
