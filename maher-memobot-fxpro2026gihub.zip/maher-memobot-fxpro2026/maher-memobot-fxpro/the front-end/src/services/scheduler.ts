type TaskCallback = () => Promise<void> | void;

export class Scheduler {
  private static tasks = new Map<string, {
    callback: TaskCallback;
    intervalMs: number;
    timerId: any;
    isPolling: boolean;
  }>();

  private static isTabVisible = true;
  private static isNetworkOnline = true;

  public static init() {
    if (typeof window === "undefined") return;

    // Track tab visibility
    document.addEventListener("visibilitychange", () => {
      this.isTabVisible = !document.hidden;
      console.log(`[Scheduler] Tab Visibility Changed: ${this.isTabVisible ? "VISIBLE" : "HIDDEN"}`);
      if (this.isTabVisible) {
        this.resumeAll();
      } else {
        this.pauseAll();
      }
    });

    // Track network online/offline status
    window.addEventListener("online", () => {
      this.isNetworkOnline = true;
      console.log("[Scheduler] System Network State: ONLINE");
      this.resumeAll();
    });

    window.addEventListener("offline", () => {
      this.isNetworkOnline = false;
      console.log("[Scheduler] System Network State: OFFLINE");
      this.pauseAll();
    });
  }

  public static register(id: string, callback: TaskCallback, intervalMs: number) {
    if (this.tasks.has(id)) {
      this.unregister(id);
    }

    this.tasks.set(id, {
      callback,
      intervalMs,
      timerId: null,
      isPolling: false,
    });

    this.startTask(id);
  }

  public static unregister(id: string) {
    this.stopTask(id);
    this.tasks.delete(id);
  }

  private static startTask(id: string) {
    const task = this.tasks.get(id);
    if (!task) return;

    if (task.timerId) {
      clearInterval(task.timerId);
    }

    const run = async () => {
      if (!this.isTabVisible || !this.isNetworkOnline) {
        return; // Suppress polling in inactive contexts
      }
      try {
        await task.callback();
      } catch (err) {
        console.error(`[Scheduler] Task Execution Exception in [${id}]:`, err);
      }
    };

    // Immediate run first
    run();

    task.timerId = setInterval(run, task.intervalMs);
    task.isPolling = true;
  }

  private static stopTask(id: string) {
    const task = this.tasks.get(id);
    if (!task) return;

    if (task.timerId) {
      clearInterval(task.timerId);
      task.timerId = null;
    }
    task.isPolling = false;
  }

  private static pauseAll() {
    this.tasks.forEach((_, id) => {
      this.stopTask(id);
    });
  }

  private static resumeAll() {
    this.tasks.forEach((_, id) => {
      if (this.isTabVisible && this.isNetworkOnline) {
        this.startTask(id);
      }
    });
  }
}

// Auto-initialize on window load
if (typeof window !== "undefined") {
  Scheduler.init();
}
