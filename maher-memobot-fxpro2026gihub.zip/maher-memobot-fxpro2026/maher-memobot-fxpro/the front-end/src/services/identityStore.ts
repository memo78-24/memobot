import { Store } from "./store";
import { TierId, TierProfile, JWTPayloadInfo, UserProfile } from "../types";

export const TIER_PROFILES: Record<TierId, TierProfile> = {
  individual: {
    id: "individual",
    name: "Individual Space",
    nameAr: "المساحة الفردية",
    category: "Individual Space",
    categoryAr: "المساحة الفردية لحماية رأس المال الصغير",
    resourceBound: "2 Engines / 2 Strategies",
    resourceBoundAr: "محركان / استراتيجيتان",
    maxEngines: 2,
    maxStrategies: 2,
    authMethod: "WebAuthn / Biometrics (FaceID/TouchID) or Magic Links",
    authMethodAr: "المصادقة البيومترية ومفتاح المرور السريع",
    scopes: ["read:profile", "trade:individual"],
    riskClamp: "Hardcoded 1.0% Maximum Loss Guard Per Position",
    riskClampAr: "تثبيت أقصى خسارة عند ١.٠٪ لكل صفقة إجبارياً",
    interfaceHud: "Simplified HUD",
    interfaceHudAr: "واجهة مبسطة وسلسة خالية من التعقيد",
    colorAccent: "#00E5FF",
    badge: "2 ENGINES • MICRO-CAPITAL SAFEGUARD",
    latencySla: "< 15ms Global Edge",
    features: [
      "Zero-friction onboarding & instant biometrics handshake",
      "Strict conservative sandbox preserving micro-capital",
      "Hardcoded 1.0% maximum loss stop-loss clamps",
      "Streamlined HUD without raw telemetry noise"
    ],
    featuresAr: [
      "تسجيل دخول فوري بدون تعقيد مع دعم البصمة والوجه",
      "بيئة تداول محافظة ومحمية لحفظ رؤوس الأموال الصغيرة",
      "تثبيت صارم لأقصى خسارة بنسبة ١.٠٪ للصفقة تلقائياً",
      "واجهة مستخدم مبسطة وواضحة تركز على النتائج المباشرة"
    ]
  },
  investor: {
    id: "investor",
    name: "Investors Suite",
    nameAr: "جناح المستثمرين",
    category: "Investors Suite",
    categoryAr: "جناح المستثمرين المحترفين",
    resourceBound: "5 Engines / 5 Strategies",
    resourceBoundAr: "٥ محركات / ٥ استراتيجيات متزامنة",
    maxEngines: 5,
    maxStrategies: 5,
    authMethod: "Multi-Factor Authentication (TOTP / Google Authenticator / YubiKey)",
    authMethodAr: "المصادقة الثنائية المتطورة (TOTP / YubiKey)",
    scopes: ["read:profile", "trade:pro", "config:strategy:5"],
    riskClamp: "Adaptive Sliding-Scale Risk Validation Filters",
    riskClampAr: "فلاتر مخاطر متدرجة ومتكيفة حسب تقلبات السوق",
    interfaceHud: "Pro Dashboard",
    interfaceHudAr: "لوحة تحكم احترافية مع رسوم بيانية تفاعلية",
    colorAccent: "#3B82F6",
    badge: "5 ENGINES • PRO MULTI-ASSET MESH",
    latencySla: "< 5.0ms Execution",
    features: [
      "Hardware-backed multi-factor TOTP & YubiKey authentication",
      "Concurrent execution across segmented multi-asset books",
      "Pro interactive technical charts & sliding risk filters",
      "Discrete node active/inactive orchestration commands"
    ],
    featuresAr: [
      "مصادقة ثنائية مدعومة بمفاتيح الأمان العتادية وتطبيقات المصادقة",
      "تنفيذ متزامن للصفقات عبر محافظ أصول رقمية متعددة",
      "رسوم بيانية وتحليلات فنية متقدمة مع فلاتر مخاطر منزلقة",
      "تحكم كامل في تفعيل وإيقاف محركات التداول الفردية"
    ]
  },
  corporate: {
    id: "corporate",
    name: "Corporate WL Portal",
    nameAr: "بوابة الشركات والحلول المخصصة (White-Label)",
    category: "Corporate WL Portal",
    categoryAr: "بوابة المؤسسات والشركات ذات الحسابات المتعددة",
    resourceBound: "10 Engines / 10 Strategies",
    resourceBoundAr: "١٠ محركات / ١٠ استراتيجيات مؤسسية",
    maxEngines: 10,
    maxStrategies: 10,
    authMethod: "Federated Enterprise SSO (SAML 2.0 / OIDC Directory)",
    authMethodAr: "تسجيل الدخول الموحد للمؤسسات (SAML 2.0 / OIDC)",
    scopes: ["tenant:admin", "manage:subaccounts", "engine:max:10"],
    tenantId: "WL_CORP_09",
    riskClamp: "Custom White-Label Markups & Tenant Sub-Allocation Rules",
    riskClampAr: "إدارة هوامش الأرباح وتوزيع مخصص للحسابات الفرعية",
    interfaceHud: "Multi-Tenant B2B",
    interfaceHudAr: "منصة إدارة مؤسسية متعددة الحسابات والتخصيص",
    colorAccent: "#8B5CF6",
    badge: "10 ENGINES • B2B MULTI-TENANT CONSOLE",
    latencySla: "< 1.5ms Priority Route",
    features: [
      "Sub-account tenant workspace routing & isolated partitions",
      "Localized parent-child API scoping with performance markups",
      "B2B White-Label Administrative Console & localized branding",
      "Multi-user access permissions control panels & client billing"
    ],
    featuresAr: [
      "توجيه حسابات فرعية مستقلة مع عزل تام للمساحات المؤسسية",
      "إدارة مفاتيح API هرمية مع تحديد هوامش الأداء المخصصة",
      "لوحة تحكم إدارية مخصصة للعلامات التجارية مع فواتير مستقلة",
      "إدارة صلاحيات المستخدمين والتحكم في وصول الموظفين والعملاء"
    ]
  },
  institutional: {
    id: "institutional",
    name: "Institutional Desk",
    nameAr: "المكتب المؤسسي عالي التردد (HFT)",
    category: "Institutional Desk",
    categoryAr: "المكتب المؤسسي الاستثماري فائق السرعة",
    resourceBound: "Ultimate / 12 Engines Unrestricted",
    resourceBoundAr: "١٢ محركاً كاملاً / غير مقيد بدون قيود خنق",
    maxEngines: 12,
    maxStrategies: 25,
    authMethod: "IP-Whitelisted mTLS + Multi-Sig HSM Hardware Enclave",
    authMethodAr: "التشفير المتبادل mTLS المعتمد بالعزل العتادي HSM",
    scopes: ["sys:root", "engine:unrestricted", "bypass:throttling", "audit:sha256"],
    riskClamp: "Microsecond Routing Hooks & Master Circuit-Breaker",
    riskClampAr: "قواطع طوارئ ميكروثانية وسجل تدقيق تشفيري لحظي",
    interfaceHud: "Quantum Mesh",
    interfaceHudAr: "شبكة كمومية كاملة للبث اللحظي عالي الكثافة",
    colorAccent: "#FA1F4E",
    badge: "12 ENGINES • UNRESTRICTED QUANTUM PIPELINE",
    latencySla: "< 0.18ms Co-Located Direct",
    features: [
      "Ultra-low latency telemetry matrix with 0-throttling pipeline",
      "Raw cryptographic SHA-256 ledger tracing on every order",
      "Instant manual kill-switch microsecond routing hooks",
      "Direct Tier-1 exchange co-located connectivity & raw quant ingestion"
    ],
    featuresAr: [
      "بث لحظي فائق السرعة عبر شبكة الألياف المباشرة بدون أي تأخير",
      "سجل تدقيق تشفيري دائم ببصمات SHA-256 لكل أمر منفذ",
      "قاطع طوارئ فوري مع خطافات إيقاف بالميكروثانية لحماية السيولة",
      "ربط مباشر مع منصات السيولة العالمية من الدرجة الأولى (Tier-1)"
    ]
  }
};

export interface IdentityState {
  activeTier: TierId;
  user: UserProfile;
  tierProfile: TierProfile;
  jwtPayload: JWTPayloadInfo;
  isTokenDecrypted: boolean;
  isIdentityModalOpen: boolean;
  mfaVerified: boolean;
  mtlsVerified: boolean;
  biometricActive: boolean;
  activeEnginesCount: number;
  activeStrategiesCount: number;
}

const initialTier: TierId = (localStorage.getItem("memobot_active_tier") as TierId) || "institutional";

const initialJWTPayload: JWTPayloadInfo = {
  sub: "usr_memobot_root_001",
  username: "maher_root",
  role: "Institutional Root Director",
  tier: initialTier,
  scopes: TIER_PROFILES[initialTier].scopes,
  tenant_id: initialTier === "corporate" ? "WL_CORP_09" : undefined,
  max_engines: TIER_PROFILES[initialTier].maxEngines,
  max_strategies: TIER_PROFILES[initialTier].maxStrategies,
  iat: Math.floor(Date.now() / 1000) - 3600,
  exp: Math.floor(Date.now() / 1000) + 86400 * 30,
  iss: "https://auth.memobot-fxpro.com/v1",
  aud: "memobot-fxpro-runtime-mesh",
  jti: "jwt_claim_" + Math.random().toString(36).substring(2, 10),
  raw_token: "eyJhbGciOiJFZDI1NTE5IiwidHlwIjoiSldUIn0..."
};

const initialIdentityState: IdentityState = {
  activeTier: initialTier,
  user: {
    id: "usr_memobot_root_001",
    username: "maher_root",
    role: "Institutional Root Director",
    tier: initialTier,
    email: "maher@memobot-fxpro.com",
    organization: "MemoBot FX-Pro Global Liquidity Desk",
    tenantId: initialTier === "corporate" ? "WL_CORP_09" : undefined,
    isActive: true,
    mfaEnabled: true,
    biometricRegistered: true,
    mtlsFingerprint: "SHA256:8f4b...39e1:APPROVED"
  },
  tierProfile: TIER_PROFILES[initialTier],
  jwtPayload: initialJWTPayload,
  isTokenDecrypted: true,
  isIdentityModalOpen: false,
  mfaVerified: true,
  mtlsVerified: true,
  biometricActive: true,
  activeEnginesCount: initialTier === "individual" ? 2 : initialTier === "investor" ? 5 : initialTier === "corporate" ? 8 : 9,
  activeStrategiesCount: initialTier === "individual" ? 2 : initialTier === "investor" ? 4 : initialTier === "corporate" ? 7 : 9
};

class IdentityStoreClass extends Store<IdentityState> {
  constructor() {
    super(initialIdentityState);
  }

  public setTier(tier: TierId, customUsername?: string) {
    const profile = TIER_PROFILES[tier];
    localStorage.setItem("memobot_active_tier", tier);
    
    const jwt: JWTPayloadInfo = {
      sub: `usr_${tier}_${Math.random().toString(36).substring(2, 7)}`,
      username: customUsername || (tier === "institutional" ? "maher_root" : tier === "corporate" ? "enterprise_admin" : tier === "investor" ? "pro_investor" : "individual_trader"),
      role: tier === "institutional" ? "Institutional Root Director" : tier === "corporate" ? "Corporate Tenant Admin" : tier === "investor" ? "Pro Portfolio Investor" : "Individual Space Trader",
      tier: tier,
      scopes: profile.scopes,
      tenant_id: tier === "corporate" ? "WL_CORP_09" : undefined,
      max_engines: profile.maxEngines,
      max_strategies: profile.maxStrategies,
      iat: Math.floor(Date.now() / 1000),
      exp: Math.floor(Date.now() / 1000) + 86400 * 30,
      iss: "https://auth.memobot-fxpro.com/v1",
      aud: "memobot-fxpro-runtime-mesh",
      jti: "jwt_" + Math.random().toString(36).substring(2, 10),
      raw_token: `eyJhbGciOiJFZDI1NTE5IiwidHlwIjoiSldUIn0.${btoa(JSON.stringify({ tier, scopes: profile.scopes }))}.SIG_${Math.random().toString(36).substring(2, 12)}`
    };

    this.setState({
      activeTier: tier,
      tierProfile: profile,
      jwtPayload: jwt,
      user: {
        id: jwt.sub,
        username: jwt.username,
        role: jwt.role,
        tier: tier,
        email: `${jwt.username}@memobot-fxpro.com`,
        organization: tier === "corporate" ? "White-Label Partner Corp WL_09" : tier === "institutional" ? "MemoBot FX-Pro Global Liquidity Desk" : "Private Client",
        tenantId: jwt.tenant_id,
        isActive: true,
        mfaEnabled: tier !== "individual",
        biometricRegistered: true,
        mtlsFingerprint: tier === "institutional" ? "SHA256:8f4b...39e1:APPROVED" : undefined
      },
      isTokenDecrypted: true,
      activeEnginesCount: Math.min(this.state.activeEnginesCount, profile.maxEngines),
      activeStrategiesCount: Math.min(this.state.activeStrategiesCount, profile.maxStrategies)
    });
  }

  public toggleIdentityModal(isOpen?: boolean) {
    this.setState({
      isIdentityModalOpen: isOpen !== undefined ? isOpen : !this.state.isIdentityModalOpen
    });
  }
}

export const identityStore = new IdentityStoreClass();
export default identityStore;
