type Listener<T> = (state: T) => void;

export class Store<T> {
  protected state: T;
  private listeners: Set<Listener<T>> = new Set();
  private initialState: T;

  constructor(initialState: T) {
    this.initialState = JSON.parse(JSON.stringify(initialState));
    this.state = JSON.parse(JSON.stringify(initialState));
  }

  public getState(): T {
    return this.state;
  }

  public setState(nextState: Partial<T> | ((current: T) => Partial<T>)): void {
    const patch = typeof nextState === "function" ? nextState(this.state) : nextState;
    this.state = { ...this.state, ...patch };
    this.notify();
  }

  public subscribe(cb: Listener<T>): () => void {
    this.listeners.add(cb);
    return () => this.unsubscribe(cb);
  }

  public unsubscribe(cb: Listener<T>): void {
    this.listeners.delete(cb);
  }

  public reset(): void {
    this.state = JSON.parse(JSON.stringify(this.initialState));
    this.notify();
  }

  private notify(): void {
    this.listeners.forEach((cb) => cb(this.state));
  }
}
