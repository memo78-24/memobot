import { socialStore } from "./socialStore";
import { ApiClient } from "./api";
import { SocialCampaign, ActivityQueueItem } from "../types";

export class SocialService {
  private static activitySyncInterval: NodeJS.Timeout | null = null;

  public static init() {
    // Start periodic background execution ticks
    if (this.activitySyncInterval) clearInterval(this.activitySyncInterval);
    
    this.activitySyncInterval = setInterval(() => {
      const state = socialStore.getState();
      if (!state.runningDaily) return;

      // Randomly process a pending queue item
      const pendingIndex = state.queue.findIndex(item => item.status === "Pending");
      if (pendingIndex !== -1) {
        const item = state.queue[pendingIndex];
        const updatedQueue = [...state.queue];
        updatedQueue[pendingIndex] = {
          ...item,
          status: "Sent"
        };

        // Increment stats
        socialStore.setState({
          queue: updatedQueue,
          totalApproachesSent: state.totalApproachesSent + 1
        });
      }
    }, 20000); // Check every 20 seconds
  }

  public static destroy() {
    if (this.activitySyncInterval) {
      clearInterval(this.activitySyncInterval);
      this.activitySyncInterval = null;
    }
  }

  public static toggleDailyRunning(running: boolean) {
    socialStore.setState({ runningDaily: running });
  }

  public static async createCampaign(campaign: Omit<SocialCampaign, "id" | "generatedApproachesCount" | "successRate">) {
    socialStore.setState({ loading: true, error: null });
    try {
      const id = "CAMP-" + Math.floor(100 + Math.random() * 900);
      const newCampaign: SocialCampaign = {
        ...campaign,
        id,
        generatedApproachesCount: 0,
        successRate: 0
      };

      const currentCampaigns = socialStore.getState().campaigns;
      socialStore.setState({
        campaigns: [...currentCampaigns, newCampaign],
        loading: false
      });
      return newCampaign;
    } catch (err: any) {
      socialStore.setState({ loading: false, error: err.message });
      throw err;
    }
  }

  public static toggleCampaignStatus(id: string) {
    const campaigns = socialStore.getState().campaigns.map(camp => {
      if (camp.id === id) {
        return {
          ...camp,
          status: (camp.status === "Active" ? "Paused" : "Active") as any
        };
      }
      return camp;
    });
    socialStore.setState({ campaigns });
  }

  public static deleteCampaign(id: string) {
    const campaigns = socialStore.getState().campaigns.filter(camp => camp.id !== id);
    socialStore.setState({ campaigns });
  }

  public static async generateCampaignOutbound(campaignId: string, customContext: string, includePic: boolean = false): Promise<string> {
    socialStore.setState({ loading: true, error: null });
    try {
      const campaign = socialStore.getState().campaigns.find(c => c.id === campaignId);
      if (!campaign) throw new Error("Campaign not found");

      // Request live content from our secure server-side proxy
      const payload = {
        platform: campaign.platform,
        campaignType: campaign.type,
        targetAudience: campaign.targetAudience,
        customContext,
        includePic
      };

      const response = await ApiClient.post("/social/generate", payload);
      const content = response.content || "";
      const imageUrl = response.imageUrl;

      // Push into our outbound activities queue
      const queueId = "Q-" + Math.floor(100 + Math.random() * 900);
      const newQueueItem: ActivityQueueItem = {
        id: queueId,
        platform: campaign.platform,
        campaignName: campaign.name,
        content,
        imageUrl,
        recipient: campaign.platform === "Twitter/X" || campaign.platform === "Reddit" ? "Public Feed" : "Target List Opener",
        scheduledAt: new Date(Date.now() + 600000).toISOString(), // Schedule in 10 minutes
        status: "Pending"
      };

      const currentQueue = socialStore.getState().queue;
      const updatedCampaigns = socialStore.getState().campaigns.map(c => {
        if (c.id === campaignId) {
          return {
            ...c,
            generatedApproachesCount: c.generatedApproachesCount + 1
          };
        }
        return c;
      });

      socialStore.setState({
        queue: [newQueueItem, ...currentQueue],
        campaigns: updatedCampaigns,
        loading: false
      });

      return content;
    } catch (err: any) {
      socialStore.setState({ loading: false, error: err.message });
      throw err;
    }
  }

  public static clearQueueItem(id: string) {
    const queue = socialStore.getState().queue.filter(item => item.id !== id);
    socialStore.setState({ queue });
  }
}
