/**
 * MEMOBOT VAULT™ Freedom & Stealth Security Service
 * Provides user-controlled passcode protection, credential obfuscation,
 * and decoy matrix configuration without forced server restrictions.
 */

export type DecoyTheme = "matrix" | "maintenance" | "ticker" | "stealth_black";

export interface VaultSecurityConfig {
  hasPasscode: boolean;
  decoyTheme: DecoyTheme;
  customDecoyText?: string;
  autoLockOnLeave: boolean;
  autoLockTimerMinutes: number; // 0 = disabled
}

const CONFIG_KEY = "memobot_vault_sec_config";
const HASH_KEY = "memobot_vault_sec_hash";
const LOCK_STATE_KEY = "memobot_vault_is_locked";

// Simple fast hash for client-side passcode validation (SHA-256 equivalent using subtle crypto or fast hash)
export function hashPasscode(passcode: string): string {
  let hash = 0;
  for (let i = 0; i < passcode.length; i++) {
    const char = passcode.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0; // Convert to 32bit integer
  }
  return "MBV_" + Math.abs(hash).toString(36) + "_" + passcode.length;
}

// Obfuscation helper using simple XOR with passcode key
export function obfuscateText(text: string, key: string): string {
  if (!text || !key) return text;
  let result = "";
  for (let i = 0; i < text.length; i++) {
    const charCode = text.charCodeAt(i) ^ key.charCodeAt(i % key.length);
    result += String.fromCharCode(charCode);
  }
  return btoa(result);
}

export function deobfuscateText(encoded: string, key: string): string {
  if (!encoded || !key) return encoded;
  try {
    const text = atob(encoded);
    let result = "";
    for (let i = 0; i < text.length; i++) {
      const charCode = text.charCodeAt(i) ^ key.charCodeAt(i % key.length);
      result += String.fromCharCode(charCode);
    }
    return result;
  } catch (e) {
    return "";
  }
}

export class VaultSecurityManager {
  static getConfig(): VaultSecurityConfig {
    const raw = localStorage.getItem(CONFIG_KEY);
    if (!raw) {
      return {
        hasPasscode: false,
        decoyTheme: "matrix",
        autoLockOnLeave: true,
        autoLockTimerMinutes: 5,
      };
    }
    try {
      return JSON.parse(raw);
    } catch {
      return {
        hasPasscode: false,
        decoyTheme: "matrix",
        autoLockOnLeave: true,
        autoLockTimerMinutes: 5,
      };
    }
  }

  static saveConfig(config: VaultSecurityConfig): void {
    localStorage.setItem(CONFIG_KEY, JSON.stringify(config));
  }

  static setPasscode(newPasscode: string, decoyTheme: DecoyTheme = "matrix"): void {
    if (!newPasscode.trim()) {
      this.removePasscode();
      return;
    }
    const hashed = hashPasscode(newPasscode.trim());
    localStorage.setItem(HASH_KEY, hashed);
    
    const config = this.getConfig();
    config.hasPasscode = true;
    config.decoyTheme = decoyTheme;
    this.saveConfig(config);
    this.lock();
  }

  static removePasscode(): void {
    localStorage.removeItem(HASH_KEY);
    const config = this.getConfig();
    config.hasPasscode = false;
    this.saveConfig(config);
    this.unlock();
  }

  static verifyPasscode(passcode: string): boolean {
    const storedHash = localStorage.getItem(HASH_KEY);
    if (!storedHash) return true; // No passcode set
    const inputHash = hashPasscode(passcode.trim());
    return inputHash === storedHash;
  }

  static isLocked(): boolean {
    const config = this.getConfig();
    if (!config.hasPasscode) return false;
    const rawState = localStorage.getItem(LOCK_STATE_KEY);
    return rawState === null ? true : rawState === "true";
  }

  static lock(): void {
    const config = this.getConfig();
    if (config.hasPasscode) {
      localStorage.setItem(LOCK_STATE_KEY, "true");
    }
  }

  static unlock(): void {
    localStorage.setItem(LOCK_STATE_KEY, "false");
  }
}
