import { Store } from "./store";

export interface Engine {
  engine_id: string;
  display_name: string;
  nickname: string;
  subtitle: string;
  theme: string;
  status: "Running" | "Stopped";
  uptime_seconds: number;
  current_stage_idx: number;
  latency_ms: number;
  cpu_load: number;
  memory_mb: number;
  strategy: string;
  asset: string;
  amount: number;
  leverage?: number;
  runtime_hours: number;
  last_tick: number;
}

export interface WingsData {
  buy_pressure: number;
  bids: Array<[number, number]>;
  asks: Array<[number, number]>;
}

export interface EngineState {
  engines: Record<string, Engine>;
  globalMode: "Paper" | "Live";
  liveModeConfirmed: boolean;
  complianceMode: "Islamic" | "Commercial";
  activeTab: string;
  wingsData: Record<string, WingsData>;
  loading: boolean;
  error: string | null;
}

const initialEngineState: EngineState = {
  engines: {},
  globalMode: "Paper",
  liveModeConfirmed: false,
  complianceMode: "Islamic",
  activeTab: "ENG-001",
  wingsData: {},
  loading: true,
  error: null,
};

class EngineStoreClass extends Store<EngineState> {
  constructor() {
    super(initialEngineState);
  }
}

export const engineStore = new EngineStoreClass();
export default engineStore;
