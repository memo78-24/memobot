// Real, professional, high-standard Arabic financial & engineering translation dictionary
// قاموس المصطلحات والترجمات المالية والتقنية الدقيقة باللغة العربية الفصحى السليمة

export const ARABIC_DICTIONARY: Record<string, string> = {
  // --- Page Loader & Synchronizer Messages ---
  "SYNCHRONIZING WITH IMMUTABLE EXCHANGE LEDGER...": "المزامنة مع دفتر أستاذ المنصات غير القابل للتغيير...",
  "SYNCHRONIZING WITH IMMUTABLE EXCHANGE LEDGER": "المزامنة مع دفتر أستاذ المنصات غير القابل للتغيير",
  "Deterministic MemoCore Cluster Active": "عنقود ميموكور الحتمي نشط",
  "SYNCHRONIZING RISK MATRIX & EXPOSURE PROTOCOLS...": "مزامنة مصفوفة المخاطر وبروتوكولات التكشف...",
  "SYNCHRONIZING RISK MATRIX & EXPOSURE PROTOCOLS": "مزامنة مصفوفة المخاطر وبروتوكولات التكشف",
  "Computing Real-Time Value-at-Risk Engine": "حساب محرك القيمة المعرضة للمخاطر في الوقت الفعلي",
  "LOADING ACTIVE SPOT ALLOCATIONS...": "تحميل مخصصات التداول الفوري النشطة...",
  "LOADING ACTIVE SPOT ALLOCATIONS": "تحميل مخصصات التداول الفوري النشطة",
  "Streaming Dynamic Order Book Depth": "بث عمق سجل الأوامر الديناميكي المباشر",
  "LOADING SECURE TRADING ENVIRONMENT...": "تحميل بيئة التداول الآمنة...",
  "LOADING SECURE TRADING ENVIRONMENT": "تحميل بيئة التداول الآمنة",
  "Syncing Order Books & Execution Gateways": "مزامنة سجلات الأوامر وبوابات التنفيذ",
  "DECRYPTING SECURE CREDENTIAL LAYERS...": "فك تشفير طبقات الاعتماد الآمنة...",
  "DECRYPTING SECURE CREDENTIAL LAYERS": "فك تشفير طبقات الاعتماد الآمنة",
  "Unlocking AES-256 GCM Hardware Keystores": "فتح مخازن مفاتيح التشفير العتادية AES-256 GCM",
  "INITIALIZING HIGHTECHEYE SUPER SYSTEM TELEMETRY COCKPIT...": "تهيئة مقصورة القياس عن بُعد لنظام HighTechEye الفائق...",
  "INITIALIZING HIGHTECHEYE SUPER SYSTEM TELEMETRY COCKPIT": "تهيئة مقصورة القياس عن بُعد لنظام HighTechEye الفائق",
  "Calibrating Real-Time Kernel Telemetry Gauges": "معايرة مقاييس القياس عن بُعد لنواة النظام لحظياً",
  "LOADING INDIVIDUAL TRADING TERMINAL...": "تحميل منصة التداول الفردية...",
  "LOADING INDIVIDUAL TRADING TERMINAL": "تحميل منصة التداول الفردية",
  "Establishing Real-Time WebSocket Ledger Feeds": "إنشاء تغذية دفتر الأستاذ عبر ويب سوكت لحظياً",
  "INITIALIZING COMPILATION IDE MODULES...": "تهيئة وحدات بيئة التطوير والترجمة البرمجية...",
  "INITIALIZING COMPILATION IDE MODULES": "تهيئة وحدات بيئة التطوير والترجمة البرمجية",
  "Validating Algorithmic Blueprints": "التحقق من صحة المخططات الخوارزمية",
  "SYNCHRONIZING EXCHANGES: OKX, BINANCE, BYBIT ACTIVE.": "مزامنة المنصات: أوكيه إكس، بينانس، باي بيت نشطة.",
  "SYNCHRONIZING EXCHANGES: OKX, BINANCE, BYBIT ACTIVE": "مزامنة المنصات: أوكيه إكس، بينانس، باي بيت نشطة",

  // --- Titles, Slogans & Banners ---
  "WE NOT JUST GIVE SIGNALS!!! WE \"PROTECT YOUR CAPITAL FIRST\"": "نحن لا نعطي إشارات فقط!!! نحن \"نحمي رأس مالك أولاً\"",
  "WE NOT JUST GIVE SIGNALS!!! WE PROTECT YOUR CAPITAL FIRST": "نحن لا نعطي إشارات فقط!!! نحن نحمي رأس مالك أولاً",
  "PRIME EDITION • HIGH-PRECISION TRADING": "النسخة الممتازة • تداول عالي الدقة",
  "PRIME EDITION": "النسخة الممتازة",
  "HIGH-PRECISION TRADING": "تداول عالي الدقة",
  "MEMOBOT ENCRYPTED VAULT™ & API DIAGNOSTICS": "خزينة ميموبوت المشفرة™ وتشخيص واجهات البرمجة",
  "MEMOBOT ENCRYPTED VAULT & API DIAGNOSTICS": "خزينة ميموبوت المشفرة وتشخيص واجهات البرمجة",
  "Manage and test all exchange APIs, notification credentials, and system endpoints in real time.": "إدارة واختبار كافة واجهات برمجة المنصات، وبيانات الاعتماد للتنبيهات، ونقاط نهاية النظام في الوقت الفعلي.",
  "Manage and test all exchange APIs, notification credentials, and system endpoints in real time": "إدارة واختبار كافة واجهات برمجة المنصات، وبيانات الاعتماد للتنبيهات، ونقاط نهاية النظام في الوقت الفعلي",
  "TEST ALL API ENTRIES": "اختبار كافة واجهات البرمجة",
  "OPERATIONAL MANIFESTO": "البيان التشغيلي",
  "FREEDOM MATRIX & AUDIT SYSTEM": "مصفوفة الحرية ونظام التدقيق",
  "FREEDOM MATRIX & AUDITING SYSTEM": "مصفوفة الحرية ونظام التدقيق",
  "MAIN POLICY: LIFE IS SIMPLE. SECURITY MEANS PERSONAL FREEDOM, NOT FORCING LOCKS OR RESTRICTIONS ON YOU!": "السياسة الأساسية: الحياة بسيطة. الأمان يعني الحرية الشخصية، وليس فرض قيود أو أقفال إجبارية عليك!",
  "MAIN POLICY: LIFE IS SIMPLE. SECURITY MEANS PERSONAL FREEDOM, NOT FORCING LOCKS OR RESTRICTIONS ON YOU": "السياسة الأساسية: الحياة بسيطة. الأمان يعني الحرية الشخصية، وليس فرض قيود أو أقفال إجبارية عليك",
  "MAIN POLICY: LIFE IS SIMPLE": "السياسة الأساسية: الحياة بسيطة",
  "SECURITY MEANS PERSONAL FREEDOM, NOT FORCING LOCKS OR RESTRICTIONS ON YOU!": "الأمان يعني الحرية الشخصية، وليس فرض قيود أو أقفال إجبارية عليك!",
  "SECURITY MEANS PERSONAL FREEDOM, NOT FORCING LOCKS OR RESTRICTIONS ON YOU": "الأمان يعني الحرية الشخصية، وليس فرض قيود أو أقفال إجبارية عليك",
  "STEALTH & FREEDOM MATRIX VAULT": "خزينة مصفوفة التخفي والحرية المطلقة",
  "No passcode set. You have full freedom to add or remove access locks anytime.": "لم يتم تعيين رمز سري. لديك الحرية الكاملة لإضافة أو إزالة أقفال الوصول في أي وقت.",
  "No passcode set. You have full freedom to add or remove access locks anytime": "لم يتم تعيين رمز سري. لديك الحرية الكاملة لإضافة أو إزالة أقفال الوصول في أي وقت",
  "ADD PASSCODE & STEALTH COVER": "إضافة رمز سري وغطاء التخفي",
  "FREEDOM MODE (NO LOCK)": "وضع الحرية (بدون قفل)",
  "USER-CONTROLLED MATRIX": "مصفوفة بتحكم المستخدم",
  "BINANCE (SLOT #1) EXCHANGE API PANEL": "لوحة مفاتيح منصة بينانس (المنفذ رقم ١)",
  "BINANCE (#1 SLOT) EXCHANGE API PANEL": "لوحة مفاتيح منصة بينانس (المنفذ رقم ١)",
  "Required for mainnet live order routing and wallet balance checks.": "مطلوب لتوجيه الأوامر الفورية الحية والتحقق من رصيد المحفظة.",
  "Required for mainnet live order routing and wallet balance checks": "مطلوب لتوجيه الأوامر الفورية الحية والتحقق من رصيد المحفظة",
  "SECURE LAYER STATE TELEMETRY": "بيانات حالة الطبقة الآمنة",
  "SECURE LAYER HOOK": "ربط الطبقة الآمنة",
  "RAM INPUT PURGE": "مسح الذاكرة العشوائية",
  "STEALTH TRANSITION": "انتقال التخفي",
  "AUTO ON UNLOAD": "تلقائي عند المغادرة",
  "3D FOLD / FADE": "طي ثلاثي الأبعاد / تلاشي",
  "When locked or navigated away, sensitive memory buffers are completely wiped from state and DOM.": "عند القفل أو مغادرة الصفحة، يتم مسح سجلات الذاكرة الحساسة نهائياً من الذاكرة والواجهة.",
  "When locked or navigated away, sensitive memory buffers are completely wiped from state and DOM": "عند القفل أو مغادرة الصفحة، يتم مسح سجلات الذاكرة الحساسة نهائياً من الذاكرة والواجهة",
  "STRATEGY IDE™ STUDIO": "استوديو تطوير الاستراتيجيات™",
  "STRATEGY IDE STUDIO": "استوديو تطوير الاستراتيجيات",
  "IDE™ STUDIO": "استوديو بيئة التطوير™",
  "IDE STUDIO": "استوديو بيئة التطوير",
  "Build algorithmic models, simulate backtest portfolios, compare versions, and apply AI optimized parameters.": "بناء النماذج الخوارزمية، ومحاكاة محافظ الاختبار العكسي، ومقارنة الإصدارات، وتطبيق معايير التحسين بالذكاء الاصطناعي.",
  "Build algorithmic models, simulate backtest portfolios, compare versions, and apply AI optimized parameters": "بناء النماذج الخوارزمية، ومحاكاة محافظ الاختبار العكسي، ومقارنة الإصدارات، وتطبيق معايير التحسين بالذكاء الاصطناعي",
  "PROTECTED BY ISLAMIC SHARIAH PROTOCOL": "محمي ببروتوكول الشريعة الإسلامية",
  "PROTECTED BY": "محمي بواسطة",
  "ISLAMIC SHARIAH PROTOCOL": "بروتوكول الشريعة الإسلامية",
  "0% Interest / 0% Leverage / Halal Assets Only": "٠٪ فوائد ربوية / ٠٪ رافعة مالية / أصول حلال فقط",
  "IX System hard-locked to Spot algorithms, risk triggers, and order routing operate strictly under AAOIFI standards.": "نظام مقفل على التداول الفوري، وتعمل الخوارزميات ومحفزات المخاطر وتوجيه الأوامر وفقاً لمعايير أيوفي (AAOIFI) الصارمة.",
  "IX System hard-locked to Spot algorithms, risk triggers, and order routing operate strictly under AAOIFI standards": "نظام مقفل على التداول الفوري، وتعمل الخوارزميات ومحفزات المخاطر وتوجيه الأوامر وفقاً لمعايير أيوفي (AAOIFI) الصارمة",
  "FULL SYSTEM LOCK": "قفل النظام بالكامل",
  "FULL SYSTEM LOCK ACTIVE": "قفل النظام بالكامل نشط",
  "ISLAMIC SHARIAH MODE ACTIVE": "الوضع الشرعي الإسلامي مفعل",
  "PROTECTED BY SHARIAH PROTOCOL": "محمي ببروتوكول الشريعة",
  "System hard-locked to Spot 1X (0% Interest / 0% Leverage / Halal Assets Only). All trading algorithms, risk triggers, and order routing operate strictly under AAOIFI Islamic standards.": "النظام مقفل حصرياً على التداول الفوري 1X (٠٪ فوائد ربوية / ٠٪ رافعة مالية / أصول حلال فقط). كافة خوارزميات التداول ومحفزات المخاطر وتوجيه الأوامر تعمل بصرامة وفقاً لمعايير أيوفي (AAOIFI) الإسلامية.",
  "System hard-locked to Spot 1X (0% Interest / 0% Leverage / Halal Assets Only). All trading algorithms, risk triggers, and order routing operate strictly under AAOIFI Islamic standards": "النظام مقفل حصرياً على التداول الفوري 1X (٠٪ فوائد ربوية / ٠٪ رافعة مالية / أصول حلال فقط). كافة خوارزميات التداول ومحفزات المخاطر وتوجيه الأوامر تعمل بصرامة وفقاً لمعايير أيوفي (AAOIFI) الإسلامية",
  "BEGINNER FRIENDLY": "مناسب للمبتدئين",
  "Beginner Friendly": "مناسب للمبتدئين",
  "HOW TO CHOOSE & DEPLOY YOUR STRATEGY": "كيف تختار وتنشر استراتيجيتك",
  "HOW TO CHOOSE AND DEPLOY YOUR STRATEGY": "كيف تختار وتنشر استراتيجيتك",
  "Step 1:": "الخطوة ١:",
  "Step 2:": "الخطوة ٢:",
  "Step 3:": "الخطوة ٣:",
  "Algorithm Templates": "قوالب الخوارزميات",
  "Clone to Draft": "استنساخ إلى المسودة",
  "Run Simulation": "تشغيل المحاكاة",
  "Promote & Deploy": "ترقية ونشر",
  "CENTRAL SWARM ENGINE INTEGRATION BRIDGE": "جسر ربط محرك السرب المركزي",
  "AUTOMATIC & ACTIVE": "تلقائي ونشط",
  "Select a template from": "اختر قالباً من",
  "on the left.": "من اليسار.",
  "to open your customizable workspace.": "لفتح مساحة العمل القابلة للتخصيص.",
  "Test parameters with": "اختبر المعايير باستخدام",
  "before clicking": "قبل الضغط على",
  "DASHBOARD CONTROL DECK": "منصة التحكم الرئيسية",
  "DASHBOARD CONTROL DESK": "منصة التحكم الرئيسية",
  "CONTROL DECK": "منصة التحكم",
  "CONTROL DESK": "منصة التحكم",

  // --- Risk Manager & Exposure ---
  "RISK MANAGER & EXPOSURE PROTOCOLS": "إدارة المخاطر وبروتوكولات التكشف",
  "RISK MANAGER AND EXPOSURE PROTOCOLS": "إدارة المخاطر وبروتوكولات التكشف",
  "Institutional-grade risk matrix control deck. Set max daily drawdown limits, position caps, automated stop losses, and anti-whale stealth execution.": "منصة تحكم مصفوفة المخاطر المؤسسية. تعيين حدود التراجع اليومي الأقصى، وسقوف المراكز، ووقف الخسارة التلقائي، والتنفيذ الخفي ضد الحيتان.",
  "Institutional-grade risk matrix control deck. Set max daily drawdown limits, position caps, automated stop losses, and anti-whale stealth execution": "منصة تحكم مصفوفة المخاطر المؤسسية. تعيين حدود التراجع اليومي الأقصى، وسقوف المراكز، ووقف الخسارة التلقائي، والتنفيذ الخفي ضد الحيتان",
  "CENTRAL SWARM RISK ENGINES STATUS DECK": "منصة حالة محركات مخاطر السرب المركزي",
  "CENTRAL SWARM RISK ENGINES DECK": "منصة محركات مخاطر السرب المركزي",
  "REAL-TIME RISK SYNC": "مزامنة المخاطر اللحظية",
  "Every change to the risk protocols below automatically propagates to all 12 exchange-specific engines instantly over secure WebSocket streams.": "كل تغيير في بروتوكولات المخاطر أدناه يُعمم تلقائياً على كافة محركات البورصات الـ ١٢ فورياً عبر قنوات ويب سوكت المشفرة.",
  "Every change to the risk protocols below automatically propagates to all 12 exchange-specific engines instantly over secure WebSocket streams": "كل تغيير في بروتوكولات المخاطر أدناه يُعمم تلقائياً على كافة محركات البورصات الـ ١٢ فورياً عبر قنوات ويب سوكت المشفرة",
  "12 ENGINES SECURED": "١٢ محرك مؤمن",
  "Binance Desk": "مكتب بينانس",
  "KuCoin Desk": "مكتب كوكوين",
  "OKX Desk": "مكتب أوكيه إكس",
  "Bybit Desk": "مكتب باي بيت",
  "BINANCE DESK": "مكتب بينانس",
  "KUCOIN DESK": "مكتب كوكوين",
  "OKX DESK": "مكتب أوكيه إكس",
  "BYBIT DESK": "مكتب باي بيت",
  "SECURED": "مؤمن",
  "WORD": "وورد",
  "EXCEL": "إكسل",
  "PDF": "بي دي إف",
  "TXT": "نص",
  "MAX DAILY DRAWDOWN LIMIT": "الحد الأقصى للتراجع اليومي",
  "MAX POSITION SIZING": "الحد الأقصى لحجم المركز",
  "AUTO STOP LOSS": "وقف الخسارة التلقائي",
  "AUTO TAKE PROFIT": "جني الأرباح التلقائي",
  "AUTOMATIC STOP THRESHOLD": "عتبة الإيقاف التلقائي",
  "ENFORCED PER ORDER": "مفروض لكل أمر",
  "TRAILING SL TRIGGER ACTIVE": "تفعيل وقف الخسارة المتحرك",
  "PROFIT CAPTURE TARGET": "هدف اقتناص الأرباح",
  "GENERAL RISK SETTINGS": "إعدادات المخاطر العامة",
  "PROTOCOL SYNCED": "البروتوكول متزامن",
  "EMERGENCY HALT": "إيقاف طوارئ",
  "PROTOCOL:": "البروتوكول:",
  "ISLAMIC SHARIAH": "الشريعة الإسلامية",
  "COMMERCIAL DESK": "المكتب التجاري",
  "ACTIVE EXPOSURE BY ASSET": "التكشف النشط حسب الأصل",
  "DRAWDOWN HEATMAP & PROJECTIONS": "خريطة التراجع الحرارية والتوقعات",
  "DYNAMIC POSITION SIZING MATRIX": "مصفوفة تحديد أحجام المراكز الديناميكية",
  "ANTI-WHALE SLIPPAGE PROTECTION": "الحماية من انزلاق الحيتان السعري",
  "GLOBAL KILL SWITCH SAFEGUARDS": "إجراءات أمان قاطع الطوارئ الشامل",

  // --- Paper Trading & Orders ---
  "PAPER TRADING HUB": "مركز التداول التجريبي (الورقي)",
  "ISOLATED PAPER SANDBOX": "بيئة تجريبية معزولة",
  "Simulated paper execution sandbox — 100% isolated from real Binance live balances.": "بيئة تنفيذ تجريبية افتراضية — معزولة بنسبة ١٠٠٪ عن أرصدة بينانس الحقيقية.",
  "Simulated paper execution sandbox — 100% isolated from real Binance live balances": "بيئة تنفيذ تجريبية افتراضية — معزولة بنسبة ١٠٠٪ عن أرصدة بينانس الحقيقية",
  "AVAILABLE BALANCE": "الرصيد المتاح",
  "CURRENT UNREALIZED PNL": "الأرباح/الخسائر غير المحققة حالياً",
  "TOTAL SIMULATED TRADES": "إجمالي الصفقات الافتراضية",
  "WIN RATE": "نسبة النجاح",
  "EXECUTE SIMULATED ORDER": "تنفيذ أمر تجريبي",
  "RESET PAPER BALANCE": "إعادة ضبط الرصيد التجريبي",
  "ACTIVE & HISTORICAL ORDERS": "الأوامر النشطة والتاريخية",
  "Comprehensive ledger of spot limit, market, stop-loss orders, and automated execution trails.": "سجل شامل لأوامر التداول الفوري المحددة والسوقية ووقف الخسارة ومسارات التنفيذ التلقائي.",
  "Comprehensive ledger of spot limit, market, stop-loss orders, and automated execution trails": "سجل شامل لأوامر التداول الفوري المحددة والسوقية ووقف الخسارة ومسارات التنفيذ التلقائي",
  "Real-time telemetry and order execution across connected multi-exchange spot trading instances.": "القياس اللحظي عن بُعد وتنفيذ الأوامر عبر منصات التداول الفوري المتعددة المتصلة.",
  "Real-time telemetry and order execution across connected multi-exchange spot trading instances": "القياس اللحظي عن بُعد وتنفيذ الأوامر عبر منصات التداول الفوري المتعددة المتصلة",
  "LIVE POSITIONS TERMINAL": "منصة المراكز المفتوحة المباشرة",
  "Real-time asset distribution, profit/loss analysis, and certified Islamic spot allocation tracking.": "توزيع الأصول اللحظي، وتحليل الأرباح والخسائر، وتتبع تخصيص الأصول الشرعية المعتمدة.",
  "Real-time asset distribution, profit/loss analysis, and certified Islamic spot allocation tracking": "توزيع الأصول اللحظي، وتحليل الأرباح والخسائر، وتتبع تخصيص الأصول الشرعية المعتمدة",
  "INSTITUTIONAL PORTFOLIO & LEDGER": "المحفظة المؤسسية وسجل الأصول",
  "ENCRYPTED CREDENTIALS & API VAULT": "خزنة المفاتيح والبيانات المشفرة",
  "Zero-knowledge client-side encryption. Keys are decrypted in-memory only during execution and purged on logout.": "تشفير تام من جانب العميل بدون حفظ المفاتيح. يتم فك تشفير المفاتيح في الذاكرة المؤقتة فقط أثناء التنفيذ وتُمسح عند تسجيل الخروج.",
  "Zero-knowledge client-side encryption. Keys are decrypted in-memory only during execution and purged on logout": "تشفير تام من جانب العميل بدون حفظ المفاتيح. يتم فك تشفير المفاتيح في الذاكرة المؤقتة فقط أثناء التنفيذ وتُمسح عند تسجيل الخروج",
  "VIP INSTITUTIONAL BUSINESS CLUB": "نادي كبار المستثمرين والمؤسسات VIP",
  "Exclusive alpha insights, private syndication desks, and direct algorithmic advisory.": "تحليلات حصرية متقدمة، ومكاتب صفقات خاصة، واستشارات خوارزمية مباشرة.",
  "Exclusive alpha insights, private syndication desks, and direct algorithmic advisory": "تحليلات حصرية متقدمة، ومكاتب صفقات خاصة، واستشارات خوارزمية مباشرة",
  "SUBSCRIPTION & SUCCESS FEES": "الاشتراكات ورسوم النجاح",
  "Review institutional pricing tiers, automated profit-sharing settlements, and payment channels.": "استعراض باقات التسعير المؤسسي، وتسويات تقاسم الأرباح التلقائية، وقنوات الدفع.",
  "Review institutional pricing tiers, automated profit-sharing settlements, and payment channels": "استعراض باقات التسعير المؤسسي، وتسويات تقاسم الأرباح التلقائية، وقنوات الدفع",
  "SYSTEM CONFIGURATION & PREFERENCES": "إعدادات وتفضيلات النظام",
  "Institutional ledger metrics, active spot allocation, and risk management parameters.": "مؤشرات الدفتر المؤسسي، وتوزيع التداول الفوري النشط، ومعايير إدارة المخاطر.",
  "Autonomous Multi-Engine Quant Station coordinating high-frequency trades, capital safeguards, and instant compliance audits.": "محطة كمية متعددة المحركات ذاتية التنسيق لتنفيذ الصفقات عالية التردد، وحماية رأس المال، والتدقيق الفوري للامتثال الشرعي.",
  "Real-time monitoring across top 50 global cryptocurrencies, order book depth sensors, and Shariah spot compliance audits.": "مراقبة لحظية لأفضل ٥٠ عملة رقمية عالمية، ومستشعرات عمق سجل الطلبات، وتدقيق التوافق الشرعي للتداول الفوري.",
  "Welcome to MEMOBOT FX-PRO™ — Trading in a certified 100% Shariah Spot & Capital Safeguarded financial ecosystem.": "مرحبًا بك في ميموبوت إف إكس برو™ — التداول في منظومة مالية معتمدة شرعية ١٠٠٪ ومحمية رأس المال.",
  "Welcome to MEMOBOT FX-PRO™": "مرحبًا بك في ميموبوت إف إكس برو™",
  "Platform telemetry configuration, theme studio, alert notifications, institutional billing, and Admin Hub controls.": "إعدادات القياس عن بُعد، واستوديو المظهر، وإشعارات التنبيه، والفواتير المؤسسية، ولوحة تحكم مركز الإدارة.",
  
  // --- Theme Studio & Inspector ---
  "THEME STUDIO — CONFIGURE LAYOUT, AESTHETICS & SIDEBAR ARCHITECTURE": "استوديو المظهر — تكوين التخطيط، والجماليات، وهيكلية القائمة الجانبية",
  "THEME STUDIO — CONFIGURE LAYOUT, AESTHETICS, AND SIDEBAR ARCHITECTURE": "استوديو المظهر — تكوين التخطيط، والجماليات، وهيكلية القائمة الجانبية",
  "THEME STUDIO": "استوديو المظهر",
  "LIVE ELEMENT INSPECTOR": "فاحص العناصر المباشر",
  "ACTIVATE POINTER TOOL": "تفعيل أداة المؤشر",
  "DEACTIVATE POINTER TOOL": "إلغاء تفعيل أداة المؤشر",
  "GLOBAL TYPOGRAPHY & COLOR ACCENTS": "الخطوط العامة وألوان التمييز",
  "BRAND TITLES & SUBTITLES": "عناوين وهوية العلامة التجارية",
  "BRAND HIGHLIGHT TITLE (ACCENT COLOR)": "العنوان الرئيسي البارز (بلون التمييز)",
  "BRAND SECONDARY TITLE": "العنوان الثانوي للعلامة",
  "BRAND SUBTITLE / TAGLINE": "الشعار اللفظي للعلامة",
  "4 FONT EDITING & FORMATTING OPTIONS": "٤ خيارات لتنسيق وتعديل الخطوط",
  "CUSTOM FONT:": "خط مخصص:",
  "CUSTOM FONT": "خط مخصص",
  "FONT FAMILY": "عائلة الخط",
  "Type ANY Google Font (e.g. Montserrat).": "اكتب اسم أي خط من خطوط جوجل (مثل Cairo أو Tajawal أو Almarai).",
  "ZERO SERVER DEPLOY REQUIRED": "معاينة فورية دون الحاجة لإعادة التشغيل",
  "APPLIES COMPANION THEME PRESETS": "تطبيق القوالب اللونية المرافقة",
  "DOM COMPONENT MODIFIER INSTANT-PREVIEW": "تعديل عناصر الواجهة بالمعاينة الحية",
  "SIDEBAR ARCHITECTURE — MOVE NAVIGATORS & RENAME PANELS": "هيكلية القائمة الجانبية — ترتيب الروابط وتعديل المسميات",
  "Activate the high-fidelity platform visual editor. Once triggered, hover any part of the application (excluding the sidebar) to instantly highlight it. Click any header, text block, or card frame to live-edit text, apply custom theme colors, select nested parent nodes, or prune unwanted layout frames on-the-fly!": "قم بتفعيل المحرر المرئي المباشر للمنصة. عند تفعيله، مرر المؤشر فوق أي عنصر في التطبيق لتمييزه فورياً. اضغط على أي عنوان أو نص أو إطار لتعديله حياً، أو تغيير ألوانه، أو اختيار العناصر الفرعية وتخصيص الواجهة فوراً!",

  // --- Integration Blueprint & Station Hero ---
  "INTEGRATION BLUEPRINT": "المخطط الهيكلي للمنظومة",
  "SYSTEM CORE": "نواة النظام",
  "SYSTEM CORE [CENTRAL ENGINES STATION]": "نواة النظام [محطة المحركات المركزية]",
  "CENTRAL ENGINES STATION": "محطة المحركات المركزية",
  "CENTRAL ENGINE STATION": "محطة المحركات المركزية",
  "STRATEGY BLUEPRINT": "مخطط الاستراتيجيات",
  "STRATEGY": "الاستراتيجية",
  "BLUEPRINT": "المخطط",
  "RISK SHIELD": "درع حماية رأس المال",
  "RISK": "المخاطر",
  "SHIELD": "الدرع",
  "SHARIYAH BUREAU": "المكتب الشرعي",
  "SHARIYAH": "الشريعة",
  "BUREAU": "المكتب",
  "PAPER TRADE": "تداول تجريبي",
  "PAPER": "تداول",
  "TRADE": "تجريبي",
  "VAULT SECURITY": "أمان الخزينة والمفاتيح",
  "VAULT": "الخزينة",
  "SECURITY": "الأمان",
  "AUDITING HUB": "مركز التدقيق وسجلات الرقابة",
  "AUDITING": "التدقيق",
  "HUB": "المركز",
  "INSPECT MODULE": "فحص الوحدة",
  "QUANT ALGORITHM ONLINE": "الخوارزمية الكمية نشطة",
  "MAX 1.5% DRAWDOWN GUARD": "حماية أقصى تراجع بنسبة ١.٥٪",
  "AAOIFI STANDARD NO.21": "معيار أيوفي الشرعي رقم ٢١",
  "HFT QUANTUM ENGINE v4.2": "محرك التداول الكمومي عالي التردد (الإصدار ٤.٢)",
  "MULTI-EXCHANGE FEED": "بث الأسعار متعدد المنصات",
  "AES-256 ENCRYPTED": "مشفر بمعيار AES-256 المتقدم",
  "IMMUTABLE LEDGER SYNCED": "السجل المشفر غير القابل للتعديل متزامن",
  "9 ACTIVE PAIRS": "٩ أزواج نشطة",
  "SL/TP ENFORCED": "وقف الخسارة وجني الأرباح إلزامي",
  "CENTRAL ENGINES": "المحركات المركزية",
  "LIVE DEPTH ON": "عمق السوق المباشر مفعل",
  "FERNET ACTIVE": "تشفير فيرنت نشط",
  "LOGS MONITOR": "مراقب السجلات",
  "QUANTUM HFT ACTIVE": "التداول الكمي فائق السرعة نشط",
  "🕌 SHARIYAH CERTIFIED": "🕌 معتمد شرعياً",
  "SHARIYAH CERTIFIED": "معتمد شرعياً",
  "0.18ms LATENCY": "زمن الاستجابة ٠.١٨ مللي ثانية",
  "100% CAPITAL PROTECTED": "حماية رأس المال ١٠٠٪",
  "L2 LIQUIDITY DIRECT": "سيولة المستوى الثاني مباشرة",
  "PROFIT ASSURANCE ENGINE ACTIVE: ZERO SLIPPAGE & CAPITAL SAFEGUARD GUARANTEED": "محرك تأمين الأرباح نشط: انعدام الانزلاق السعري وضمان حماية رأس المال",
  "INSTITUTIONAL ENCRYPTION:": "التشفير المؤسسي:",
  "WEBSOCKET PING:": "استجابة مقبس الويب:",
  "Ledger Type": "نوع السجل",
  "Immutable Cryptographic": "سجل مشفر غير قابل للتعديل",
  "Traceability": "قابلية التتبع",
  "100% Correlation ID Linked": "مرتبط بمعرف الارتباط ١٠٠٪",
  "Export Formats": "صيغ التصدير المتاحة",
  "PDF, Word, Excel, Email": "ملفات PDF، Word، Excel، والبريد الإلكتروني",
  "BTC, ETH, SOL, XAU, EUR, GBP, XRP, ADA, BNB": "بيتكوين، إيثريوم، سولانا، ذهب، يورو، إسترليني، ريبل، كاردانو، بي إن بي",
  "High-frequency algorithmic strategy engine executing micro-breakout and mean-reversion trades across 9 vetted crypto & forex spot pairs.": "محرك استراتيجيات خوارزمي عالي التردد ينفذ صفقات الاختراق اللحظي والارتداد السعري عبر ٩ أزواج فورية معتمدة ومفحوصة.",
  "Autonomous capital protection shield that enforces rigid Stop-Loss/Take-Profit bounds on every millisecond order to guarantee capital safety.": "درع حماية رأس المال الذاتي الذي يفرض حدوداً صارمة لوقف الخسارة وجني الأرباح مع كل صفقة لضمان سلامة رأس المال التامة.",
  "100% Islamic Spot Trading certification ensuring zero interest (Riba), zero overnight swap fees, zero margin leverage loans, and immediate physical settlement.": "شهادة تداول فوري إسلامي معتمد ١٠٠٪ تضمن خلو الصفقات من الفوائد الربوية، وانعدام رسوم التبييت (السواب)، وخلوها من قروض الرافعة المالية، مع التقابض الفوري الحقيقي.",
  "The neural nerve center of Memobot FX-Pro™. Orchestrates data streams, risk models, AI signals, and execution routes with sub-millisecond precision.": "المركز العصبي الرئيسي لمنصة ميموبوت إف إكس برو™. يقوم بتنسيق تدفقات البيانات، ونماذج إدارة المخاطر، وإشارات الذكاء الاصطناعي، ومسارات التنفيذ بدقة فائقة السرعة.",
  "Direct L2/L3 orderbook depth stream connected to tier-1 liquidity venues (Binance, OKX, Bybit, LMAX) for optimal bid/ask fill execution.": "بث مباشر لعمق سجل الأوامر من المستويين الثاني والثالث متصل بأكبر مزودي السيولة العالميين لتنفيذ أفضل عروض الشراء والطلب.",
  "Cryptographic Fernet key storage and HSM hardware isolation preserving user credentials, API secret keys, and transaction logs from unauthorized access.": "تخزين مشفر للمفاتيح مع عزل عتادي كامل لحماية بيانات الاعتماد ومفاتيح واجهات البرمجة السرية وسجلات العمليات من أي وصول غير مصرح به.",
  "Real-time cryptographically hashed telemetry logger tracking every buy/sell order, indicator snapshot, and execution timestamp for full compliance.": "نظام تسجيل قياس عن بُعد مشفر ولحظي يتتبع كل أمر شراء وبيع، ولقطات المؤشرات، والأختام الزمنية للتنفيذ لضمان الامتثال التام.",

  // --- Metrics Labels & Values in Blueprint ---
  "Throughput": "معدل المعالجة",
  "THROUGHPUT": "معدل المعالجة",
  "250,000 Operations / Sec": "٢٥٠,٠٠٠ عملية / ثانية",
  "Uptime SLA": "مستوى الخدمة والجاهزية",
  "99.999% Institutional": "٩٩.٩٩٩٪ جاهزية مؤسسية",
  "Neural Model": "النموذج العصبي",
  "AlphaZero-Memobot v4": "ألفا زيرو - ميموبوت (الإصدار ٤)",
  "Active Spot Pairs": "أزواج التداول الفوري النشطة",
  "Execution Speed": "سرعة التنفيذ",
  "0.18 ms Average": "٠.١٨ مللي ثانية (المتوسط)",
  "Win Probability": "احتمالية النجاح",
  "88.4% Confidence Index": "٨٨.٤٪ مؤشر الثقة",
  "Max Position Risk": "أقصى مخاطرة للصفقة",
  "1.00% Per Trade": "١.٠٠٪ لكل صفقة",
  "Slippage Guard": "حماية الانزلاق السعري",
  "< 0.001% Enforced": "أقل من ٠.٠٠١٪ إلزامي",
  "Auto-Kill Switch": "قاطع الطوارئ الآلي",
  "Armed & Responsive": "مجهز وفي وضع الاستعداد",
  "Riba / Interest Rate": "الربا ومعدل الفائدة",
  "0.00% (Strictly Forbidden)": "٠.٠٠٪ (محرم تماماً)",
  "Overnight Swap": "رسوم التبييت (السواب)",
  "0.00 USD": "٠.٠٠ دولار أمريكي",
  "Handshake Protocol": "بروتوكول التقابض الفوري",
  "Instant Spot Handshake": "تقابض فوري حقيقي",
  "Orderbook Layers": "طبقات سجل الأوامر",
  "50 Level Depth": "٥٠ مستوى عمق",
  "Latency": "زمن الاستجابة",
  "< 10ms Global Ping": "أقل من ١٠ مللي ثانية",
  "Liquidity Access": "السيولة المتاحة",
  "$4.2B Institutional": "٤.٢ مليار دولار (مؤسسي)",
  "Encryption Grade": "مستوى التشفير",
  "AES-256-GCM + Fernet": "تشفير AES-256-GCM مع فيرنت",
  "Key Storage": "تخزين المفاتيح",
  "Hardware Isolation": "عزل عتادي محمي",
  "Audit State": "حالة التدقيق الأمني",
  "Zero Leak Verified": "مؤكد خلوه من أي تسريب",
  "Log Integrity": "سلامة السجلات",
  "SHA-256 Hash Chain": "سلسلة تجزئة SHA-256",
  "Audit Frequency": "دورية التدقيق",
  "Every 100ms Continuous": "كل ١٠٠ مللي ثانية باستمرار",
  "Regulator Ready": "جاهز للجهات الرقابية",
  "Instant Export Ready": "جاهز للتصدير الفوري",

  // --- Kill Switch & Emergency ---
  "EMERGENCY KILL SWITCH": "قاطع الطوارئ لإيقاف التداول",
  "KILL SWITCH ENGAGED": "تم تفعيل قاطع الطوارئ",
  "TRIGGER EMERGENCY KILL SWITCH": "تشغيل قاطع الطوارئ فوراً",
  "EMERGENCY KILL SWITCH ACTIVE": "قاطع الطوارئ نشط حالياً",
  "EMERGENCY KILL SWITCH CONFIRMATION": "تأكيد تشغيل قاطع الطوارئ",
  "ACTIVE PROTOCOL:": "البروتوكول النشط:",
  "ACTIVE PROTOCOL": "البروتوكول النشط",
  "ISLAMIC SHARIAH (SPOT 1X)": "الشريعة الإسلامية (فوري ١× بدون رافعة)",
  "ISLAMIC SHARIAH (HALAL SPOT)": "الشريعة الإسلامية (فوري حلال)",
  "SWITCH TO ISLAMIC MODE": "التحويل إلى الوضع الإسلامي",

  // --- Wings & Telemetry ---
  "WING_L // STABLE NODES": "الجناح الأيسر // العقد المستقرة",
  "WING_R // UNIFIED NODES": "الجناح الأيمن // العقد الموحدة",
  "WING L // STABLE NODES": "الجناح الأيسر // العقد المستقرة",
  "WING R // UNIFIED NODES": "الجناح الأيمن // العقد الموحدة",
  "WING_L": "الجناح الأيسر",
  "WING_R": "الجناح الأيمن",
  "STABLE NODES": "العقد المستقرة",
  "UNIFIED NODES": "العقد الموحدة",
  "TELEMETRY DIAGNOSTICS (LEFT)": "تشخيص القياس عن بُعد (الجناح الأيسر)",
  "TELEMETRY DIAGNOSTICS (RIGHT)": "تشخيص القياس عن بُعد (الجناح الأيمن)",
  "LEFT WING TELEMETRY (6 ENGINES)": "قياس الجناح الأيسر عن بُعد (٦ محركات)",
  "RIGHT WING TELEMETRY (6 ENGINES)": "قياس الجناح الأيمن عن بُعد (٦ محركات)",
  "LEFT WING TELEMETRY": "قياس الجناح الأيسر عن بُعد",
  "RIGHT WING TELEMETRY": "قياس الجناح الأيمن عن بُعد",
  "SYS_POWER:": "طاقة النظام:",
  "SYS_POWER": "طاقة النظام",
  "STANDBY POOL": "مجمع الاحتياط",
  "MAX LEVERAGE 1x SPOT": "أقصى رافعة مالية ١× فوري",
  "ISLAMIC MODE": "الوضع الشرعي",
  "AI OPERATIONS": "عمليات الذكاء الاصطناعي",
  "ENGLISH (EN)": "English (EN)",
  "ARABIC (AR)": "العربية (AR)",
  "WS ALIVE": "مقبس الويب متصل",
  "WS CONNECTED": "مقبس الويب متصل",
  "WS DISCONNECTED": "مقبس الويب غير متصل",

  // --- Navigation & Core Modules ---
  "CORE WORKSPACE": "مساحة العمل الأساسية",
  "CORE EQUITY": "رأس المال الأساسي",
  "TRADING GATEWAY": "بوابة التداول",
  "ORBIT-ME AI": "ذكاء أوربيت الاصطناعي",
  "MEMO-TECH": "تقنيات ميمو",
  "MEMOBOT VAULT": "خزينة ميموبوت المشفرة",
  "MEMOBOT VAULT™": "خزينة ميموبوت المشفرة™",
  "MEMO BUSINESS CLUB": "نادي ميمو للأعمال",
  "MEMO BUSINESS CLUB™": "نادي ميمو للأعمال™",
  "SYSTEM CONTROLS": "أنظمة التحكم",
  "DASHBOARD": "لوحة التحكم",
  "DECISION ENGINE": "محرك القرار",
  "STRATEGIES": "الاستراتيجيات",
  "RISK MANAGER": "إدارة المخاطر",
  "MARKET OVERVIEW": "نظرة عامة على السوق",
  "MARKET INTEL": "معلومات وتحليلات السوق",
  "INDIVIDUAL TRADE": "تداول فردي",
  "PAPER TRADING": "تداول تجريبي",
  "MEMOBOT AI": "ذكاء ميموبوت الاصطناعي",
  "HIGHTECHEYE": "العين التقنية للمراقبة",
  "SETTINGS": "الإعدادات",
  "SYSTEM SETTINGS": "إعدادات النظام",

  // --- Engine Names ---
  "ENG-001": "محرك-٠٠١",
  "ENG-002": "محرك-٠٠٢",
  "ENG-003": "محرك-٠٠٣",
  "ENG-004": "محرك-٠٠٤",
  "ENG-005": "محرك-٠٠٥",
  "ENG-006": "محرك-٠٠٦",
  "ENG-007": "محرك-٠٠٧",
  "ENG-008": "محرك-٠٠٨",
  "ENG-009": "محرك-٠٠٩",
  "ENG-010": "محرك-٠١٠",
  "MEMOCODEX": "ميموكوديكس",
  "MEMOBOT": "ميموبوت",
  "FX-PRO": "إف إكس برو",
  "REGULUS": "ريجولوس (قلب الأسد)",
  "SIRIUS": "سيريوس (الشعرى اليمانية)",
  "CANOPUS": "كانوبوس (سهيل)",
  "POLARIS": "بولاريس (نجم القطب)",
  "BETELGEUSE": "بيتيلجوس (إبط الجوزاء)",
  "ARCTURUS": "أركتوروس (السماك الرامح)",
  "ALGOL": "رأس الغول",
  "NEXUS": "نيكسوس",
  "ALPHA CENTAURI": "رجل القنطور",
  "UY SCUTI": "يو واي سكوتي",
  "RIGEL": "ريجل (رجل الجوزاء)",
  "LAMOOR": "لامور",
  "LOOOL": "لووول",
  "OOOKA": "أوووكا",
  "CANOPUS (OOOKA)": "كانوبوس (أوووكا)",
  "RIGEL (LAMOOR)": "ريجل (لامور)",
  "SIRIUS (LOOOL)": "سيريوس (لووول)",
  "REGULUS ENGINE": "محرك ريجولوس",
  "SIRIUS ENGINE": "محرك سيريوس",
  "MEMOBOT PRIME": "ميموبوت الرئيسي",

  // --- Exchanges ---
  "BINANCE": "بينانس",
  "BYBIT": "باي بيت",
  "OKX": "أو كيه إكس",
  "KUCOIN": "كوكوين",
  "COINBASE": "كوين بيس",
  "KRAKEN": "كراكن",

  // --- Financial Terminology ---
  "ACCOUNT EQUITY": "صافي قيمة الحساب",
  "AVAILABLE USDT": "الرصيد المتاح (USDT)",
  "TOTAL TRADES": "إجمالي الصفقات",
  "EXECUTED TODAY": "تم تنفيذها اليوم",
  "WIN RATE INDEX": "مؤشر نسبة النجاح",
  "WIN RATE & TX": "نسبة النجاح والمعاملات",
  "EFFECTIVENESS": "الكفاءة",
  "TRANSACTIONS": "الصفقات",
  "TRANSACTION": "صفقة",
  "TX": "صفقة",
  "WR": "نسبة النجاح",
  "VOL": "الحجم",
  "BALANCE": "الرصيد",
  "EQUITY": "صافي القيمة",
  "P&L": "الأرباح والخسائر",
  "PNL": "الأرباح والخسائر",
  "NET P&L": "صافي الأرباح والخسائر",
  "UNREALIZED P&L": "الأرباح والخسائر غير المحققة",
  "REALIZED P&L": "الأرباح والخسائر المحققة",
  "24H NET PNL": "صافي الأرباح (٢٤ ساعة)",
  "24H PNL": "أرباح ٢٤ ساعة",
  "24H VOLUME": "حجم تداول ٢٤ ساعة",
  "TOP ALPHA": "الأعلى أداءً (ألفا)",
  "#1 TOP ALPHA": "المركز الأول - أعلى ألفا",
  "HIGH PNL": "ربحية عالية",
  "HIGH EFF": "كفاءة مرتفعة",
  "DRAWDOWN": "التراجع",
  "MAX DRAWDOWN": "أقصى تراجع",
  "DAILY DRAWDOWN": "التراجع اليومي",
  "MARGIN": "الهامش",
  "LEVERAGE": "الرافعة المالية",
  "SPOT": "تداول فوري",
  "FUTURES": "عقود آجلة",
  "SWAPS": "عقود مبادلة",
  "ORDER BOOK": "سجل الأوامر",
  "ORDERBOOK": "سجل الأوامر",
  "DEPTH": "العمق",
  "SPREAD": "الفارق السعري",
  "SLIPPAGE": "الانزلاق السعري",
  "LIQUIDITY": "السيولة",
  "VOLATILITY": "التقلب السعري",
  "BUY": "شراء",
  "SELL": "بيع",
  "HOLD": "احتفاظ",
  "LIMIT": "أمر محدد",
  "MARKET": "أمر بسعر السوق",
  "STOP LOSS": "وقف الخسارة",
  "TAKE PROFIT": "جني الأرباح",
  "PRICE": "السعر",
  "AMOUNT": "الكمية",
  "TOTAL": "الإجمالي",
  "FEE": "الرسوم",
  "FILLED": "منفذ بالكامل",
  "REJECTED": "مرفوض",
  "CANCELLED": "ملغي",
  "PENDING": "قيد الانتظار",
  "OPEN": "مفتوح",
  "CLOSED": "مغلق",
  "ACTIVE": "نشط",
  "INACTIVE": "غير نشط",
  "STANDBY": "استعداد",
  "OFFLINE": "غير متصل",
  "ONLINE": "متصل بالشبكة",
  "HALTED": "متوقف",
  "AUTO": "تلقائي",
  "MANUAL": "يدوي",
  "RANK": "الترتيب",
  "SCORE": "التقييم",
  "CONFIDENCE": "درجة الثقة",
  "PAIR": "زوج العملات",
  "ASSET": "الأصل المالي",
  "DATE": "التاريخ",
  "TIME": "الوقت",
  "SIDE": "الاتجاه",
  "TYPE": "النوع",
  "STATUS": "الحالة",
  "VALUE": "القيمة",
  "SIZE": "الحجم",
  "UPTIME": "وقت التشغيل",
  "VERSION": "الإصدار",
  "UTC TIME": "التوقيت العالمي الموحد",
  "UTC": "التوقيت العالمي",
  "MS": "مللي ثانية",
  "SEC": "ثانية",
  "MIN": "دقيقة",
  "HR": "ساعة",
  "HOURS": "ساعات",
  "DAYS": "أيام",

  // --- Settings & Tabs ---
  "GENERAL": "عام",
  "NOTIFICATIONS": "الإشعارات والتنبيهات",
  "SUBSCRIPTION & FEES": "الاشتراك والرسوم",
  "SUBSCRIPTION": "الاشتراك",
  "CANVAS VIEWPORT": "تحريك المنصة أفقياً",
  "LEFT WING (STABLE)": "الجناح الأيسر (عقد الاستقرار)",
  "CENTER UNIVERSE": "المركز الرئيسي (المحرك الكمي)",
  "RIGHT WING (ALPHA)": "الجناح الأيمن (عقد ألفا)",
  "Scroll to Left Wing": "الانتقال للجناح الأيسر",
  "Scroll to Right Wing": "الانتقال للجناح الأيمن",
  "WING_R // ALPHA NODES": "الجناح الأيمن // عقد عوائد ألفا",
  "ALPHA NODES": "عقد ألفا",
  "LMAX": "إل ماكس",
  "Toggle Language / تبديل اللغة": "تبديل اللغة / Toggle Language",
  "Logout / خروج": "تسجيل الخروج",
  "FEES": "الرسوم",
  "SOCIAL SUITE": "جناح التواصل الاجتماعي",
  "ADMIN HUB": "مركز الإدارة",

  // --- Shariah Terminology ---
  "HALAL": "حلال",
  "HARAM": "محرم",
  "PURIFIED": "مُطهر",
  "SHARIAH": "الشريعة الإسلامية",
  "ISLAMIC": "إسلامي",
  "ISLAMIC COMPLIANT": "متوافق مع الشريعة الإسلامية",
  "MEMOBOT™ FX-PRO ISLAMIC SHARIYAH COMPLIANCE CERTIFICATE": "شهادة التوافق الشرعي الإسلامي لمنصة ميموبوت™ إف إكس برو",
  "Compliance Rating: 100% ISLAMIC SPOT VERIFIED (0% SWAP, 0% RIBA)": "نسبة الامتثال: تداول فوري إسلامي موثق ١٠٠٪ (٠٪ سواب، ٠٪ ربا)",
  "ISLAMIC SCHOLAR BOARD DECLARATION": "إقرار الهيئة الشرعية للرقابة المالية",

  // --- Crypto Currencies ---
  "BTC": "بيتكوين",
  "ETH": "إيثريوم",
  "USDT": "تيذر",
  "USDC": "يو إس دي سي",
  "SOL": "سولانا",
  "BNB": "بي إن بي",
  "XRP": "ريبل",
  "ADA": "كاردانو",
  "AVAX": "أفالانش",
  "DOGE": "دوجكوين",
  "DOT": "بولكادوت",
  "NEAR": "نير",
  "SUI": "سوي",
  "LINK": "تشين لينك",
  "MATIC": "بوليجون",
  "POL": "بوليجون",
  "PEPE": "بيبي",
  "SHIB": "شيبا",
  "TON": "تون",
  "TRX": "ترون",
  "APT": "أبتوس",
  "LTC": "لايتكوين",
  "BCH": "بيتكوين كاش",
  "UNI": "يونيسواب",
  "ATOM": "كوزموس",
  "XLM": "ستيلر",
  "XMR": "مونيرو",
  "ETC": "إيثريوم كلاسيك",
  "FIL": "فايل كوين",
  "HBAR": "هيديرا",
  "KAS": "كاسبا",
  "ICP": "بروتوكول الإنترنت",
  "AAVE": "آفي",
  "MKR": "ميكر",
  "GRT": "ذا جراف",
  "FTM": "فانتوم",
  "ALGO": "ألجوراند",
  "INJ": "إنجكتيف",
  "TIA": "سيليستيا",
  "SEI": "سي",
  "RENDER": "ريندر",
  "RNDR": "ريندر",
  "FET": "فيتش",
  "WIF": "ويف",
  "BONK": "بونك",
  "FLOKI": "فلوكي",
  "NOTCOIN": "نوت كوين",
  "JUP": "جوبيتر",
  "PYTH": "بايث",
  "WLD": "وورلد كوين",
  "STRK": "ستارك نت",
  "ARB": "أربتروم",
  "OP": "أوبتيميزم",
  "XAU": "الذهب الفوري",
  "EUR": "اليورو",
  "GBP": "الجنيه الإسترليني",
  "USD": "الدولار الأمريكي",
  "SAR": "الريال السعودي",
  "AED": "الدرهم الإماراتي",

  // --- Pairs ---
  "BTC/USDT": "بيتكوين / تيذر",
  "ETH/USDT": "إيثريوم / تيذر",
  "SOL/USDT": "سولانا / تيذر",
  "BNB/USDT": "بي إن بي / تيذر",
  "XRP/USDT": "ريبل / تيذر",
  "ADA/USDT": "كاردانو / تيذر",
  "AVAX/USDT": "أفالانش / تيذر",
  "DOGE/USDT": "دوجكوين / تيذر",
  "DOT/USDT": "بولكادوت / تيذر",
  "NEAR/USDT": "نير / تيذر",
  "SUI/USDT": "سوي / تيذر",
  "LINK/USDT": "تشين لينك / تيذر",
  "MATIC/USDT": "بوليجون / تيذر",
  "POL/USDT": "بوليجون / تيذر",
  "PEPE/USDT": "بيبي / تيذر",
  "SHIB/USDT": "شيبا / تيذر",
  "TON/USDT": "تون / تيذر",
  "TRX/USDT": "ترون / تيذر",
  "APT/USDT": "أبتوس / تيذر",
  "LTC/USDT": "لايتكوين / تيذر",
  "BCH/USDT": "بيتكوين كاش / تيذر",
  "UNI/USDT": "يونيسواب / تيذر",
  "ATOM/USDT": "كوزموس / تيذر",
  "XLM/USDT": "ستيلر / تيذر",
  "XMR/USDT": "مونيرو / تيذر",
  "ETC/USDT": "إيثريوم كلاسيك / تيذر",
  "FIL/USDT": "فايل كوين / تيذر",
  "HBAR/USDT": "هيديرا / تيذر",
  "KAS/USDT": "كاسبا / تيذر",
  "ICP/USDT": "بروتوكول الإنترنت / تيذر",
  "AAVE/USDT": "آفي / تيذر",
  "MKR/USDT": "ميكر / تيذر",
  "GRT/USDT": "ذا جراف / تيذر",
  "FTM/USDT": "فانتوم / تيذر",
  "ALGO/USDT": "ألجوراند / تيذر",
  "INJ/USDT": "إنجكتيف / تيذر",
  "TIA/USDT": "سيليستيا / تيذر",
  "SEI/USDT": "سي / تيذر",
  "RENDER/USDT": "ريندر / تيذر",
  "RNDR/USDT": "ريندر / تيذر",
  "FET/USDT": "فيتش / تيذر",
  "WIF/USDT": "ويف / تيذر",
  "BONK/USDT": "بونك / تيذر",
  "FLOKI/USDT": "فلوكي / تيذر",
  "NOT/USDT": "نوت كوين / تيذر",
  "JUP/USDT": "جوبيتر / تيذر",
  "PYTH/USDT": "بايث / تيذر",
  "WLD/USDT": "وورلد كوين / تيذر",
  "STRK/USDT": "ستارك نت / تيذر",
  "ARB/USDT": "أربتروم / تيذر",
  "OP/USDT": "أوبتيميزم / تيذر",

  // --- Identity Matrix & Tier Architecture ---
  "IDENTITY MATRIX": "مصفوفة الهوية والتفويض",
  "DYNAMIC ROLE ROUTING": "التوجيه الديناميكي للأدوار",
  "MULTI-ENGINE PROVISIONING": "تخصيص الموارد متعدد المحركات",
  "AUTHENTICATION GATEWAY": "بوابة المصادقة الموحدة",
  "SELECT PROVISIONING TIER": "اختر فئة التخصيص والمستوى",
  "INDIVIDUAL SPACE": "المساحة الفردية",
  "INVESTORS SUITE": "جناح المستثمرين",
  "CORPORATE WL PORTAL": "بوابة الشركات (White-Label)",
  "INSTITUTIONAL DESK": "المكتب المؤسسي عالي التردد",
  "MICRO-CAPITAL SAFEGUARD": "حماية رأس المال الصغير",
  "PRO MULTI-ASSET MESH": "شبكة متعددة الأصول للمحترفين",
  "B2B MULTI-TENANT CONSOLE": "منصة إدارة مؤسسية متعددة الحسابات",
  "UNRESTRICTED QUANTUM PIPELINE": "خط تداول كمي غير مقيد فائق السرعة",
  "RESOURCE BOUND": "الحد الأقصى للموارد",
  "AUTH METHOD": "طريقة المصادقة",
  "TOKEN & SCOPE": "الرمز ونطاق الصلاحيات",
  "RISK CLAMP": "قيد إدارة المخاطر",
  "INTERFACE HUD": "واجهة الاستخدام",
  "DECRYPTED JWT MATRIX": "مصفوفة فك تشفير رمز الجلسة (JWT)",
  "SESSION TOKEN": "رمز الجلسة المشفر",
  "ISSUER (ISS)": "الجهة المصدرة",
  "SUBJECT (SUB)": "معرف المستخدم",
  "EXPIRATION (EXP)": "تاريخ انتهاء الصلاحية",
  "ISSUED AT (IAT)": "تاريخ الإصدار",
  "ASSIGNED SCOPES": "الصلاحيات والنطاقات الممنوحة",
  "TENANT ID": "معرف المؤسسة / الفرع",
  "MAX ENGINES": "الحد الأقصى للمحركات",
  "MAX STRATEGIES": "الحد الأقصى للاستراتيجيات",
  "WEBAUTHN / BIOMETRICS": "المصادقة البيومترية ومفتاح الأمان",
  "MULTI-FACTOR AUTH (TOTP)": "المصادقة متعددة العوامل (TOTP)",
  "ENTERPRISE SSO (SAML 2.0)": "تسجيل الدخول الموحد للمؤسسات (SAML 2.0)",
  "mTLS + HSM MULTI-SIG": "التشفير المتبادل mTLS والعزل العتادي",
  "VERIFY BIOMETRIC HANDSHAKE": "تأكيد المصادقة البيومترية",
  "VERIFY MFA CODE": "التحقق من رمز المصادقة الثنائية",
  "VERIFY SSO ASSERTION": "التحقق من تأكيد الدخول الموحد",
  "VERIFY mTLS CERTIFICATE": "التحقق من شهادة التشفير المتبادل",
  "QUICK SWITCH PROVISIONING": "التبديل الفوري لفئة التخصيص",
  "ACTIVE PROVISIONING PROFILE": "الملف النشط لتخصيص الموارد",
  "SWITCH TIER": "تغيير الفئة",
  "CURRENT TIER": "المستوى الحالي",
  "SESSION SCOPES": "نطاقات الجلسة",
  "HARDWARE ENCLAVE ACTIVE": "العزل العتادي الآمن مفعل",
  "ENFORCE 1.0% RISK CLAMP": "تطبيق حماية ١.٠٪ إجبارياً",
  "RAW TELEMETRY MESH": "شبكة القياس والبيانات اللحظية",
  "ZERO-THROTTLING ENABLED": "عدم وجود أي قيود خنق متاح",
  "AUDIT CHAIN SYNCED": "سلسلة التدقيق المشفرة متزامنة",

  // --- Pure Arabic High-Standard UI & Trading Terms ---
  "ACCESS ID (USERNAME)": "معرف الدخول (اسم المستخدم)",
  "SECURE PASSWORD KEY": "المفتاح السري المشفر",
  "INITIALIZE SECURE SESSION": "بدء الجلسة الآمنة المشفرة",
  "INITIALIZING...": "جاري التحقق وبدء الجلسة...",
  "AUTHENTICATING SECURE SESSION": "جاري المصادقة وربط الجلسة...",
  "SECURE CREDENTIAL SWAP COMPLETED": "تم تحديث بيانات الاعتماد المشفرة بنجاح",
  "RE-KEY TERMINAL PASSWORD": "إعادة تعيين كلمة المرور للمنصة",
  "NEW SECURE KEY": "المفتاح السري الجديد",
  "CONFIRM SECURE KEY": "تأكيد المفتاح السري الجديد",
  "UPDATE PASSWORD & LAUNCH": "تحديث كلمة المرور والدخول",
  "RETURN TO LOGIN": "العودة لشاشة الدخول",
  "SYSTEM POWER STATUS": "حالة طاقة النظام",
  "ACTIVE SPOT ALLOCATION": "توزيع التداول الفوري النشط",
  "RISK MANAGEMENT PARAMETERS": "معايير وإعدادات إدارة المخاطر",
  "INSTITUTIONAL LEDGER METRICS": "مؤشرات الدفتر المؤسسي",
  "REAL-TIME MARKET TELEMETRY": "بيانات ومؤشرات السوق اللحظية",
  "ORDER BOOK DEPTH SENSORS": "مستشعرات عمق سجل الأوامر",
  "SPOT COMPLIANCE AUDITS": "تدقيق الامتثال للتداول الفوري",
  "CROSS-EXCHANGE LIQUIDITY": "السيولة المشتركة بين المنصات",
  "INSTANT SETTLEMENT": "التقابض الفوري الحقيقي",
  "ZERO OVERNIGHT SWAP": "انعدام رسوم التبييت (السواب)",
  "ZERO LEVERAGE LOANS": "خلو تام من قروض الرافعة المالية",
  "ISLAMIC SPOT RATIO": "نسبة التداول الفوري الإسلامي",
  "AAOIFI COMPLIANT": "معتمد وفق معايير أيوفي الشرعية",
  "EXECUTION PIPELINE": "مسار تنفيذ الصفقات",
  "SUB-MILLISECOND ROUTING": "توجيه الأوامر بأجزاء من المللي ثانية",
  "CAPITAL SAFEGUARD ACTIVE": "حماية رأس المال مفعلة بنجاح",
  "MAX CAPITAL ALLOCATION": "الحد الأقصى لتخصيص رأس المال",
  "DAILY PERFORMANCE AUDIT": "تقرير التدقيق اليومي للأداء",
  "ALL ENGINES STATION": "محطة كافة المحركات",
  "ACTIVE STRATEGIES DECK": "لوحة الاستراتيجيات الفعالة",
  "VAULT ENCRYPTION": "تشفير الخزنة الرقمية",
  "SECURITY PROTOCOLS": "بروتوكولات الأمان والحماية",
  "AUDIT LOGS & TRACING": "سجلات التدقيق والتتبع التشفيري",
  "CORRELATION ID LINKED": "مرتبط بمعرف التتبع والارتباط",
  "LIVE POSITIONS MONITOR": "مراقب الصفقات الفورية المفتوحة",
  "PERFORMANCE METRICS": "مؤشرات الأداء والكفاءة",
  "EXECUTIVE BUSINESS CLUB": "نادي كبار المستثمرين والمؤسسات",
  "INSTITUTIONAL BILLING": "الفواتير والحسابات المؤسسية",
  "ADVANCED SYSTEM SETTINGS": "الإعدادات المتقدمة للمنظومة",
  "TELEGRAM MINI APP": "تطبيق تيليجرام المصغر",
  "LIVE ELEMENT MODIFIER": "أداة تعديل عناصر الواجهة الحية",
  "ACTIVATE LIVE MODIFIER": "تفعيل التعديل المرئي المباشر",
  "DEACTIVATE LIVE MODIFIER": "إلغاء التعديل المرئي",
  "EXPORT PDF AUDIT": "تصدير تقرير التدقيق (PDF)",
  "EXPORT EXCEL AUDIT": "تصدير تقرير التدقيق (Excel)",
  "EXPORT WORD AUDIT": "تصدير تقرير التدقيق (Word)",
  "ASSET PORTFOLIO": "محفظة الأصول الرقمية",
  "SECURE ORDER HUB": "مركز الأوامر المشفر",
  "CLUB": "نادي النخبة",
  "UTC TIME:": "التوقيت العالمي الموحد:",
  "VERSION:": "إصدار المنظومة:",
  "PORTFOLIO": "المحفظة الاستثمارية",
  "ORDERS": "سجل الأوامر",
  "ANALYTICS & INTELLIGENCE": "التحليلات والذكاء الكمي",
  "EXECUTIVE SUITE": "الجناح التنفيذي",
  "BILLING & TIERS": "الاشتراكات والفئات",
  "DISPATCH VIA EMAIL": "إرسال فوري عبر البريد الإلكتروني",

  // --- Shariah Bureau & Full Governance ---
  "SHARIYAH BUREAU & GOVERNANCE": "المكتب الشرعي والحوكمة",
  "AAOIFI Standard No. 21 & No. 59 Governance Deck • Real-Time Spot Handshake (Qabd) & Zero-Riba Audit": "حوكمة معايير أيوفي رقم 21 ورقم 59 • التقابض الفوري اللحظي وتدقيق انعدام الربا بالكامل",
  "RE-AUDIT SPOT": "إعادة تدقيق التداول الفوري",
  "DOWNLOAD FATWA CERTIFICATE": "تحميل شهادة الفتوى الشرعية",
  "⚡ COMMERCIAL DESK UNRESTRICTED MODE": "⚡ وضع المكتب التجاري غير المقيد",
  "COMMERCIAL DESK UNRESTRICTED MODE": "وضع المكتب التجاري غير المقيد",
  "System is running in standard commercial desk mode. Shariah Safeguard enforcement is currently in manual audit mode.": "يعمل النظام في وضع المكتب التجاري القياسي. إنفاذ الدرع الشرعي حالياً في وضع التدقيق اليدوي.",
  "AAOIFI SHARIAH STANDARD NO. 21 CERTIFIED": "معتمد وفق معيار أيوفي الشرعي رقم 21",
  "100% HALAL SPOT": "تداول فوري حلال 100%",
  "All trading routes strictly enforce 1:1 physical spot allocation (Qabd), zero overnight swap interest (Riba), and total elimination of derivative short selling.": "تلتزم جميع مسارات التداول بإنفاذ التخصيص الفوري الحقيقي 1:1 (التقابض الشرعي)، وانعدام فوائد التبييت (الربا)، والإلغاء التام للمبيعات على المكشوف والمشتقات.",
  "LAST VERIFIED:": "آخر تحقق:",
  "LAST VERIFIED": "آخر تحقق",
  "AUDIT SEAL:": "ختم التدقيق:",
  "AUDIT SEAL": "ختم التدقيق",
  "SHARIYAH SAFEGUARD:": "الدرع الشرعي:",
  "SHARIYAH SAFEGUARD": "الدرع الشرعي",
  "Enforced: Non-compliant routes hard-blocked": "مفعل: المسارات غير المتوافقة محظورة برمجياً",
  "Manual Audit Mode Active": "وضع التدقيق اليدوي نشط",
  "ZERO RIBA / NO SWAP": "صفر ربا / بدون تبييت",
  "0% Rollover fees or overnight financing interest charged on open spot positions.": "0% رسوم تبييت أو فوائد تمويل ليلي على المراكز الفورية المفتوحة.",
  "✓ 100% RIBA-FREE": "✓ 100% خالٍ من الربا",
  "100% RIBA-FREE": "100% خالٍ من الربا",
  "SPOT HANDSHAKE (QABD)": "التقابض الفوري (قبض حقيقي)",
  "1:1 PHYSICAL": "1:1 عيني حقيقي",
  "Immediate constructiveness and possession upon order fulfillment without synthetic delays.": "التقابض الفعلي والحيازة الفورية عند تنفيذ الأمر دون تأخير اصطناعي.",
  "✓ VERIFIED SPOT DELIVERED": "✓ تسليم فوري موثق",
  "VERIFIED SPOT DELIVERED": "تسليم فوري موثق",
  "ANTI-GHARAR SHIELD": "درع منع الغرر",
  "ACTIVE REJECTION": "رفض نشط للمحظورات",
  "Futures, options, un-backed short selling, and high-uncertainty contracts strictly blocked.": "حظر صارم للعقود الآجلة، الخيارات، البيع على المكشوف بدون تغطية، وعقود الغرر العالية.",
  "✓ ZERO UNCERTAINTY": "✓ انعدام تام للغرر",
  "ZERO UNCERTAINTY": "انعدام تام للغرر",
  "PURIFICATION LEDGER": "سجل التطهير المالي",
  "0.00% NON-HALAL": "0.00% غير متوافق",
  "Continuous screening of token revenues and debt ratios. Zero purification required.": "فحص مستمر لإيرادات العملات ونسب الديون. صفر تطهير مطلوب.",
  "✓ CLEAN CAPITAL": "✓ رأس مال نقي",
  "CLEAN CAPITAL": "رأس مال نقي",
  "APPROVED ASSET SHARIAH SCREENING MATRIX": "مصفوفة الفحص الشرعي للأصول المعتمدة",
  "AAOIFI FINANCIAL RATIO LIMITS: DEBT < 33% • CASH < 33% • IMPURE INCOME < 5%": "حدود نسب أيوفي المالية: الديون < 33% • النقدية < 33% • الدخل غير المتوافق < 5%",
  "ASSET & NAME": "الأصل المالي والاسم",
  "SHARIAH STATUS": "الحالة الشرعية",
  "DEBT RATIO (<33%)": "نسبة الديون (<33%)",
  "CASH RATIO (<33%)": "نسبة النقدية (<33%)",
  "IMPURE INC. (<5%)": "الدخل غير المتوافق (<5%)",
  "OVERNIGHT SWAP": "رسوم التبييت (السواب)",
  "FATWA REF": "مرجع الفتوى",
  "\"We hereby certify that MEMOBOT™ FX-Pro operates strictly as a 100% Halal Spot Execution Terminal. All leveraged derivatives, interest-based margin swaps, margin interest charges, and un-owned asset short selling are programmatically disabled when Shariyah Safeguard is active.\"": "\"نشهد بموجب هذا أن منصة ميموبوت™ إف إكس برو تعمل كمنصة تداول فوري حلال 100%. وجميع المشتقات ذات الرافعة المالية، ورسوم التبييت الربوية، وفوائد الهامش، والبيع على المكشوف للأصول غير المملوكة معطلة برمجياً تماماً عند تفعيل الدرع الشرعي.\"",
  "We hereby certify that MEMOBOT™ FX-Pro operates strictly as a 100% Halal Spot Execution Terminal. All leveraged derivatives, interest-based margin swaps, margin interest charges, and un-owned asset short selling are programmatically disabled when Shariyah Safeguard is active.": "نشهد بموجب هذا أن منصة ميموبوت™ إف إكس برو تعمل كمنصة تداول فوري حلال 100%. وجميع المشتقات ذات الرافعة المالية، ورسوم التبييت الربوية، وفوائد الهامش، والبيع على المكشوف للأصول غير المملوكة معطلة برمجياً تماماً عند تفعيل الدرع الشرعي.",
  "FATWA COUNCIL ID:": "رقم اعتماد المجلس الشرعي:",
  "FATWA COUNCIL ID": "رقم اعتماد المجلس الشرعي",
  "VERIFIED COMPLIANT": "معتمد ومطابق للشريعة",
  "EXECUTION ENGINE ENFORCEMENT RULES": "قواعد إنفاذ محرك التنفيذ الشرعي",
  "0% Overnight Swap Fee Enforcer": "إنفاذ انعدام رسوم التبييت (0% سواب)",
  "Instant Hand-to-Hand Handshake (Qabd)": "التقابض الفوري يداً بيد (القبض الشرعي)",
  "Futures / Options / Shorts Blocker": "حظر العقود الآجلة / الخيارات / البيع المكشوف",
  "SHARIYAH BUREAU SYSTEM NOTIFICATION": "إشعار منظومة المكتب الشرعي",
  "ACKNOWLEDGE": "تأكيد واستيعاب",
  "Shariyah Safeguard Protocol ENFORCED across all execution routes.": "تم إنفاذ بروتوكول الدرع الشرعي عبر جميع مسارات التنفيذ.",
  "Shariyah Safeguard Protocol set to MANUAL AUDIT MODE.": "تم ضبط بروتوكول الدرع الشرعي على وضع التدقيق اليدوي.",
  "Bitcoin": "بيتكوين",
  "Ethereum (Spot)": "إيثريوم (فوري)",
  "Solana": "سولانا",
  "BNB Chain Asset": "أصل سلسلة بينانس (BNB)",
  "Ripple Ledger": "دفتر أستاذ ريبل (XRP)",
  "PERMISSIBLE WITH PURIFICATION": "جائز مع التطهير",
  "PERMISSIBLE_WITH_PURIFICATION": "جائز مع التطهير",
  "NON COMPLIANT": "غير متوافق",
  "NON_COMPLIANT": "غير متوافق",
  "$0.00 (0% Rollover)": "$0.00 (0% تبييت)",

  // --- About MemoBot & System Topology ---
  "ABOUT MEMOBOT": "حول ميموبوت FX-PRO",
  "ABOUT MEMOBOT FX-PRO": "دليل ومنظومة ميموبوت FX-PRO المؤسسية",
  "QUANTUM ALGORITHMIC EXECUTION & ARCHITECTURE BLUEPRINT": "المخطط الهيكلي ومنظومة التداول الخوارزمي الكمي",
  "SYSTEM TOPOLOGY & ARCHITECTURE TREE": "شجرة الهيكلية المعمارية للمنظومة والواجهات والخوادم",
  "FRONT-END ARCHITECTURE": "هيكلية الواجهة الأمامية والتفاعل",
  "BACK-END & RUNTIME ENGINE": "محرك الخادم الخلفي والبيئة التشغيلية",
  "INTERACTIVE PAGE DIRECTORY & USER MANUAL": "دليل صفحات المنصة وشرح الاستخدام التفصيلي",
  "CORE CAPABILITIES & INSTITUTIONAL SPECIFICATIONS": "القدرات الفائقة والمواصفات المؤسسية للمنظومة",
  "HOW TO OPERATE": "طريقة الاستخدام والتنفيذ",
  "KEY CAPABILITIES": "أبرز الإمكانيات والوظائف",
  "PURPOSE & ROLE": "الغرض والدور التشغيلي",
  "SYSTEM SPECIFICATIONS": "المواصفات التقنية للمنظومة",
  "HIGH FREQUENCY EXECUTION": "تنفيذ عالي التردد فائق السرعة",
  "INSTANT RISK CLAMPING": "تثبيت فوري وحاسم للمخاطر",
  "SHARIAH COMPLIANCE ENGINE": "محرك الامتثال الشرعي الصارم",
  "MULTI-TENANT ISOLATION": "عزل تام للحسابات والمؤسسات",
  "STATE FLOW ARCHITECTURE": "مسار تدفق البيانات والحالة",
  "DATA PIPELINE FLOW": "مسار نقل ومعالجة البيانات",
  "CLICK TO EXPAND DETAILS": "اضغط لعرض التفاصيل الكاملة",
  "COLLAPSE DETAILS": "طي التفاصيل",
  "EXPLORE ARCHITECTURE NODE": "استكشاف العقدة الهيكلية",
  "ALL PLATFORM PAGES": "كافة صفحات المنصة",

  // --- 9 Execution Stages ---
  "TAILOR THE 9 EXECUTION STAGES": "تخصيص مراحل التنفيذ الـ 9",
  "Toggle stage nodes ON/OFF": "تبديل تشغيل/إيقاف عقد المراحل",
  "SELECT ALL 9 STAGES": "تحديد كافة المراحل الـ 9",
  "SIGNAL DETECTION": "اكتشاف الإشارة",
  "QUANTUM ALPHA SCORING": "تقييم ألفا الكمي",
  "RISK PROTOCOL VALIDATION": "التحقق من بروتوكول المخاطر",
  "SHARIAH COMPLIANCE AUDIT": "تدقيق الامتثال الشرعي",
  "ORDERBOOK DEPTH ROUTING": "توجيه عمق سجل الأوامر",
  "CRYPTOGRAPHIC SIGNING": "التوقيع التشفيري الرقمي",
  "EXCHANGE FIX DISPATCH": "إرسال أمر التبادل عبر بروتوكول FIX",
  "SUB-MS SPOT FILL": "تنفيذ فوري فائق السرعة",
  "IMMUTABLE LEDGER RECORDED": "توثيق ثابت في السجل المحصن",

  // --- Login & Identity Gateway ---
  "IDENTITY MATRIX & AUTHENTICATION GATEWAY": "مصفوفة الهوية وبوابة المصادقة الآمنة",

  // --- Market Intelligence Terminal ---
  "MARKET INTELLIGENCE TERMINAL": "منصة استخبارات وتحليل السوق المالي",
  "50 MONITORED CURRENCIES": "50 أصل خاضع للمراقبة",
  "MONITORED ASSETS": "الأصول المراقبة",
  "CURRENCIES": "عملات",
  "TOP MARKET CAP INDEX": "مؤشر أعلى قيمة سوقية",
  "APPROVED SPOT UTILITY": "أصول فورية معتمدة ومفحوصة",
  "RISK / NON-COMPLIANT": "أصول عالية المخاطر / غير متوافقة",
  "FLAGGED GHARAR / MEME": "محظورة بسبب الغرر والمضاربة المفرطة",
  "BTC BUY PRESSURE": "قوة شراء البيتكوين",
  "ORDER BOOK SENSOR ACTIVE": "مجسات سجل الأوامر نشطة",
  "AES-256 ENCRYPTED TELEMETRY": "قياس مشفر بتقنية AES-256",
  "Search top 50 currencies (e.g., BTC, Solana, L2)...": "البحث في أكبر 50 أصل (مثل BTC، Solana، L2)...",
  "ALL (50)": "الكل (50)",
  "TOP 10": "أعلى 10 أصول",
  "HIGH VOLATILITY": "تقلب سعري مرتفع",
  "FLAGGED / RISKY": "محظور / عالي المخاطر",
  "LIVE PRICE": "السعر الفوري",
  "24H CHANGE": "التغير (24 ساعة)",
  "CLASSIFICATION": "التصنيف",
  "COMPLIANCE AUDIT": "التدقيق الشرعي",
  "WINGS REAL-TIME DEPTH SENSORS (BTC/USDT HIGH FREQUENCY)": "مجسات العمق اللحظي WINGS (التردد العالي لزوج BTC/USDT)",
  "LIVE DEPTH FEED ACTIVE": "بث العمق المباشر نشط",
  "BUY PRESSURE:": "ضغط الشراء:",
  "SELL PRESSURE:": "ضغط البيع:",
  "BIDS (BUY DEPTH)": "عروض الشراء (BIDS)",
  "ASKS (SELL DEPTH)": "طلبات البيع (ASKS)",
  "REAL-TIME SOCKET SYNC: 18ms": "مزامنة لحظية للشبكة: 18 مللي ثانية",

  // --- HighTechEye Analytics Cockpit ---
  "NONEORDINARY // SUPER SYSTEM COCKPIT": "مقصورة القياس الفائقة // NONEORDINARY",
  "HighTechEye — High-grade telemetry monitoring, predictive AI, and autonomous repair.": "HighTechEye — مراقبة قياس عن بُعد فائقة الدقة، وذكاء اصطناعي تنبؤي، وإصلاح ذاتي مستقل.",
  "NETWORK: MALINET-V4": "الشبكة: MALINET-V4",
  "PROTOCOL: ISLAMIC SPOT 1X": "البروتوكول: فوري إسلامي 1X",
  "LATENCY:": "زمن الاستجابة:",
  "SECURITY CERTIFICATION & AUDIT": "شهادة الأمان والتدقيق المؤسسي",
  "Engine Heartbeat:": "نبض المحرك:",
  "Cryptographic Hash:": "التوقيع التشفيري:",
  "Compliance Alerts:": "تنبيهات الامتثال:",
  "Corridor Health:": "صحة الممرات:",
  "Banking Trust Level:": "مستوى الثقة المصرفية:",
  "HighTechEye Autopilot Telemetry": "القياس الذاتي للطيار الآلي HighTechEye",
  "NONEORDINARY Super System · Real-time distributed tracing, zero-loss routing, and AAOIFI Shariah Spot governance verified continuous.": "نظام NONEORDINARY الفائق · تتبع موزع لحظي، توجيه بدون خسارة، وحوكمة فورية معتمدة وفقاً لمعايير أيوفي (AAOIFI).",

  // --- Portfolio & Individual Terminal ---
  "INDIVIDUAL TRADING TERMINAL": "منصة التداول الفردي المؤسسي",
  "Institutional spot trading execution, high-precision ticker, and physical spot ledger audit.": "تنفيذ فوري مؤسسي، ومؤشر أسعار فائق الدقة، وتدقيق دفتر الأستاذ الفعلي الحقيقي.",
  "EMERGENCY SWITCH": "مفتاح الطوارئ",
  "EMERGENCY HALTED": "متوقف بحالة طوارئ",
  "PAIR:": "الزوج:",
  "INDEX PRICE": "سعر المؤشر",
  "24H HIGH / LOW": "أعلى / أدنى (24 ساعة)",
  "TECHNICAL CONSENSUS": "الإجماع الفني",
  "ISLAMIC SPOT STATUS": "حالة التداول الفوري الإسلامي",
  "1:1 PHYSICAL APPROVED": "معتمد تداول فعلي حقيقي 1:1",
  "PHYSICAL SPOT LEDGER & RESERVE AUDIT": "دفتر أستاذ التداول الفعلي الحقيقي وتدقيق الاحتياطي",
  "100% COVERAGE": "تغطية 100%",
  "FIAT VALUE": "القيمة النقدية",
  "Physical Spot": "تداول فوري حقيقي",

  // --- Secure Vault & Diagnostics ---
  "SYSTEM AUDITING & FREEDOM MATRIX": "مصفوفة التدقيق والحرية المطلقة",
  "TESTING ALL ENTRIES...": "جارِ اختبار كافة الاتصالات...",
  "AI CO-PILOT DECK RECOMMENDATIONS": "توصيات باقة الذكاء الاصطناعي المساند",
  "TO PROTECT YOUR DECISIONS AGAINST SINGLE-MODEL BIAS, WE RECOMMEND CONFIGURING 3 ELITE REASONING AI ENGINES IN CONJUNCTION WITH GEMINI:": "لحماية قراراتك من انحياز النموذج الفردي، نوصي بربط 3 محركات ذكاء اصطناعي فائقة الاستدلال بالتوازي مع Gemini:",
  "Industry-standard for low-latency news parsing, multilingual audit reporting, and rapid signal extraction.": "المعيار الصناعي لتحليل الأخبار الفوري، وتقارير التدقيق متعددة اللغات، واستخراج الإشارات فائق السرعة.",
  "Unmatched logical reasoning for strategy verification, strict rule-compliance checking, and advanced code executions.": "استدلال منطقي استثنائي للتحقق من الاستراتيجيات، وفحص الامتثال الصارم للقواعد، وتحليل الكود البرمجي.",
  "Extremely fast, open-weights reasoning model for high-frequency mathematical evaluations and strict trade-log validation.": "نموذج استدلال فائق السرعة للتقييم الرياضي عالي التردد والتحقق الصارم من سجلات التداول.",

  // --- Billing & Subscription ---
  "Institutional billing management, performance-based fee tracking, and license orchestration.": "إدارة الفواتير المؤسسية، وتتبع رسوم الأداء القائمة على النتائج، وإدارة تراخيص المنصة.",
  "ACTIVE LICENSE PLAN": "خطة الترخيص النشطة",
  "Proprietary Institutional": "الترخيص المؤسسي الاحترافي",
  "NEXT RENEWAL:": "موعد التجديد القادم:",
  "BILLING CYCLE:": "دورة الفوترة:",
  "MONTHLY (INSTITUTIONAL)": "شهرياً (مؤسسي)",
  "INCLUDED CAPABILITIES:": "الإمكانيات والخدمات المشمولة:",
  "Unlimited Engine Execution": "تنفيذ غير محدود للمحركات",
  "Priority HFT WebSocket Gateway": "بوابة ويب سوكت ذات أولوية فائقة السرعة",
  "Shariah Compliance Auditor Pro": "المدقق الشرعي الاحترافي المعتمد",
  "Full AI Co-Pilot Suite": "باقة الذكاء الاصطناعي المساندة الكاملة",
  "Multi-Exchange Connectivity": "ربط متعدد لكافة المنصات",
  "INVOICE & PERFORMANCE FEE LEDGER": "سجل الفواتير ورسوم الأداء",
  "EXPORT DATA (.CSV)": "تصدير البيانات (.CSV)",
  "INVOICE ID": "رقم الفاتورة",
  "FEE TYPE": "نوع الرسم",
  "AMOUNT (USDT)": "المبلغ (USDT)",
  "SUCCESS_FEE": "رسوم نجاح",
  "PAID": "مدفوع",
  "SUCCESS FEES ARE COMPUTED BASED ON NET NEW PNL AUDITED ON-CHAIN.": "يتم احتساب رسوم النجاح بناءً على صافي الأرباح الجديدة المحققة والمدققة.",
  "UPDATE PAYMENT METHOD": "تحديث طريقة الدفع",

  // --- Business Club & Syndicate ---
  "VIP PRIVATE NETWORK": "شبكة كبار الشخصيات الخاصة",
  "Exclusive institutional syndicate network for accredited partners, family offices, and quant prop traders operating under strict Capital Protection & AAOIFI Shariah governance.": "شبكة ائتلاف مؤسسية حصرية للشركاء المعتمدين والمكاتب العائلية والمتداولين الكميين تحت مظلة حماية رأس المال وحوكمة أيوفي الشرعية.",
  "YOUR CLUB STATUS": "حالة عضويتك في النادي",
  "VIP PRO SPACE ACTIVE": "مساحة المحترفين (VIP) نشطة",
  "VIP CONCIERGE": "خدمة كبار الشخصيات المباشرة",

  // --- Audit & Compliance Hub ---
  "INSTITUTIONAL AUDITING HUB": "مركز التدقيق المؤسسي والتوثيق",
  "100% VERIFIED SPOT": "تداول فوري موثق 100%",
  "Deterministic execution passports, multi-stage trade verification, and holographic audit dossiers.": "جوازات تنفيذ حتمية، وتوثيق صفقات متعدد المراحل، وملفات تدقيق هولوغرافية شاملة.",
  "VERIFICATION LEDGER:": "سجل التوثيق:",
  "SHA-256 PROVEN": "مثبت بتشفير SHA-256"
};

// Eastern Arabic-Indic Digits Map
export const DIGIT_MAP: Record<string, string> = {
  "0": "٠",
  "1": "١",
  "2": "٢",
  "3": "٣",
  "4": "٤",
  "5": "٥",
  "6": "٦",
  "7": "٧",
  "8": "٨",
  "9": "٩",
};

export const REVERSE_DIGIT_MAP: Record<string, string> = {
  "٠": "0",
  "١": "1",
  "٢": "2",
  "٣": "3",
  "٤": "4",
  "٥": "5",
  "٦": "6",
  "٧": "7",
  "٨": "8",
  "٩": "9",
};

export function convertDigitsToArabic(str: string): string {
  return str.replace(/[0-9]/g, (d) => DIGIT_MAP[d] || d);
}

export function convertDigitsToEnglish(str: string): string {
  return str.replace(/[٠-٩]/g, (d) => REVERSE_DIGIT_MAP[d] || d);
}

// Master translation from English to Real Arabic
export function transformToLiteralArabic(text: string): string {
  if (!text || typeof text !== "string") return text;
  const trimmed = text.trim();
  if (!trimmed) return text;

  // 1. Direct exact match in dictionary
  if (ARABIC_DICTIONARY[trimmed]) {
    return convertDigitsToArabic(ARABIC_DICTIONARY[trimmed]);
  }

  // 1b. Normalized whitespace match
  const normalizedSpaces = trimmed.replace(/\s+/g, " ");
  if (ARABIC_DICTIONARY[normalizedSpaces]) {
    return convertDigitsToArabic(ARABIC_DICTIONARY[normalizedSpaces]);
  }

  // 1c. Case-insensitive direct match
  const upperTrimmed = normalizedSpaces.toUpperCase();
  for (const key in ARABIC_DICTIONARY) {
    if (key.toUpperCase() === upperTrimmed) {
      return convertDigitsToArabic(ARABIC_DICTIONARY[key]);
    }
  }

  // 1d. Quotes stripped match (e.g. `"We hereby certify..."` or `'text'`)
  const quoteStripped = trimmed.replace(/^["'“”«»]+|["'“”«»]+$/g, "").trim();
  if (quoteStripped && quoteStripped !== trimmed) {
    const quoteStrippedNorm = quoteStripped.replace(/\s+/g, " ");
    for (const key in ARABIC_DICTIONARY) {
      if (key.toUpperCase() === quoteStrippedNorm.toUpperCase()) {
        return `"${convertDigitsToArabic(ARABIC_DICTIONARY[key])}"`;
      }
    }
  }

  // 1e. Punctuation-stripped match (e.g. "TIME:", "STATUS.", "✓ 100% RIBA-FREE", "⚡ COMMERCIAL DESK...")
  const prefixMatch = trimmed.match(/^([✓★⚡🕌•\-\s]+)/);
  const suffixMatch = trimmed.match(/([:.!?•\-\s]+)$/);
  const coreClean = trimmed
    .replace(/^[✓★⚡🕌•\-\s]+/, "")
    .replace(/[:.!?•\-\s]+$/, "")
    .trim()
    .replace(/\s+/g, " ");

  if (coreClean && coreClean.length > 1) {
    const coreUpper = coreClean.toUpperCase();
    for (const key in ARABIC_DICTIONARY) {
      if (key.toUpperCase() === coreUpper) {
        const prefix = prefixMatch ? prefixMatch[0] : "";
        const suffix = suffixMatch ? suffixMatch[0] : "";
        const arSuffix = suffix.replace(/:/g, ": ").replace(/\?/g, "؟").replace(/!/g, "!");
        return prefix + convertDigitsToArabic(ARABIC_DICTIONARY[key]) + arSuffix;
      }
    }
  }

  // 2. Segment/sentence-level translation if text contains delimiters
  const delimiters = ["\n", " • ", " &bull; ", " | ", " // "];
  for (const delim of delimiters) {
    if (trimmed.includes(delim)) {
      const parts = trimmed.split(delim);
      const translatedParts = parts.map((p) => transformToLiteralArabic(p));
      const hasArabic = translatedParts.some((p) => /[\u0600-\u06FF]/.test(p));
      if (hasArabic) {
        return translatedParts.join(delim);
      }
    }
  }

  // 3. Multi-sentence translation (split by `. `)
  if (trimmed.includes(". ")) {
    const sentences = trimmed.split(/(?<=\.)\s+/);
    if (sentences.length > 1) {
      const translatedSentences = sentences.map((s) => transformToLiteralArabic(s));
      const hasArabic = translatedSentences.some((s) => /[\u0600-\u06FF]/.test(s));
      if (hasArabic) {
        return translatedSentences.join(" ");
      }
    }
  }

  // 4. Multi-word phrase search for SHORT labels/badges (only if word count <= 4)
  const words = trimmed.split(/\s+/);
  if (words.length <= 4) {
    for (const key in ARABIC_DICTIONARY) {
      if (key.length >= 3 && key.toUpperCase() === upperTrimmed) {
        return convertDigitsToArabic(ARABIC_DICTIONARY[key]);
      }
    }
  }

  // 5. If already contains Arabic characters, ensure numbers and symbols are formatted
  if (/[\u0600-\u06FF]/.test(text)) {
    return convertDigitsToArabic(text).replace(/%/g, "٪").replace(/\?/g, "؟").replace(/;/g, "؛");
  }

  // Return unchanged original text rather than butchering with partial single-word injections
  return text;
}

// Reverse Translation (Arabic -> English)
export const ENGLISH_DICTIONARY: Record<string, string> = Object.entries(ARABIC_DICTIONARY).reduce(
  (acc, [en, ar]) => {
    acc[ar.trim()] = en.trim();
    return acc;
  },
  {} as Record<string, string>
);

export function transformArabicToEnglish(text: string): string {
  if (!text || typeof text !== "string") return text;
  const trimmed = text.trim();
  if (!trimmed) return text;

  if (ENGLISH_DICTIONARY[trimmed]) {
    return convertDigitsToEnglish(ENGLISH_DICTIONARY[trimmed]);
  }

  let result = text;
  const arabicKeysByLength = Object.keys(ENGLISH_DICTIONARY).sort((a, b) => b.length - a.length);

  for (const arKey of arabicKeysByLength) {
    if (arKey.length < 2) continue;
    if (result.includes(arKey)) {
      result = result.split(arKey).join(ENGLISH_DICTIONARY[arKey]);
    }
  }

  result = convertDigitsToEnglish(result);
  result = result.replace(/٪/g, "%").replace(/؟/g, "?").replace(/؛/g, ";");

  return result;
}

// Smart translation suggestion helper
export function suggestArabicTranslation(text: string): string {
  if (!text || typeof text !== "string") return "";
  const trimmed = text.trim();
  if (!trimmed) return "";

  // 1. Direct or phrase match
  const direct = transformToLiteralArabic(trimmed);
  if (/[\u0600-\u06FF]/.test(direct)) {
    return direct;
  }

  // 2. Word-by-word token translation
  const words = trimmed.split(/\s+/);
  const translatedWords = words.map((w) => {
    const cleanWord = w.replace(/^[^\w\d]+|[^\w\d]+$/g, "");
    if (!cleanWord) return w;
    const arWord = transformToLiteralArabic(cleanWord);
    if (/[\u0600-\u06FF]/.test(arWord)) {
      return w.replace(cleanWord, arWord);
    }
    return w;
  });

  const joined = translatedWords.join(" ");
  if (/[\u0600-\u06FF]/.test(joined)) {
    return joined;
  }

  return "";
}

// ==========================================
// PERMANENT CUSTOM TRANSLATIONS PERSISTENCE
// ==========================================
const CUSTOM_TRANSLATIONS_STORAGE_KEY = "memobot_custom_permanent_translations";

export function loadCustomPermanentTranslations(): Record<string, string> {
  try {
    const raw = localStorage.getItem(CUSTOM_TRANSLATIONS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (typeof parsed === "object" && parsed !== null) {
        // Merge into active in-memory dictionary
        Object.assign(ARABIC_DICTIONARY, parsed);
        for (const [k, v] of Object.entries(parsed)) {
          if (typeof v === "string") {
            ENGLISH_DICTIONARY[v.trim()] = k.trim();
          }
        }
        return parsed;
      }
    }
  } catch (e) {
    console.warn("Failed to load custom translations from storage:", e);
  }
  return {};
}

export function savePermanentTranslation(englishText: string, arabicTranslation: string): boolean {
  if (!englishText || !arabicTranslation) return false;
  const cleanEn = englishText.trim();
  const cleanAr = arabicTranslation.trim();
  if (!cleanEn || !cleanAr) return false;

  try {
    const current = loadCustomPermanentTranslations();
    current[cleanEn] = cleanAr;
    localStorage.setItem(CUSTOM_TRANSLATIONS_STORAGE_KEY, JSON.stringify(current));
    
    // Update live memory dictionaries immediately
    ARABIC_DICTIONARY[cleanEn] = cleanAr;
    ENGLISH_DICTIONARY[cleanAr] = cleanEn;
    
    // Dispatch global event for live rerender / translation trigger
    window.dispatchEvent(new CustomEvent("memobot:translation_updated", {
      detail: { english: cleanEn, arabic: cleanAr }
    }));
    return true;
  } catch (e) {
    console.error("Failed to save permanent translation:", e);
    return false;
  }
}

export function removePermanentTranslation(englishText: string): boolean {
  if (!englishText) return false;
  const cleanEn = englishText.trim();
  try {
    const current = loadCustomPermanentTranslations();
    if (current[cleanEn]) {
      const arVal = current[cleanEn];
      delete current[cleanEn];
      localStorage.setItem(CUSTOM_TRANSLATIONS_STORAGE_KEY, JSON.stringify(current));
      delete ARABIC_DICTIONARY[cleanEn];
      if (arVal) delete ENGLISH_DICTIONARY[arVal.trim()];
      
      window.dispatchEvent(new CustomEvent("memobot:translation_updated", {
        detail: { removed: cleanEn }
      }));
      return true;
    }
  } catch (e) {
    console.error("Failed to remove translation:", e);
  }
  return false;
}

// Auto-load custom translations on startup
if (typeof window !== "undefined") {
  loadCustomPermanentTranslations();
}

