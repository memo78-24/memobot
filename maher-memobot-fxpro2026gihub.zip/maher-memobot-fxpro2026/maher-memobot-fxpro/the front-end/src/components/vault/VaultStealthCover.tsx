import React, { useState, useEffect } from "react";
import { VaultSecurityManager, DecoyTheme } from "../../services/vaultSecurity";
import { Shield, Key, Eye, EyeOff, Lock, AlertCircle, Cpu, Radio, Terminal, Zap } from "lucide-react";

interface VaultStealthCoverProps {
  decoyTheme: DecoyTheme;
  onUnlockSuccess: (passcode: string) => boolean;
}

export const VaultStealthCover: React.FC<VaultStealthCoverProps> = ({
  decoyTheme,
  onUnlockSuccess,
}) => {
  const [passcode, setPasscode] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isUnlocking, setIsUnlocking] = useState(false);
  const [matrixText, setMatrixText] = useState<string[]>([]);

  // Simulated Matrix Stream for Decoy Screen
  useEffect(() => {
    if (decoyTheme !== "matrix") return;
    const interval = setInterval(() => {
      const hex = Array.from({ length: 8 }, () => Math.floor(Math.random() * 256).toString(16).padStart(2, "0")).join(" ");
      const line = `0x${Math.floor(Math.random() * 65535).toString(16).toUpperCase()}  [NET_PACKET_${Math.floor(Math.random() * 999)}]  ${hex}  SYNC_OK`;
      setMatrixText(prev => [line, ...prev.slice(0, 11)]);
    }, 400);
    return () => clearInterval(interval);
  }, [decoyTheme]);

  const handleUnlock = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setErrorMsg(null);
    setIsUnlocking(true);

    setTimeout(() => {
      const isValid = onUnlockSuccess(passcode);
      if (!isValid) {
        setErrorMsg("INVALID PASSCODE / MATRIX KEY. ACCESS DENIED.");
        setIsUnlocking(false);
      }
    }, 300);
  };

  return (
    <div className="relative min-h-[520px] w-full bg-[#030406] border border-[#FA1F4E]/30 rounded-lg p-6 flex flex-col justify-between overflow-hidden shadow-[0_0_30px_rgba(250,31,78,0.15)] font-mono text-xs">
      {/* Background Decoy Layer */}
      {decoyTheme === "matrix" && (
        <div className="absolute inset-0 pointer-events-none p-4 opacity-25 overflow-hidden font-mono text-[10px] text-[#00f2ff] space-y-1">
          <div className="text-[#FA1F4E] font-bold mb-2 uppercase tracking-widest">
            *** MEMOBOT DECOY STEALTH MATRIX STREAM ACTIVE ***
          </div>
          {matrixText.map((line, idx) => (
            <div key={idx} className="truncate">{line}</div>
          ))}
        </div>
      )}

      {decoyTheme === "maintenance" && (
        <div className="absolute inset-0 pointer-events-none flex flex-col items-center justify-center p-8 opacity-20 text-center space-y-3">
          <Cpu className="w-16 h-16 text-[#00f2ff] animate-pulse" />
          <h3 className="text-xl font-aquire text-white tracking-widest">SYSTEM CHANNEL OFFLINE</h3>
          <p className="text-[#8a8d9a] max-w-md">HIGH FREQUENCY ROUTER DIAGNOSTICS IN PROGRESS. ALL CREDS MASKED.</p>
        </div>
      )}

      {decoyTheme === "ticker" && (
        <div className="absolute inset-0 pointer-events-none p-6 opacity-20 grid grid-cols-2 gap-4">
          <div className="border border-[#11131c] p-3 rounded bg-black/40">
            <div className="text-white font-bold">BTC/USDT INDEX</div>
            <div className="text-[#00e676] font-bold text-lg mt-1">$68,420.50 +2.4%</div>
            <div className="h-12 bg-emerald-500/10 rounded mt-2 animate-pulse" />
          </div>
          <div className="border border-[#11131c] p-3 rounded bg-black/40">
            <div className="text-white font-bold">ETH/USDT INDEX</div>
            <div className="text-[#00e676] font-bold text-lg mt-1">$3,540.10 +1.8%</div>
            <div className="h-12 bg-emerald-500/10 rounded mt-2 animate-pulse" />
          </div>
        </div>
      )}

      {/* Top Banner Status */}
      <div className="relative z-10 flex items-center justify-between border-b border-[#161822] pb-3">
        <div className="flex items-center gap-2">
          <div className="p-1 bg-[#FA1F4E]/20 rounded border border-[#FA1F4E]/40">
            <Lock className="w-4 h-4 text-[#FA1F4E]" />
          </div>
          <div>
            <span className="text-white font-bold uppercase tracking-wider text-[11px] flex items-center gap-1">
              MEMOBOT VAULT<span className="text-[9px] font-mono text-[#FA1F4E] font-black -mt-1">™</span> STEALTH MASK
            </span>
            <span className="text-[9px] text-[#FA1F4E] block -mt-0.5">PROTECTED BY YOUR CUSTOM PASSCODE</span>
          </div>
        </div>

        <div className="px-2.5 py-1 bg-[#FA1F4E]/10 border border-[#FA1F4E]/40 text-[#FA1F4E] rounded text-[9px] font-extrabold flex items-center gap-1.5 uppercase">
          <span className="w-2 h-2 rounded-full bg-[#FA1F4E] animate-ping" />
          VAULT LOCKED
        </div>
      </div>

      {/* Central Unlock Interface */}
      <div className="relative z-10 max-w-md mx-auto w-full bg-[#0a0c10]/90 border border-[#1e2230] p-6 rounded-lg space-y-4 my-auto shadow-2xl backdrop-blur-md">
        <div className="text-center space-y-1">
          <div className="mx-auto w-10 h-10 bg-[#FA1F4E]/10 border border-[#FA1F4E]/30 rounded-full flex items-center justify-center">
            <Key className="w-5 h-5 text-[#FA1F4E]" />
          </div>
          <h3 className="text-sm font-extrabold text-white uppercase tracking-wider pt-1">
            ENTER VAULT PASSCODE
          </h3>
          <p className="text-[10px] text-[#8a8d9a]">
            Enter your custom security key or matrix combination to unmask API credentials.
          </p>
        </div>

        <form onSubmit={handleUnlock} className="space-y-3">
          <div className="relative">
            <input
              type={showPass ? "text" : "password"}
              value={passcode}
              onChange={(e) => setPasscode(e.target.value)}
              placeholder="Enter passcode / combination..."
              className="w-full bg-[#040507] border border-[#1a1d26] hover:border-[#FA1F4E] focus:border-[#FA1F4E] text-white px-3 py-2.5 rounded text-sm outline-none tracking-widest font-mono text-center pr-10"
              autoFocus
            />
            <button
              type="button"
              onClick={() => setShowPass(!showPass)}
              className="absolute right-3 top-3 text-[#8a8d9a] hover:text-white"
            >
              {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>

          {errorMsg && (
            <div className="p-2 bg-[#ef4444]/10 border border-[#ef4444]/40 text-[#ef4444] rounded text-[9px] font-bold flex items-center gap-1.5">
              <AlertCircle className="w-3.5 h-3.5 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          <button
            type="submit"
            disabled={isUnlocking || !passcode.trim()}
            className="w-full py-2.5 bg-[#FA1F4E] hover:bg-[#d9143e] text-white rounded font-extrabold text-xs uppercase tracking-wider transition-all shadow-[0_0_15px_rgba(250,31,78,0.3)] flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {isUnlocking ? (
              <>
                <Zap className="w-4 h-4 animate-spin" />
                UNMASKING CREDS...
              </>
            ) : (
              <>
                <Shield className="w-4 h-4" />
                UNMASK & ACCESS VAULT
              </>
            )}
          </button>
        </form>

        <p className="text-[9px] text-[#6b6f77] text-center pt-1">
          Freedom Guarantee: You can change or completely remove this passcode anytime inside Vault Settings.
        </p>
      </div>

      {/* Footer Info */}
      <div className="relative z-10 border-t border-[#161822] pt-3 flex justify-between items-center text-[9px] text-[#6b6f77]">
        <div className="flex items-center gap-2">
          <Terminal className="w-3.5 h-3.5 text-[#00f2ff]" />
          <span>DECOY THEME: <span className="text-[#00f2ff] uppercase font-bold">{decoyTheme}</span></span>
        </div>
        <span>FREEDOM MATRIX SECURITY ACTIVE</span>
      </div>
    </div>
  );
};
