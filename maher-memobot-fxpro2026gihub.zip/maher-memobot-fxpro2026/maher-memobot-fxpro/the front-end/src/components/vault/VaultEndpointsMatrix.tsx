import React from "react";
import { Terminal, Play, RefreshCw } from "lucide-react";

export interface EndpointTest {
  id: string;
  name: string;
  method: "GET" | "POST";
  path: string;
  payload?: any;
  status: "idle" | "testing" | "success" | "error";
  httpCode?: number;
  latency_ms?: number;
  response?: any;
}

interface VaultEndpointsMatrixProps {
  endpointTests: EndpointTest[];
  onTestSingle: (epId: string) => void;
  onTestAll: () => void;
}

export const VaultEndpointsMatrix: React.FC<VaultEndpointsMatrixProps> = ({
  endpointTests,
  onTestSingle,
  onTestAll,
}) => {
  return (
    <div className="bg-[#0d0e12] border border-[#1a1d26] p-5 rounded space-y-4 font-mono text-xs">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#11131c] pb-3">
        <div className="flex items-center gap-2">
          <Terminal className="w-4 h-4 text-[#FA1F4E]" />
          <h3 className="text-xs font-extrabold text-[#FA1F4E] uppercase tracking-wider">
            SYSTEM API ENDPOINTS TESTING MATRIX
          </h3>
        </div>
        <button
          onClick={onTestAll}
          className="px-3 py-1 bg-[#00e5ff]/10 border border-[#00e5ff] text-[#00e5ff] hover:bg-[#00e5ff] hover:text-black rounded text-[9px] font-bold uppercase transition-all flex items-center gap-1.5 self-start sm:self-auto"
        >
          <Play className="w-3 h-3" />
          RUN ALL ENDPOINT TESTS
        </button>
      </div>

      <p className="text-[10px] text-[#8a8d9a]">
        Execute live HTTP requests against each system backend entry point to verify response health, latency, and JSON structure.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
        {endpointTests.map((ep) => {
          const isTesting = ep.status === "testing";
          return (
            <div key={ep.id} className="bg-[#06070a] border border-[#1a1d26] p-3 rounded space-y-2">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <span className={`px-1.5 py-0.5 text-[8px] font-extrabold rounded ${
                    ep.method === "GET"
                      ? "bg-blue-500/20 text-blue-400 border border-blue-500/40"
                      : "bg-purple-500/20 text-purple-400 border border-purple-500/40"
                  }`}>
                    {ep.method}
                  </span>
                  <span className="text-white font-bold text-[11px]">{ep.name}</span>
                </div>

                <button
                  onClick={() => onTestSingle(ep.id)}
                  disabled={isTesting}
                  className="px-2.5 py-1 bg-[#00e5ff]/10 hover:bg-[#00e5ff] hover:text-black border border-[#00e5ff]/40 text-[#00e5ff] rounded text-[9px] font-bold uppercase transition-all flex items-center gap-1"
                >
                  {isTesting ? <RefreshCw className="w-2.5 h-2.5 animate-spin" /> : <Play className="w-2.5 h-2.5" />}
                  {isTesting ? "TESTING" : "TEST ENTRY"}
                </button>
              </div>

              <div className="text-[9px] text-[#8a8d9a] font-mono bg-[#0d0e12] px-2 py-1 rounded border border-[#1a1d26] flex justify-between">
                <span>{ep.path}</span>
                {ep.httpCode && (
                  <span className={ep.httpCode === 200 ? "text-[#00e676] font-bold" : "text-[#ef4444] font-bold"}>
                    HTTP {ep.httpCode} ({ep.latency_ms}ms)
                  </span>
                )}
              </div>

              {ep.response && (
                <pre className="text-[8px] bg-black/60 text-[#00e5ff] p-2 rounded max-h-24 overflow-y-auto font-mono border border-[#1a1d26] whitespace-pre-wrap">
                  {JSON.stringify(ep.response, null, 2)}
                </pre>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
