import React, { useState } from "react";
import { useLanguage } from "../../LanguageProvider";
import { 
  Cpu, 
  Layers, 
  TrendingUp, 
  ShieldCheck, 
  Briefcase, 
  CreditCard, 
  Settings as SettingsIcon, 
  Activity, 
  ChevronDown, 
  ChevronUp, 
  ExternalLink,
  BookOpen,
  CheckCircle2,
  Sliders,
  DollarSign
} from "lucide-react";

interface PageInfo {
  id: string;
  icon: any;
  name: string;
  nameAr: string;
  badge: string;
  badgeAr: string;
  route: string;
  purpose: string;
  purposeAr: string;
  capabilities: string[];
  capabilitiesAr: string[];
  howToUse: string[];
  howToUseAr: string[];
}

export const PageGuideExplorer: React.FC = () => {
  const { isArabic, t } = useLanguage();
  const [expandedPage, setExpandedPage] = useState<string>("dashboard");

  const pages: PageInfo[] = [
    {
      id: "dashboard",
      icon: Activity,
      name: "Live Matrix & Dashboard",
      nameAr: "لوحة التحكم والمصفوفة الحية",
      badge: "REAL-TIME TELEMETRY",
      badgeAr: "مراقبة لحظية مباشرة",
      route: "/dashboard",
      purpose: "Unified high-level overview of portfolio equity, real-time spot balances, 12-engine status matrix, and instant master emergency stop controls.",
      purposeAr: "نظرة شاملة ولحظية على حقوق المحفظة، وأرصدة التداول الفوري، ومصفوفة حالة الـ ١٢ محركاً، مع أزرار الإيقاف الطارئ الفوري.",
      capabilities: [
        "Live portfolio equity & net PnL telemetry graph",
        "Active Spot Allocation breakdown across major digital assets",
        "Global Emergency Stop (Master Kill-Switch)",
        "Top market depth sensors & instant tick tickers"
      ],
      capabilitiesAr: [
        "رسم بياني لحظي لحقوق المحفظة وصافي الأرباح والخسائر",
        "توزيع رأس المال الفوري النشط عبر الأصول الرقمية الرئيسية",
        "قاطع طوارئ عام فوري لإيقاف كافة العمليات بضغطة واحدة",
        "مستشعرات عمق السوق وشريط حركة الأسعار الحية"
      ],
      howToUse: [
        "Check total equity & active capital ratio at top metric cards.",
        "Observe engine grid status to ensure active nodes are healthy.",
        "Use the Master Emergency Stop only in severe market turbulence."
      ],
      howToUseAr: [
        "متابعة إجمالي حقوق الحساب ونسبة رأس المال المستثمر في البطاقات العلوية.",
        "مراقبة شبكة المحركات للتأكد من سلامة واستقرار العقد النشطة.",
        "استخدام قاطع الطوارئ فقط في حالات التقلب الشديد لإغلاق المراكز."
      ]
    },
    {
      id: "engines",
      icon: Cpu,
      name: "Engines Station",
      nameAr: "محطة المحركات الخوارزمية",
      badge: "12 HIGH-SPEED NODES",
      badgeAr: "١٢ محركاً عالي السرعة",
      route: "/engines",
      purpose: "Dedicated management station for all 12 quantitative trading engines (Sirius, Canopus, Vega, Antares, etc.) with granular parameter adjustments.",
      purposeAr: "محطة الإدارة والتحكم في كافة المحركات الـ ١٢ مع إمكانية ضبط المعايير اللحظية وحدود المخاطر لكل محرك بشكل منفصل.",
      capabilities: [
        "Individual Start/Stop/Rebalance controls for each engine node",
        "Granular risk slider & hardcoded loss tolerance settings",
        "Live sensor readings (RSI, Bollinger Bandwidth, Order Flow)",
        "Strategy binding and pair assignment"
      ],
      capabilitiesAr: [
        "تحكم كامل في تشغيل وإيقاف وإعادة توازن كل محرك على حدة",
        "شريط منزلق لضبط معايير المخاطرة وأقصى خسارة مسموح بها",
        "قراءات مستشعرات لحظية (مؤشر القوة، نطاق بولينجر، تدفق الأوامر)",
        "ربط الاستراتيجيات المخصصة وتعيين أزواج التداول المستهدفة"
      ],
      howToUse: [
        "Click on an Engine card to view its internal sensor parameters.",
        "Toggle the Active switch to deploy or decommission an engine.",
        "Adjust Max Drawdown clamp to automatically lock profits."
      ],
      howToUseAr: [
        "الضغط على بطاقة المحرك لاستعراض مستشعراته وإعداداته الداخلية.",
        "تفعيل زر التشغيل لإطلاق المحرك أو إيقافه عن التداول.",
        "تعديل قيد أقصى تراجع لحماية الأرباح وتثبيت الخسائر تلقائياً."
      ]
    },
    {
      id: "strategies",
      icon: Layers,
      name: "Strategies Deck",
      nameAr: "لوحة الاستراتيجيات والنماذج",
      badge: "QUANTITATIVE MODELS",
      badgeAr: "نماذج التداول الكمي",
      route: "/strategies",
      purpose: "Repository of tested algorithmic models (Gold Arbitrage, Multi-Asset Momentum, Islamic Grid, Volatility Compression) ready for deployment.",
      purposeAr: "مستودع الاستراتيجيات والنماذج الكمية المعتمدة (مراجحة الذهب، الزخم متعدد الأصول، الشبكة الإسلامية، انضغاط التقلبات).",
      capabilities: [
        "Backtest verification logs & historical win rate metrics",
        "1-Click strategy activation to assigned engine nodes",
        "Detailed parameter customization (spread threshold, grid steps)",
        "Performance risk score indicators"
      ],
      capabilitiesAr: [
        "سجلات تدقيق الاختبار التاريخي ومعدل نجاح الصفقات",
        "تفعيل الاستراتيجية بضغطة واحدة وربطها بالمحرك المناسب",
        "تخصيص دقيق للمعايير (فارق السعر، خطوات الشبكة، فترات الزخم)",
        "مؤشرات تقييم درجة المخاطرة والكفاءة الاستثمارية"
      ],
      howToUse: [
        "Filter strategies by Risk Category or Asset Class.",
        "Review target APY and maximum drawdown metrics.",
        "Assign the strategy to an idle Engine node from the dropdown."
      ],
      howToUseAr: [
        "تصفية الاستراتيجيات حسب فئة المخاطرة أو نوع الأصل المالي.",
        "مراجعة العائد السنوي المتوقع وأقصى تراجع مسجل.",
        "تعيين الاستراتيجية لأحد المحركات الخاملة من القائمة المنسدلة."
      ]
    },
    {
      id: "orders",
      icon: TrendingUp,
      name: "Orders & Asset Portfolio",
      nameAr: "سجل الأوامر والمحفظة الرقمية",
      badge: "SPOT EXECUTION HUB",
      badgeAr: "مركز التنفيذ الفوري",
      route: "/orders",
      purpose: "Real-time execution log and portfolio balance viewer with sub-millisecond order fill times and direct physical settlement tracking.",
      purposeAr: "سجل تنفيذ الأوامر اللحظي ومتابعة أرصدة المحفظة مع سرعات تنفيذ ميكروثانية وتتبع التقابض الفعلي للأصول.",
      capabilities: [
        "Real-time open orders and execution latency audits",
        "Cryptographic trade hash confirmation (SHA-256)",
        "Zero-leverage spot holding distribution",
        "CSV/PDF export of all historical fills"
      ],
      capabilitiesAr: [
        "متابعة الأوامر المفتوحة وسرعات التنفيذ بالمللي ثانية",
        "تأكيد البصمة التشفيرية لكل صفقة منفذة (SHA-256)",
        "عرض الأصول الفورية الخالية تماماً من الرافعة المالية",
        "تصدير كامل لكافة الصفقات السابقة بصيغ CSV و PDF"
      ],
      howToUse: [
        "Monitor live active positions in the Open Orders tab.",
        "Verify correlation IDs for institutional auditing.",
        "Check physical settlement timestamps to ensure spot compliance."
      ],
      howToUseAr: [
        "مراقبة المراكز المفتوحة في تبويب الأوامر النشطة.",
        "التحقق من معرفات التتبع لأغراض التدقيق المؤسسي.",
        "التأكد من التوقيت الزمني للتقابض الفوري ومطابقته للضوابط."
      ]
    },
    {
      id: "shariyah",
      icon: ShieldCheck,
      name: "Shariyah Bureau",
      nameAr: "ديوان الرقابة الشرعية (AAOIFI)",
      badge: "100% SPOT HALAL",
      badgeAr: "تداول فوري شرعي ١٠٠٪",
      route: "/shariyah",
      purpose: "Governance and audit portal ensuring 100% Spot Halal trading in compliance with AAOIFI Standards 21 and 59, with zero Riba and zero Gharar.",
      purposeAr: "بوابة الحوكمة والرقابة الشرعية لضمان التداول الفوري الحلال وفق معايير أيوفي ٢١ و ٥٩، مع خلو تام من الربا والغرر والتبييت.",
      capabilities: [
        "AAOIFI Standard 21 (Financial Paper) & 59 (Gold/Currencies) audits",
        "Real-time Riba & Overnight Swap detection clamp (0.00%)",
        "Direct physical asset possession confirmation certificates",
        "Shariah Board compliance memorandum downloads"
      ],
      capabilitiesAr: [
        "تدقيق معايير أيوفي رقم ٢١ (الأوراق المالية) و ٥٩ (الذهب والعملات)",
        "كاشف وحاجز الربا ورسوم التبييت الفوري (بنسبة ٠.٠٠٪)",
        "شهادات تأكيد التقابض الفعلي وحيازة الأصول الرقمية",
        "تحميل تقارير واعتمادات الهيئة الشرعية الموثقة"
      ],
      howToUse: [
        "Review the live Spot Compliance meter (always 100%).",
        "Verify the zero-interest pledge before starting automated engines.",
        "Download official compliance audit reports for Islamic accounting."
      ],
      howToUseAr: [
        "مراجعة مؤشر الامتثال الفوري (يجب أن يكون دائماً ١٠٠٪).",
        "التحقق من تعهد انعدام الفائدة والتبييت قبل بدء المحركات.",
        "تحميل تقارير التدقيق الشرعي المعتمدة للمحاسبة الإسلامية."
      ]
    },
    {
      id: "business-club",
      icon: Briefcase,
      name: "Executive Business Club",
      nameAr: "نادي كبار المستثمرين والمؤسسات",
      badge: "PRIVATE SYNDICATE",
      badgeAr: "صفقات استثمارية حصرية",
      route: "/business-club",
      purpose: "Exclusive portal for high-net-worth investors and institutions to access private syndicate deals, 24/7 VIP concierge, and alpha intelligence.",
      purposeAr: "بوابة حصرية لكبار المستثمرين والمؤسسات للاشتراك في الصفقات الخاصة والتواصل مع المكتب التنفيذي والاطلاع على تقارير الذكاء الكمي.",
      capabilities: [
        "Private Shariah-backed syndicate investment pools (Gold & Sukuk)",
        "Direct VIP Concierge desk with 15-minute priority SLA",
        "Real-time Alpha Intelligence breakout signals",
        "4-Tier privilege matrix integration"
      ],
      capabilitiesAr: [
        "مجمعات استثمارية وصفقات خاصة مدعومة بالذهب والصكوك",
        "مكتب مساعدة وتنفيذ VIP مع استجابة خلال ١٥ دقيقة",
        "بث إشارات وتوصيات الذكاء الكمي عالية الدقة (Alpha)",
        "الربط التلقائي مع مصفوفة الفئات والمزايا الأربع"
      ],
      howToUse: [
        "Browse open syndicate deals and review target APY.",
        "Click 'Reserve Allocation' to commit capital from your secure vault.",
        "Submit bespoke requests directly to the senior managing desk."
      ],
      howToUseAr: [
        "استعراض الصفقات المتاحة ومراجعة العائد المستهدف ودورة الاستثمار.",
        "الضغط على 'حجز حصة استثمارية' للاكتتاب برأس المال المطلوب.",
        "إرسال طلبات التخصيص والاستشارات مباشرة للمكتب التنفيذي."
      ]
    },
    {
      id: "billing",
      icon: CreditCard,
      name: "Billing & Tiers",
      nameAr: "الفواتير وتخصيص الفئات",
      badge: "PROVISIONING HUB",
      badgeAr: "إدارة الاشتراكات والتراخيص",
      route: "/billing",
      purpose: "Subscription management, instant multi-tier provisioning, white-label corporate licensing, and tax-compliant invoice generation.",
      purposeAr: "إدارة الاشتراكات، وترقية الفئات الفورية، وتراخيص الشركات المخصصة (White-Label)، وتوليد الفواتير الضريبية المعتمدة.",
      capabilities: [
        "Tier upgrades (Individual, Investor, Corporate, Institutional)",
        "Automated crypto & bank wire invoice generation",
        "Corporate seat management and tenant keys",
        "Usage quota & throughput monitoring"
      ],
      capabilitiesAr: [
        "ترقية الفئات (فردي، مستثمر، شركات، مكاتب مؤسسية)",
        "توليد الفواتير المشفرة وفواتير التحويل البنكي المعتمدة",
        "إدارة مقاعد الشركات وتراخيص العلامات التجارية البيضاء",
        "مراقبة سعة الاستهلاك وحدود تدفق العمليات"
      ],
      howToUse: [
        "Select your desired tier matching your capital and engine count needs.",
        "Generate and download PDF invoices for accounting.",
        "Manage tenant licenses if operating in Corporate mode."
      ],
      howToUseAr: [
        "اختيار الفئة المناسبة لحجم رأس المال وعدد المحركات المطلوبة.",
        "توليد وتحميل الفواتير بصيغة PDF لأغراض المحاسبة والضرائب.",
        "إدارة تراخيص المؤسسة في حال تفعيل بوابة الشركات."
      ]
    },
    {
      id: "settings",
      icon: SettingsIcon,
      name: "System Settings",
      nameAr: "الإعدادات العامة والمنظومة",
      badge: "CONFIG & THEME STUDIO",
      badgeAr: "الاستوديو والتحكم المتقدم",
      route: "/settings",
      purpose: "Central cockpit for Theme Studio customization, live DOM Element Modifier, Telegram Mini App integration, and multi-format audit report exports.",
      purposeAr: "غرفة التحكم المركزية لتخصيص الألوان والمظهر، وتعديل عناصر الواجهة الحية، وربط بوت تيليجرام، وتصدير تقارير التدقيق.",
      capabilities: [
        "Theme Studio with instant accent color adjustments",
        "Live Element Modifier for on-the-fly DOM styling",
        "Telegram Mini App bot token synchronization",
        "Export audit reports in PDF, Word, Excel, or Email dispatch"
      ],
      capabilitiesAr: [
        "استوديو المظهر لتخصيص الألوان والسمات البصرية فورياً",
        "أداة تعديل عناصر الواجهة الحية لتخصيص التصميم والنصوص",
        "مزامنة تطبيق تيليجرام المصغر مع المنصة",
        "تصدير تقارير التدقيق بصيغ PDF و Word و Excel والإرسال بالبريد"
      ],
      howToUse: [
        "Use Theme Studio to pick custom accent hues matching your desk mood.",
        "Configure notification channels for Telegram and email alerts.",
        "Export institutional audit logs for end-of-day compliance."
      ],
      howToUseAr: [
        "استخدام استوديو المظهر لاختيار السمة اللونية المفضلة للمنصة.",
        "تحديد قنوات الإشعارات الفورية عبر تيليجرام أو البريد الإلكتروني.",
        "تصدير تقارير التدقيق المؤسسية اليومية لمراجعة الامتثال والأداء."
      ]
    }
  ];

  return (
    <div className="bg-[#08090d] border border-[#1a1d26] rounded-xl p-5 space-y-4 font-mono">
      <div className="border-b border-[#161822] pb-3">
        <h4 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
          <BookOpen className="w-4 h-4 text-emerald-400" />
          {t("INTERACTIVE PAGE DIRECTORY & USER MANUAL")}
        </h4>
        <p className="text-xs text-[#8a8d9a] mt-0.5">
          {t("Comprehensive breakdown of every platform module, core capabilities, and step-by-step operating guidelines.")}
        </p>
      </div>

      <div className="space-y-3">
        {pages.map((page) => {
          const Icon = page.icon;
          const isExpanded = expandedPage === page.id;

          return (
            <div
              key={page.id}
              className={`border rounded-xl transition-all overflow-hidden ${
                isExpanded ? "bg-[#0b0e16] border-cyan-500/50 shadow-lg" : "bg-[#0a0c12] border-[#161a26] hover:border-[#333]"
              }`}
            >
              {/* Card Header */}
              <button
                onClick={() => setExpandedPage(isExpanded ? "" : page.id)}
                className="w-full p-4 flex items-center justify-between text-left cursor-pointer transition-colors"
                style={{ direction: isArabic ? "rtl" : "ltr" }}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-9 h-9 rounded-lg flex items-center justify-center border ${
                    isExpanded ? "bg-cyan-500/20 border-cyan-500/50 text-cyan-400" : "bg-[#141824] border-[#222838] text-[#8a8d9a]"
                  }`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h5 className="font-bold text-white text-xs">{isArabic ? page.nameAr : page.name}</h5>
                      <span className="text-[9px] px-2 py-0.5 rounded bg-[#161a26] text-cyan-400 border border-[#222838] font-bold">
                        {isArabic ? page.badgeAr : page.badge}
                      </span>
                    </div>
                    <p className="text-[10px] text-[#717684] mt-0.5 line-clamp-1">
                      {isArabic ? page.purposeAr : page.purpose}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-[9px] text-[#8a8d9a] hidden sm:inline">
                    {isExpanded ? t("COLLAPSE DETAILS") : t("CLICK TO EXPAND DETAILS")}
                  </span>
                  {isExpanded ? (
                    <ChevronUp className="w-4 h-4 text-cyan-400" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-[#8a8d9a]" />
                  )}
                </div>
              </button>

              {/* Card Expanded Content */}
              {isExpanded && (
                <div className="p-4 pt-0 border-t border-[#161a26] mt-2 space-y-4 text-xs">
                  <div className="p-3 bg-[#07090e] border border-[#141824] rounded-lg">
                    <span className="text-[9px] font-bold text-cyan-400 uppercase tracking-widest block mb-1">
                      {t("PURPOSE & ROLE")}:
                    </span>
                    <p className="text-[#a0a4b0] text-[11px] leading-relaxed">
                      {isArabic ? page.purposeAr : page.purpose}
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {/* Key Capabilities */}
                    <div className="p-3 bg-[#07090e] border border-[#141824] rounded-lg space-y-2">
                      <span className="text-[9px] font-bold text-emerald-400 uppercase tracking-widest block">
                        {t("KEY CAPABILITIES")}:
                      </span>
                      <div className="space-y-1.5">
                        {(isArabic ? page.capabilitiesAr : page.capabilities).map((cap, i) => (
                          <div key={i} className="flex items-start gap-1.5 text-[10px] text-white/90">
                            <CheckCircle2 className="w-3 h-3 text-emerald-400 mt-0.5 shrink-0" />
                            <span>{cap}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* How to Operate */}
                    <div className="p-3 bg-[#07090e] border border-[#141824] rounded-lg space-y-2">
                      <span className="text-[9px] font-bold text-amber-400 uppercase tracking-widest block">
                        {t("HOW TO OPERATE")}:
                      </span>
                      <div className="space-y-1.5">
                        {(isArabic ? page.howToUseAr : page.howToUse).map((step, i) => (
                          <div key={i} className="flex items-start gap-1.5 text-[10px] text-white/90">
                            <span className="w-3.5 h-3.5 rounded bg-[#181d2c] text-amber-400 text-[8px] flex items-center justify-center font-bold shrink-0 mt-0.5">
                              {i + 1}
                            </span>
                            <span>{step}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
