import React, { useState } from "react";
import { 
  Wallet, 
  QrCode, 
  Copy, 
  CheckCircle2, 
  Save, 
  ShieldCheck, 
  ExternalLink, 
  Zap, 
  Lock, 
  DollarSign,
  Layers,
  Code2
} from "lucide-react";
import { MemoCorePaymentBench } from "../exportable/MemoCoreSubscriptionBench";

interface PersonalPayoutTreasuryProps {
  showAlert: (msg: string) => void;
}

export const PersonalPayoutTreasury: React.FC<PersonalPayoutTreasuryProps> = ({ showAlert }) => {
  const [trc20Address, setTrc20Address] = useState<string>(() => {
    return localStorage.getItem("memobot_payout_trc20_address") || "TQn9Y2khEsLJW1ChVWFMSMeRDow5KcbLSE";
  });

  const [erc20Address, setErc20Address] = useState<string>(() => {
    return localStorage.getItem("memobot_payout_erc20_address") || "0x71C2d674f2858485293A24fB210b429dF78249dF";
  });

  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [isSaved, setIsSaved] = useState<boolean>(false);
  const [showBenchPreview, setShowBenchPreview] = useState<boolean>(false);
  const [showCodeExport, setShowCodeExport] = useState<boolean>(false);

  const handleSaveWallets = () => {
    localStorage.setItem("memobot_payout_trc20_address", trc20Address.trim());
    localStorage.setItem("memobot_payout_erc20_address", erc20Address.trim());
    setIsSaved(true);
    showAlert("Personal USDT Payout Receiving Addresses updated & verified.");
    setTimeout(() => setIsSaved(false), 3000);
  };

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    showAlert(`Copied ${key} address to clipboard.`);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const snippetCode = `// Drop into your MemoCore React / Next.js app:
import { MemoCorePaymentBench } from "./components/MemoCoreSubscriptionBench";

export default function MemoCoreCheckout() {
  return (
    <MemoCorePaymentBench 
      trc20Address="${trc20Address}"
      erc20Address="${erc20Address}"
      onSuccess={(plan, tx) => console.log('Paid:', plan, tx)}
    />
  );
}`;

  return (
    <div className="bg-[#0a0c12] border border-[#1a1e2a] rounded-xl p-5 space-y-5 font-mono text-xs shadow-xl">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#161a26] pb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
            <Wallet className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h4 className="text-sm font-bold text-white uppercase tracking-wider">
                PERSONAL USDT PAYOUT & RECEIVING TREASURY
              </h4>
              <span className="px-2 py-0.5 rounded bg-emerald-950/60 border border-emerald-500/40 text-emerald-400 text-[9px] font-bold">
                NON-CUSTODIAL DIRECT
              </span>
            </div>
            <p className="text-[10px] text-[#717684] mt-0.5">
              All subscription fees, bot licenses, and client payments route directly to these private addresses.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowBenchPreview(!showBenchPreview)}
            className="px-3 py-1.5 bg-[#FA1F4E]/15 border border-[#FA1F4E]/40 text-white hover:bg-[#FA1F4E] rounded-lg text-[10px] font-bold uppercase transition-all flex items-center gap-1.5 cursor-pointer shadow-[0_0_10px_rgba(250,31,78,0.2)]"
          >
            <Zap className="w-3.5 h-3.5 text-[#FA1F4E]" />
            <span>{showBenchPreview ? "HIDE MEMOCORE BENCH" : "PREVIEW MEMOCORE BENCH"}</span>
          </button>

          <button
            onClick={() => setShowCodeExport(!showCodeExport)}
            className="px-3 py-1.5 bg-cyan-500/15 border border-cyan-500/40 text-cyan-400 hover:bg-cyan-500 hover:text-black rounded-lg text-[10px] font-bold uppercase transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <Code2 className="w-3.5 h-3.5" />
            <span>COPY CODE SNIPPET</span>
          </button>
        </div>
      </div>

      {/* Code Export Drawer */}
      {showCodeExport && (
        <div className="p-4 bg-[#06080e] border border-cyan-500/30 rounded-lg space-y-2 animate-fadeIn">
          <div className="flex justify-between items-center text-[10px]">
            <span className="text-cyan-400 font-bold uppercase">Ready-to-use MemoCore Integration Code:</span>
            <button
              onClick={() => {
                navigator.clipboard.writeText(snippetCode);
                showAlert("MemoCore React Component snippet copied!");
              }}
              className="px-2.5 py-1 rounded bg-cyan-500/20 text-cyan-400 hover:bg-cyan-500 hover:text-black text-[9px] font-bold flex items-center gap-1 cursor-pointer"
            >
              <Copy className="w-3 h-3" />
              <span>COPY TSX CODE</span>
            </button>
          </div>
          <pre className="p-3 bg-[#0a0d16] border border-[#1a1f2e] rounded text-[10px] text-white/90 overflow-x-auto select-all">
            {snippetCode}
          </pre>
        </div>
      )}

      {/* Embedded MemoCore Bench Preview */}
      {showBenchPreview && (
        <div className="p-4 bg-[#040508] border border-[#FA1F4E]/40 rounded-xl space-y-3 animate-fadeIn">
          <div className="flex items-center justify-between text-[10px] border-b border-[#1a1f2e] pb-2">
            <span className="text-[#FA1F4E] font-bold uppercase flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5" />
              LIVE MEMOCORE QUICK PAYMENT BENCH (WITH YOUR REAL WALLET)
            </span>
            <span className="text-[#717684]">Drop-in ready component from /src/components/exportable/</span>
          </div>
          <MemoCorePaymentBench 
            trc20Address={trc20Address}
            erc20Address={erc20Address}
            onSuccess={(plan, tx) => showAlert(`Test payment processed for ${plan}! TX: ${tx.slice(0, 10)}...`)}
          />
        </div>
      )}

      {/* Wallet Input Fields */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* TRC-20 USDT Wallet */}
        <div className="p-4 bg-[#07090e] border border-[#181c2b] rounded-lg space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-white font-bold text-[11px] flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
              USDT Receiving Wallet (TRC-20 Network)
            </span>
            <span className="text-[9px] text-[#717684]">Zero-fee fast transfers</span>
          </div>
          <p className="text-[10px] text-[#717684]">
            Paste your personal Tron (TRC-20) USDT address (e.g. from Trust Wallet, Binance, or Ledger):
          </p>
          <div className="flex items-center gap-2">
            <input
              type="text"
              value={trc20Address}
              onChange={(e) => setTrc20Address(e.target.value)}
              placeholder="Paste TRC20 USDT Address (starts with T)..."
              className="flex-1 bg-[#0c0f17] border border-[#1e2436] rounded-lg px-3 py-2 text-white text-[11px] font-mono focus:border-emerald-400 focus:outline-none"
            />
            <button
              onClick={() => handleCopy(trc20Address, "TRC-20")}
              className="p-2 bg-[#141824] hover:bg-[#1f2538] text-[#8a8d9a] hover:text-white rounded-lg border border-[#222838] transition-all cursor-pointer"
              title="Copy Address"
            >
              {copiedKey === "TRC-20" ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* ERC-20 / BEP-20 USDT Wallet */}
        <div className="p-4 bg-[#07090e] border border-[#181c2b] rounded-lg space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-white font-bold text-[11px] flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-cyan-400" />
              USDT Receiving Wallet (ERC-20 / Arbitrum / BSC)
            </span>
            <span className="text-[9px] text-[#717684]">Multi-chain compatible</span>
          </div>
          <p className="text-[10px] text-[#717684]">
            Paste your EVM USDT address (e.g. from MetaMask, Trust Wallet, or exchange):
          </p>
          <div className="flex items-center gap-2">
            <input
              type="text"
              value={erc20Address}
              onChange={(e) => setErc20Address(e.target.value)}
              placeholder="Paste ERC20/BEP20 Address (starts with 0x)..."
              className="flex-1 bg-[#0c0f17] border border-[#1e2436] rounded-lg px-3 py-2 text-white text-[11px] font-mono focus:border-cyan-400 focus:outline-none"
            />
            <button
              onClick={() => handleCopy(erc20Address, "ERC-20")}
              className="p-2 bg-[#141824] hover:bg-[#1f2538] text-[#8a8d9a] hover:text-white rounded-lg border border-[#222838] transition-all cursor-pointer"
              title="Copy Address"
            >
              {copiedKey === "ERC-20" ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </div>

      {/* Save Action Footer */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2 border-t border-[#161a26]">
        <div className="flex items-center gap-2 text-[10px] text-emerald-400">
          <ShieldCheck className="w-4 h-4" />
          <span>Non-Custodial: 100% of user subscriptions route directly to your addresses without intermediary fees.</span>
        </div>

        <button
          onClick={handleSaveWallets}
          className="px-6 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold uppercase tracking-wider text-[11px] transition-all flex items-center justify-center gap-2 shadow-[0_0_15px_rgba(16,185,129,0.3)] cursor-pointer"
        >
          {isSaved ? <CheckCircle2 className="w-4 h-4 text-white" /> : <Save className="w-4 h-4" />}
          <span>{isSaved ? "SAVED SUCCESSFULLY!" : "SAVE RECEIVING WALLETS"}</span>
        </button>
      </div>
    </div>
  );
};
