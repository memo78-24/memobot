import React, { useState } from "react";
import { Globe, MousePointerClick, BookOpen, Sparkles, Database } from "lucide-react";
import { TranslationDictionaryTable } from "../translation/TranslationDictionaryTable";
import { TranslationPlayground } from "../translation/TranslationPlayground";
import { TranslationBackupSync } from "../translation/TranslationBackupSync";
import { TranslationService } from "../../services/translationService";
import { useTheme } from "../ThemeProvider";

interface Props {
  showAlert: (msg: string) => void;
}

export const TranslationStudioSettings: React.FC<Props> = ({ showAlert }) => {
  const [activeSubTab, setActiveSubTab] = useState<"dictionary" | "playground" | "backup">("dictionary");
  
  let accentColor = "#FA1F4E";
  try {
    const theme = useTheme();
    if (theme?.accentColor) accentColor = theme.accentColor;
  } catch (e) {}

  const allItems = TranslationService.getAllTranslations();

  const handleStartInspector = () => {
    TranslationService.toggleInspector(true);
    showAlert("Click-to-Translate active! Click any element on your screen to translate.");
  };

  return (
    <div className="space-y-6 text-xs font-mono">
      {/* Header Banner */}
      <div 
        style={{ borderColor: `${accentColor}30` }}
        className="p-4 rounded-xl bg-[#0a0b10] border flex flex-col md:flex-row justify-between items-start md:items-center gap-4"
      >
        <div className="flex items-center gap-3">
          <div 
            style={{ backgroundColor: `${accentColor}20`, borderColor: accentColor }}
            className="p-2.5 rounded-lg border"
          >
            <Globe className="w-5 h-5" style={{ color: accentColor }} />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white uppercase tracking-wide flex items-center gap-2">
              TRANSLATION & CUSTOM DICTIONARY STUDIO
            </h3>
            <p className="text-[11px] text-[#8a8d9a] font-sans">
              Manage all Arabic & English translations, customize wording across every card, or use the interactive on-screen click translator.
            </p>
          </div>
        </div>

        <button
          onClick={handleStartInspector}
          className="px-3.5 py-2 rounded-lg bg-cyan-950/70 hover:bg-cyan-900 border border-cyan-500/60 text-cyan-200 font-bold flex items-center gap-2 cursor-pointer shadow-sm transition-all"
        >
          <MousePointerClick className="w-4 h-4" />
          <span>Launch On-Page Click & Translate</span>
        </button>
      </div>

      {/* Sub-Tabs */}
      <div className="flex gap-2 border-b border-[#181a24] pb-2">
        {[
          { id: "dictionary", label: "Dictionary Catalog", icon: BookOpen },
          { id: "playground", label: "Translation Tester", icon: Sparkles },
          { id: "backup", label: "Import / Export & Backup", icon: Database },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeSubTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveSubTab(tab.id as any)}
              style={
                isActive
                  ? { borderColor: accentColor, backgroundColor: `${accentColor}20`, color: "#fff" }
                  : {}
              }
              className={`px-3.5 py-1.5 rounded border text-[11px] font-bold uppercase transition-all flex items-center gap-1.5 cursor-pointer ${
                isActive
                  ? ""
                  : "bg-[#0a0b0f] border-[#181a24] text-[#8a8d9a] hover:text-white hover:border-[#333]"
              }`}
            >
              <Icon className="w-3.5 h-3.5" style={{ color: isActive ? accentColor : "#8a8d9a" }} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab Views */}
      <div className="pt-1">
        {activeSubTab === "dictionary" && (
          <TranslationDictionaryTable
            items={allItems}
            accentColor={accentColor}
            showAlert={showAlert}
          />
        )}

        {activeSubTab === "playground" && (
          <TranslationPlayground
            accentColor={accentColor}
            showAlert={showAlert}
          />
        )}

        {activeSubTab === "backup" && (
          <TranslationBackupSync
            accentColor={accentColor}
            showAlert={showAlert}
          />
        )}
      </div>
    </div>
  );
};
