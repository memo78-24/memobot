import React, { useState } from "react";
import { useLanguage } from "../LanguageProvider";
import { useTheme } from "../ThemeProvider";
import { ArchitectureTree } from "./about/ArchitectureTree";
import { PageGuideExplorer } from "./about/PageGuideExplorer";
import { CoreCapabilitiesMatrix } from "./about/CoreCapabilitiesMatrix";
import { OrbitEmblem } from "../OrbitEmblem";
import { 
  Network, 
  BookOpen, 
  Sparkles, 
  ShieldCheck, 
  Cpu, 
  Terminal, 
  Layers, 
  Zap, 
  ExternalLink,
  Sliders,
  CheckCircle2,
  Code
} from "lucide-react";
import { identityStore } from "../../services/identityStore";

export const AboutMemoBotSettings: React.FC = () => {
  const { isArabic, t } = useLanguage();
  const { accentColor } = useTheme();
  const [activeSection, setActiveSection] = useState<"topology" | "pages" | "capabilities">("topology");
  const identity = identityStore.getState();
  const currentTier = identity.tierProfile;

  return (
    <div className="space-y-6 font-mono animate-fadeIn" style={{ direction: isArabic ? "rtl" : "ltr" }}>
      {/* Futuristic Hero Banner */}
      <div className="bg-[#08090d] border border-[#1a1d26] rounded-xl p-6 relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-bl from-cyan-500/10 via-transparent to-transparent rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 relative z-10">
          <div className="flex items-start sm:items-center gap-4">
            {/* Dynamic Orbit Logo Emblem */}
            <div className="shrink-0">
              <OrbitEmblem size={68} className="border-cyan-500/30" />
            </div>

            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h3 className="text-xl font-bold text-white tracking-wider">
                  {isArabic ? "ميموبوت FX-PRO™" : "MEMOBOT FX-PRO™"}
                </h3>
                <span 
                  className="px-2.5 py-0.5 rounded text-[10px] font-black border tracking-wider"
                  style={{ backgroundColor: `${currentTier.colorAccent}20`, color: currentTier.colorAccent, borderColor: `${currentTier.colorAccent}50` }}
                >
                  {isArabic ? `${currentTier.nameAr} (${currentTier.maxEngines} محركات)` : `${currentTier.name} (${currentTier.maxEngines} ENGINES)`}
                </span>
                <span className="px-2 py-0.5 rounded bg-emerald-950/60 border border-emerald-500/40 text-emerald-400 text-[9px] font-bold">
                  {isArabic ? "معتمد شرعياً وفق معايير أيوفي (AAOIFI)" : "AAOIFI SHARIAH CERTIFIED"}
                </span>
              </div>

              <p className="font-sans text-[13px] text-[#8a8d9a] mt-1 max-w-2xl leading-relaxed">
                {isArabic 
                  ? "مصفوفة التنفيذ الخوارزمي المؤسسية للجيل القادم، المصممة لمراجحة الأصول الرقمية الفورية والذهب الحقيقي في أجزاء من المللي ثانية، مع امتثال صارم لمعايير أيوفي الشرعية وانعدام العمليات المالية على واجهة المستخدم."
                  : t("Next-Generation Institutional Algorithmic Execution Matrix engineered for sub-millisecond spot cryptocurrency and physical gold arbitrage, featuring strict AAOIFI compliance and zero client-side financial computation.")
                }
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 w-full lg:w-auto justify-end">
            <div className="p-3 bg-[#0d0f17] border border-[#1a1e2a] rounded-lg text-right text-xs">
              <span className="text-[9px] text-[#8a8d9a] block">{t("ACTIVE LATENCY SLA")}</span>
              <span className="text-cyan-400 font-bold font-mono">{currentTier.latencySla}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Futuristic Navigation Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-[#161822] pb-3 shrink-0">
        <button
          onClick={() => setActiveSection("topology")}
          className={`px-4 py-2.5 rounded-lg text-xs font-bold uppercase transition-all flex items-center gap-2 border cursor-pointer ${
            activeSection === "topology"
              ? "bg-[#FA1F4E]/20 border-[#FA1F4E] text-white shadow-[0_0_15px_rgba(250,31,78,0.25)]"
              : "bg-[#090a0d] border-[#181a24] text-[#8a8d9a] hover:border-[#444] hover:text-white"
          }`}
        >
          <Network className="w-4 h-4" style={{ color: activeSection === "topology" ? "#FA1F4E" : "#8a8d9a" }} />
          <span>{t("SYSTEM TOPOLOGY & ARCHITECTURE TREE")}</span>
        </button>

        <button
          onClick={() => setActiveSection("pages")}
          className={`px-4 py-2.5 rounded-lg text-xs font-bold uppercase transition-all flex items-center gap-2 border cursor-pointer ${
            activeSection === "pages"
              ? "bg-[#FA1F4E]/20 border-[#FA1F4E] text-white shadow-[0_0_15px_rgba(250,31,78,0.25)]"
              : "bg-[#090a0d] border-[#181a24] text-[#8a8d9a] hover:border-[#444] hover:text-white"
          }`}
        >
          <BookOpen className="w-4 h-4" style={{ color: activeSection === "pages" ? "#FA1F4E" : "#8a8d9a" }} />
          <span>{t("INTERACTIVE PAGE DIRECTORY & USER MANUAL")}</span>
        </button>

        <button
          onClick={() => setActiveSection("capabilities")}
          className={`px-4 py-2.5 rounded-lg text-xs font-bold uppercase transition-all flex items-center gap-2 border cursor-pointer ${
            activeSection === "capabilities"
              ? "bg-[#FA1F4E]/20 border-[#FA1F4E] text-white shadow-[0_0_15px_rgba(250,31,78,0.25)]"
              : "bg-[#090a0d] border-[#181a24] text-[#8a8d9a] hover:border-[#444] hover:text-white"
          }`}
        >
          <Sparkles className="w-4 h-4" style={{ color: activeSection === "capabilities" ? "#FA1F4E" : "#8a8d9a" }} />
          <span>{t("CORE CAPABILITIES & INSTITUTIONAL SPECIFICATIONS")}</span>
        </button>
      </div>

      {/* Active Section Content */}
      <div className="space-y-4">
        {activeSection === "topology" && <ArchitectureTree />}
        {activeSection === "pages" && <PageGuideExplorer />}
        {activeSection === "capabilities" && <CoreCapabilitiesMatrix />}
      </div>
    </div>
  );
};
