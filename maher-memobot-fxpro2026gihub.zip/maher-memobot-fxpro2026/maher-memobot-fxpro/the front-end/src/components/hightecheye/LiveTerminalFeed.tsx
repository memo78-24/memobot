import React, { useState, useEffect, useRef } from "react";
import { Terminal, Search, Pause, Play, Trash2, CheckCircle2, Shield, Activity } from "lucide-react";

interface LogEvent {
  id: string;
  timestamp: string;
  category: "ENGINE" | "GATEWAY" | "RISK" | "AUDIT";
  message: string;
  correlationId: string;
  latency: string;
}

export const LiveTerminalFeed: React.FC = () => {
  const [filter, setFilter] = useState<string>("ALL");
  const [search, setSearch] = useState("");
  const [isPaused, setIsPaused] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  const [logs, setLogs] = useState<LogEvent[]>([
    {
      id: "1",
      timestamp: "15:12:01.104",
      category: "AUDIT",
      message: "SHARIAH PROTOCOL SEAL VERIFIED: Spot 1X Physical Handshake valid across BTC/USDT and ETH/USDT.",
      correlationId: "CORR-AUDIT-982144",
      latency: "0.12ms",
    },
    {
      id: "2",
      timestamp: "15:12:01.890",
      category: "ENGINE",
      message: "HIGH FREQUENCY ORDER BOOK DEPTH: Synchronized 50 crypto assets with 0 slippage threshold.",
      correlationId: "CORR-ENG-441209",
      latency: "0.18ms",
    },
    {
      id: "3",
      timestamp: "15:12:02.450",
      category: "GATEWAY",
      message: "L2 NETWORK INGRESS: WebSocket channel established to primary liquidity pool. Zero frame drop.",
      correlationId: "CORR-NET-331908",
      latency: "0.22ms",
    },
    {
      id: "4",
      timestamp: "15:12:03.112",
      category: "RISK",
      message: "CAPITAL SAFEGUARD ENFORCED: Maximum drawdown threshold locked at 0.00% intrusion.",
      correlationId: "CORR-RSK-110293",
      latency: "0.14ms",
    },
    {
      id: "5",
      timestamp: "15:12:03.900",
      category: "AUDIT",
      message: "PURIFICATION LEDGER INSPECTION: Non-compliant revenue calculated at $0.00 (100% Halal Spot).",
      correlationId: "CORR-AUDIT-884321",
      latency: "0.16ms",
    },
  ]);

  // Periodic simulated live event injection when not paused
  useEffect(() => {
    if (isPaused) return;

    const interval = setInterval(() => {
      const categories: ("ENGINE" | "GATEWAY" | "RISK" | "AUDIT")[] = ["ENGINE", "GATEWAY", "RISK", "AUDIT"];
      const chosenCat = categories[Math.floor(Math.random() * categories.length)];
      const randId = Math.floor(100000 + Math.random() * 900000);
      const now = new Date();
      const timeStr = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}:${String(now.getSeconds()).padStart(2, "0")}.${String(now.getMilliseconds()).padStart(3, "0")}`;

      const messages = {
        ENGINE: "Quant node heartbeat verified: matching engine cycle completed in sub-millisecond cadence.",
        GATEWAY: "Ingress telemetry: zero network packet congestion detected on global proxy tunnel.",
        RISK: "Autonomous hedge guard active: stop-loss and take-profit bounds calibrated dynamically.",
        AUDIT: "AAOIFI compliance token refreshed: physical asset backing confirmed with zero interest (Riba).",
      };

      const newLog: LogEvent = {
        id: `${Date.now()}-${Math.random()}`,
        timestamp: timeStr,
        category: chosenCat,
        message: messages[chosenCat],
        correlationId: `CORR-${chosenCat}-${randId}`,
        latency: `${(0.1 + Math.random() * 0.25).toFixed(2)}ms`,
      };

      setLogs((prev) => [...prev.slice(-35), newLog]);
    }, 2800);

    return () => clearInterval(interval);
  }, [isPaused]);

  useEffect(() => {
    if (!isPaused && scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs, isPaused]);

  const filteredLogs = logs.filter((l) => {
    const matchesCat = filter === "ALL" || l.category === filter;
    const matchesSearch =
      search === "" ||
      l.message.toLowerCase().includes(search.toLowerCase()) ||
      l.correlationId.toLowerCase().includes(search.toLowerCase());
    return matchesCat && matchesSearch;
  });

  return (
    <div className="bg-[#0b101b] border border-[#1e293b] rounded-lg p-4 font-mono shadow-[0_4px_24px_rgba(0,0,0,0.5)] flex flex-col h-full">
      {/* Feed Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between border-b border-[#1e293b] pb-3 gap-2">
        <div className="flex items-center gap-2">
          <Terminal className="w-4 h-4 text-[#3b82f6]" />
          <span className="text-xs font-black text-white uppercase tracking-widest">
            REAL-TIME TELEMETRY AUDIT STREAM
          </span>
          <span className="w-2 h-2 rounded-full bg-[#3b82f6] animate-ping" />
        </div>

        {/* Controls */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsPaused(!isPaused)}
            className={`px-2.5 py-1 rounded text-[9px] font-bold uppercase flex items-center gap-1 border transition-all ${
              isPaused
                ? "bg-[#3b82f6] text-white border-[#3b82f6]"
                : "bg-[#1e293b] text-[#93c5fd] border-[#3b82f6]/30 hover:bg-[#3b82f6]/20"
            }`}
          >
            {isPaused ? <Play className="w-3 h-3" /> : <Pause className="w-3 h-3" />}
            <span>{isPaused ? "RESUME" : "FREEZE"}</span>
          </button>
          <button
            onClick={() => setLogs([])}
            className="p-1 rounded bg-[#1e293b] text-[#94a3b8] hover:text-white border border-[#1e293b] hover:border-[#3b82f6]/50 transition-all"
            title="Clear Console"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="mt-3 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2 text-[10px]">
        {/* Category Filter Pills */}
        <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0">
          {["ALL", "AUDIT", "ENGINE", "GATEWAY", "RISK"].map((cat) => (
            <button
              key={cat}
              onClick={() => setFilter(cat)}
              className={`px-2 py-0.5 rounded font-bold uppercase transition-all whitespace-nowrap ${
                filter === cat
                  ? "bg-[#3b82f6] text-white border border-[#3b82f6] shadow-[0_0_8px_rgba(59,130,246,0.4)]"
                  : "bg-[#080d16] text-[#64748b] border border-[#1e293b] hover:text-white"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="w-3 h-3 text-[#64748b] absolute left-2 top-2" />
          <input
            type="text"
            placeholder="Search trace / correlation..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="bg-[#080d16] border border-[#1e293b] rounded pl-7 pr-2 py-1 text-[10px] text-white placeholder-[#475569] focus:outline-none focus:border-[#3b82f6] w-full sm:w-48"
          />
        </div>
      </div>

      {/* Terminal Log Output Window */}
      <div
        ref={scrollRef}
        className="mt-3 bg-[#060a12] border border-[#1e293b] rounded-lg p-3 overflow-y-auto space-y-2 flex-1 max-h-[290px] text-[10px]"
      >
        {filteredLogs.length === 0 ? (
          <div className="text-[#64748b] text-center py-6">NO LOG EVENTS MATCHING CURRENT FILTER</div>
        ) : (
          filteredLogs.map((log) => (
            <div
              key={log.id}
              className="p-2 rounded bg-[#0b101b]/80 border border-[#1e293b]/60 hover:border-[#3b82f6]/40 transition-all font-mono leading-relaxed group"
            >
              <div className="flex flex-wrap items-center justify-between gap-1 text-[9px]">
                <div className="flex items-center gap-2">
                  <span className="text-[#64748b]">{log.timestamp}</span>
                  <span className="px-1.5 py-0.2 rounded bg-[#1e293b] text-[#93c5fd] font-bold uppercase">
                    {log.category}
                  </span>
                </div>
                <div className="flex items-center gap-2 text-[#64748b]">
                  <span>{log.latency}</span>
                  <span className="text-white font-bold">{log.correlationId}</span>
                </div>
              </div>
              <p className="mt-1 text-[#cbd5e1] group-hover:text-white transition-colors">
                {log.message}
              </p>
            </div>
          ))
        )}
      </div>

      {/* Stream Summary Footer */}
      <div className="mt-3 pt-2 border-t border-[#1e293b] flex items-center justify-between text-[9px] text-[#64748b]">
        <span>STATUS: <strong>SOCKET ONLINE</strong></span>
        <span>ENCRYPTED VIA <strong>AES-GCM-256</strong></span>
      </div>
    </div>
  );
};
