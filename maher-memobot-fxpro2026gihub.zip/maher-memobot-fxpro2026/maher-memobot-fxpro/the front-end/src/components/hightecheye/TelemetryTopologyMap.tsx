import React, { useEffect, useState } from "react";
import { Activity, Shield, Database, Cpu, ArrowRight, Zap, RefreshCw, CheckCircle2 } from "lucide-react";

interface NodeStatus {
  id: string;
  name: string;
  category: string;
  status: "OPTIMAL" | "NOMINAL" | "PROCESSING";
  latency: number;
  throughput: string;
  load: number;
  icon: any;
}

export const TelemetryTopologyMap: React.FC = () => {
  const [activeNode, setActiveNode] = useState<string>("engine");
  const [packetTick, setPacketTick] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setPacketTick((t) => (t + 1) % 100);
    }, 150);
    return () => clearInterval(interval);
  }, []);

  const nodes: NodeStatus[] = [
    {
      id: "vault",
      name: "VAULT PROTOCOL",
      category: "SECURITY LAYER",
      status: "OPTIMAL",
      latency: 0.12,
      throughput: "14.2 GB/s",
      load: 18,
      icon: Shield,
    },
    {
      id: "engine",
      name: "CORE MATCHING ENGINE",
      category: "QUANT EXECUTION",
      status: "OPTIMAL",
      latency: 0.18,
      throughput: "240k OPS",
      load: 32,
      icon: Zap,
    },
    {
      id: "gateway",
      name: "L2 GATEWAY ROUTER",
      category: "NETWORK INGRESS",
      status: "NOMINAL",
      latency: 0.45,
      throughput: "82.4 MB/s",
      load: 44,
      icon: Activity,
    },
    {
      id: "ledger",
      name: "IMMUTABLE LEDGER DB",
      category: "SQL PERSISTENCE",
      status: "OPTIMAL",
      latency: 0.85,
      throughput: "4,200 TPS",
      load: 28,
      icon: Database,
    },
    {
      id: "compliance",
      name: "SHARIAH AUDIT SENSOR",
      category: "INSTITUTIONAL",
      status: "OPTIMAL",
      latency: 0.14,
      throughput: "100% PASS",
      load: 12,
      icon: CheckCircle2,
    },
  ];

  const selectedNodeData = nodes.find((n) => n.id === activeNode) || nodes[1];

  return (
    <div className="bg-[#0b101b] border border-[#1e293b] rounded-lg p-4 font-mono shadow-[0_4px_24px_rgba(0,0,0,0.5)]">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between border-b border-[#1e293b] pb-3 gap-2">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-[#3b82f6] shadow-[0_0_8px_#3b82f6] animate-pulse" />
          <span className="text-xs font-black text-white uppercase tracking-widest">
            ACTIVE TOPOLOGY MESH // CROSS-LAYER PIPELINE
          </span>
        </div>
        <div className="flex items-center gap-3 text-[10px] text-[#94a3b8]">
          <span className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-[#60a5fa]" /> 5/5 NODES SYNCHRONIZED
          </span>
          <span className="px-2 py-0.5 rounded bg-[#1e293b]/60 border border-[#3b82f6]/30 text-[#93c5fd] font-bold">
            0.18ms AVG MESH PING
          </span>
        </div>
      </div>

      {/* Interactive Topology Diagram */}
      <div className="mt-4 grid grid-cols-1 lg:grid-cols-5 gap-3 relative">
        {nodes.map((node, idx) => {
          const isSelected = activeNode === node.id;
          const Icon = node.icon;
          return (
            <div
              key={node.id}
              onClick={() => setActiveNode(node.id)}
              className={`cursor-pointer rounded-lg p-3 border transition-all duration-200 relative overflow-hidden group ${
                isSelected
                  ? "bg-[#131d31] border-[#3b82f6] shadow-[0_0_18px_rgba(59,130,246,0.25)]"
                  : "bg-[#080d16] border-[#1e293b] hover:border-[#3b82f6]/50 hover:bg-[#0f172a]"
              }`}
            >
              {/* Dynamic Packet Flow Line in BG */}
              <div
                className="absolute inset-x-0 bottom-0 h-0.5 bg-gradient-to-r from-transparent via-[#3b82f6] to-transparent opacity-40 group-hover:opacity-100 transition-opacity"
                style={{
                  transform: `translateX(${(packetTick * 2) % 100 - 50}%)`,
                }}
              />

              <div className="flex items-start justify-between">
                <span className="text-[8px] text-[#64748b] font-black uppercase tracking-wider">
                  NODE 0{idx + 1}
                </span>
                <span
                  className={`w-2 h-2 rounded-full ${
                    node.status === "OPTIMAL" ? "bg-[#3b82f6] shadow-[0_0_6px_#3b82f6]" : "bg-[#93c5fd]"
                  }`}
                />
              </div>

              <div className="flex items-center gap-2 mt-2">
                <div
                  className={`p-1.5 rounded ${
                    isSelected ? "bg-[#3b82f6] text-white" : "bg-[#1e293b] text-[#93c5fd]"
                  }`}
                >
                  <Icon className="w-4 h-4" />
                </div>
                <div className="overflow-hidden">
                  <div className="text-[11px] font-bold text-white truncate">{node.name}</div>
                  <div className="text-[8px] text-[#94a3b8] uppercase truncate">{node.category}</div>
                </div>
              </div>

              <div className="mt-3 pt-2 border-t border-[#1e293b]/70 flex justify-between text-[9px]">
                <span className="text-[#64748b]">LATENCY:</span>
                <span className="text-white font-bold">{node.latency}ms</span>
              </div>
              <div className="flex justify-between text-[9px] mt-0.5">
                <span className="text-[#64748b]">LOAD:</span>
                <span className="text-white font-bold">{node.load}%</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Selected Node Deep-Dive Inspection Strip */}
      <div className="mt-4 bg-[#080d16] border border-[#1e293b] rounded-lg p-3 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
        <div>
          <span className="text-[8px] text-[#64748b] uppercase block">INSPECTED NODE</span>
          <span className="text-xs font-bold text-white uppercase">{selectedNodeData.name}</span>
        </div>
        <div>
          <span className="text-[8px] text-[#64748b] uppercase block">INSTANT THROUGHPUT</span>
          <span className="text-xs font-bold text-white">{selectedNodeData.throughput}</span>
        </div>
        <div>
          <span className="text-[8px] text-[#64748b] uppercase block">CRYPTO AUDIT STATE</span>
          <span className="text-xs font-bold text-white">AES-GCM-256 (SEALED)</span>
        </div>
        <div>
          <span className="text-[8px] text-[#64748b] uppercase block">FAILOVER REDUNDANCY</span>
          <span className="text-xs font-bold text-white">HOT STANDBY READY</span>
        </div>
      </div>
    </div>
  );
};
