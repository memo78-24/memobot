import React from "react";
import { Cpu, Server, Database, Gauge, Activity, Radio } from "lucide-react";

interface ObservabilityMetrics {
  cpu_usage_pct: number;
  ram_usage_pct: number;
  db_latency_ms: number;
  queue_depth: number;
  active_threads: number;
}

interface SystemGaugesProps {
  metrics: ObservabilityMetrics;
  winRate: number;
}

export const SystemGauges: React.FC<SystemGaugesProps> = ({ metrics, winRate }) => {
  // SVG Circular Gauge calculations
  const calculateStroke = (pct: number, radius: number) => {
    const circumference = 2 * Math.PI * radius;
    const strokeDashoffset = circumference - (pct / 100) * circumference;
    return { circumference, strokeDashoffset };
  };

  const cpuDash = calculateStroke(metrics.cpu_usage_pct, 28);
  const ramDash = calculateStroke(metrics.ram_usage_pct, 28);

  // Segmented latency bars
  const latencySegments = 16;
  const activeSegments = Math.min(latencySegments, Math.max(1, Math.round((metrics.db_latency_ms / 10) * latencySegments)));

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4 font-mono">
      {/* GAUGE 1: CPU EFFICIENCY */}
      <div className="bg-[#0b101b] border border-[#1e293b] rounded-lg p-4 relative overflow-hidden shadow-[0_4px_20px_rgba(0,0,0,0.4)]">
        <div className="flex justify-between items-start">
          <div>
            <span className="text-[9px] text-[#64748b] font-bold uppercase tracking-wider block">
              HOST CPU CORE EFFICIENCY
            </span>
            <div className="text-2xl font-black text-white mt-1">
              {metrics.cpu_usage_pct}%
            </div>
            <span className="text-[9px] text-[#93c5fd] font-bold uppercase block mt-0.5">
              16 CORES ACTIVE // NOMINAL
            </span>
          </div>
          {/* Circular SVG Gauge */}
          <div className="relative w-16 h-16 flex items-center justify-center shrink-0">
            <svg className="w-16 h-16 transform -rotate-90">
              <circle
                cx="32"
                cy="32"
                r="28"
                stroke="#1e293b"
                strokeWidth="4"
                fill="none"
              />
              <circle
                cx="32"
                cy="32"
                r="28"
                stroke="#3b82f6"
                strokeWidth="4"
                strokeDasharray={cpuDash.circumference}
                strokeDashoffset={cpuDash.strokeDashoffset}
                strokeLinecap="round"
                fill="none"
                className="transition-all duration-500 ease-out"
              />
            </svg>
            <Cpu className="w-4 h-4 text-[#93c5fd] absolute" />
          </div>
        </div>
        <div className="mt-3 pt-2.5 border-t border-[#1e293b] flex justify-between text-[8px] text-[#64748b]">
          <span>AVG CLOCK: 4.8 GHz</span>
          <span className="text-white font-bold">TEMP: 41.2°C</span>
        </div>
      </div>

      {/* GAUGE 2: JVM / RAM ALLOCATION */}
      <div className="bg-[#0b101b] border border-[#1e293b] rounded-lg p-4 relative overflow-hidden shadow-[0_4px_20px_rgba(0,0,0,0.4)]">
        <div className="flex justify-between items-start">
          <div>
            <span className="text-[9px] text-[#64748b] font-bold uppercase tracking-wider block">
              JVM / MEMORY BUFFER
            </span>
            <div className="text-2xl font-black text-white mt-1">
              {metrics.ram_usage_pct}%
            </div>
            <span className="text-[9px] text-[#93c5fd] font-bold uppercase block mt-0.5">
              21.8 GB ALLOCATED / 64 GB
            </span>
          </div>
          {/* Circular SVG Gauge */}
          <div className="relative w-16 h-16 flex items-center justify-center shrink-0">
            <svg className="w-16 h-16 transform -rotate-90">
              <circle
                cx="32"
                cy="32"
                r="28"
                stroke="#1e293b"
                strokeWidth="4"
                fill="none"
              />
              <circle
                cx="32"
                cy="32"
                r="28"
                stroke="#60a5fa"
                strokeWidth="4"
                strokeDasharray={ramDash.circumference}
                strokeDashoffset={ramDash.strokeDashoffset}
                strokeLinecap="round"
                fill="none"
                className="transition-all duration-500 ease-out"
              />
            </svg>
            <Server className="w-4 h-4 text-[#60a5fa] absolute" />
          </div>
        </div>
        <div className="mt-3 pt-2.5 border-t border-[#1e293b] flex justify-between text-[8px] text-[#64748b]">
          <span>GARBAGE COLLECTOR: ZGC</span>
          <span className="text-white font-bold">GC PAUSE: &lt; 1ms</span>
        </div>
      </div>

      {/* GAUGE 3: SQL LEDGER LATENCY OSCILLOSCOPE */}
      <div className="bg-[#0b101b] border border-[#1e293b] rounded-lg p-4 relative overflow-hidden shadow-[0_4px_20px_rgba(0,0,0,0.4)]">
        <div className="flex justify-between items-start">
          <div>
            <span className="text-[9px] text-[#64748b] font-bold uppercase tracking-wider block">
              SQL PERSISTENCE LATENCY
            </span>
            <div className="text-2xl font-black text-white mt-1">
              {metrics.db_latency_ms}ms
            </div>
            <span className="text-[9px] text-[#93c5fd] font-bold uppercase block mt-0.5">
              ZERO DRIFT INTENSITY
            </span>
          </div>
          <div className="p-2 rounded bg-[#1e293b] text-[#93c5fd]">
            <Database className="w-5 h-5" />
          </div>
        </div>

        {/* Segmented LED meter */}
        <div className="mt-3 space-y-1">
          <div className="flex items-center gap-1">
            {Array.from({ length: latencySegments }).map((_, idx) => (
              <div
                key={idx}
                className={`h-2 flex-1 rounded-xs transition-all ${
                  idx < activeSegments
                    ? "bg-[#3b82f6] shadow-[0_0_6px_#3b82f6]"
                    : "bg-[#1e293b]"
                }`}
              />
            ))}
          </div>
          <div className="flex justify-between text-[8px] text-[#64748b]">
            <span>0.1ms</span>
            <span className="text-white font-bold">CURRENT: {metrics.db_latency_ms}ms</span>
            <span>10ms MAX</span>
          </div>
        </div>
      </div>

      {/* GAUGE 4: QUANT EXECUTION WIN RATIO & QUEUE DEPTH */}
      <div className="bg-[#0b101b] border border-[#1e293b] rounded-lg p-4 relative overflow-hidden shadow-[0_4px_20px_rgba(0,0,0,0.4)]">
        <div className="flex justify-between items-start">
          <div>
            <span className="text-[9px] text-[#64748b] font-bold uppercase tracking-wider block">
              EXECUTION WIN RATE INDEX
            </span>
            <div className="text-2xl font-black text-white mt-1">
              {winRate.toFixed(1)}%
            </div>
            <span className="text-[9px] text-[#93c5fd] font-bold uppercase block mt-0.5">
              QUEUE DEPTH: {metrics.queue_depth} BUFFERED
            </span>
          </div>
          <div className="p-2 rounded bg-[#1e293b] text-[#3b82f6]">
            <Gauge className="w-5 h-5" />
          </div>
        </div>

        <div className="mt-3 pt-2.5 border-t border-[#1e293b] flex justify-between text-[8px] text-[#64748b]">
          <span>ACTIVE THREADS: {metrics.active_threads}</span>
          <span className="text-white font-bold">FILL RATIO: 99.98%</span>
        </div>
      </div>
    </div>
  );
};
