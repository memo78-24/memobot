import React from "react";
import { Play, Pause, Trash2, Twitter, Linkedin, MessageSquare, Send, Users, Shield, Mail, Phone, Instagram, Video, Facebook, MessageCircle } from "lucide-react";
import { SocialCampaign } from "../../types";

interface CampaignCardProps {
  campaign: SocialCampaign;
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
  onSelect: (campaign: SocialCampaign) => void;
}

export const CampaignCard: React.FC<CampaignCardProps> = ({
  campaign,
  onToggle,
  onDelete,
  onSelect
}) => {
  const getPlatformIcon = (platform: string) => {
    switch (platform) {
      case "Twitter/X":
        return <Twitter className="w-4 h-4 text-[#38bdf8]" />;
      case "LinkedIn":
        return <Linkedin className="w-4 h-4 text-[#0284c7]" />;
      case "Reddit":
        return <MessageSquare className="w-4 h-4 text-[#f97316]" />;
      case "Telegram":
        return <Send className="w-4 h-4 text-[#22d3ee]" />;
      case "WhatsApp":
        return <MessageCircle className="w-4 h-4 text-[#22c55e]" />;
      case "Email":
        return <Mail className="w-4 h-4 text-[#e2e8f0]" />;
      case "SMS":
        return <Phone className="w-4 h-4 text-[#fbbf24]" />;
      case "Instagram":
        return <Instagram className="w-4 h-4 text-[#ec4899]" />;
      case "TikTok":
        return <Video className="w-4 h-4 text-[#f43f5e]" />;
      case "Facebook":
        return <Facebook className="w-4 h-4 text-[#3b82f6]" />;
      default:
        return <Users className="w-4 h-4 text-[#a855f7]" />;
    }
  };

  const isActive = campaign.status === "Active";

  return (
    <div 
      className="relative flex flex-col justify-between p-4 h-[180px] select-none hover:scale-[1.01] transition-all duration-200 border-0 shadow-lg bg-[#02050c]/90"
      style={{
        clipPath: "polygon(10px 0px, calc(100% - 10px) 0px, 100% 10px, 100% calc(100% - 10px), calc(100% - 10px) 100%, 10px 100%, 0px calc(100% - 10px), 0px 10px)",
      }}
    >
      {/* 1px Dark Outline with Red Neon Accent */}
      <svg className="absolute inset-0 w-full h-full pointer-events-none z-30" viewBox="0 0 100 100" preserveAspectRatio="none">
        <polygon 
          points="4,1 96,1 99,4 99,96 96,99 4,99 1,96 1,4" 
          fill="none" 
          stroke={isActive ? "rgba(239, 68, 68, 0.45)" : "#1e293b"} 
          strokeWidth="1.2"
          className={isActive ? "animate-pulse" : ""}
        />
      </svg>

      {/* Campaign Header: Icon, Name and ID */}
      <div className="flex justify-between items-start z-10">
        <div className="flex items-center gap-2">
          <div className="p-1.5 bg-black/40 rounded border border-slate-900 flex items-center justify-center">
            {getPlatformIcon(campaign.platform)}
          </div>
          <div>
            <h4 className="text-[11px] font-black tracking-wider text-slate-100 uppercase truncate max-w-[130px]">
              {campaign.name}
            </h4>
            <span className="text-[6.5px] font-mono text-slate-500 block uppercase tracking-widest">
              ID: {campaign.id} | {campaign.type}
            </span>
          </div>
        </div>

        {/* Status Indicator */}
        <span className={`text-[7px] font-bold font-mono px-1.5 py-0.2 rounded border uppercase tracking-wider ${
          isActive 
            ? "border-emerald-500/30 text-emerald-400 bg-emerald-950/20" 
            : "border-slate-800 text-slate-500 bg-black/30"
        }`}>
          {campaign.status}
        </span>
      </div>

      {/* Target Audience details */}
      <div className="my-2 z-10">
        <span className="text-[5.5px] font-mono text-slate-500 uppercase tracking-wider block">TARGET COMPLIANT CHANNEL</span>
        <p className="text-[9px] font-bold text-[#22d3ee] truncate mt-0.5 uppercase tracking-wide">
          {campaign.targetAudience}
        </p>
      </div>

      {/* Metrics breakdown */}
      <div className="grid grid-cols-2 gap-2 my-1.5 z-10">
        <div className="bg-black/60 border border-slate-900/60 rounded p-1 text-center">
          <span className="text-[5px] font-mono text-slate-500 uppercase block tracking-wider">APPROACHES</span>
          <span className="text-[10px] font-mono font-black text-slate-200">
            {campaign.generatedApproachesCount}
          </span>
        </div>
        <div className="bg-black/60 border border-slate-900/60 rounded p-1 text-center">
          <span className="text-[5px] font-mono text-slate-500 uppercase block tracking-wider">SUCCESS RATE</span>
          <span className="text-[10px] font-mono font-black text-rose-500">
            {campaign.successRate}%
          </span>
        </div>
      </div>

      {/* Interaction Actions */}
      <div className="flex justify-between items-center pt-2 border-t border-slate-900/50 z-10">
        <button
          onClick={() => onSelect(campaign)}
          className="text-[7.5px] font-mono font-black text-red-500 hover:text-red-400 uppercase tracking-widest cursor-pointer flex items-center gap-1"
        >
          <Shield className="w-2.5 h-2.5 text-red-500 animate-pulse" /> GENERATE OUTBOUND
        </button>

        <div className="flex items-center gap-2">
          {/* Play/Pause toggle */}
          <button
            onClick={() => onToggle(campaign.id)}
            className={`p-1 rounded bg-black/40 border border-slate-900 hover:bg-slate-950 hover:text-white transition-all cursor-pointer`}
            title={isActive ? "Pause" : "Activate"}
          >
            {isActive ? <Pause className="w-2.5 h-2.5 text-slate-400" /> : <Play className="w-2.5 h-2.5 text-emerald-400" />}
          </button>

          {/* Delete */}
          <button
            onClick={() => onDelete(campaign.id)}
            className="p-1 rounded bg-black/40 border border-slate-900 hover:bg-red-950 hover:text-red-400 text-slate-500 transition-all cursor-pointer"
            title="Delete"
          >
            <Trash2 className="w-2.5 h-2.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
export default CampaignCard;
