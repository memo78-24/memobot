import React from "react";
import { WingsData, Engine } from "../services/engineStore";

interface WingsIntelligenceProps {
  wingsData: Record<string, WingsData>;
  engines: Record<string, Engine>;
}

export const WingsIntelligence: React.FC<WingsIntelligenceProps> = ({ wingsData, engines }) => {
  const getAssetData = (asset: string) => {
    const data = wingsData[asset];
    const buyPressure = data?.buy_pressure || 50.0;
    const sellPressure = parseFloat((100 - buyPressure).toFixed(1));
    const bids = data?.bids && data.bids.length >= 4 ? data.bids.slice(0, 4) : [];
    const asks = data?.asks && data.asks.length >= 4 ? data.asks.slice(0, 4) : [];
    return { buyPressure, sellPressure, bids, asks };
  };

  const engineList = [
    {
      id: "ENG-001",
      name: "RIGEL (LAM000R)",
      asset: engines["ENG-001"]?.asset || "BTCUSDT",
      status: engines["ENG-001"]?.status || "Stopped",
      color: "#b3e0ff"
    },
    {
      id: "ENG-002",
      name: "SIRIUS (L000L)",
      asset: engines["ENG-002"]?.asset || "ETHUSDT",
      status: engines["ENG-002"]?.status || "Stopped",
      color: "#ffffff"
    },
    {
      id: "ENG-003",
      name: "CANOPUS (OOOKA)",
      asset: engines["ENG-003"]?.asset || "SOLUSDT",
      status: engines["ENG-003"]?.status || "Stopped",
      color: "#fff8d6"
    }
  ];

  // Helper to render segmented pressure bar (12 blocks)
  const renderSegmentedBar = (percentage: number, color: string) => {
    const totalBlocks = 12;
    const filledBlocks = Math.round((percentage / 100) * totalBlocks);

    return (
      <div className="flex gap-1 h-2 w-full my-2">
        {Array.from({ length: totalBlocks }).map((_, idx) => (
          <div
            key={idx}
            className="flex-1 h-full rounded-xs transition-all"
            style={{
              backgroundColor: idx < filledBlocks ? color : "#11131c"
            }}
          />
        ))}
      </div>
    );
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 font-mono text-xs select-none">
      
      {/* ==========================================
          LEFT WING: BUY-SIDE INTELLIGENCE
          ========================================== */}
      <div className="bg-[#06070a] border border-[#00e676]/30 border-t-2 border-t-[#00e676] rounded overflow-hidden shadow-[0_0_20px_rgba(0,230,118,0.05)] flex flex-col">
        {/* Wing Header */}
        <div className="bg-[#090a0d] px-4 py-2.5 border-b border-[#11131c] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#00e676] animate-pulse" />
            <h3 className="text-[11px] font-black text-white uppercase tracking-wider">
              LEFT WING: BUY-SIDE INTELLIGENCE
            </h3>
          </div>
          <span className="w-1.5 h-1.5 rounded-full bg-[#00e676]" />
        </div>

        {/* Engine Cards inside Left Wing */}
        <div className="p-4 space-y-6">
          {engineList.map((eng) => {
            const isRunning = engines[eng.id]?.status === "Running";
            const { buyPressure, bids } = isRunning ? getAssetData(eng.asset) : { buyPressure: 0, bids: [] };
            const baseAsset = eng.asset.replace("USDT", "");

            return (
              <div key={eng.id} className="bg-[#090a0d] border border-[#11131c] rounded p-4 mb-4 last:mb-0 space-y-3 relative overflow-hidden" style={{ borderColor: `${eng.color}20` }}>
                {/* Engine color top glow */}
                <div className="absolute top-0 left-0 w-full h-1" style={{ backgroundColor: eng.color, opacity: 0.8 }} />
                <div className="absolute top-0 left-0 w-full h-16 pointer-events-none" style={{ background: `linear-gradient(to bottom, ${eng.color}20, transparent)` }} />
                
                {/* Engine Title & Symbol */}
                <div className="flex justify-between items-center">
                  <span className="font-black text-xs uppercase" style={{ color: eng.color }}>{eng.name}</span>
                  <span className="text-[10px] text-[#6b6f77] font-bold uppercase">{eng.asset}</span>
                </div>

                {/* Order Book Buy Pressure */}
                <div className="space-y-1">
                  <span className="text-[9px] text-[#6b6f77] font-black uppercase tracking-wider block">
                    ORDER BOOK BUY PRESSURE
                  </span>
                  <div className="text-sm font-black" style={{ color: eng.color }}>{buyPressure}%</div>
                  {renderSegmentedBar(buyPressure, eng.color)}
                </div>

                {/* Live Bid Depth (Buy Walls) */}
                <div className="space-y-1 pt-1">
                  <span className="text-[9px] text-[#6b6f77] font-black uppercase tracking-wider block">
                    LIVE BID DEPTH (BUY WALLS)
                  </span>
                  <div className="space-y-1 text-[10px]">
                    {bids.map((bid, idx) => (
                      <div key={idx} className="flex justify-between items-center py-0.5">
                        <span className="font-bold" style={{ color: eng.color }}>{baseAsset} BID #{idx + 1}</span>
                        <span className="text-white font-bold">${(bid[0] ?? 0).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                        <span className="text-[#6b6f77] font-semibold">{bid[1].toFixed(4)} {baseAsset}</span>
                      </div>
                    ))}
                    {bids.length === 0 && <div className="text-[#6b6f77] italic py-1">Awaiting sensor data...</div>}
                  </div>
                </div>

                {/* Active Long Positions */}
                <div className="space-y-1 pt-1">
                  <span className="text-[9px] text-[#6b6f77] font-black uppercase tracking-wider block">
                    ACTIVE LONG POSITIONS
                  </span>
                  <p className="text-[10px] text-white italic font-serif">
                    {eng.status === "Running" ? `Active Long tracking ${baseAsset} @ market` : "No active Long positions."}
                  </p>
                </div>

                {/* Buy-Side Signals Ticker */}
                <div className="space-y-1 pt-1">
                  <span className="text-[9px] text-[#6b6f77] font-black uppercase tracking-wider block">
                    BUY-SIDE SIGNALS TICKER
                  </span>
                  <div className="space-y-1 text-[9px] text-[#6b6f77]">
                    <div className="flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 shrink-0" style={{ backgroundColor: eng.color }} />
                      <span>Swarm sentiment indicates {buyPressure > 50 ? "bullish accumulation" : "bearish resistance"}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 shrink-0" style={{ backgroundColor: eng.color }} />
                      <span>Volatility range compliant for execution</span>
                    </div>
                  </div>
                </div>

              </div>
            );
          })}
        </div>
      </div>

      {/* ==========================================
          RIGHT WING: SELL-SIDE INTELLIGENCE
          ========================================== */}
      <div className="bg-[#06070a] border border-[#FA1F4E]/30 border-t-2 border-t-[#FA1F4E] rounded overflow-hidden shadow-[0_0_20px_rgba(250,31,78,0.05)] flex flex-col">
        {/* Wing Header */}
        <div className="bg-[#090a0d] px-4 py-2.5 border-b border-[#11131c] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#FA1F4E] animate-pulse" />
            <h3 className="text-[11px] font-black text-white uppercase tracking-wider">
              RIGHT WING: SELL-SIDE INTELLIGENCE
            </h3>
          </div>
          <span className="w-1.5 h-1.5 rounded-full bg-[#FA1F4E]" />
        </div>

        {/* Engine Cards inside Right Wing */}
        <div className="p-4 space-y-6">
          {engineList.map((eng) => {
            const isRunning = engines[eng.id]?.status === "Running";
            const { sellPressure, asks, buyPressure } = isRunning ? getAssetData(eng.asset) : { sellPressure: 0, asks: [], buyPressure: 0 };
            const baseAsset = eng.asset.replace("USDT", "");

            return (
              <div key={eng.id} className="bg-[#090a0d] border border-[#11131c] rounded p-4 mb-4 last:mb-0 space-y-3 relative overflow-hidden" style={{ borderColor: `${eng.color}20` }}>
                {/* Engine color top glow */}
                <div className="absolute top-0 left-0 w-full h-1" style={{ backgroundColor: eng.color, opacity: 0.8 }} />
                <div className="absolute top-0 left-0 w-full h-16 pointer-events-none" style={{ background: `linear-gradient(to bottom, ${eng.color}20, transparent)` }} />
                
                {/* Engine Title & Symbol */}
                <div className="flex justify-between items-center">
                  <span className="font-black text-xs uppercase" style={{ color: eng.color }}>{eng.name}</span>
                  <span className="text-[10px] text-[#6b6f77] font-bold uppercase">{eng.asset}</span>
                </div>

                {/* Order Book Sell Pressure */}
                <div className="space-y-1">
                  <span className="text-[9px] text-[#6b6f77] font-black uppercase tracking-wider block">
                    ORDER BOOK SELL PRESSURE
                  </span>
                  <div className="text-sm font-black" style={{ color: eng.color }}>{sellPressure}%</div>
                  {renderSegmentedBar(sellPressure, eng.color)}
                </div>

                {/* Live Ask Depth (Sell Walls) */}
                <div className="space-y-1 pt-1">
                  <span className="text-[9px] text-[#6b6f77] font-black uppercase tracking-wider block">
                    LIVE ASK DEPTH (SELL WALLS)
                  </span>
                  <div className="space-y-1 text-[10px]">
                    {asks.map((ask, idx) => (
                      <div key={idx} className="flex justify-between items-center py-0.5">
                        <span className="font-bold" style={{ color: eng.color }}>{baseAsset} ASK #{idx + 1}</span>
                        <span className="text-white font-bold">${(ask[0] ?? 0).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                        <span className="text-[#6b6f77] font-semibold">{ask[1].toFixed(4)} {baseAsset}</span>
                      </div>
                    ))}
                    {asks.length === 0 && <div className="text-[#6b6f77] italic py-1">Awaiting sensor data...</div>}
                  </div>
                </div>

                {/* Active Short Positions */}
                <div className="space-y-1 pt-1">
                  <span className="text-[9px] text-[#6b6f77] font-black uppercase tracking-wider block">
                    ACTIVE SHORT POSITIONS
                  </span>
                  <p className="text-[10px] text-white italic font-serif">
                    No active Short positions.
                  </p>
                </div>

                {/* Sell-Side Signals Ticker */}
                <div className="space-y-1 pt-1">
                  <span className="text-[9px] text-[#6b6f77] font-black uppercase tracking-wider block">
                    SELL-SIDE SIGNALS TICKER
                  </span>
                  <div className="space-y-1 text-[9px] text-[#6b6f77]">
                    <div className="flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 shrink-0" style={{ backgroundColor: eng.color }} />
                      <span>{baseAsset} {buyPressure > 50 ? "Buy" : "Sell"} Pressure dominant ({buyPressure > 50 ? buyPressure : sellPressure}%)</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 shrink-0" style={{ backgroundColor: eng.color }} />
                      <span>Swarm indicators confirming {buyPressure > 50 ? "long" : "short"} consensus</span>
                    </div>
                  </div>
                </div>

              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
};

export default WingsIntelligence;
