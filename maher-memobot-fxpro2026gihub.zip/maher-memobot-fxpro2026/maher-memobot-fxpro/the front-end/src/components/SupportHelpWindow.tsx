import React, { useState, useEffect, useRef } from "react";
import { ApiClient } from "../services/api";
import { VoiceInputButton } from "./VoiceInputButton";
import { SupportCrmConsole } from "./SupportCrmConsole";
import { MemoBotIcon } from "./MemoBotIcon";
import { useNotification } from "./NotificationProvider";
import {
  LifeBuoy,
  Send,
  User,
  Activity,
  Cpu,
  RefreshCw,
  X,
  ShieldCheck,
  Zap,
  Terminal,
  Clock,
  CheckCircle2,
  AlertCircle,
  FileText,
  MessageSquare
} from "lucide-react";

interface SupportMessage {
  id: string;
  role: "user" | "ai";
  text: string;
  timestamp: string;
  agentName?: string;
}

interface SupportHelpWindowProps {
  isOpen: boolean;
  onClose: () => void;
  currentRoute?: string;
  complianceMode?: "Islamic" | "Commercial";
  wsStatus?: "CONNECTED" | "DISCONNECTED";
}

export const SupportHelpWindow: React.FC<SupportHelpWindowProps> = ({
  isOpen,
  onClose,
  currentRoute = "dashboard",
  complianceMode = "Islamic",
  wsStatus = "CONNECTED"
}) => {
  const { showAlert } = useNotification();
  const [activeView, setActiveView] = useState<"CHAT" | "TICKETS">("CHAT");
  const [messages, setMessages] = useState<SupportMessage[]>([
    {
      id: "supp-init-1",
      role: "ai",
      text: "Salam Alaykum. I am the MEMOBOT FX-PRO Operations Support Co-Pilot.\n\n• Verified Architecture: 1:1 Spot physical allocations (AAOIFI Standard No. 21/59) & AES-256 vault security.\n• State Synced: Active Page [" + currentRoute.toUpperCase() + "] • Compliance [" + complianceMode + " Mode].\n\nHow can our operations desk assist your trading workflow?",
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      agentName: "Eng. Adnan Al-Harbi"
    }
  ]);
  const [inputMessage, setInputMessage] = useState("");
  const [sending, setSending] = useState(false);
  const [diagnosticsRunning, setDiagnosticsRunning] = useState(false);
  const [systemTelemetry, setSystemTelemetry] = useState({
    cpu: "3.4%",
    ram: "29.1%",
    latency: "19ms",
    wsSync: "100% OK"
  });

  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages, isOpen, sending]);

  if (!isOpen) return null;

  const handleSendMessage = async (customPrompt?: string) => {
    const textToSend = (customPrompt || inputMessage).trim();
    if (!textToSend || sending) return;

    setInputMessage("");
    setSending(true);

    const userMsg: SupportMessage = {
      id: `usr-${Date.now()}`,
      role: "user",
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    };

    setMessages((prev) => [...prev, userMsg]);

    try {
      const response = await ApiClient.post("/ai/support", {
        message: textToSend,
        systemStats: systemTelemetry,
        context: {
          activeTab: currentRoute,
          complianceMode: complianceMode === "Islamic" ? "Islamic Spot 1x" : "Commercial Unrestricted",
          wsStatus
        }
      });

      const aiMsg: SupportMessage = {
        id: `ai-${Date.now()}`,
        role: "ai",
        text: response.response || "Logged with operations team.",
        agentName: response.agentName || "Eng. Adnan Al-Harbi",
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
      };

      setMessages((prev) => [...prev, aiMsg]);
    } catch (err: any) {
      setMessages((prev) => [
        ...prev,
        {
          id: `err-${Date.now()}`,
          role: "ai",
          text: `Support Service Note: ${err.message || "Operating in offline telemetry mode."}`,
          agentName: "Operations Desk",
          timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
        }
      ]);
    } finally {
      setSending(false);
    }
  };

  const handleRunDiagnostics = () => {
    setDiagnosticsRunning(true);
    showAlert("Running institutional system telemetry scan...");

    setTimeout(() => {
      const updated = {
        cpu: `${(2.8 + Math.random() * 2).toFixed(1)}%`,
        ram: `${(28 + Math.random() * 4).toFixed(1)}%`,
        latency: `${Math.floor(14 + Math.random() * 12)}ms`,
        wsSync: "STABLE (0% Jitter)"
      };
      setSystemTelemetry(updated);
      setDiagnosticsRunning(false);

      handleSendMessage(
        `[DIAGNOSTIC TELEMETRY REPORT] Latency: ${updated.latency}, CPU: ${updated.cpu}, RAM: ${updated.ram}. Please verify system health and report any anomalies.`
      );
    }, 1000);
  };

  const quickShortcuts = [
    { label: "WebSocket Sync Check", query: "Check WebSocket heartbeat latency and confirm cluster stream stability." },
    { label: "AAOIFI Spot 1x Verification", query: "Verify that all open orders adhere to AAOIFI Standard No. 21 and 59 without naked leverage." },
    { label: "Exchange API Geo-Restrictions", query: "Troubleshoot potential HTTP 451 geo-restrictions on Binance API and suggest Paper Trading shift." },
    { label: "AES-256 Vault KMS Status", query: "Audit AES-256 vault credentials and KMS Ed25519 signing signatures." }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-sm animate-fade-in font-mono select-none">
      <div className="bg-[#07080c] border border-[#1e2330] rounded-xl w-full max-w-5xl h-[92vh] max-h-[850px] flex flex-col shadow-[0_0_50px_rgba(0,230,118,0.15)] overflow-hidden">
        
        {/* TOP BAR */}
        <div className="h-14 bg-[#0c0e14] border-b border-[#1a1d26] px-4 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-[#00e676]/10 border border-[#00e676]/30 flex items-center justify-center">
              <LifeBuoy className="w-4 h-4 text-[#00e676] animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-white font-black text-xs tracking-wider">MEMOBOT FX-PRO • OPERATIONS SERVICE DESK</span>
                <span className="px-1.5 py-0.2 bg-[#00e676]/15 text-[#00e676] border border-[#00e676]/30 text-[8px] font-bold rounded">
                  TIER-1 SUPPORT
                </span>
              </div>
              <p className="text-[9px] text-[#8a8d9a]">Institutional Technical Operations & Zero-Trust Resolution Hub</p>
            </div>
          </div>

          {/* VIEW TOGGLES & CLOSE */}
          <div className="flex items-center gap-2">
            <div className="bg-[#06070a] border border-[#1a1d26] rounded p-0.5 flex items-center">
              <button
                onClick={() => setActiveView("CHAT")}
                className={`px-3 py-1 text-[10px] font-bold rounded transition-all cursor-pointer flex items-center gap-1.5 ${
                  activeView === "CHAT"
                    ? "bg-[#00e676] text-black"
                    : "text-[#8a8d9a] hover:text-white"
                }`}
              >
                <MessageSquare className="w-3 h-3" />
                AI ASSISTANT
              </button>
              <button
                onClick={() => setActiveView("TICKETS")}
                className={`px-3 py-1 text-[10px] font-bold rounded transition-all cursor-pointer flex items-center gap-1.5 ${
                  activeView === "TICKETS"
                    ? "bg-[#3b82f6] text-white"
                    : "text-[#8a8d9a] hover:text-white"
                }`}
              >
                <FileText className="w-3 h-3" />
                INCIDENT CRM
              </button>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 rounded hover:bg-[#161822] text-[#8a8d9a] hover:text-white border border-[#1a1d26] transition-colors cursor-pointer ml-1"
              title="Close Support Window"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* TELEMETRY & CONTEXT SUB-BAR */}
        <div className="bg-[#090b10] border-b border-[#141620] px-4 py-2 flex flex-wrap items-center justify-between gap-2 text-[9px] text-[#8a8d9a]">
          <div className="flex items-center gap-3">
            <span>ROUTE: <strong className="text-white uppercase">{currentRoute}</strong></span>
            <span>•</span>
            <span className="flex items-center gap-1">
              COMPLIANCE: 
              <strong className={complianceMode === "Islamic" ? "text-[#00e676]" : "text-sky-400"}>
                {complianceMode === "Islamic" ? "ISLAMIC SPOT 1X" : "COMMERCIAL"}
              </strong>
            </span>
            <span>•</span>
            <span>WS: <strong className={wsStatus === "CONNECTED" ? "text-[#00e676]" : "text-red-400"}>{wsStatus}</strong></span>
          </div>

          <div className="flex items-center gap-3">
            <span>CPU: <strong className="text-white">{systemTelemetry.cpu}</strong></span>
            <span>RAM: <strong className="text-white">{systemTelemetry.ram}</strong></span>
            <span>LATENCY: <strong className="text-[#00e676]">{systemTelemetry.latency}</strong></span>
            <button
              onClick={handleRunDiagnostics}
              disabled={diagnosticsRunning}
              className="px-2 py-0.5 bg-[#121622] hover:bg-[#00e676]/20 border border-[#00e676]/30 text-[#00e676] rounded font-bold transition-all flex items-center gap-1 cursor-pointer disabled:opacity-50"
            >
              <Activity className="w-2.5 h-2.5 animate-pulse" />
              {diagnosticsRunning ? "SAMPLING..." : "DIAGNOSTIC SCAN"}
            </button>
          </div>
        </div>

        {/* CONTENT AREA */}
        {activeView === "CHAT" ? (
          <div className="flex-1 flex flex-col min-h-0 bg-[#06070a]">
            {/* MESSAGES SCROLLER */}
            <div className="flex-1 p-4 overflow-y-auto space-y-4 text-xs leading-relaxed">
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex gap-3 max-w-[90%] md:max-w-[80%] ${
                    msg.role === "user" ? "ml-auto flex-row-reverse" : "mr-auto"
                  }`}
                >
                  <div
                    className={`w-8 h-8 rounded-lg shrink-0 flex items-center justify-center font-bold border ${
                      msg.role === "user"
                        ? "bg-[#3b82f6]/10 text-[#3b82f6] border-[#3b82f6]/40"
                        : "bg-[#00e676]/10 text-[#00e676] border-[#00e676]/40"
                    }`}
                  >
                    {msg.role === "user" ? <User className="w-4 h-4" /> : <MemoBotIcon size={16} color="#00e676" />}
                  </div>

                  <div className="space-y-1.5 flex-1">
                    <div className="flex items-center justify-between text-[9px] text-[#8a8d9a]">
                      <span className="font-bold uppercase tracking-wider">
                        {msg.role === "user" ? "TACTICAL OPERATOR" : msg.agentName || "OPERATIONS SERVICE DESK"}
                      </span>
                      <span>{msg.timestamp}</span>
                    </div>

                    <div
                      className={`p-3.5 rounded-lg border leading-relaxed space-y-2 ${
                        msg.role === "user"
                          ? "bg-[#12161f] border-[#1e2330] text-white"
                          : "bg-[#0c0e14] border-[#1a1d26] text-[#e2e8f0]"
                      }`}
                    >
                      <p className="whitespace-pre-wrap">{msg.text}</p>
                    </div>
                  </div>
                </div>
              ))}

              {sending && (
                <div className="flex gap-3 max-w-[80%] mr-auto items-center">
                  <div className="w-8 h-8 rounded-lg shrink-0 flex items-center justify-center bg-[#00e676]/10 border border-[#00e676]/40 text-[#00e676]">
                    <Cpu className="w-4 h-4 animate-spin" />
                  </div>
                  <div className="p-3 bg-[#0c0e14] border border-[#1a1d26] rounded-lg text-[10px] text-[#00e676] flex items-center gap-2">
                    <RefreshCw className="w-3 h-3 animate-spin" />
                    <span>OPERATIONS CO-PILOT ANALYZING CONTEXT & RESOLUTION MATRICES...</span>
                  </div>
                </div>
              )}
              <div ref={chatEndRef} />
            </div>

            {/* QUICK SHORTCUTS */}
            <div className="p-2 bg-[#090b10] border-t border-[#141620] flex items-center gap-2 overflow-x-auto text-[9.5px]">
              <span className="text-[#8a8d9a] font-bold uppercase shrink-0 flex items-center gap-1">
                <Terminal className="w-3 h-3 text-[#00e676]" />
                TRIAGE DIRECTIVES:
              </span>
              {quickShortcuts.map((item, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSendMessage(item.query)}
                  disabled={sending}
                  className="px-2.5 py-1 bg-[#0c0e14] hover:bg-[#151822] border border-[#1a1d26] text-[#8a8d9a] hover:text-white rounded whitespace-nowrap transition-all cursor-pointer font-mono text-[9px]"
                >
                  {item.label}
                </button>
              ))}
            </div>

            {/* INPUT FORM WITH VOICE TRANSCRIPTION */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage();
              }}
              className="p-3 bg-[#0a0c12] border-t border-[#1a1d26] flex items-center gap-2 shrink-0"
            >
              {/* Voice Transcription Button via gemini-3.5-transcribe */}
              <VoiceInputButton
                onTranscribe={(transcribedText) => {
                  setInputMessage((prev) => (prev ? `${prev} ${transcribedText}` : transcribedText));
                }}
                disabled={sending}
                buttonLabel="MIC"
              />

              <input
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                placeholder="Ask technical support or speak via microphone (e.g. WebSocket latency, Shariah audit, API keys)..."
                className="flex-1 bg-[#06070a] border border-[#1a1d26] focus:border-[#00e676] text-white px-3.5 py-2.5 rounded-lg outline-none font-mono text-xs"
              />

              <button
                type="submit"
                disabled={sending || !inputMessage.trim()}
                className="px-4 py-2.5 bg-[#00e676] hover:bg-[#00c965] text-black font-extrabold rounded-lg text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 disabled:opacity-50 cursor-pointer"
              >
                <Send className="w-4 h-4" />
                <span>SEND</span>
              </button>
            </form>
          </div>
        ) : (
          <div className="flex-1 p-4 overflow-y-auto bg-[#06070a]">
            <SupportCrmConsole showAlert={showAlert} />
          </div>
        )}

      </div>
    </div>
  );
};
