# ⚡ MEMOCORE™ Quick Payment Bench — Drop-In Integration Guide

This package provides the exact cyberpunk **MEMOCORE™ Quick Payment Bench** UI shown on your main interface, fully configured for:
- **Daily ($3)**, **Weekly ($18)**, and **Monthly ($50)** subscription tiers.
- **Crypto USDT (TRC-20 / ERC-20 / BEP-20)** direct wallet payments with one-click copy and on-chain TX Hash verification.
- **Card / Apple Pay / Google Pay / PayPal** checkout triggers.
- Responsive Tailwind CSS / pure React 18+ TypeScript structure with zero heavy external dependencies.

---

## 🚀 How to Add to Your "MemoCore" Website

### Option 1: React / Next.js Component (TypeScript)
1. Copy the file `/src/components/exportable/MemoCoreSubscriptionBench.tsx` directly into your MemoCore components directory (e.g. `src/components/MemoCoreSubscriptionBench.tsx`).
2. Import and place it inside your page:

```tsx
import { MemoCorePaymentBench } from "./components/MemoCoreSubscriptionBench";

export default function MemoCorePage() {
  return (
    <div className="min-h-screen bg-[#020306] flex items-center justify-center p-4">
      <MemoCorePaymentBench 
        trc20Address="YOUR_ACTUAL_TRC20_USDT_WALLET_HERE"
        erc20Address="YOUR_ACTUAL_ERC20_USDT_WALLET_HERE"
        onSuccess={(plan, txHash) => {
          console.log(`Plan ${plan} paid with TX: ${txHash}`);
        }}
      />
    </div>
  );
}
```

---

### Option 2: Standalone HTML / Vanilla JS (No Framework Required)
If your MemoCore site is built with pure HTML/CSS/JS, you can open or embed `/public/memocore-payment-bench.html` directly in an `<iframe>` or copy its raw HTML + CSS blocks!

---

## 🔒 Treasury & Receiving Wallets Note
You can customize the receiving USDT wallet address anytime directly inside:
- **MemoBot Settings ➔ Subscription & Fees ➔ Personal Payout Treasury**
- Or by passing `trc20Address="YOUR_ADDRESS"` prop to the component!
