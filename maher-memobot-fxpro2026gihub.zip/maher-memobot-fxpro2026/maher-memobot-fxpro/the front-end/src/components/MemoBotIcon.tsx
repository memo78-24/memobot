import React from "react";

export interface MemoBotIconProps extends React.SVGProps<SVGSVGElement> {
  size?: number | string;
  color?: string;
  strokeWidth?: number | string;
  glow?: boolean;
}

export const MemoBotIcon: React.FC<MemoBotIconProps> = ({
  size = 20,
  color = "currentColor",
  strokeWidth = 2,
  glow = false,
  className = "",
  ...props
}) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke={color}
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={`${glow ? "drop-shadow-[0_0_8px_rgba(250,31,78,0.6)]" : ""} transition-all ${className}`}
      {...props}
    >
      {/* Precision Geometric Outlined M Icon */}
      <path d="M3 20V4l9 8 9-8v16" />
      <path d="M3 4l9 8 9-8" />
      <path d="M1.5 20h3M19.5 20h3" />
      <circle cx="12" cy="12" r="1.2" fill={color} stroke="none" />
    </svg>
  );
};

export default MemoBotIcon;
