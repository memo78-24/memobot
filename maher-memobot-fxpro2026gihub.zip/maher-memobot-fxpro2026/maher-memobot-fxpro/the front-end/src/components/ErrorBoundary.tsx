import React, { ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends React.Component<Props, State> {
  public props!: Props;
  public state: State = {
    hasError: false,
    error: null,
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('HighTechEye System Error:', error, errorInfo);
    fetch('/api/log', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ message: error.message, stack: error.stack, componentStack: errorInfo.componentStack }) }).catch(() => {});
  }

  private handleClearCache = () => {
    localStorage.clear();
    sessionStorage.clear();
    window.location.reload();
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#06070a] flex items-center justify-center p-6 text-[#8a8d9a]">
          <div className="max-w-lg w-full bg-[#0d0e12] border border-[#FA1F4E]/30 p-8 rounded-lg shadow-2xl panel-glow">
            <div className="flex items-center gap-4 mb-6">
              <div className="p-3 bg-[#FA1F4E]/10 rounded-full border border-[#FA1F4E]/30">
                <AlertTriangle className="w-8 h-8 text-[#FA1F4E]" />
              </div>
              <h1 className="text-xl font-extrabold text-white uppercase tracking-wider font-mono">
                System Critical Failure
              </h1>
            </div>
            
            <p className="text-sm font-mono text-[#8a8d9a] mb-6 leading-relaxed">
              HighTechEye telemetry engine has encountered a terminal state. 
              Component rendering aborted to maintain system integrity.
            </p>

            <div className="bg-[#06070a] p-4 rounded border border-[#1a1d26] mb-8">
              <p className="text-[10px] font-mono text-[#3b82f6] uppercase font-bold mb-2">
                Traceback Log
              </p>
              <pre className="text-[10px] text-white font-mono overflow-x-auto whitespace-pre-wrap">
                {this.state.error?.message || 'Unknown system error'}
              </pre>
            </div>

            <button
              onClick={this.handleClearCache}
              className="w-full py-3 bg-[#FA1F4E]/10 hover:bg-[#FA1F4E]/20 border border-[#FA1F4E]/40 text-[#FA1F4E] rounded text-xs font-bold uppercase tracking-widest transition-all flex items-center justify-center gap-2"
            >
              <RefreshCw className="w-4 h-4" />
              Clear System Cache & Reboot
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
