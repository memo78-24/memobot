import React from "react";
import { Play, Square, ShoppingCart, Terminal, Zap, ShieldAlert, Cpu } from "lucide-react";

interface HologramPanelProps {
  isOpen: boolean;
  onClose: () => void;
  selectedEngineId: string;
  selectedEngine: {
    nickname?: string;
    display_name?: string;
    status?: string;
    strategy?: string;
    asset?: string;
  };
  localConfig: { strategy: string; asset: string; amount: number; leverage: number };
  onUpdateConfig: (field: string, value: any) => void;
  onApplyConfig: () => void;
  savingState: boolean;
  saveMessage: string | null;
  handleStartStop: (id: string, status: string) => void;
  handleManualTrade: (side: "BUY" | "SELL") => void;
  logs: string[];
  powerOn: boolean;
}

const MANUAL_IDS = ["MEMOCODEX", "ENG-009", "ENG-003", "MEMOBOT"];

export const HologramPanel: React.FC<HologramPanelProps> = ({
  selectedEngineId,
  selectedEngine,
  localConfig,
  onUpdateConfig,
  onApplyConfig,
  savingState,
  saveMessage,
  handleStartStop,
  handleManualTrade,
  logs,
  powerOn,
}) => {
  const isRunning = selectedEngine.status === "Running";
  const isManual = MANUAL_IDS.includes(selectedEngineId);

  // Calculate matching dynamic LED bar values synchronized with individual engine cards
  const cleanIdNum = Number(selectedEngineId.replace(/\D/g, "")) || 5;
  const leftPercentage = Math.floor(10 + cleanIdNum * 7.5) % 100;
  const rightPercentage = (leftPercentage + 25) % 100;

  return (
    <div 
      id="giant-engine-panel"
      className="relative transition-all duration-300 flex overflow-hidden w-full select-none border border-[#0d1017] bg-[#05070c] rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.95)]"
    >
      {/* Precision Obsidian Outer Border with Subtle Cyan & Crimson Accent Edge */}
      <div className="absolute inset-0 pointer-events-none rounded-2xl border border-white/[0.04] z-30" />
      <div className="absolute top-0 inset-x-8 h-[1.5px] bg-gradient-to-r from-transparent via-[#FA1F4E] to-transparent z-40 shadow-[0_0_8px_rgba(250,31,78,0.9)]" />

      {/* ================= LEFT SIDEBAR: SELL PANEL ================= */}
      <div className="flex flex-col items-center justify-between bg-[#030407] border-r border-[#161a24] w-[32px] py-3.5 z-10 shrink-0">
        <span className={`text-[8px] font-bold text-rose-500/90 ${isRunning ? "animate-pulse opacity-100" : "opacity-30"}`}>▼</span>
        
        <div className="flex flex-col items-center gap-[4px] text-rose-500 font-mono text-[7.5px] font-black leading-none my-1 tracking-widest">
          <span>S</span>
          <span>E</span>
          <span>L</span>
          <span>L</span>
        </div>

        {/* Dense LED progress stack */}
        <div className="flex flex-col gap-[1.5px] w-[5px] h-18 bg-black rounded-sm overflow-hidden border border-rose-950/40 my-1 p-[0.5px]">
          {Array.from({ length: 12 }).map((_, i) => {
            const activeCount = Math.floor((leftPercentage / 100) * 12);
            const isActive = isRunning && (12 - i) <= activeCount;
            return (
              <div 
                key={i} 
                className={`h-[4px] w-full rounded-[0.5px] transition-all duration-500 ${
                  isActive 
                    ? "bg-[#FA1F4E] shadow-[0_0_5px_#FA1F4E]" 
                    : "bg-rose-950/30"
                }`} 
              />
            );
          })}
        </div>

        <span className={`text-[8px] font-bold text-rose-500/90 ${isRunning ? "animate-pulse opacity-100" : "opacity-30"}`}>▼</span>
        <span className="text-[7.5px] text-rose-300 font-black font-mono tracking-tight">{leftPercentage}%</span>
      </div>

      {/* ================= MAIN INTERCONNECTED COCKPIT CONTAINER ================= */}
      <div className="flex-1 flex flex-col p-3.5 relative z-10 gap-2.5 min-w-0 bg-[#05070c]">
        
        {/* ================= TOP BENCH HEADER: ENGINE ID (LEFT) | MEMOCORE CENTER | PROMINENT LOGO (RIGHT) ================= */}
        <div className="bg-[#06080f] border border-[#181d2c] rounded-xl px-5 py-3 flex items-center justify-between gap-4 shadow-[inset_0_1px_0_rgba(255,255,255,0.06),0_4px_24px_rgba(0,0,0,0.6)]">
          
          {/* Left: Engine Identifier & Status Badges */}
          <div className="flex flex-col gap-1.5 shrink-0 justify-center">
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-black/80 border border-white/10 text-[8.5px] font-mono font-bold">
                <span className={`w-2 h-2 rounded-full ${isRunning ? "bg-cyan-400 animate-pulse shadow-[0_0_8px_#22d3ee]" : "bg-slate-600"}`} />
                <span className={isRunning ? "text-cyan-300 font-black tracking-wide" : "text-slate-400"}>
                  {isRunning ? "ONLINE ACTIVE" : "STANDBY POOL"}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <div className="px-3 py-1 bg-[#0b0f19] border border-cyan-500/50 text-[#00f0ff] rounded-lg text-[11px] font-black font-mono tracking-widest shadow-[0_0_15px_rgba(0,240,255,0.25)] whitespace-nowrap">
                {selectedEngineId}-ADV
              </div>
              <span className="px-2 py-0.5 bg-slate-900/90 border border-slate-800 rounded text-[8px] font-mono text-slate-400 font-bold tracking-wider whitespace-nowrap">
                SPOT 1X
              </span>
            </div>
          </div>

          {/* Center: MEMOCORE ORCHESTRATION & ROUTING KERNEL */}
          <div className="flex flex-col items-center justify-center text-center flex-1 min-w-0">
            <h2 className="text-[15px] sm:text-[17px] font-sans font-black text-white tracking-[0.18em] uppercase drop-shadow-[0_2px_10px_rgba(0,0,0,0.9)] whitespace-nowrap">
              MEMOCORE ORCHESTRATION
            </h2>
            <div className="text-[8.5px] font-mono text-slate-400 tracking-[0.22em] uppercase font-semibold mt-1 flex items-center gap-2">
              <span>Deterministic Routing Kernel</span>
            </div>
          </div>

          {/* Right: PROMINENT OFFICIAL MEMOBOT EMBLEM LOGO (FREE-STANDING & ENLARGED) */}
          <div className="flex items-center justify-end shrink-0 pl-2">
            <div className="relative flex items-center justify-center group">
              <img 
                src="/MemoBot.png" 
                alt="Official MemoBot Logo" 
                className="h-14 sm:h-16 w-auto object-contain mix-blend-screen relative z-10 filter drop-shadow-[0_0_20px_rgba(250,31,78,0.95)] transition-all duration-300 group-hover:scale-105 group-hover:drop-shadow-[0_0_25px_rgba(250,31,78,1)]"
              />
            </div>
          </div>

        </div>

        {/* ================= MIDDLE CONFIGURATION ROW ================= */}
        <div className="bg-[#080a11] border border-[#141824] rounded-xl p-3 flex items-center justify-between gap-4 text-slate-300">
          <div className="flex items-center gap-3 flex-1">
            {/* Strategy */}
            <div className="flex-1 min-w-[130px]">
              <span className="text-[7.5px] font-mono font-bold text-slate-400 block uppercase tracking-wider mb-1">STRATEGY</span>
              {isManual ? (
                <input
                  type="text"
                  value={localConfig.strategy || ""}
                  onChange={(e) => onUpdateConfig("strategy", e.target.value)}
                  className="w-full bg-[#05070c] border border-[#1b2133] focus:border-[#00f0ff] rounded-lg px-2.5 py-1.5 text-[9.5px] font-mono text-white outline-none transition-colors"
                />
              ) : (
                <div className="w-full bg-[#05070c] border border-cyan-500/30 rounded-lg px-3 py-1.5 text-[9.5px] font-mono text-cyan-300 font-bold shadow-[0_0_8px_rgba(6,182,212,0.15)] whitespace-nowrap">
                  SWARM ROUTING
                </div>
              )}
            </div>

            {/* Size USD */}
            <div className="w-[110px]">
              <span className="text-[7.5px] font-mono font-bold text-slate-400 block uppercase tracking-wider mb-1">SIZE (USD)</span>
              <input
                type="number"
                value={localConfig.amount || 100}
                onChange={(e) => onUpdateConfig("amount", Number(e.target.value))}
                className="w-full bg-[#05070c] border border-[#1a2030] focus:border-cyan-400 rounded-lg px-3 py-1.5 text-[9.5px] font-mono text-white font-bold outline-none transition-all shadow-inner"
              />
            </div>

            {/* Target */}
            <div className="w-[120px]">
              <span className="text-[7.5px] font-mono font-bold text-slate-400 block uppercase tracking-wider mb-1">TARGET</span>
              {isManual ? (
                <input
                  type="text"
                  value={localConfig.asset || ""}
                  onChange={(e) => onUpdateConfig("asset", e.target.value)}
                  className="w-full bg-[#05070c] border border-[#1b2133] focus:border-[#00f0ff] rounded-lg px-2.5 py-1.5 text-[9.5px] font-mono text-white outline-none transition-colors"
                />
              ) : (
                <div className="w-full bg-[#05070c] border border-[#1a2030] rounded-lg px-3 py-1.5 text-[9.5px] font-mono text-slate-200 font-semibold whitespace-nowrap">
                  AUTOMATIC
                </div>
              )}
            </div>
          </div>

          {/* Right: Version Tag, Execution Badge & Apply Action */}
          <div className="flex items-center gap-3 shrink-0">
            <span className="text-[8px] text-[#FA1F4E] px-2 py-0.5 rounded bg-[#FA1F4E]/15 border border-[#FA1F4E]/40 font-mono font-bold shadow-[0_0_6px_rgba(250,31,78,0.25)]">
              v1.1
            </span>

            <div className="px-3 py-1 bg-black/80 border border-amber-500/40 rounded-lg shadow-[0_0_10px_rgba(245,158,11,0.18)] flex items-center gap-2 whitespace-nowrap">
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse shadow-[0_0_6px_#f59e0b]" />
              <span className="text-[8.5px] font-mono font-black text-amber-300 uppercase tracking-widest">
                {isManual ? "MANUAL ENGINE" : "AUTO SWARM"}
              </span>
            </div>

            <button
              onClick={onApplyConfig}
              className="py-2 px-6 bg-gradient-to-r from-[#FA1F4E] to-[#d81943] hover:from-[#ff2d5d] hover:to-[#e11d48] text-white font-mono text-[9.5px] font-black rounded-lg uppercase tracking-wider transition-all cursor-pointer shadow-[0_0_18px_rgba(250,31,78,0.45)] active:scale-98"
            >
              {savingState ? "SAVING..." : "APPLY"}
            </button>

            {saveMessage && (
              <span className="text-[8px] font-mono text-cyan-400 font-bold uppercase animate-pulse">
                {saveMessage}
              </span>
            )}
          </div>
        </div>

        {/* ================= BOTTOM ACTION ROW: SPOT BUY | STOP/DEPLOY BUTTON | SPOT SELL ================= */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-3.5 my-1 items-stretch">
          
          {/* 1. SPOT BUY BUTTON (Electric Cyan / Blue Gradient) */}
          <button
            onClick={() => handleManualTrade("BUY")}
            className="group relative overflow-hidden py-3 px-5 rounded-xl bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 hover:from-cyan-400 hover:to-blue-500 text-white font-sans text-[12px] font-black uppercase tracking-[0.2em] transition-all flex items-center justify-center gap-3 shadow-[0_4px_25px_rgba(6,182,212,0.4)] hover:shadow-[0_6px_30px_rgba(6,182,212,0.65)] cursor-pointer active:scale-98 border border-cyan-400/40"
          >
            <div className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity" />
            <ShoppingCart className="w-4 h-4 transition-transform group-hover:scale-110 text-cyan-100" />
            <span className="drop-shadow-[0_0_8px_rgba(255,255,255,0.5)]">SPOT BUY</span>
          </button>

          {/* 2. DEDICATED THREAD STATE / STOP & DEPLOY BUTTON (High-Tech Center Controller) */}
          <div className="flex flex-col justify-center">
            <button
              onClick={() => handleStartStop(selectedEngineId, selectedEngine.status || "Stopped")}
              className={`group relative overflow-hidden w-full py-3 px-5 rounded-xl border text-[11.5px] font-mono font-black uppercase tracking-[0.16em] flex items-center justify-center gap-2.5 cursor-pointer transition-all active:scale-98 ${
                isRunning
                  ? "bg-gradient-to-r from-rose-950/80 via-red-900/60 to-rose-950/80 border-rose-500/70 text-rose-200 hover:border-rose-400 hover:bg-rose-900/80 shadow-[0_0_22px_rgba(244,63,94,0.45)]"
                  : "bg-gradient-to-r from-cyan-950/80 via-slate-900/80 to-cyan-950/80 border-cyan-500/70 text-cyan-200 hover:border-cyan-400 hover:bg-cyan-900/80 shadow-[0_0_22px_rgba(6,182,212,0.45)]"
              }`}
            >
              <div className="absolute inset-0 bg-white/5 opacity-0 group-hover:opacity-100 transition-opacity" />
              {isRunning ? (
                <>
                  <Square className="w-4.5 h-4.5 text-rose-400 fill-rose-400 animate-pulse shrink-0" />
                  <span className="drop-shadow-[0_0_8px_rgba(244,63,94,0.7)] font-black tracking-widest">STOP ENGINE</span>
                </>
              ) : (
                <>
                  <Play className="w-4.5 h-4.5 text-cyan-400 fill-cyan-400 animate-pulse shrink-0" />
                  <span className="drop-shadow-[0_0_8px_rgba(6,182,212,0.7)] font-black tracking-widest">DEPLOY ENGINE</span>
                </>
              )}
            </button>
          </div>

          {/* 3. SPOT SELL BUTTON (Neon Crimson / Rose Gradient) */}
          <button
            onClick={() => handleManualTrade("SELL")}
            className="group relative overflow-hidden py-3 px-5 rounded-xl bg-gradient-to-r from-[#FA1F4E] via-rose-600 to-red-600 hover:from-[#ff2d5d] hover:to-rose-500 text-white font-sans text-[12px] font-black uppercase tracking-[0.2em] transition-all flex items-center justify-center gap-3 shadow-[0_4px_25px_rgba(250,31,78,0.4)] hover:shadow-[0_6px_30px_rgba(250,31,78,0.65)] cursor-pointer active:scale-98 border border-rose-400/40"
          >
            <div className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity" />
            <ShoppingCart className="w-4 h-4 transition-transform group-hover:scale-110 text-rose-100" />
            <span className="drop-shadow-[0_0_8px_rgba(255,255,255,0.5)]">SPOT SELL</span>
          </button>

        </div>

        {/* TELEMETRY DYNAMIC LOG TERMINAL */}
        <div className="relative w-full h-[135px] bg-[#030408] border border-[#131722] rounded-xl p-3 font-mono text-[8.5px] text-[#22d3ee] overflow-hidden flex flex-col justify-start select-none shadow-[inset_0_0_15px_rgba(0,0,0,0.95)]">
          {/* Terminal Header */}
          <div className="flex items-center justify-between border-b border-[#131722] pb-1.5 mb-1.5 font-bold tracking-wider text-slate-400 uppercase">
            <span className="flex items-center gap-1.5 text-slate-300">
              <Terminal className="w-3 h-3 text-[#FA1F4E]" /> STACK TELEMETRY CORRELATION FEED
            </span>
            <span className="text-cyan-400 animate-pulse text-[8px] font-black tracking-widest flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 shadow-[0_0_6px_#22d3ee]" /> LIVE CONNECTION
            </span>
          </div>

          {/* Logs scrollable */}
          <div className="flex-1 overflow-y-auto space-y-1 scrollbar-thin scrollbar-thumb-slate-800 pr-1">
            {logs.map((log, i) => (
              <div key={i} className="leading-tight whitespace-pre-wrap opacity-95 border-l border-[#1b2030] pl-2 py-0.5 hover:bg-slate-900/40 transition-colors">
                <span className="text-[#FA1F4E] font-bold">{log.split(" ")[0]}</span>
                <span className="text-slate-300">{log.substring(log.indexOf(" "))}</span>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* ================= RIGHT SIDEBAR: BUY PANEL (Cyan styled) ================= */}
      <div className="flex flex-col items-center justify-between bg-[#030407] border-l border-[#161a24] w-[32px] py-3.5 z-10 shrink-0">
        <span className={`text-[8px] font-bold text-cyan-400/90 ${isRunning ? "animate-pulse opacity-100" : "opacity-30"}`}>▲</span>
        <span className="text-[7.5px] text-cyan-300 font-black font-mono tracking-tight">{rightPercentage}%</span>

        {/* Dense LED progress stack */}
        <div className="flex flex-col gap-[1.5px] w-[5px] h-18 bg-black rounded-sm overflow-hidden border border-cyan-950/40 my-1 p-[0.5px]">
          {Array.from({ length: 12 }).map((_, i) => {
            const activeCount = Math.floor((rightPercentage / 100) * 12);
            const isActive = isRunning && (12 - i) <= activeCount;
            return (
              <div 
                key={i} 
                className={`h-[4px] w-full rounded-[0.5px] transition-all duration-500 ${
                  isActive 
                    ? "bg-cyan-500 shadow-[0_0_5px_#06b6d4]" 
                    : "bg-cyan-950/30"
                }`} 
              />
            );
          })}
        </div>

        <div className="flex flex-col items-center gap-[4px] text-cyan-400 font-mono text-[7.5px] font-black leading-none my-1 tracking-widest">
          <span>B</span>
          <span>U</span>
          <span>Y</span>
        </div>

        <span className={`text-[8px] font-bold text-cyan-400/90 ${isRunning ? "animate-pulse opacity-100" : "opacity-30"}`}>▲</span>
      </div>
    </div>
  );
};

export default HologramPanel;
