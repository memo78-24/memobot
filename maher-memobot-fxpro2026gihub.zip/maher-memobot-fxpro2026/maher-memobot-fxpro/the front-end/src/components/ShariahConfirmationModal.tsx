import React from "react";
import { ShieldCheck, CheckCircle2, Lock, Sparkles } from "lucide-react";
import { useLanguage } from "./LanguageProvider";

interface ShariahConfirmationModalProps {
  isOpen: boolean;
  onConfirm: () => void;
}

export const ShariahConfirmationModal: React.FC<ShariahConfirmationModalProps> = ({ isOpen, onConfirm }) => {
  const { t } = useLanguage();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-lg bg-[#080d0a] border-2 border-[#00e676] rounded-2xl p-6 sm:p-8 shadow-[0_0_50px_rgba(0,230,118,0.3)] overflow-hidden">
        {/* Subtle background glow */}
        <div className="absolute -top-24 -right-24 w-48 h-48 bg-[#00e676]/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-[#00e676]/15 rounded-full blur-3xl pointer-events-none" />

        {/* Top Header Badge */}
        <div className="flex items-center justify-between border-b border-[#00e676]/20 pb-4 mb-5">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl bg-[#00e676]/10 border border-[#00e676]/40 text-[#00e676] shadow-[0_0_15px_rgba(0,230,118,0.2)]">
              <ShieldCheck className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="inline-block w-2 h-2 rounded-full bg-[#00e676] animate-ping" />
                <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-[#00e676]">
                  {t("PROTOCOL SYNCHRONIZED")}
                </span>
              </div>
              <h3 className="text-xl font-aquire text-white tracking-wide uppercase">
                {t("SHARIAH MODE ACTIVATED")}
              </h3>
            </div>
          </div>
          <div className="flex items-center gap-1 px-2.5 py-1 rounded bg-[#00e676]/20 border border-[#00e676]/40 text-[#00e676] text-[10px] font-mono font-bold uppercase">
            <Lock className="w-3 h-3" />
            <span>100% HALAL</span>
          </div>
        </div>

        {/* Body Description */}
        <div className="space-y-4 mb-6 text-sm text-[#c1c7d0]">
          <p className="leading-relaxed font-sans text-[13.5px]">
            {t("The entire MEMOBOT™ trading ecosystem (Central Engines Station, Decision Kernel, Strategies, and Risk Manager) is now fully synchronized and operates under strict Islamic Shariah principles.")}
          </p>

          <div className="bg-[#05130b] border border-[#00e676]/30 rounded-xl p-4 space-y-3">
            <div className="flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-[#00e676] shrink-0 mt-0.5" />
              <div>
                <p className="text-xs font-bold text-white uppercase tracking-wide">
                  {t("1X Spot Physical Settlement")}
                </p>
                <p className="text-[11px] text-[#8a8d9a] mt-0.5">
                  {t("100% real spot trading with 0% margin, zero leverage, and 0% interest or swap (Riba-free).")}
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 border-t border-[#00e676]/10 pt-2.5">
              <CheckCircle2 className="w-5 h-5 text-[#00e676] shrink-0 mt-0.5" />
              <div>
                <p className="text-xs font-bold text-white uppercase tracking-wide">
                  {t("Real-Time Halal Asset Filtering")}
                </p>
                <p className="text-[11px] text-[#8a8d9a] mt-0.5">
                  {t("Automated O(1) Bloom Filter continuously audits and restricts trading to AAOIFI-certified spot assets.")}
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 border-t border-[#00e676]/10 pt-2.5">
              <CheckCircle2 className="w-5 h-5 text-[#00e676] shrink-0 mt-0.5" />
              <div>
                <p className="text-xs font-bold text-white uppercase tracking-wide">
                  {t("Locked Compliance Governance")}
                </p>
                <p className="text-[11px] text-[#8a8d9a] mt-0.5">
                  {t("Strategies and Risk Manager pages are locked into Shariah-compliant parameters to eliminate speculative risk.")}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Confirmation Button */}
        <button
          onClick={onConfirm}
          className="w-full py-3.5 px-6 rounded-xl bg-gradient-to-r from-[#00e676] to-[#00c853] hover:from-[#00c853] hover:to-[#009624] text-black font-bold font-mono text-sm uppercase tracking-wider shadow-[0_0_25px_rgba(0,230,118,0.4)] transition-all flex items-center justify-center gap-2 transform active:scale-98 cursor-pointer"
        >
          <Sparkles className="w-4 h-4 fill-black" />
          <span>{t("OK / I UNDERSTAND & ACKNOWLEDGE PROTOCOL")}</span>
        </button>
      </div>
    </div>
  );
};
