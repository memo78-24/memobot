import React, { useState, useEffect } from "react";
import { 
  Layers, 
  Sparkles, 
  Lock, 
  Unlock, 
  Check, 
  X, 
  Edit3, 
  RotateCcw, 
  Eye, 
  Palette, 
  Search, 
  Filter, 
  ChevronRight, 
  Sliders,
  Type,
  Square,
  Shield,
  MousePointer
} from "lucide-react";

export interface PageElementItem {
  id: string;
  el: HTMLElement;
  tag: string;
  label: string;
  classes: string;
  textColor: string;
  bgColor: string;
  borderColor: string;
  isModified: boolean;
  isLocked: boolean;
  originalStyles: {
    color: string;
    backgroundColor: string;
    borderColor: string;
    borderWidth: string;
    borderStyle: string;
    fontSize: string;
    padding: string;
    borderRadius: string;
    textContent?: string;
  };
}

interface PageElementsManifestProps {
  accentColor: string;
  onSelectElement: (el: HTMLElement) => void;
  onHighlightElement: (el: HTMLElement | null) => void;
  onClose: () => void;
}

export const PageElementsManifest: React.FC<PageElementsManifestProps> = ({
  accentColor,
  onSelectElement,
  onHighlightElement,
  onClose
}) => {
  const [elements, setElements] = useState<PageElementItem[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterMode, setFilterMode] = useState<"ALL" | "MODIFIED" | "LOCKED" | "TEXT_ONLY" | "CONTAINERS">("ALL");
  const [pageTitle, setPageTitle] = useState("CURRENT STANDING PAGE");

  // Helper to extract clean computed colors
  const getComputedStyleValue = (el: HTMLElement, prop: string): string => {
    try {
      return window.getComputedStyle(el).getPropertyValue(prop) || "";
    } catch (e) {
      return "";
    }
  };

  // Convert RGB/RGBA to HEX for clean visual display
  const rgbToHex = (rgb: string): string => {
    if (!rgb || rgb === "transparent" || rgb === "rgba(0, 0, 0, 0)") return "transparent";
    const rgbMatch = rgb.match(/^rgba?[\s+]?\([\s+]?(\d+)[\s+]?,[\s+]?(\d+)[\s+]?,[\s+]?(\d+)/i);
    return rgbMatch && rgbMatch.length === 4
      ? "#" +
          ("0" + parseInt(rgbMatch[1], 10).toString(16)).slice(-2) +
          ("0" + parseInt(rgbMatch[2], 10).toString(16)).slice(-2) +
          ("0" + parseInt(rgbMatch[3], 10).toString(16)).slice(-2)
      : rgb;
  };

  // Scan and index meaningful elements on the current standing page
  const scanPageElements = () => {
    const mainContent = document.querySelector("main") || document.getElementById("root") || document.body;
    if (!mainContent) return;

    // Detect standing page identifier
    const activeHeader = document.querySelector("h1, h2, [id*='page'], header h1");
    if (activeHeader && activeHeader.textContent) {
      setPageTitle(activeHeader.textContent.trim().slice(0, 35).toUpperCase());
    }

    // Query meaningful visible candidate nodes (cards, buttons, titles, paragraphs, inputs, spans with text)
    const candidateNodes = mainContent.querySelectorAll<HTMLElement>(
      "button, input, select, textarea, h1, h2, h3, h4, h5, h6, p, [role='button'], .card, .panel, header, nav, section, div[class*='border'], div[class*='bg-'], div[class*='rounded'], div[id]"
    );

    const manifest: PageElementItem[] = [];
    let counter = 0;

    candidateNodes.forEach((el) => {
      // Exclude inspector itself and sidebar
      if (
        el.closest(".inspector-exclude") ||
        el.closest("#sidebar-panel") ||
        el.id === "sidebar-panel" ||
        el.offsetHeight === 0 ||
        el.offsetWidth === 0
      ) {
        return;
      }

      // Generate a short meaningful label
      let textSnippet = el.textContent?.trim() || "";
      if (textSnippet.length > 45) {
        textSnippet = textSnippet.slice(0, 42) + "...";
      }

      const tag = el.tagName.toLowerCase();
      let label = textSnippet;
      if (!label) {
        if (el.id) label = `#${el.id}`;
        else if (el.getAttribute("aria-label")) label = el.getAttribute("aria-label") || "";
        else label = `<${tag}> element`;
      }

      const compColor = getComputedStyleValue(el, "color");
      const compBg = getComputedStyleValue(el, "background-color");
      const compBorder = getComputedStyleValue(el, "border-color");

      const origStyles = {
        color: el.style.color || "",
        backgroundColor: el.style.backgroundColor || "",
        borderColor: el.style.borderColor || "",
        borderWidth: el.style.borderWidth || "",
        borderStyle: el.style.borderStyle || "",
        fontSize: el.style.fontSize || "",
        padding: el.style.padding || "",
        borderRadius: el.style.borderRadius || "",
        textContent: el.textContent || ""
      };

      const isModified = !!(
        el.getAttribute("data-inspector-modified") ||
        el.style.color ||
        el.style.backgroundColor ||
        el.style.borderColor
      );

      const isLocked = el.getAttribute("data-inspector-locked") === "true";

      manifest.push({
        id: `manifest-${counter++}`,
        el,
        tag,
        label,
        classes: Array.from(el.classList).filter(c => !c.startsWith("inspector-")).slice(0, 3).join(" "),
        textColor: rgbToHex(compColor),
        bgColor: rgbToHex(compBg),
        borderColor: rgbToHex(compBorder),
        isModified,
        isLocked,
        originalStyles: origStyles
      });
    });

    setElements(manifest);
  };

  useEffect(() => {
    scanPageElements();
    const timer = setTimeout(scanPageElements, 300);
    return () => clearTimeout(timer);
  }, []);

  // Option 1: Trigger Change / Edit Modal for this specific element
  const handleOptionChange = (item: PageElementItem) => {
    item.el.setAttribute("data-inspector-modified", "true");
    item.el.scrollIntoView({ behavior: "smooth", block: "center" });
    onSelectElement(item.el);
  };

  // Option 2: Keep / Lock (Do Not Change) toggle
  const handleToggleLock = (item: PageElementItem, e: React.MouseEvent) => {
    e.stopPropagation();
    const newLockState = !item.isLocked;
    if (newLockState) {
      item.el.setAttribute("data-inspector-locked", "true");
      // Add a subtle protected badge effect
      item.el.style.outline = "none";
    } else {
      item.el.removeAttribute("data-inspector-locked");
    }

    setElements((prev) =>
      prev.map((el) =>
        el.id === item.id ? { ...el, isLocked: newLockState } : el
      )
    );
  };

  // Option to Revert / Reset element back to clean initial state
  const handleResetElement = (item: PageElementItem, e: React.MouseEvent) => {
    e.stopPropagation();
    const el = item.el;
    el.style.color = item.originalStyles.color;
    el.style.backgroundColor = item.originalStyles.backgroundColor;
    el.style.borderColor = item.originalStyles.borderColor;
    el.style.borderWidth = item.originalStyles.borderWidth;
    el.style.borderStyle = item.originalStyles.borderStyle;
    el.style.fontSize = item.originalStyles.fontSize;
    el.style.padding = item.originalStyles.padding;
    el.style.borderRadius = item.originalStyles.borderRadius;
    el.removeAttribute("data-inspector-modified");

    setElements((prev) =>
      prev.map((it) =>
        it.id === item.id ? { ...it, isModified: false } : it
      )
    );
  };

  // Filter items based on active search and tab mode
  const filteredElements = elements.filter((item) => {
    const matchesSearch =
      searchQuery === "" ||
      item.label.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.tag.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.classes.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;

    if (filterMode === "MODIFIED") return item.isModified;
    if (filterMode === "LOCKED") return item.isLocked;
    if (filterMode === "TEXT_ONLY") return ["h1", "h2", "h3", "h4", "h5", "p", "span"].includes(item.tag);
    if (filterMode === "CONTAINERS") return ["div", "section", "card", "panel", "header"].includes(item.tag);
    return true;
  });

  return (
    <div className="pointer-events-auto fixed top-16 left-1/2 -translate-x-1/2 w-[95vw] max-w-5xl bg-[#06070a] border border-[#1a1d26] rounded-xl shadow-[0_20px_60px_rgba(0,0,0,0.9)] overflow-hidden flex flex-col max-h-[80vh] font-mono text-white text-xs z-[99999] animate-in fade-in zoom-in-95 duration-150">
      
      {/* Header with Title & Quick Counts */}
      <div className="p-4 bg-[#0d0e12] border-b border-[#1a1d26] flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div 
            style={{ backgroundColor: `${accentColor}20`, borderColor: accentColor }}
            className="p-2 rounded-lg border text-white"
          >
            <Layers className="w-5 h-5" style={{ color: accentColor }} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-black uppercase tracking-wider text-white">
                PAGE ELEMENTS MANIFEST // {pageTitle}
              </h3>
              <span 
                style={{ borderColor: `${accentColor}50`, color: accentColor }}
                className="px-2 py-0.5 rounded text-[9px] font-black uppercase border bg-[#06070a]"
              >
                {elements.length} ELEMENTS DETECTED
              </span>
            </div>
            <p className="text-[10px] text-[#8a8d9a] font-sans">
              Choose for every element whether to <strong className="text-white">CHANGE & MODIFY</strong> or <strong className="text-emerald-400">KEEP AS-IS (LOCK)</strong>.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={scanPageElements}
            className="px-3 py-1.5 bg-[#161822] hover:bg-[#202433] text-[#8a8d9a] hover:text-white rounded border border-[#23273a] text-[10px] font-bold uppercase transition-all flex items-center gap-1.5"
            title="Refresh Page Elements Scan"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Rescan</span>
          </button>
          <button
            onClick={onClose}
            className="p-1.5 bg-[#161822] hover:bg-[#FA1F4E] text-[#8a8d9a] hover:text-white rounded border border-[#23273a] transition-all"
            title="Close Manifest"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="p-3 bg-[#08090d] border-b border-[#141722] flex flex-wrap items-center justify-between gap-3">
        {/* Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto">
          {[
            { id: "ALL" as const, label: `ALL (${elements.length})` },
            { id: "MODIFIED" as const, label: `MODIFIED (${elements.filter(e => e.isModified).length})` },
            { id: "LOCKED" as const, label: `LOCKED / KEPT (${elements.filter(e => e.isLocked).length})` },
            { id: "TEXT_ONLY" as const, label: "HEADINGS & TEXT" },
            { id: "CONTAINERS" as const, label: "CARDS & PANELS" },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilterMode(tab.id)}
              className={`px-2.5 py-1 rounded text-[9px] font-bold uppercase transition-all whitespace-nowrap border ${
                filterMode === tab.id
                  ? "bg-[#FA1F4E] border-[#FA1F4E] text-white shadow-[0_0_10px_rgba(250,31,78,0.3)]"
                  : "bg-[#0d0e12] border-[#1a1d26] text-[#8a8d9a] hover:text-white hover:border-[#333]"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Search Field */}
        <div className="relative w-full sm:w-64">
          <Search className="w-3.5 h-3.5 text-[#666] absolute left-2.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search tag, text or class..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#0d0e12] border border-[#1a1d26] focus:border-[#FA1F4E] rounded pl-8 pr-3 py-1 text-[11px] text-white placeholder-[#555] outline-none font-mono"
          />
        </div>
      </div>

      {/* Elements Table / Grid */}
      <div className="flex-1 overflow-y-auto p-4 space-y-2.5">
        {filteredElements.length === 0 ? (
          <div className="text-center py-12 text-[#666] space-y-2">
            <Filter className="w-8 h-8 mx-auto text-[#444]" />
            <p className="text-xs font-bold uppercase">No matching elements found</p>
            <p className="text-[10px] text-[#555]">Try clearing search filter or switching tabs</p>
          </div>
        ) : (
          filteredElements.map((item) => (
            <div
              key={item.id}
              onMouseEnter={() => onHighlightElement(item.el)}
              onMouseLeave={() => onHighlightElement(null)}
              className={`p-3 rounded-lg border transition-all flex flex-col md:flex-row items-start md:items-center justify-between gap-3 bg-[#0d0e12] hover:bg-[#11131c] ${
                item.isLocked
                  ? "border-emerald-500/30 bg-emerald-950/5"
                  : item.isModified
                  ? "border-[#FA1F4E]/40 shadow-[0_0_15px_rgba(250,31,78,0.1)]"
                  : "border-[#1a1d26] hover:border-[#333]"
              }`}
            >
              {/* Left Column: Tag, Label & Class Details */}
              <div className="space-y-1 flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="px-1.5 py-0.5 rounded bg-[#06070a] border border-[#1a1d26] text-[#FA1F4E] text-[9px] font-black uppercase">
                    &lt;{item.tag}&gt;
                  </span>
                  {item.isLocked && (
                    <span className="px-1.5 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/40 text-emerald-400 text-[8px] font-black uppercase flex items-center gap-1">
                      <Shield className="w-3 h-3" />
                      LOCKED / KEPT
                    </span>
                  )}
                  {item.isModified && (
                    <span className="px-1.5 py-0.5 rounded bg-[#FA1F4E]/10 border border-[#FA1F4E]/40 text-[#FA1F4E] text-[8px] font-black uppercase flex items-center gap-1">
                      <Sparkles className="w-3 h-3" />
                      MODIFIED
                    </span>
                  )}
                  {item.classes && (
                    <span className="text-[9px] text-[#555] truncate max-w-[200px]">
                      .{item.classes}
                    </span>
                  )}
                </div>

                <div className="text-white font-bold text-xs truncate max-w-xl">
                  {item.label}
                </div>
              </div>

              {/* Middle Column: Visual Color Chips */}
              <div className="flex items-center gap-3 bg-[#06070a] p-2 rounded border border-[#1a1d26] shrink-0">
                {/* Text Color */}
                <div className="flex items-center gap-1.5" title={`Text Color: ${item.textColor}`}>
                  <span className="text-[8px] text-[#666] uppercase">TXT:</span>
                  <div
                    style={{ backgroundColor: item.textColor === "transparent" ? "#333" : item.textColor }}
                    className="w-3.5 h-3.5 rounded border border-white/20 shadow-inner shrink-0"
                  />
                  <span className="text-[9px] text-white font-mono">{item.textColor}</span>
                </div>

                <div className="w-px h-3 bg-[#1a1d26]" />

                {/* BG Color */}
                <div className="flex items-center gap-1.5" title={`Background: ${item.bgColor}`}>
                  <span className="text-[8px] text-[#666] uppercase">BG:</span>
                  <div
                    style={{ backgroundColor: item.bgColor === "transparent" ? "#1a1d26" : item.bgColor }}
                    className="w-3.5 h-3.5 rounded border border-white/20 shadow-inner shrink-0"
                  />
                  <span className="text-[9px] text-white font-mono">{item.bgColor}</span>
                </div>

                <div className="w-px h-3 bg-[#1a1d26]" />

                {/* Border Color */}
                <div className="flex items-center gap-1.5" title={`Border: ${item.borderColor}`}>
                  <span className="text-[8px] text-[#666] uppercase">BDR:</span>
                  <div
                    style={{ backgroundColor: item.borderColor === "transparent" ? "#1a1d26" : item.borderColor }}
                    className="w-3.5 h-3.5 rounded border border-white/20 shadow-inner shrink-0"
                  />
                </div>
              </div>

              {/* Right Column: Two Primary Decision Options (CHANGE vs KEEP AS-IS) */}
              <div className="flex items-center gap-2 shrink-0">
                {/* Option A: CHANGE & MODIFY */}
                <button
                  onClick={() => handleOptionChange(item)}
                  style={{ backgroundColor: accentColor }}
                  className="px-3 py-1.5 rounded font-bold text-white uppercase text-[10px] tracking-wider hover:opacity-90 transition-all flex items-center gap-1.5 shadow-[0_0_12px_rgba(250,31,78,0.25)]"
                  title="Open Modifier Core to live customize this element"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>CHANGE</span>
                </button>

                {/* Option B: KEEP AS-IS (LOCK / FREEZE) */}
                <button
                  onClick={(e) => handleToggleLock(item, e)}
                  className={`px-3 py-1.5 rounded font-bold uppercase text-[10px] tracking-wider transition-all border flex items-center gap-1.5 ${
                    item.isLocked
                      ? "bg-emerald-500/20 border-emerald-500 text-emerald-400"
                      : "bg-[#06070a] border-[#1a1d26] text-[#8a8d9a] hover:text-white hover:border-[#444]"
                  }`}
                  title={item.isLocked ? "Unlock element for changes" : "Lock element to keep it untouched"}
                >
                  {item.isLocked ? <Lock className="w-3.5 h-3.5 text-emerald-400" /> : <Unlock className="w-3.5 h-3.5" />}
                  <span>{item.isLocked ? "KEPT AS-IS" : "DO NOT CHANGE"}</span>
                </button>

                {/* Optional: Reset element */}
                {item.isModified && (
                  <button
                    onClick={(e) => handleResetElement(item, e)}
                    className="p-1.5 bg-[#06070a] hover:bg-amber-500/20 border border-[#1a1d26] hover:border-amber-500/40 text-[#8a8d9a] hover:text-amber-400 rounded transition-all"
                    title="Reset to default clean style"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          ))
        )}
      </div>

      {/* Footer info bar */}
      <div className="p-3 bg-[#0d0e12] border-t border-[#1a1d26] flex items-center justify-between text-[10px] text-[#8a8d9a]">
        <div className="flex items-center gap-2">
          <MousePointer className="w-3.5 h-3.5 text-[#FA1F4E]" />
          <span>Hover over any item to highlight it on your standing page. Click <strong className="text-white">CHANGE</strong> to customize colors, text, padding, and borders.</span>
        </div>
        <span className="text-white font-bold">{filteredElements.length} SHOWN</span>
      </div>
    </div>
  );
};
