import React from "react";

interface PerformanceChartProps {
  data: Array<{ timestamp: string; value: number }>;
}

export const PerformanceChart: React.FC<PerformanceChartProps> = ({ data }) => {
  const padding = 40;
  const width = 600;
  const height = 240;

  if (!data || data.length === 0) {
    return (
      <div className="h-60 bg-[#0d0e12] border border-[#1a1d26] rounded flex items-center justify-center font-mono text-xs text-[#8a8d9a]">
        NO HISTORICAL TRADE METRICS DETECTED IN ACTIVE LEDGER
      </div>
    );
  }

  const values = data.map((d) => d.value);
  const minVal = Math.min(...values, 0);
  const maxVal = Math.max(...values, 100);
  const valRange = maxVal - minVal || 1;

  const w = width - padding * 2;
  const h = height - padding * 2;

  // Map values to SVG coordinates
  const points = data.map((d, i) => {
    const x = padding + (i / (data.length - 1 || 1)) * w;
    const y = padding + h - ((d.value - minVal) / valRange) * h;
    return { x, y, val: d.value, label: d.timestamp };
  });

  // Construct SVG path string
  let pathStr = "";
  let areaStr = "";
  if (points.length > 0) {
    pathStr = `M ${points[0].x} ${points[0].y}`;
    areaStr = `M ${points[0].x} ${padding + h}`;
    points.forEach((p) => {
      pathStr += ` L ${p.x} ${p.y}`;
      areaStr += ` L ${p.x} ${p.y}`;
    });
    areaStr += ` L ${points[points.length - 1].x} ${padding + h} Z`;
  }

  // Horizontal Grid Lines
  const gridLinesCount = 4;
  const gridLines = Array.from({ length: gridLinesCount + 1 }).map((_, i) => {
    const ratio = i / gridLinesCount;
    const y = padding + h - ratio * h;
    const val = minVal + ratio * valRange;
    return { y, val };
  });

  return (
    <div className="bg-[#0d0e12] border border-[#1a1d26] rounded p-5 panel-glow">
      <span className="text-xs font-bold font-mono text-[#FA1F4E] tracking-wider block mb-4 uppercase">
        PORTFOLIO PERFORMANCE LEDGER
      </span>
      <div className="relative" style={{ height: `${height}px` }}>
        <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-full">
          <defs>
            <linearGradient id="chartGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#FA1F4E" stopOpacity="0.25" />
              <stop offset="100%" stopColor="#FA1F4E" stopOpacity="0.0" />
            </linearGradient>
          </defs>

          {/* Grid lines */}
          {gridLines.map((line, i) => (
            <g key={i}>
              <line
                x1={padding}
                y1={line.y}
                x2={width - padding}
                y2={line.y}
                stroke="#1a1d26"
                strokeDasharray="4,4"
              />
              <text
                x={padding - 8}
                y={line.y + 4}
                fill="#ffffff"
                fontSize="9"
                fontFamily="monospace"
                textAnchor="end"
              >
                ${line.val.toFixed(0)}
              </text>
            </g>
          ))}

          {/* Area under curve */}
          <path d={areaStr} fill="url(#chartGradient)" />

          {/* Line path */}
          <path d={pathStr} fill="none" stroke="#FA1F4E" strokeWidth="2" />

          {/* Dots on points */}
          {points.map((p, i) => (
            <g key={i} className="group cursor-pointer">
              <circle
                cx={p.x}
                cy={p.y}
                r="3.5"
                fill="#0d0e12"
                stroke="#FA1F4E"
                strokeWidth="1.5"
              />
              {/* Simple title tooltip */}
              <title>{`P&L: $${p.val.toFixed(2)}`}</title>
            </g>
          ))}
        </svg>
      </div>
    </div>
  );
};