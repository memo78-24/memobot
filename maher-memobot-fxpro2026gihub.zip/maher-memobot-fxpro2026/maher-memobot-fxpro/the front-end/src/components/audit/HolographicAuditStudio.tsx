import React, { useState, useMemo } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Printer, FileSpreadsheet } from "lucide-react";
import { useLanguage } from "../../components/LanguageProvider";
import { useNotification } from "../../components/NotificationProvider";
import { OrderAuditRecord, INITIAL_SAMPLE_ORDERS } from "./auditTypes";
import { generateAndTriggerPrint } from "./PrintPassportModal";
import {
  HologramEngineSelector,
  ENGINES_CATALOG,
  EngineItem,
} from "./HologramEngineSelector";
import {
  HologramNodeControls,
  REPORT_THEMES,
} from "./HologramNodeControls";
import { HologramStageSelector } from "./HologramStageSelector";

interface HolographicAuditStudioProps {
  complianceMode: "Islamic" | "Commercial";
  onComplianceToggle?: (mode: "Islamic" | "Commercial") => void;
}

export const HolographicAuditStudio: React.FC<HolographicAuditStudioProps> = ({
  complianceMode,
  onComplianceToggle,
}) => {
  const { isArabic, t } = useLanguage();
  const { showAlert } = useNotification();

  // Selected Engine from the directory
  const [selectedEngine, setSelectedEngine] = useState<EngineItem>(ENGINES_CATALOG[0]);
  const [isHologramOpen, setIsHologramOpen] = useState<boolean>(true);

  // Active theme accent color (unified throughout the studio)
  const accentColor = selectedEngine.color || "#FA1F4E";

  // Hologram Tailoring Nodes
  const [selectedTimeRange, setSelectedTimeRange] = useState<string>("LIVE_24H");
  const [selectedCurrency, setSelectedCurrency] = useState<string>("ALL");
  const [selectedLatency, setSelectedLatency] = useState<string>("ALL");
  const [selectedReportTheme, setSelectedReportTheme] = useState<string>("SHARIAH_CERT");
  const [enabledStages, setEnabledStages] = useState<number[]>([1, 2, 3, 4, 5, 6, 7, 8, 9]);
  const [statusFilter, setStatusFilter] = useState<"ALL" | "APPROVED" | "REJECTED">("ALL");

  // Dynamic live cryptographic hash generated on the fly based on tailored parameters
  const dynamicReportHash = useMemo(() => {
    const raw = `${selectedEngine.id}-${complianceMode}-${selectedReportTheme}-${selectedTimeRange}-${selectedCurrency}-${enabledStages.join(",")}`;
    let hashVal = 0;
    for (let i = 0; i < raw.length; i++) {
      hashVal = (hashVal << 5) - hashVal + raw.charCodeAt(i);
      hashVal |= 0;
    }
    const hex = Math.abs(hashVal).toString(16).padStart(8, "0");
    return `0x8f7a90b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9`.slice(0, 48) + hex;
  }, [selectedEngine, selectedTimeRange, selectedCurrency, enabledStages, selectedReportTheme, complianceMode]);

  // Generate live tailored orders dynamically based on current selected engine & nodes
  const tailoredOrders: OrderAuditRecord[] = useMemo(() => {
    const baseList: OrderAuditRecord[] = INITIAL_SAMPLE_ORDERS.map((ord, idx) => {
      const isEngineMatch = ord.engine.includes(selectedEngine.name) || ord.engine.includes(selectedEngine.code);
      return {
        ...ord,
        engine: isEngineMatch ? `${selectedEngine.code} ${selectedEngine.name}` : ord.engine,
        exchange: `${selectedEngine.exchange.toUpperCase()} GATEWAY`,
        symbol: selectedCurrency === "ALL" ? ord.symbol : selectedCurrency,
        latencyMs: Number((selectedEngine.speedMs + (idx * 0.02) % 0.05).toFixed(2)),
      };
    });

    return baseList.filter((o) => {
      if (!enabledStages.includes(o.stageNumber)) return false;
      if (statusFilter !== "ALL" && o.status !== statusFilter) return false;
      if (selectedLatency === "ULTRA_FAST" && o.latencyMs >= 0.15) return false;
      if (selectedLatency === "FAST" && o.latencyMs >= 0.25) return false;
      if (selectedLatency === "STANDARD" && o.latencyMs >= 0.50) return false;
      if (selectedCurrency !== "ALL" && !o.symbol.includes(selectedCurrency.split("/")[0])) return false;
      return true;
    });
  }, [selectedEngine, selectedCurrency, enabledStages, statusFilter, selectedLatency]);

  const toggleStage = (stageNum: number) => {
    setEnabledStages((prev) => {
      if (prev.includes(stageNum)) {
        if (prev.length === 1) {
          showAlert(t("At least one pipeline stage must remain active"));
          return prev;
        }
        return prev.filter((s) => s !== stageNum);
      } else {
        return [...prev, stageNum].sort((a, b) => a - b);
      }
    });
  };

  const handlePrintTailoredPassport = () => {
    const reportTitle = `${REPORT_THEMES.find((r) => r.id === selectedReportTheme)?.label} [${selectedEngine.name}]`;
    generateAndTriggerPrint(reportTitle, tailoredOrders, complianceMode);
    showAlert(t(`Audit Passport generated for ${selectedEngine.name}`));
  };

  const handleExportCSV = () => {
    const headers = ["Order #", "Correlation ID", "Engine", "Exchange", "Pair", "Price", "Value", "Stage", "Status", "Latency (ms)", "Hash"];
    const rows = tailoredOrders.map((o) => [
      `"${o.orderNumber}"`, `"${o.correlationId}"`, `"${o.engine}"`, `"${o.exchange}"`,
      `"${o.symbol}"`, `"${o.price}"`, `"${o.totalValue}"`, `"${o.stage}"`,
      `"${o.status}"`, `"${o.latencyMs}"`, `"${o.hash}"`
    ]);
    const csvContent = "\ufeff" + [headers.join(","), ...rows.map((e) => e.join(","))].join("\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `TAILORED_AUDIT_${selectedEngine.code}_${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);
    showAlert(t("Custom Tailored CSV Audit Exported"));
  };

  return (
    <div className="space-y-4 select-none font-mono">
      {/* 1. Engine Directory Panel (Compact 3D Buttons) */}
      <HologramEngineSelector
        selectedEngine={selectedEngine}
        accentColor={accentColor}
        onSelectEngine={(eng) => {
          setSelectedEngine(eng);
          setIsHologramOpen(true);
        }}
      />

      {/* 2. Holographic Projection Panel with Unified Accent Styling */}
      <AnimatePresence>
        {isHologramOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.98, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.98, y: -10 }}
            transition={{ duration: 0.25, ease: "easeOut" }}
            className="relative bg-[#07090f]/95 border rounded-2xl p-4 sm:p-5 shadow-2xl backdrop-blur-xl overflow-hidden"
            style={{
              borderColor: `${accentColor}40`,
              boxShadow: `0 0 35px ${accentColor}18, inset 0 1px 0 rgba(255,255,255,0.05)`,
            }}
          >
            {/* Subtle Holographic Ambient Glow */}
            <div 
              className="absolute inset-0 pointer-events-none opacity-20"
              style={{
                background: `radial-gradient(ellipse at top, ${accentColor} 0%, transparent 70%)`
              }}
            />
            <div 
              className="absolute top-0 inset-x-0 h-[1.5px]"
              style={{
                background: `linear-gradient(90deg, transparent, ${accentColor}, transparent)`
              }}
            />

            {/* Hologram Header with Official Logo & Framed Action Buttons */}
            <div className="relative z-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-[#181d2a] pb-4">
              <div className="flex items-center gap-3">
                {/* Official MemoBot Brand Logo with Clean Bevel Container */}
                <div 
                  className="w-10 h-10 rounded-xl bg-[#090b13] border flex items-center justify-center shrink-0 shadow-md relative overflow-hidden group"
                  style={{
                    borderColor: `${accentColor}50`,
                    boxShadow: `0 0 12px ${accentColor}25, inset 0 1px 0 rgba(255,255,255,0.08)`,
                  }}
                >
                  <img 
                    src="/MemoBot.png" 
                    alt="MemoBot Logo" 
                    className="w-7 h-7 object-contain mix-blend-screen drop-shadow-[0_0_8px_rgba(250,31,78,0.5)] transition-transform group-hover:scale-110" 
                  />
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span 
                      className="text-[9px] font-black px-1.5 py-0.2 rounded border uppercase tracking-widest"
                      style={{
                        backgroundColor: `${accentColor}15`,
                        color: accentColor,
                        borderColor: `${accentColor}40`,
                      }}
                    >
                      {isArabic ? "شعاع الهولوغرام نشط" : "HOLOGRAM BEAM ACTIVE"}
                    </span>
                    <span 
                      className="text-white font-black text-sm sm:text-base uppercase tracking-wider font-aquire"
                      style={{
                        textShadow: "0 1px 2px rgba(0,0,0,0.8)",
                      }}
                    >
                      {isArabic ? (selectedEngine.nameAr || selectedEngine.name) : selectedEngine.name} &bull; {isArabic ? "استوديو التقارير المخصص" : t("CUSTOM REPORT STUDIO")}
                    </span>
                  </div>
                  <p className="text-[11px] text-[#717688] mt-0.5">
                    {isArabic 
                      ? "اضبط العقد المباشرة أدناه لتخصيص جواز التدقيق المؤسسي المعتمد وتصديره فورياً."
                      : t("Configure live nodes below to tailor your verified institutional audit passport.")
                    }
                  </p>
                </div>
              </div>

              {/* Framed Action Buttons (Framed border instead of solid red) */}
              <div className="flex items-center gap-2 w-full sm:w-auto">
                <button
                  onClick={handlePrintTailoredPassport}
                  className="flex-1 sm:flex-initial flex items-center justify-center gap-2 px-3.5 py-2 border rounded-xl text-white hover:text-white font-black text-[11px] uppercase transition-all cursor-pointer active:scale-95 group shadow-sm"
                  style={{
                    borderColor: accentColor,
                    backgroundColor: `${accentColor}12`,
                    boxShadow: `0 0 14px ${accentColor}25, inset 0 1px 0 rgba(255,255,255,0.08)`,
                  }}
                >
                  <Printer className="w-3.5 h-3.5 group-hover:scale-110 transition-transform" style={{ color: accentColor }} />
                  <span>{isArabic ? "طباعة جواز التدقيق المخصص" : t("PRINT TAILORED PASSPORT")}</span>
                </button>

                <button
                  onClick={handleExportCSV}
                  className="p-2 border border-[#1e2434] bg-[#090c15] hover:bg-[#121624] text-slate-300 hover:text-white rounded-xl transition-all cursor-pointer shadow-sm"
                  title={t("Export Excel (.csv)")}
                >
                  <FileSpreadsheet className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* 3. Interactive Holographic Nodes (Flow: Protocol -> Timing -> Currency -> Immutable Seal) */}
            <HologramNodeControls
              selectedTimeRange={selectedTimeRange}
              onSelectTimeRange={setSelectedTimeRange}
              selectedLatency={selectedLatency}
              onSelectLatency={setSelectedLatency}
              selectedCurrency={selectedCurrency}
              onSelectCurrency={setSelectedCurrency}
              statusFilter={statusFilter}
              onSelectStatusFilter={setStatusFilter}
              selectedReportTheme={selectedReportTheme}
              onSelectReportTheme={setSelectedReportTheme}
              complianceMode={complianceMode}
              onComplianceToggle={onComplianceToggle}
              dynamicReportHash={dynamicReportHash}
              tailoredOrdersCount={tailoredOrders.length}
              accentColor={accentColor}
            />

            {/* 4. Compact 3D 9-Stage Checkpoint Matrix */}
            <HologramStageSelector
              enabledStages={enabledStages}
              onToggleStage={toggleStage}
              onSelectAllStages={() => setEnabledStages([1, 2, 3, 4, 5, 6, 7, 8, 9])}
              accentColor={accentColor}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
