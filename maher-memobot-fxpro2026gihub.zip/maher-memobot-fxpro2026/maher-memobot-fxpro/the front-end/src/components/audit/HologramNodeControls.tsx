import React from "react";
import {
  ShieldCheck,
  Clock,
  Coins,
  Hash,
  ChevronDown,
} from "lucide-react";
import { useLanguage } from "../../components/LanguageProvider";

export const CURRENCIES = [
  { symbol: "ALL", name: "ALL CURRENCIES" },
  { symbol: "BTC/USDT", name: "Bitcoin Spot (BTC)" },
  { symbol: "ETH/USDT", name: "Ethereum Spot (ETH)" },
  { symbol: "SOL/USDT", name: "Solana Spot (SOL)" },
  { symbol: "XAU/USD (Gold)", name: "Physical Gold Spot (XAU)" },
  { symbol: "EUR/USD", name: "Euro FX Spot (EUR)" },
  { symbol: "ADA/USDT", name: "Cardano Spot (ADA)" },
];

export const TIME_RANGES = [
  { id: "LIVE_1H", label: "LAST 1 HOUR", desc: "Ultra-low latency micro-stream" },
  { id: "LIVE_4H", label: "LAST 4 HOURS", desc: "Session market window" },
  { id: "LIVE_24H", label: "LAST 24 HOURS", desc: "Full daily cycle" },
  { id: "LIVE_7D", label: "LAST 7 DAYS", desc: "Weekly multi-session proof" },
  { id: "CUSTOM_UTC", label: "CUSTOM UTC WINDOW", desc: "Forensic time range" },
];

export const LATENCY_THRESHOLDS = [
  { id: "ALL", label: "ALL LATENCY BANDS" },
  { id: "ULTRA_FAST", label: "< 0.15 ms (Sub-micro)" },
  { id: "FAST", label: "< 0.25 ms (Institutional FIX)" },
  { id: "STANDARD", label: "< 0.50 ms (Standard Spot)" },
];

export const REPORT_THEMES = [
  { id: "SHARIAH_CERT", label: "AAOIFI-21 SHARIAH COMPLIANCE PASSPORT" },
  { id: "EXECUTION_PROOF", label: "SUB-MS FIX EXECUTION & DEPTH AUDIT" },
  { id: "QUANT_ALPHA", label: "QUANTITATIVE ALPHA FORENSIC REPORT" },
  { id: "FULL_MASTER", label: "FULL MULTI-ENGINE INSTITUTIONAL DOSSIER" },
];

interface HologramNodeControlsProps {
  selectedTimeRange: string;
  onSelectTimeRange: (val: string) => void;
  selectedLatency: string;
  onSelectLatency: (val: string) => void;
  selectedCurrency: string;
  onSelectCurrency: (val: string) => void;
  statusFilter: "ALL" | "APPROVED" | "REJECTED";
  onSelectStatusFilter: (val: "ALL" | "APPROVED" | "REJECTED") => void;
  selectedReportTheme: string;
  onSelectReportTheme: (val: string) => void;
  complianceMode: "Islamic" | "Commercial";
  onComplianceToggle?: (mode: "Islamic" | "Commercial") => void;
  dynamicReportHash: string;
  tailoredOrdersCount: number;
  accentColor?: string;
}

export const HologramNodeControls: React.FC<HologramNodeControlsProps> = ({
  selectedTimeRange,
  onSelectTimeRange,
  selectedLatency,
  onSelectLatency,
  selectedCurrency,
  onSelectCurrency,
  statusFilter,
  onSelectStatusFilter,
  selectedReportTheme,
  onSelectReportTheme,
  complianceMode,
  onComplianceToggle,
  dynamicReportHash,
  tailoredOrdersCount,
  accentColor = "#FA1F4E",
}) => {
  const { isArabic, t } = useLanguage();

  const timeRangeOptions = isArabic ? [
    { id: "LIVE_1H", label: "آخر ساعة واحدة (مباشر)" },
    { id: "LIVE_4H", label: "آخر 4 ساعات (مباشر)" },
    { id: "LIVE_24H", label: "آخر 24 ساعة (دورة يومية)" },
    { id: "LIVE_7D", label: "آخر 7 أيام (أسبوعي)" },
    { id: "CUSTOM_UTC", label: "نافذة توقيت مخصصة (UTC)" },
  ] : TIME_RANGES;

  const latencyOptions = isArabic ? [
    { id: "ALL", label: "كافة نطاقات الاستجابة" },
    { id: "ULTRA_FAST", label: "< 0.15 مللي ثانية (فائق السرعة)" },
    { id: "FAST", label: "< 0.25 مللي ثانية (مؤسسي)" },
    { id: "STANDARD", label: "< 0.50 مللي ثانية (فوري قياسي)" },
  ] : LATENCY_THRESHOLDS;

  const reportThemeOptions = isArabic ? [
    { id: "SHARIAH_CERT", label: "جواز الامتثال الشرعي لمعيار أيوفي 21" },
    { id: "EXECUTION_PROOF", label: "إثبات التنفيذ الفوري وعمق سجل الأوامر" },
    { id: "QUANT_ALPHA", label: "تقرير التدقيق الكمي واستخراج الإشارات" },
    { id: "FULL_MASTER", label: "ملف التدقيق المؤسسي الشامل لكافة المحركات" },
  ] : REPORT_THEMES;

  const currencyOptions = isArabic ? [
    { symbol: "ALL", name: "كافة العملات والأصول" },
    { symbol: "BTC/USDT", name: "بيتكوين فوري (BTC)" },
    { symbol: "ETH/USDT", name: "إيثريوم فوري (ETH)" },
    { symbol: "SOL/USDT", name: "سولانا فوري (SOL)" },
    { symbol: "XAU/USD (Gold)", name: "ذهب فعلي حقيقي (XAU)" },
    { symbol: "EUR/USD", name: "يورو فوري (EUR)" },
    { symbol: "ADA/USDT", name: "كاردانو فوري (ADA)" },
  ] : CURRENCIES;

  return (
    <div className="relative z-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3.5 my-4 font-mono" style={{ direction: isArabic ? "rtl" : "ltr" }}>
      {/* NODE 01: PROTOCOL (Islamic - Commercial & Dossier Blueprint) */}
      <div 
        className="bg-[#080a12]/90 border border-[#181d2a] hover:border-[#2a3248] p-3.5 rounded-2xl transition-all space-y-2.5 relative group shadow-lg"
        style={{
          boxShadow: `0 4px 20px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.03)`,
        }}
      >
        <div className="flex items-center justify-between text-[11px] font-black uppercase">
          <div className="flex items-center gap-1.5" style={{ color: accentColor }}>
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>{isArabic ? "العقدة 01: البروتوكول الشرعي" : t("NODE 01: PROTOCOL")}</span>
          </div>
          <span 
            className="text-[8.5px] px-1.5 py-0.2 rounded font-mono font-bold"
            style={{ backgroundColor: `${accentColor}15`, color: accentColor }}
          >
            {isArabic ? (complianceMode === "Islamic" ? "إسلامي" : "تجاري") : complianceMode.toUpperCase()}
          </span>
        </div>

        <div className="space-y-1">
          <label className="text-[9.5px] text-[#787d8f] font-bold uppercase">{isArabic ? "معيار الامتثال:" : t("Compliance Standard:")}</label>
          <div className="flex items-center gap-1 bg-[#05060b] p-1 border border-[#1b202e] rounded-xl">
            <button
              onClick={() => onComplianceToggle && onComplianceToggle("Islamic")}
              className={`flex-1 py-1 text-[9px] font-black uppercase rounded-lg transition-all cursor-pointer ${
                complianceMode === "Islamic"
                  ? "text-white shadow-sm"
                  : "text-[#787d8f] hover:text-white"
              }`}
              style={{
                backgroundColor: complianceMode === "Islamic" ? accentColor : "transparent",
                boxShadow: complianceMode === "Islamic" ? `0 0 10px ${accentColor}40` : "none",
              }}
            >
              {isArabic ? "إسلامي" : "ISLAMIC"}
            </button>
            <button
              onClick={() => onComplianceToggle && onComplianceToggle("Commercial")}
              className={`flex-1 py-1 text-[9px] font-black uppercase rounded-lg transition-all cursor-pointer ${
                complianceMode === "Commercial"
                  ? "text-white shadow-sm"
                  : "text-[#787d8f] hover:text-white"
              }`}
              style={{
                backgroundColor: complianceMode === "Commercial" ? accentColor : "transparent",
                boxShadow: complianceMode === "Commercial" ? `0 0 10px ${accentColor}40` : "none",
              }}
            >
              {isArabic ? "تجاري" : "COMMERCIAL"}
            </button>
          </div>
        </div>

        <div className="space-y-1">
          <label className="text-[9.5px] text-[#787d8f] font-bold uppercase">{isArabic ? "مخطط الملف التدقيقي:" : t("Dossier Blueprint:")}</label>
          <div className="relative">
            <select
              value={selectedReportTheme}
              onChange={(e) => onSelectReportTheme(e.target.value)}
              className="w-full bg-[#05060b] border border-[#1b202e] rounded-xl px-2.5 py-1.5 text-[11px] text-white appearance-none focus:outline-none cursor-pointer pr-7 transition-colors truncate"
              style={{ borderColor: "#1f2638" }}
            >
              {reportThemeOptions.map((th) => (
                <option key={th.id} value={th.id}>
                  {th.label}
                </option>
              ))}
            </select>
            <ChevronDown className="w-3 h-3 text-[#787d8f] absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>
        </div>
      </div>

      {/* NODE 02: TIMING (Time Window & Latency) */}
      <div 
        className="bg-[#080a12]/90 border border-[#181d2a] hover:border-[#2a3248] p-3.5 rounded-2xl transition-all space-y-2.5 relative group shadow-lg"
        style={{
          boxShadow: `0 4px 20px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.03)`,
        }}
      >
        <div className="flex items-center justify-between text-[11px] font-black uppercase">
          <div className="flex items-center gap-1.5" style={{ color: accentColor }}>
            <Clock className="w-3.5 h-3.5" />
            <span>{isArabic ? "العقدة 02: التوقيت الزمني" : t("NODE 02: TIMING")}</span>
          </div>
          <span 
            className="text-[8.5px] px-1.5 py-0.2 rounded font-mono font-bold"
            style={{ backgroundColor: `${accentColor}15`, color: accentColor }}
          >
            UTC
          </span>
        </div>

        <div className="space-y-1">
          <label className="text-[9.5px] text-[#787d8f] font-bold uppercase">{isArabic ? "النافذة الزمنية:" : t("Time Window:")}</label>
          <div className="relative">
            <select
              value={selectedTimeRange}
              onChange={(e) => onSelectTimeRange(e.target.value)}
              className="w-full bg-[#05060b] border border-[#1b202e] rounded-xl px-2.5 py-1.5 text-[11px] text-white appearance-none focus:outline-none cursor-pointer pr-7 transition-colors truncate"
            >
              {timeRangeOptions.map((tr) => (
                <option key={tr.id} value={tr.id}>
                  {tr.label}
                </option>
              ))}
            </select>
            <ChevronDown className="w-3 h-3 text-[#787d8f] absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>
        </div>

        <div className="space-y-1">
          <label className="text-[9.5px] text-[#787d8f] font-bold uppercase">{isArabic ? "تحمل زمن الاستجابة:" : t("Latency Tolerance:")}</label>
          <select
            value={selectedLatency}
            onChange={(e) => onSelectLatency(e.target.value)}
            className="w-full bg-[#05060b] border border-[#1b202e] rounded-xl px-2.5 py-1.5 text-[11px] text-slate-300 focus:outline-none cursor-pointer truncate"
          >
            {latencyOptions.map((lat) => (
              <option key={lat.id} value={lat.id}>
                {lat.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* NODE 03: CURRENCIES & ASSETS */}
      <div 
        className="bg-[#080a12]/90 border border-[#181d2a] hover:border-[#2a3248] p-3.5 rounded-2xl transition-all space-y-2.5 relative group shadow-lg"
        style={{
          boxShadow: `0 4px 20px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.03)`,
        }}
      >
        <div className="flex items-center justify-between text-[11px] font-black uppercase">
          <div className="flex items-center gap-1.5" style={{ color: accentColor }}>
            <Coins className="w-3.5 h-3.5" />
            <span>{isArabic ? "العقدة 03: الأصول والعملات" : t("NODE 03: CURRENCY")}</span>
          </div>
          <span 
            className="text-[8.5px] px-1.5 py-0.2 rounded font-mono font-bold"
            style={{ backgroundColor: `${accentColor}15`, color: accentColor }}
          >
            {isArabic ? "فوري" : "SPOT"}
          </span>
        </div>

        <div className="space-y-1">
          <label className="text-[9.5px] text-[#787d8f] font-bold uppercase">{isArabic ? "الأصل الفوري المستهدف:" : t("Target Spot Asset:")}</label>
          <div className="relative">
            <select
              value={selectedCurrency}
              onChange={(e) => onSelectCurrency(e.target.value)}
              className="w-full bg-[#05060b] border border-[#1b202e] rounded-xl px-2.5 py-1.5 text-[11px] text-white appearance-none focus:outline-none cursor-pointer pr-7 transition-colors truncate"
            >
              {currencyOptions.map((c) => (
                <option key={c.symbol} value={c.symbol}>
                  {c.name || c.symbol}
                </option>
              ))}
            </select>
            <ChevronDown className="w-3 h-3 text-[#787d8f] absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>
        </div>

        <div className="space-y-1">
          <label className="text-[9.5px] text-[#787d8f] font-bold uppercase">{isArabic ? "بوابة حالة الأوامر:" : t("Order Status Gate:")}</label>
          <div className="grid grid-cols-3 gap-1 bg-[#05060b] p-1 border border-[#1b202e] rounded-xl">
            {(["ALL", "APPROVED", "REJECTED"] as const).map((st) => (
              <button
                key={st}
                onClick={() => onSelectStatusFilter(st)}
                className={`py-1 text-[8.5px] font-black uppercase rounded-lg transition-all cursor-pointer ${
                  statusFilter === st
                    ? "text-white shadow-sm"
                    : "text-[#787d8f] hover:text-white"
                }`}
                style={{
                  backgroundColor: statusFilter === st ? accentColor : "transparent",
                  boxShadow: statusFilter === st ? `0 0 10px ${accentColor}40` : "none",
                }}
              >
                {isArabic ? (st === "ALL" ? "الكل" : st === "APPROVED" ? "معتمد" : "مرفوض") : st}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* NODE 04: IMMUTABLE SEAL */}
      <div 
        className="bg-[#080a12]/90 border border-[#181d2a] hover:border-[#2a3248] p-3.5 rounded-2xl transition-all space-y-2.5 relative group shadow-lg"
        style={{
          boxShadow: `0 4px 20px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.03)`,
        }}
      >
        <div className="flex items-center justify-between text-[11px] font-black uppercase">
          <div className="flex items-center gap-1.5" style={{ color: accentColor }}>
            <Hash className="w-3.5 h-3.5" />
            <span>{isArabic ? "العقدة 04: الختم التشفيري الثابت" : t("NODE 04: IMMUTABLE SEAL")}</span>
          </div>
          <span 
            className="text-[8.5px] px-1.5 py-0.2 rounded font-mono font-bold"
            style={{ backgroundColor: `${accentColor}15`, color: accentColor }}
          >
            SHA-256
          </span>
        </div>

        <div className="bg-[#05060b] border border-[#1b202e] p-2 rounded-xl space-y-0.5">
          <div className="text-[8px] text-[#787d8f] uppercase font-bold">{isArabic ? "بصمة التركيب التشفيرية:" : t("Synthesis Fingerprint:")}</div>
          <div 
            className="text-[8.5px] font-mono break-all leading-tight text-white/90"
          >
            {dynamicReportHash}
          </div>
        </div>

        <div className="flex items-center justify-between text-[9.5px] text-[#787d8f] pt-0.5">
          <span>{isArabic ? "الأوامر:" : t("Orders:")} <strong className="text-white">{tailoredOrdersCount}</strong></span>
          <span className="font-bold text-white/80">{isArabic ? "تداول فوري موثق 100%" : "100% VERIFIED SPOT"}</span>
        </div>
      </div>
    </div>
  );
};
