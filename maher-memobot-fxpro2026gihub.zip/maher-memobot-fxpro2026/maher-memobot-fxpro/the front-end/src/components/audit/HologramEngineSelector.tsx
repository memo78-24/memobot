import React from "react";
import { useLanguage } from "../../components/LanguageProvider";

export interface EngineItem {
  id: string;
  name: string;
  nameAr: string;
  code: string;
  exchange: string;
  defaultSymbol: string;
  color: string;
  speedMs: number;
}

export const ENGINES_CATALOG: EngineItem[] = [
  { id: "MEMOBOT", name: "MEMOBOT PRIME", nameAr: "ميموبوت الرئيسي", code: "ENG-000", exchange: "OKX", defaultSymbol: "SOL/USDT", color: "#FA1F4E", speedMs: 0.16 },
  { id: "MEMOCODEX", name: "MEMOCODEX RIGEL", nameAr: "ميموكوديكس ريجل", code: "ENG-X01", exchange: "Binance", defaultSymbol: "BTC/USDT", color: "#FA1F4E", speedMs: 0.14 },
  { id: "ENG-001", name: "SIRIUS ALPHA", nameAr: "سيريوس ألفا", code: "ENG-001", exchange: "LMAX FIX", defaultSymbol: "EUR/USD", color: "#FA1F4E", speedMs: 0.19 },
  { id: "ENG-002", name: "REGULUS PRIME", nameAr: "ريجولوس برايم", code: "ENG-002", exchange: "Binance", defaultSymbol: "BTC/USDT", color: "#FA1F4E", speedMs: 0.18 },
  { id: "ENG-003", name: "ALGOL CORE", nameAr: "رأس الغول (ألجول)", code: "ENG-003", exchange: "OKX", defaultSymbol: "ETH/USDT", color: "#FA1F4E", speedMs: 0.22 },
  { id: "ENG-004", name: "NEXUS ALPHA", nameAr: "نيكسوس ألفا", code: "ENG-004", exchange: "KuCoin", defaultSymbol: "XAU/USD", color: "#FA1F4E", speedMs: 0.20 },
  { id: "ENG-005", name: "UY SCUTI", nameAr: "يو واي سكوتي", code: "ENG-005", exchange: "OKX", defaultSymbol: "BTC/USDT", color: "#FA1F4E", speedMs: 0.25 },
  { id: "ENG-006", name: "ALPHA CENTAURI", nameAr: "رجل القنطور", code: "ENG-006", exchange: "KuCoin", defaultSymbol: "ADA/USDT", color: "#FA1F4E", speedMs: 0.12 },
  { id: "ENG-007", name: "BETELGEUSE", nameAr: "منكب الجوزاء", code: "ENG-007", exchange: "KuCoin", defaultSymbol: "ETH/USDT", color: "#FA1F4E", speedMs: 0.21 },
  { id: "ENG-008", name: "CANOPUS", nameAr: "سهيل (كانوبوس)", code: "ENG-008", exchange: "LMAX", defaultSymbol: "XAU/USD", color: "#FA1F4E", speedMs: 0.15 },
  { id: "ENG-009", name: "ARCTURUS", nameAr: "السماك الرامح", code: "ENG-009", exchange: "Bybit", defaultSymbol: "SOL/USDT", color: "#FA1F4E", speedMs: 0.17 },
  { id: "ENG-010", name: "POLARIS", nameAr: "نجم القطب", code: "ENG-010", exchange: "KuCoin", defaultSymbol: "BTC/USDT", color: "#FA1F4E", speedMs: 0.23 },
];

interface HologramEngineSelectorProps {
  selectedEngine: EngineItem;
  onSelectEngine: (engine: EngineItem) => void;
  accentColor?: string;
}

export const HologramEngineSelector: React.FC<HologramEngineSelectorProps> = ({
  selectedEngine,
  onSelectEngine,
  accentColor = "#FA1F4E",
}) => {
  const { isArabic, t } = useLanguage();

  return (
    <div className="bg-[#07090e] border border-[#171b26] rounded-2xl p-3 shadow-xl relative overflow-hidden" style={{ direction: isArabic ? "rtl" : "ltr" }}>
      <div 
        className="absolute top-0 inset-x-0 h-[1.5px] opacity-70"
        style={{ background: `linear-gradient(90deg, transparent, ${accentColor}, transparent)` }}
      />

      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 mb-2.5 px-1">
        <div className="flex items-center gap-2">
          <div 
            className="w-2 h-2 rounded-full animate-ping"
            style={{ backgroundColor: accentColor }}
          />
          <span className="text-[11px] font-black uppercase text-white tracking-widest font-aquire">
            {isArabic ? "دليل محركات التنفيذ الخوارزمي" : t("EXECUTION ENGINES DIRECTORY")}
          </span>
          <span className="text-[9.5px] text-[#717688]">
            ({isArabic ? "اختر المحرك لعرض التدقيق الهولوغرافي" : t("Select engine to project holographic audit")})
          </span>
        </div>

        <div className="flex items-center gap-1.5 text-[10px]">
          <span className="text-[#717688] font-bold uppercase">{isArabic ? "النشط:" : t("ACTIVE:")}</span>
          <span
            className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase border text-white transition-all shadow-sm"
            style={{
              borderColor: `${accentColor}80`,
              backgroundColor: `${accentColor}15`,
              boxShadow: `0 0 10px ${accentColor}30`,
            }}
          >
            {isArabic ? (selectedEngine.nameAr || selectedEngine.name) : selectedEngine.name}
          </span>
        </div>
      </div>

      {/* Sleek half-size compact 3D buttons */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2">
        {ENGINES_CATALOG.map((eng) => {
          const isSelected = selectedEngine.id === eng.id;
          return (
            <button
              key={eng.id}
              onClick={() => onSelectEngine(eng)}
              className={`group relative py-2 px-2.5 rounded-xl border text-left transition-all duration-200 cursor-pointer overflow-hidden active:scale-95 flex items-center justify-between gap-2 ${
                isSelected
                  ? "bg-gradient-to-b from-[#141926] to-[#0d101a] text-white shadow-lg"
                  : "bg-gradient-to-b from-[#0b0e17] to-[#07090f] border-[#181d2c] hover:border-[#2b334a] hover:from-[#0f1320]"
              }`}
              style={{
                borderColor: isSelected ? accentColor : undefined,
                boxShadow: isSelected
                  ? `0 0 14px ${accentColor}35, inset 0 1px 0 rgba(255,255,255,0.1), 0 3px 6px rgba(0,0,0,0.5)`
                  : "inset 0 1px 0 rgba(255,255,255,0.03), 0 2px 4px rgba(0,0,0,0.4)",
                textAlign: isArabic ? "right" : "left",
              }}
            >
              <div className="min-w-0 flex-1">
                <div
                  className={`text-[10.5px] font-black uppercase tracking-wide truncate transition-all ${
                    isSelected ? "text-white" : "text-slate-300 group-hover:text-white"
                  }`}
                  style={{
                    textShadow: isSelected
                      ? `0 0 10px ${accentColor}80, 0 1px 2px rgba(0,0,0,0.9)`
                      : "0 1px 2px rgba(0,0,0,0.8)",
                  }}
                >
                  {isArabic ? eng.nameAr : eng.name}
                </div>
                <div className="flex items-center gap-1.5 text-[8px] text-[#717688] font-mono mt-0.5">
                  <span className="truncate">{eng.exchange}</span>
                  <span className="opacity-40">&bull;</span>
                  <span style={{ color: isSelected ? accentColor : "#8a8d9a" }}>{eng.speedMs}ms</span>
                </div>
              </div>

              <div
                className="w-1.5 h-1.5 rounded-full shrink-0 transition-all"
                style={{
                  backgroundColor: isSelected ? accentColor : "#2a3144",
                  boxShadow: isSelected ? `0 0 6px ${accentColor}` : "none",
                }}
              />
            </button>
          );
        })}
      </div>
    </div>
  );
};
