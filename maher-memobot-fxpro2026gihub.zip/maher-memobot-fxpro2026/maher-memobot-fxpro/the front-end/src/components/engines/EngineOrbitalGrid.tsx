import React, { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Cpu, Activity, ShieldAlert, Zap, Power, ChevronDown, ChevronUp, Star, HelpCircle } from "lucide-react";
import { Engine } from "../../services/engineStore";

interface EngineOrbitalGridProps {
  engines: Record<string, Engine>;
  selectedEngineId: string;
  onSelectEngine: (id: string) => void;
  onStartStop: (id: string, currentStatus: "Running" | "Stopped") => void;
  complianceMode: "Islamic" | "Commercial";
  onToggleComplianceMode: () => void;
  onKillSwitch: () => void;
  connectionStatus: boolean;
  onPowerOnAll: () => void;
  // Dropdown exchange router callback
  onSelectExchange: (engineId: string, exchange: "Binance" | "KuCoin" | "OKX" | "Bybit") => void;
  // 5 toggle states and setters passed down from parent
  geminiFlash: boolean;
  onToggleGeminiFlash: () => void;
  exchangesEnabled: { Binance: boolean; KuCoin: boolean; OKX: boolean; Bybit: boolean };
  onToggleExchange: (exchange: "Binance" | "KuCoin" | "OKX" | "Bybit") => void;
  selectedExchanges: Record<string, "Binance" | "KuCoin" | "OKX" | "Bybit">;
  children?: React.ReactNode; // Memocore central hub
}

export const EngineOrbitalGrid: React.FC<EngineOrbitalGridProps> = ({
  engines,
  selectedEngineId,
  onSelectEngine,
  onStartStop,
  complianceMode,
  onToggleComplianceMode,
  onKillSwitch,
  connectionStatus,
  onPowerOnAll,
  onSelectExchange,
  geminiFlash,
  onToggleGeminiFlash,
  exchangesEnabled,
  onToggleExchange,
  selectedExchanges,
  children,
}) => {
  const isIslamic = complianceMode === "Islamic";
  const accentColor = isIslamic ? "#10b981" : "#FA1F4E"; // Emerald vs Laser Red
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // States for lower payment fold
  const [isFolded, setIsFolded] = useState(false);
  const [paymentOption, setPaymentOption] = useState<"daily" | "weekly" | "monthly">("weekly");
  const [paymentMethod, setPaymentMethod] = useState<"card" | "apple" | "gpay" | "paypal" | "crypto">("card");

  // Define 12-node symmetric configuration
  const leftNodes = [
    { id: "ENG-005", name: "ENGINE 5", sub: "SYSTEM NODE", subtitle: "Halal Guardian Loop" },
    { id: "MEMOBOT", name: "MEMOBOT", sub: "DECRYPT GATEWAY", subtitle: "AI Dialogue Module", isSpecial: true },
    { id: "MEMOCODEX", name: "MEMOCODEX", sub: "DECRYPT WORKSPACE", subtitle: "App Workspace Core", isSpecial: true },
    { id: "ENG-010", name: "ENGINE 10", sub: "SYSTEM NODE", subtitle: "High-Speed Thread Worker" }
  ];

  const topNodes = [
    { id: "ENG-003", name: "ENGINE 3", sub: "SYSTEM NODE", subtitle: "Pre-Trade Auditing Core" },
    { id: "ENG-002", name: "SIRIUS TRADER", sub: "AUTOPILOT MAIN", subtitle: "Master System Node", isSpecial: true },
    { id: "ENG-001", name: "RIGEL (LAM000R)", sub: "SCALPER MAIN", subtitle: "Manual Scalping Core", isSpecial: true },
    { id: "ENG-004", name: "ENGINE 4", sub: "SYSTEM NODE", subtitle: "Quantitative Arb Feed" }
  ];

  const rightNodes = [
    { id: "ENG-006", name: "ENGINE 1", sub: "SYSTEM NODE", subtitle: "Binance Feed Connector" },
    { id: "ENG-007", name: "ENGINE 2", sub: "SYSTEM NODE", subtitle: "KuCoin Feed Connector" },
    { id: "ENG-008", name: "ENGINE 7", sub: "SYSTEM NODE", subtitle: "OKX Feed Connector" },
    { id: "ENG-009", name: "ENGINE 9", sub: "SYSTEM NODE", subtitle: "Bybit Feed Connector" }
  ];

  // Animated background circuits matching the reference design
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animFrame: number;
    let width = (canvas.width = canvas.parentElement?.clientWidth || window.innerWidth);
    let height = (canvas.height = canvas.parentElement?.clientHeight || 650);

    const handleResize = () => {
      if (canvas && canvas.parentElement) {
        width = canvas.width = canvas.parentElement.clientWidth;
        height = canvas.height = canvas.parentElement.clientHeight;
      }
    };
    window.addEventListener("resize", handleResize);

    interface CircuitLine {
      x: number;
      y: number;
      tx: number;
      ty: number;
      progress: number;
      speed: number;
      color: string;
      width: number;
    }

    const circuits: CircuitLine[] = Array.from({ length: 40 }, () => {
      const angle = Math.random() * Math.PI * 2;
      const length = 120 + Math.random() * 320;
      return {
        x: width / 2,
        y: height / 2,
        tx: width / 2 + Math.cos(angle) * length,
        ty: height / 2 + Math.sin(angle) * length,
        progress: Math.random(),
        speed: 0.003 + Math.random() * 0.005,
        color: isIslamic ? "rgba(16, 185, 129, " : "rgba(250, 31, 78, ",
        width: 1 + Math.random() * 1.5
      };
    });

    const render = () => {
      ctx.fillStyle = "rgba(4, 5, 8, 0.25)";
      ctx.fillRect(0, 0, width, height);

      // Cyber Grid Overlays
      ctx.strokeStyle = isIslamic ? "rgba(16, 185, 129, 0.03)" : "rgba(250, 31, 78, 0.02)";
      ctx.lineWidth = 1;
      const spacing = 35;
      for (let x = 0; x < width; x += spacing) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = 0; y < height; y += spacing) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      // Render flowing circuits with neon endpoints
      circuits.forEach((c) => {
        c.progress += c.speed;
        if (c.progress > 1) {
          c.progress = 0;
          const angle = Math.random() * Math.PI * 2;
          const length = 120 + Math.random() * 320;
          c.tx = width / 2 + Math.cos(angle) * length;
          c.ty = height / 2 + Math.sin(angle) * length;
        }

        const currX = c.x + (c.tx - c.x) * c.progress;
        const currY = c.y + (c.ty - c.y) * c.progress;

        ctx.beginPath();
        ctx.moveTo(c.x, c.y);
        ctx.lineTo(currX, currY);
        ctx.strokeStyle = `${c.color}${0.05 + (1 - c.progress) * 0.3})`;
        ctx.lineWidth = c.width;
        ctx.stroke();

        ctx.beginPath();
        ctx.arc(currX, currY, c.width * 1.8, 0, Math.PI * 2);
        ctx.fillStyle = c.color.replace(", ", ", 0.85)");
        ctx.fill();
      });

      animFrame = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animFrame);
      window.removeEventListener("resize", handleResize);
    };
  }, [complianceMode]);

  const renderNodeCard = (node: typeof leftNodes[0], group: "left" | "top" | "right") => {
    // Check if node is interactive or mapped to a database engine
    const eng = engines[node.id] || { status: "Stopped", strategy: "FAST SCALPER", cpu_load: 0, memory_mb: 12 };
    const isRunning = eng.status === "Running";
    const isSelected = selectedEngineId === node.id;
    const currentExchange = selectedExchanges[node.id] || "Binance";

    // Colors matching state
    const nodeBorderClass = isSelected
      ? isIslamic
        ? "border-emerald-500 shadow-[0_0_15px_rgba(16,185,129,0.35)] bg-emerald-950/5"
        : "border-rose-500 shadow-[0_0_15px_rgba(250,31,78,0.35)] bg-rose-950/5"
      : isRunning
      ? isIslamic
        ? "border-emerald-500/20 hover:border-emerald-500/50"
        : "border-rose-500/20 hover:border-rose-500/50"
      : "border-[#141622] hover:border-[#2f354a]";

    return (
      <motion.div
        key={node.id}
        whileHover={{ scale: 1.03 }}
        onClick={() => onSelectEngine(node.id)}
        className={`relative p-3.5 rounded-xl border bg-[#030508]/95 select-none cursor-pointer transition-all ${nodeBorderClass}`}
      >
        {node.isSpecial && (
          <div
            className={`absolute -top-2 left-1/2 -translate-x-1/2 text-[7px] font-mono font-bold px-2 py-0.5 rounded uppercase tracking-wider text-white`}
            style={{ backgroundColor: accentColor }}
          >
            {node.sub}
          </div>
        )}

        <div className="flex items-center justify-between gap-2 mb-1.5 mt-1">
          <div className="flex items-center gap-1.5">
            <Cpu className="w-3.5 h-3.5" style={{ color: accentColor }} />
            <h4 className="text-[10px] font-mono font-black text-white tracking-wider">{node.name}</h4>
          </div>
          <span
            onClick={(e) => {
              e.stopPropagation();
              onStartStop(node.id, eng.status as any);
            }}
            className={`text-[7px] font-mono font-black px-1.5 py-0.5 rounded cursor-pointer uppercase select-none transition-colors ${
              isRunning
                ? "bg-emerald-500/15 text-emerald-400 hover:bg-rose-500/20 hover:text-rose-400"
                : "bg-zinc-800 text-zinc-500 hover:bg-emerald-500/20 hover:text-emerald-400"
            }`}
          >
            {eng.status || "Stopped"}
          </span>
        </div>

        <p className="text-[8px] text-[#6b6f77] font-mono text-left truncate uppercase leading-none tracking-tight">
          {node.subtitle}
        </p>

        {/* Dropdown Exchange Selection - Rule 4 requirement */}
        <div className="mt-2.5 flex items-center justify-between border-t border-[#11131c] pt-2">
          <span className="text-[7px] text-[#6b6f77] font-bold uppercase tracking-wide">Route:</span>
          <div className="relative" onClick={(e) => e.stopPropagation()}>
            <select
              value={currentExchange}
              onChange={(e) => onSelectExchange(node.id, e.target.value as any)}
              className="bg-black/85 border border-[#171926] text-[#a0a5b5] hover:text-white rounded px-1.5 py-0.5 text-[8px] font-mono font-bold outline-none cursor-pointer tracking-wider"
            >
              <option value="Binance">Binance</option>
              <option value="KuCoin">KuCoin</option>
              <option value="OKX">OKX</option>
              <option value="Bybit">Bybit</option>
            </select>
          </div>
        </div>
      </motion.div>
    );
  };

  return (
    <div id="central-cyber-station" className="w-full relative bg-[#040508] border border-[#11131a] rounded-2xl overflow-hidden min-h-[750px] flex flex-col justify-between">
      {/* 1. ANIMATING BG CIRCUIT CANVAS */}
      <canvas ref={canvasRef} className="absolute inset-0 z-0 pointer-events-none" />

      {/* Decorative backdrop gradients */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(17,19,26,0.5),transparent_75%)] pointer-events-none" />

      {/* Header and Compliance Switcher */}
      <div className="relative z-10 flex flex-col sm:flex-row justify-between items-center p-6 gap-4 border-b border-[#11131a]">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-slate-950/85 border border-[#1d2133] rounded">
            <Zap className="w-5 h-5" style={{ color: accentColor }} />
          </div>
          <div>
            <span className="text-[8px] text-[#6b6f77] block font-mono font-bold uppercase tracking-widest">CENTRAL GRID ENGINE</span>
            <span className="text-sm font-sans font-black text-slate-100 tracking-wider">MEMOCORE MATRIX DECK</span>
          </div>
        </div>

        {/* Dual Mode Switcher - Rule 3 */}
        <div className="flex items-center gap-3 p-1 bg-black/60 border border-[#161822] rounded-lg">
          <button
            onClick={() => { if (!isIslamic) onToggleComplianceMode(); }}
            className={`px-3 py-1 text-[9px] font-mono font-black uppercase rounded transition-all ${
              isIslamic
                ? "bg-emerald-500 text-black shadow-[0_0_10px_rgba(16,185,129,0.3)]"
                : "text-zinc-500 hover:text-zinc-300"
            }`}
          >
            Islamic Mode
          </button>
          <button
            onClick={() => { if (isIslamic) onToggleComplianceMode(); }}
            className={`px-3 py-1 text-[9px] font-mono font-black uppercase rounded transition-all ${
              !isIslamic
                ? "bg-rose-600 text-white shadow-[0_0_10px_rgba(250,31,78,0.3)]"
                : "text-zinc-500 hover:text-zinc-300"
            }`}
          >
            Commercial Mode
          </button>
        </div>
      </div>

      {/* 2. SYMMETRICAL 12-NODE SATELLITE MAP */}
      <div className="relative z-10 w-full max-w-7xl mx-auto px-6 py-6 flex-1 flex flex-col justify-between gap-8">
        
        {/* Top 4 Nodes row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 w-full">
          {topNodes.map((n) => renderNodeCard(n, "top"))}
        </div>

        {/* Central Core Circle Container with Left and Right Wings */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center w-full my-auto">
          
          {/* Left Stack (4 nodes) */}
          <div className="lg:col-span-3 space-y-4 flex flex-col justify-center">
            <span className="text-[7px] text-[#6b6f77] font-mono block text-center uppercase tracking-widest">Left Wing Telemetries</span>
            {leftNodes.map((n) => renderNodeCard(n, "left"))}
          </div>

          {/* Central Rotating Vortex & Title */}
          <div className="lg:col-span-6 flex flex-col items-center justify-center relative min-h-[300px]">
            {children}
          </div>

          {/* Right Stack (4 nodes) */}
          <div className="lg:col-span-3 space-y-4 flex flex-col justify-center">
            <span className="text-[7px] text-[#6b6f77] font-mono block text-center uppercase tracking-widest">Right Wing Telemetries</span>
            {rightNodes.map((n) => renderNodeCard(n, "right"))}
          </div>

        </div>

      </div>

      {/* 3. SIDEBAR METRICS & POWER SWITCH (RIGHT FLANK) */}
      <div className="absolute top-28 right-6 z-20 flex flex-col items-center gap-5 font-mono">
        <div className="bg-black/60 border border-[#161822]/80 p-3 rounded-xl space-y-4 flex flex-col items-center">
          
          {/* Load */}
          <div className="flex flex-col items-center">
            <div className="relative w-12 h-12 rounded-full border border-dashed flex flex-col items-center justify-center bg-slate-950/80" style={{ borderColor: accentColor }}>
              <span className="text-xs font-black text-slate-100">{connectionStatus ? "78" : "0"}</span>
              <span className="text-[6px] text-zinc-500">%</span>
            </div>
            <span className="text-[7px] text-zinc-400 tracking-wider mt-1 uppercase">CPU LOAD</span>
          </div>

          {/* Latency */}
          <div className="flex flex-col items-center">
            <div className="relative w-12 h-12 rounded-full border border-dashed flex flex-col items-center justify-center bg-slate-950/80" style={{ borderColor: accentColor }}>
              <span className="text-[10px] font-black text-slate-100">{connectionStatus ? "14" : "0"}</span>
              <span className="text-[6px] text-zinc-500">ms</span>
            </div>
            <span className="text-[7px] text-zinc-400 tracking-wider mt-1 uppercase">LATENCY</span>
          </div>

          {/* Power switch - Rule 1 requirement */}
          <div className="flex flex-col items-center mt-1 border-t border-[#1a1d2d] pt-3">
            <button
              onClick={() => {
                if (connectionStatus) {
                  onKillSwitch();
                } else {
                  onPowerOnAll();
                }
              }}
              className={`h-9 w-14 rounded-full p-0.5 flex items-center transition-all ${
                connectionStatus
                  ? "bg-rose-950/50 border border-rose-500 justify-end shadow-[0_0_12px_rgba(244,63,94,0.3)]"
                  : "bg-zinc-950 border border-zinc-800 justify-start"
              }`}
            >
              <div
                className={`h-7 w-7 rounded-full flex items-center justify-center text-slate-950 shadow-md transition-all ${
                  connectionStatus ? "bg-rose-500" : "bg-zinc-700"
                }`}
              >
                <Power className="w-3.5 h-3.5 text-black font-bold" />
              </div>
            </button>
            <span className="text-[7px] tracking-widest mt-1.5 uppercase font-black" style={{ color: connectionStatus ? accentColor : "#6b6f77" }}>
              {connectionStatus ? "ARMED" : "HALTED"}
            </span>
          </div>

        </div>
      </div>

      {/* 4. THE REDESIGNED QUICK PAYMENT BENCH WITH 5 DYNAMIC ROUTING TOGGLES */}
      <div className="relative z-10 w-full max-w-xl mx-auto px-4 mb-6">
        <div className="bg-[#030508]/95 border border-[#161822] shadow-[0_-10px_35px_rgba(0,0,0,0.85)] rounded-xl overflow-hidden transition-all duration-300">
          
          {/* Fold Header */}
          <div className="flex items-center justify-between border-b border-[#161822] px-4 py-2.5 bg-[#030508]/60 font-mono text-[10px]">
            <div className="flex items-center gap-2 text-cyan-400">
              <Zap className="w-3.5 h-3.5 animate-pulse" />
              <span className="font-bold uppercase tracking-widest">MEMO CORE INTERACTIVE CONTROL BENCH</span>
            </div>
            <button
              onClick={() => setIsFolded(!isFolded)}
              className="text-zinc-500 hover:text-white transition-colors text-[8px] font-mono tracking-widest uppercase font-bold"
            >
              [{isFolded ? "UNFOLD" : "FOLD"}]
            </button>
          </div>

          {/* Pricing Grid (Collapsible) */}
          <AnimatePresence>
            {!isFolded && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="p-4 space-y-4 overflow-hidden"
              >
                <div className="grid grid-cols-3 gap-3">
                  <button
                    onClick={() => setPaymentOption("daily")}
                    className={`relative p-3 rounded-lg border text-center transition-all ${
                      paymentOption === "daily"
                        ? "border-cyan-500 bg-cyan-950/15"
                        : "border-[#141622] hover:border-zinc-800 bg-zinc-950/40"
                    }`}
                  >
                    <span className="block text-[8px] font-mono text-[#6b6f77] tracking-wider">DAILY</span>
                    <span className="block text-lg font-black text-white mt-0.5">$3</span>
                    <span className="block text-[7px] font-mono text-[#6b6f77] mt-0.5">Billed Daily</span>
                  </button>

                  <button
                    onClick={() => setPaymentOption("weekly")}
                    className={`relative p-3 rounded-lg border text-center transition-all ${
                      paymentOption === "weekly"
                        ? "border-rose-500 bg-rose-950/15"
                        : "border-[#141622] hover:border-zinc-800 bg-zinc-950/40"
                    }`}
                  >
                    <div className="absolute -top-2 left-1/2 -translate-x-1/2 bg-rose-500 text-white text-[6px] font-extrabold px-1.5 py-0.5 rounded uppercase tracking-wider font-mono">
                      POPULAR
                    </div>
                    <span className="block text-[8px] font-mono text-[#6b6f77] tracking-wider">WEEKLY</span>
                    <span className="block text-lg font-black text-white mt-0.5">$18</span>
                    <span className="block text-[7px] font-mono text-[#6b6f77] mt-0.5">Billed Weekly</span>
                  </button>

                  <button
                    onClick={() => setPaymentOption("monthly")}
                    className={`relative p-3 rounded-lg border text-center transition-all ${
                      paymentOption === "monthly"
                        ? "border-cyan-500 bg-cyan-950/15"
                        : "border-[#141622] hover:border-zinc-800 bg-zinc-950/40"
                    }`}
                  >
                    <div className="absolute -top-2 left-1/2 -translate-x-1/2 bg-cyan-400 text-black text-[6px] font-extrabold px-1.5 py-0.5 rounded uppercase tracking-wider font-mono">
                      BEST VALUE
                    </div>
                    <span className="block text-[8px] font-mono text-[#6b6f77] tracking-wider">MONTHLY</span>
                    <span className="block text-lg font-black text-white mt-0.5">$50</span>
                    <span className="block text-[7px] font-mono text-[#6b6f77] mt-0.5">Billed Monthly</span>
                  </button>
                </div>

                {/* The 5 Toggle Switchers - Rule 2 requirement */}
                <div className="border-t border-[#161822] pt-3.5 space-y-2">
                  <span className="text-[8px] text-[#6b6f77] font-mono font-black uppercase block tracking-wider mb-2">
                    5-CHANNEL GATEWAY & ROUTING TOGGLES
                  </span>
                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                    {/* Gemini Flash */}
                    <div className="flex flex-col items-center bg-black/40 border border-[#161822] p-2 rounded-lg">
                      <span className="text-[7px] text-[#6b6f77] font-black uppercase tracking-tight mb-1.5 truncate">GEMINI FLASH</span>
                      <button
                        onClick={onToggleGeminiFlash}
                        className={`w-10 h-5 rounded-full p-0.5 flex items-center transition-all ${
                          geminiFlash ? "bg-purple-600 justify-end" : "bg-zinc-800 justify-start"
                        }`}
                      >
                        <div className="w-4 h-4 rounded-full bg-white shadow" />
                      </button>
                    </div>

                    {/* Binance */}
                    <div className="flex flex-col items-center bg-black/40 border border-[#161822] p-2 rounded-lg">
                      <span className="text-[7px] text-[#6b6f77] font-black uppercase tracking-tight mb-1.5 truncate">BINANCE</span>
                      <button
                        onClick={() => onToggleExchange("Binance")}
                        className={`w-10 h-5 rounded-full p-0.5 flex items-center transition-all ${
                          exchangesEnabled.Binance ? "bg-emerald-600 justify-end" : "bg-zinc-800 justify-start"
                        }`}
                      >
                        <div className="w-4 h-4 rounded-full bg-white shadow" />
                      </button>
                    </div>

                    {/* KuCoin */}
                    <div className="flex flex-col items-center bg-black/40 border border-[#161822] p-2 rounded-lg">
                      <span className="text-[7px] text-[#6b6f77] font-black uppercase tracking-tight mb-1.5 truncate">KUCOIN</span>
                      <button
                        onClick={() => onToggleExchange("KuCoin")}
                        className={`w-10 h-5 rounded-full p-0.5 flex items-center transition-all ${
                          exchangesEnabled.KuCoin ? "bg-emerald-600 justify-end" : "bg-zinc-800 justify-start"
                        }`}
                      >
                        <div className="w-4 h-4 rounded-full bg-white shadow" />
                      </button>
                    </div>

                    {/* OKX */}
                    <div className="flex flex-col items-center bg-black/40 border border-[#161822] p-2 rounded-lg">
                      <span className="text-[7px] text-[#6b6f77] font-black uppercase tracking-tight mb-1.5 truncate">OKX</span>
                      <button
                        onClick={() => onToggleExchange("OKX")}
                        className={`w-10 h-5 rounded-full p-0.5 flex items-center transition-all ${
                          exchangesEnabled.OKX ? "bg-emerald-600 justify-end" : "bg-zinc-800 justify-start"
                        }`}
                      >
                        <div className="w-4 h-4 rounded-full bg-white shadow" />
                      </button>
                    </div>

                    {/* Bybit */}
                    <div className="flex flex-col items-center bg-black/40 border border-[#161822] p-2 rounded-lg">
                      <span className="text-[7px] text-[#6b6f77] font-black uppercase tracking-tight mb-1.5 truncate">BYBIT</span>
                      <button
                        onClick={() => onToggleExchange("Bybit")}
                        className={`w-10 h-5 rounded-full p-0.5 flex items-center transition-all ${
                          exchangesEnabled.Bybit ? "bg-emerald-600 justify-end" : "bg-zinc-800 justify-start"
                        }`}
                      >
                        <div className="w-4 h-4 rounded-full bg-white shadow" />
                      </button>
                    </div>
                  </div>
                </div>

                {/* Payment Methods */}
                <div className="border-t border-[#161822] pt-3 flex flex-col gap-2">
                  <div className="flex justify-between items-center text-[7px] text-zinc-500 tracking-wider uppercase font-bold">
                    <span>Active Gateway Channel</span>
                    <span className="text-cyan-400">Card Terminal Online</span>
                  </div>
                  <div className="grid grid-cols-5 gap-1.5">
                    {[
                      { id: "card", name: "CARD" },
                      { id: "apple", name: "APPLE" },
                      { id: "gpay", name: "G-PAY" },
                      { id: "paypal", name: "PAYPAL" },
                      { id: "crypto", name: "CRYPTO" },
                    ].map((m) => (
                      <button
                        key={m.id}
                        onClick={() => setPaymentMethod(m.id as any)}
                        className={`py-1.5 rounded text-[8px] font-mono font-bold transition-all border ${
                          paymentMethod === m.id
                            ? isIslamic
                              ? "border-emerald-500 bg-emerald-950/20 text-emerald-400"
                              : "border-rose-500 bg-rose-950/20 text-rose-400"
                            : "border-[#141622] bg-[#07090f]/60 text-zinc-500 hover:text-white hover:border-zinc-800"
                        }`}
                      >
                        {m.name}
                      </button>
                    ))}
                  </div>
                </div>

              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

    </div>
  );
};
