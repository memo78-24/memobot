import React from "react";
import { Terminal, Trash2 } from "lucide-react";

interface TerminalLogsProps {
  logs: Record<string, string[]>;
  selectedEngineId: string;
  selectedEngineName: string;
  onClearLogs: () => void;
}

export const TerminalLogs: React.FC<TerminalLogsProps> = ({
  logs,
  selectedEngineId,
  selectedEngineName,
  onClearLogs,
}) => {
  const activeLogs = logs[selectedEngineId] || [];

  return (
    <div id="terminal-logs" className="p-4 bg-[#030406]/95 border border-[#161822] rounded-2xl relative overflow-hidden flex flex-col h-[280px]">
      {/* Decorative backdrop grid */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(17,19,28,0.15)_1px,transparent_1px)] bg-[size:100%_4px] pointer-events-none" />

      {/* Header */}
      <div className="flex justify-between items-center border-b border-[#161822] pb-2 mb-2 shrink-0 relative z-10">
        <div className="flex items-center gap-2">
          <Terminal className="w-3.5 h-3.5 text-zinc-500" />
          <span className="text-[10px] font-mono text-zinc-400 font-extrabold uppercase tracking-wider">
            {selectedEngineName} Live Stream Observability Feed
          </span>
        </div>

        <button
          onClick={onClearLogs}
          className="p-1 hover:bg-zinc-800 text-zinc-500 hover:text-white rounded transition-colors"
          title="Clear Terminal Feed"
        >
          <Trash2 className="w-3 h-3" />
        </button>
      </div>

      {/* Logs Scroll Area */}
      <div className="flex-1 overflow-y-auto font-mono text-[10px] text-zinc-500 space-y-1 relative z-10 p-2 bg-black/40 border border-[#161822]/40 rounded-lg">
        {activeLogs.length === 0 ? (
          <div className="text-center py-12 text-[9px] text-zinc-700 italic">
            [STANDBY] System operational. Awaiting algorithmic events or manual order dispatches...
          </div>
        ) : (
          activeLogs.map((line, idx) => {
            let lineClass = "text-zinc-500";
            if (line.includes("[PIPELINE]")) lineClass = "text-[#a855f7]";
            if (line.includes("[TRANSACTION]")) lineClass = "text-emerald-400 font-bold";
            if (line.includes("[REJECTED]") || line.includes("[EMERGENCY]")) lineClass = "text-rose-500 font-bold";
            if (line.includes("[SYSTEM]")) lineClass = "text-zinc-400";

            return (
              <div key={idx} className="leading-normal border-b border-[#0b0c10]/40 pb-0.5 last:border-0 flex items-start gap-1">
                <span className="text-[8px] text-zinc-700 shrink-0 select-none">[{idx + 1}]</span>
                <span className={lineClass}>{line}</span>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
