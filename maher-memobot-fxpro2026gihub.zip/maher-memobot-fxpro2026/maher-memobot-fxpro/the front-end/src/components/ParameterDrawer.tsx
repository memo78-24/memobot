import React from "react";
import { motion, AnimatePresence } from "motion/react";
import { Cpu, X } from "lucide-react";

interface ParameterDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  selectedEngineId: string;
  selectedEngine: {
    nickname?: string;
    display_name?: string;
    status?: string;
    strategy?: string;
    asset?: string;
  };
  localConfig: { strategy: string; asset: string; amount: number; leverage: number };
  onUpdateConfig: (field: string, value: any) => void;
  onApplyConfig: () => void;
  savingState: boolean;
  saveMessage: string | null;
  handleStartStop: (id: string, status: string) => void;
  handleManualTrade: (side: "BUY" | "SELL") => void;
}

export const ParameterDrawer: React.FC<ParameterDrawerProps> = ({
  isOpen,
  onClose,
  selectedEngineId,
  selectedEngine,
  localConfig,
  onUpdateConfig,
  onApplyConfig,
  savingState,
  saveMessage,
  handleStartStop,
  handleManualTrade,
}) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="absolute inset-0 bg-black/70 backdrop-blur-sm z-40 flex justify-end"
          onClick={onClose}
        >
          <motion.div
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 20, stiffness: 120 }}
            className="w-full max-w-md bg-[#090b11] border-l border-slate-800 h-full shadow-2xl flex flex-col p-6 overflow-y-auto space-y-6 pointer-events-auto select-none"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <Cpu className="w-5 h-5 text-red-500" />
                  <h3 className="text-sm font-black text-slate-100 tracking-wider uppercase font-mono">
                    {selectedEngine.nickname || selectedEngine.display_name} CONFIG
                  </h3>
                </div>
                <span className="text-[9px] text-slate-500 font-mono mt-1 uppercase">
                  Configuring node • {selectedEngineId}
                </span>
              </div>
              <button
                onClick={onClose}
                className="p-1.5 rounded border border-slate-800 bg-[#0d1017] text-zinc-500 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Status Section */}
            <div className="bg-[#0e111a] p-4 rounded border border-slate-800 flex items-center justify-between">
              <div>
                <span className="text-[8px] text-zinc-500 font-mono block uppercase">Operational Status</span>
                <span
                  className="text-xs font-mono font-black uppercase mt-1 block"
                  style={{ color: selectedEngine.status === "Running" ? "#10b981" : "#ef4444" }}
                >
                  {selectedEngine.status || "Stopped"}
                </span>
              </div>
              <button
                onClick={() => handleStartStop(selectedEngineId, selectedEngine.status || "Stopped")}
                className={`px-4 py-2 text-[10px] font-mono font-black uppercase rounded transition-all flex items-center gap-1.5 border ${
                  selectedEngine.status === "Running"
                    ? "border-red-500 text-red-500 bg-red-500/10 hover:bg-red-500 hover:text-white"
                    : "border-purple-500 text-purple-500 bg-purple-500/10 hover:bg-purple-500 hover:text-white"
                }`}
              >
                {selectedEngine.status === "Running" ? "HALT THREAD" : "DEPLOY THREAD"}
              </button>
            </div>

            {/* Configure Fields */}
            <div className="space-y-4">
              <div>
                <label className="text-[9px] font-mono text-zinc-400 block mb-1.5 uppercase tracking-wider">Strategy Blueprint</label>
                <input
                  type="text"
                  value={localConfig.strategy || ""}
                  onChange={(e) => onUpdateConfig("strategy", e.target.value)}
                  className="w-full bg-[#0d1017] border border-slate-800 rounded px-3 py-2 text-xs font-mono text-white outline-none focus:border-red-500"
                />
              </div>

              <div>
                <label className="text-[9px] font-mono text-zinc-400 block mb-1.5 uppercase tracking-wider">Asset Target Pair</label>
                <input
                  type="text"
                  value={localConfig.asset || ""}
                  onChange={(e) => onUpdateConfig("asset", e.target.value)}
                  className="w-full bg-[#0d1017] border border-slate-800 rounded px-3 py-2 text-xs font-mono text-white outline-none focus:border-red-500"
                />
              </div>

              <div>
                <label className="text-[9px] font-mono text-zinc-400 block mb-1.5 uppercase tracking-wider">Allocation Size (USDT)</label>
                <input
                  type="number"
                  value={localConfig.amount || 100}
                  onChange={(e) => onUpdateConfig("amount", Number(e.target.value))}
                  className="w-full bg-[#0d1017] border border-slate-800 rounded px-3 py-2 text-xs font-mono text-white outline-none focus:border-red-500"
                />
              </div>

              <div>
                <label className="text-[9px] font-mono text-zinc-400 block mb-1.5 uppercase tracking-wider">Max Leverage Multiplier</label>
                <input
                  type="number"
                  value={localConfig.leverage || 1}
                  onChange={(e) => onUpdateConfig("leverage", Number(e.target.value))}
                  className="w-full bg-[#0d1017] border border-slate-800 rounded px-3 py-2 text-xs font-mono text-white outline-none focus:border-red-500"
                />
              </div>

              <button
                onClick={onApplyConfig}
                className="w-full py-2.5 bg-red-600 hover:bg-red-700 text-white font-mono text-xs font-bold rounded uppercase tracking-wider transition-all"
              >
                {savingState ? "APPLYING PARAMETERS..." : "APPLY PARAMETERS"}
              </button>
              {saveMessage && (
                <span className="block text-[9px] font-mono text-center text-emerald-400 tracking-wider">
                  {saveMessage}
                </span>
              )}
            </div>

            {/* Spot Order Dispatcher */}
            <div className="border-t border-slate-800 pt-6 space-y-3">
              <span className="text-[9px] text-slate-400 font-mono block uppercase tracking-wider">Manual Pipeline Order</span>
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => handleManualTrade("BUY")}
                  className="py-2 bg-emerald-600/90 hover:bg-emerald-600 text-white font-mono text-xs font-bold rounded uppercase tracking-wider"
                >
                  SPOT BUY
                </button>
                <button
                  onClick={() => handleManualTrade("SELL")}
                  className="py-2 bg-rose-600/90 hover:bg-rose-600 text-white font-mono text-xs font-bold rounded uppercase tracking-wider"
                >
                  SPOT SELL
                </button>
              </div>
            </div>

          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
