import React, { useState, useEffect, useRef } from "react";
import { Globe, Check, X, Sparkles, CornerDownLeft, ExternalLink } from "lucide-react";
import { TranslationService } from "../../services/translationService";
import { transformToLiteralArabic, transformArabicToEnglish, suggestArabicTranslation } from "../../config/arabicDictionary";
import { useLanguage } from "../LanguageProvider";
import { useTheme } from "../ThemeProvider";

interface Props {
  showAlert?: (msg: string) => void;
}

export const SelectionQuickTranslator: React.FC<Props> = ({ showAlert }) => {
  const [markedText, setMarkedText] = useState<string>("");
  const [btnPos, setBtnPos] = useState<{ x: number; y: number } | null>(null);
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  
  const [sourceText, setSourceText] = useState("");
  const [arabicText, setArabicText] = useState("");
  const arabicInputRef = useRef<HTMLTextAreaElement | null>(null);
  const popoverRef = useRef<HTMLDivElement | null>(null);

  const { isArabic, forceRetranslateAll } = useLanguage();
  
  let accentColor = "#FA1F4E";
  try {
    const theme = useTheme();
    if (theme?.accentColor) accentColor = theme.accentColor;
  } catch (e) {}

  // Detect mouse selection on screen
  useEffect(() => {
    const handleSelection = () => {
      if (isEditorOpen) return; // keep editor open if already editing

      const sel = window.getSelection();
      if (!sel || sel.rangeCount === 0 || sel.isCollapsed) {
        if (!isEditorOpen) {
          setBtnPos(null);
          setMarkedText("");
        }
        return;
      }

      const text = sel.toString().trim();
      if (!text || text.length < 1) {
        setBtnPos(null);
        setMarkedText("");
        return;
      }

      // Avoid triggering when selecting inside input/textarea fields of our own editor
      const anchorNode = sel.anchorNode;
      if (anchorNode && (anchorNode as HTMLElement).parentElement?.closest("#selection-quick-translator-popover")) {
        return;
      }

      try {
        const range = sel.getRangeAt(0);
        const rect = range.getBoundingClientRect();
        if (rect.width === 0 && rect.height === 0) return;

        // Position pill centered above the selection (or below if too close to top)
        const x = Math.max(10, Math.min(window.innerWidth - 220, rect.left + rect.width / 2 - 90));
        const y = rect.top < 60 ? rect.bottom + 10 : rect.top - 42;

        setMarkedText(text);
        setBtnPos({ x, y });
      } catch (e) {
        // Range might be detached
      }
    };

    const handleMouseUp = () => {
      setTimeout(handleSelection, 10);
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.key === "Shift" || e.key.startsWith("Arrow")) {
        setTimeout(handleSelection, 10);
      }
    };

    // Hotkey: Alt + T or clicking header button with active selection
    const handleCustomTrigger = (e: any) => {
      const targetText = e.detail?.text || window.getSelection()?.toString().trim();
      if (targetText) {
        openEditorForText(targetText);
      }
    };

    const handleGlobalKeyDown = (e: KeyboardEvent) => {
      if (e.altKey && (e.key === "t" || e.key === "T" || e.key === "ف")) {
        const sel = window.getSelection()?.toString().trim();
        if (sel) {
          e.preventDefault();
          openEditorForText(sel);
        }
      }
    };

    window.addEventListener("mouseup", handleMouseUp);
    window.addEventListener("keyup", handleKeyUp);
    window.addEventListener("keydown", handleGlobalKeyDown);
    window.addEventListener("memobot:open_selection_translator", handleCustomTrigger);

    return () => {
      window.removeEventListener("mouseup", handleMouseUp);
      window.removeEventListener("keyup", handleKeyUp);
      window.removeEventListener("keydown", handleGlobalKeyDown);
      window.removeEventListener("memobot:open_selection_translator", handleCustomTrigger);
    };
  }, [isEditorOpen]);

  const openEditorForText = (text: string) => {
    const isAr = /[\u0600-\u06FF]/.test(text);
    const en = isAr ? transformArabicToEnglish(text) : text;
    let ar = isAr ? text : suggestArabicTranslation(text);

    // If ar is identical to en or has no Arabic characters, leave blank for user input
    if (!isAr && (!ar || !/[\u0600-\u06FF]/.test(ar) || ar.trim().toUpperCase() === en.trim().toUpperCase())) {
      ar = "";
    }

    setSourceText(en);
    setArabicText(ar);
    setIsEditorOpen(true);

    // Calculate position for popover
    const sel = window.getSelection();
    if (sel && sel.rangeCount > 0 && !sel.isCollapsed) {
      const rect = sel.getRangeAt(0).getBoundingClientRect();
      const x = Math.max(20, Math.min(window.innerWidth - 380, rect.left + rect.width / 2 - 180));
      const y = Math.max(70, Math.min(window.innerHeight - 340, rect.bottom + 10));
      setBtnPos({ x, y });
    } else {
      setBtnPos({ x: window.innerWidth / 2 - 180, y: 150 });
    }

    setTimeout(() => {
      arabicInputRef.current?.focus();
      if (ar) {
        arabicInputRef.current?.select();
      }
    }, 50);
  };

  const handleSaveAndApply = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!sourceText.trim() || !arabicText.trim()) {
      showAlert?.("Please enter both source and translation text.");
      return;
    }

    const cleanEn = sourceText.trim();
    const cleanAr = arabicText.trim();

    // 1. Save permanently to translation engine
    const success = TranslationService.saveTranslation(cleanEn, cleanAr);

    if (success) {
      // 2. Retranslate DOM live immediately
      forceRetranslateAll();

      showAlert?.(`Direct translation saved & applied for "${cleanEn.slice(0, 25)}..."!`);
      setIsEditorOpen(false);
      setBtnPos(null);
      setMarkedText("");

      // Clear window selection
      window.getSelection()?.removeAllRanges();
    }
  };

  const handleKeyDownInEditor = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSaveAndApply();
    } else if (e.key === "Escape") {
      setIsEditorOpen(false);
      setBtnPos(null);
    }
  };

  if (!btnPos) return null;

  return (
    <>
      {/* Floating Mini Action Pill (Hovering near selection) */}
      {!isEditorOpen && markedText && (
        <div
          style={{ top: btnPos.y, left: btnPos.x }}
          className="fixed z-[999999] animate-in fade-in zoom-in-95 duration-100 font-mono"
        >
          <button
            onClick={() => openEditorForText(markedText)}
            style={{ borderColor: accentColor, boxShadow: `0 0 20px ${accentColor}40` }}
            className="px-3 py-1.5 rounded-full bg-[#0a0c14]/95 hover:bg-[#121624] border text-white text-xs font-bold flex items-center gap-2 shadow-2xl backdrop-blur-md cursor-pointer transition-all hover:scale-105 active:scale-95 group"
            title="Translate marked selection directly (Alt+T)"
          >
            <Globe className="w-3.5 h-3.5 text-cyan-400 group-hover:rotate-45 transition-transform" />
            <span className="text-[11px] text-cyan-200">
              Translate: <span className="text-white">"{markedText.slice(0, 16)}{markedText.length > 16 ? "…" : ""}"</span>
            </span>
            <span className="px-1.5 py-0.5 rounded bg-cyan-950 text-[9px] text-cyan-400 border border-cyan-700/50">
              Alt+T
            </span>
          </button>
        </div>
      )}

      {/* Instant In-Place Translation Box */}
      {isEditorOpen && (
        <div
          id="selection-quick-translator-popover"
          ref={popoverRef}
          style={{ top: btnPos.y, left: btnPos.x, borderColor: `${accentColor}80` }}
          className="fixed z-[999999] w-[360px] sm:w-[400px] bg-[#090b10]/98 border shadow-[0_15px_50px_rgba(0,0,0,0.9)] rounded-xl p-4 text-xs font-mono text-white space-y-3.5 backdrop-blur-xl animate-in fade-in zoom-in-95 duration-150"
        >
          {/* Header */}
          <div className="flex items-center justify-between border-b border-[#1a1e2e] pb-2.5">
            <div className="flex items-center gap-2 text-cyan-400 font-bold">
              <Globe className="w-4 h-4" style={{ color: accentColor }} />
              <span className="text-xs uppercase tracking-wide">Direct Translation Tool</span>
            </div>
            <button
              onClick={() => { setIsEditorOpen(false); setBtnPos(null); }}
              className="p-1 rounded-md text-[#8a8d9a] hover:text-white hover:bg-[#181a24] transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Form */}
          <form onSubmit={handleSaveAndApply} className="space-y-3">
            {/* Source Text Field */}
            <div>
              <div className="flex justify-between items-center mb-1 text-[10px] text-[#8a8d9a] uppercase font-bold">
                <span>Source Marked Text (English / Original)</span>
              </div>
              <textarea
                value={sourceText}
                onChange={(e) => setSourceText(e.target.value)}
                onKeyDown={handleKeyDownInEditor}
                rows={2}
                className="w-full p-2 bg-[#050608] border border-[#1f2433] rounded-lg text-white font-sans text-xs placeholder-[#555] focus:outline-none focus:border-cyan-500"
              />
            </div>

            {/* Arabic Translation Field */}
            <div>
              <div className="flex justify-between items-center mb-1 text-[10px] text-[#8a8d9a] uppercase font-bold">
                <span className="text-cyan-400">Arabic Translation (الترجمة العربية)</span>
                <span className="text-[#666] text-[9px]">Press Enter ↵ to save</span>
              </div>
              <textarea
                ref={arabicInputRef}
                value={arabicText}
                onChange={(e) => setArabicText(e.target.value)}
                onKeyDown={handleKeyDownInEditor}
                dir="rtl"
                rows={2}
                placeholder="اكتب الترجمة العربية هنا..."
                className="w-full p-2 bg-[#050608] border border-cyan-500/80 rounded-lg text-cyan-200 font-sans text-xs placeholder-[#555] focus:outline-none focus:border-cyan-400 shadow-[0_0_12px_rgba(6,182,212,0.15)]"
              />
            </div>

            {/* Action Buttons */}
            <div className="flex items-center justify-between pt-1 border-t border-[#1a1e2e]">
              <button
                type="button"
                onClick={() => {
                  setIsEditorOpen(false);
                  setBtnPos(null);
                  TranslationService.openStudio(sourceText);
                }}
                className="text-[10px] text-[#8a8d9a] hover:text-cyan-300 flex items-center gap-1 transition-colors"
              >
                <ExternalLink className="w-3 h-3" />
                <span>Full Studio</span>
              </button>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => { setIsEditorOpen(false); setBtnPos(null); }}
                  className="px-3 py-1.5 bg-[#141722] hover:bg-[#1a1e2e] border border-[#222] rounded-lg text-[10px] text-[#8a8d9a] hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  style={{ backgroundColor: accentColor }}
                  className="px-4 py-1.5 rounded-lg text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer hover:brightness-110 active:scale-95 shadow-lg transition-all"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>Save & Apply Directly</span>
                  <CornerDownLeft className="w-3 h-3 opacity-60" />
                </button>
              </div>
            </div>
          </form>
        </div>
      )}
    </>
  );
};
