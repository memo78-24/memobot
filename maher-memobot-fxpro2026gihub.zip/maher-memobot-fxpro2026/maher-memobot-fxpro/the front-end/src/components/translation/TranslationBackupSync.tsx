import React, { useState } from "react";
import { Download, Upload, Copy, RefreshCw, AlertTriangle, Check, FileJson } from "lucide-react";
import { TranslationService } from "../../services/translationService";

interface Props {
  showAlert: (msg: string) => void;
  accentColor: string;
}

export const TranslationBackupSync: React.FC<Props> = ({ showAlert, accentColor }) => {
  const [importJson, setImportJson] = useState("");
  const [copied, setCopied] = useState(false);
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  const handleExportDownload = () => {
    const jsonStr = TranslationService.exportAsJson();
    const blob = new Blob([jsonStr], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `memobot-translations-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showAlert("Translation JSON dictionary exported successfully!");
  };

  const handleCopyJson = () => {
    const jsonStr = TranslationService.exportAsJson();
    navigator.clipboard.writeText(jsonStr);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    showAlert("Copied dictionary JSON to clipboard!");
  };

  const handleImportSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!importJson.trim()) {
      showAlert("Please paste JSON translations code first.");
      return;
    }

    const res = TranslationService.importFromJson(importJson.trim());
    if (res.success) {
      showAlert(`Successfully imported ${res.count} custom translations!`);
      setImportJson("");
    } else {
      showAlert(`Import failed: ${res.error}`);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        const res = TranslationService.importFromJson(content);
        if (res.success) {
          showAlert(`Successfully imported ${res.count} translations from file!`);
        } else {
          showAlert(`Import failed: ${res.error}`);
        }
      }
    };
    reader.readAsText(file);
  };

  const handleResetAll = () => {
    TranslationService.resetCustomOverrides();
    setShowResetConfirm(false);
    showAlert("All custom translations have been reset to factory defaults.");
  };

  return (
    <div className="space-y-4 text-xs font-mono">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Export Card */}
        <div className="bg-[#0d0e12] p-4 rounded-lg border border-[#1a1d26] space-y-3">
          <div className="flex items-center gap-2 text-cyan-400 font-bold">
            <Download className="w-4 h-4" />
            <span>Export Dictionary & Custom Overrides</span>
          </div>
          <p className="text-[#8a8d9a] text-[11px] leading-relaxed">
            Download your full custom dictionary as a portable JSON file or copy to clipboard for backup or sharing across devices.
          </p>

          <div className="flex gap-2 pt-2">
            <button
              onClick={handleExportDownload}
              className="flex-1 py-2 bg-[#141722] hover:bg-[#1a1d2e] border border-[#222] hover:border-cyan-500/40 rounded text-white text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-cyan-400" />
              <span>Download JSON</span>
            </button>
            <button
              onClick={handleCopyJson}
              className="px-4 py-2 bg-[#141722] hover:bg-[#1a1d2e] border border-[#222] rounded text-[#8a8d9a] hover:text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? "Copied!" : "Copy JSON"}</span>
            </button>
          </div>
        </div>

        {/* Import Card */}
        <div className="bg-[#0d0e12] p-4 rounded-lg border border-[#1a1d26] space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-emerald-400 font-bold">
              <Upload className="w-4 h-4" />
              <span>Import & Merge JSON</span>
            </div>
            <label className="px-2.5 py-1 bg-emerald-950/40 hover:bg-emerald-900/60 border border-emerald-500/40 rounded text-emerald-300 text-[10px] font-bold cursor-pointer flex items-center gap-1">
              <FileJson className="w-3 h-3" />
              <span>Upload .json</span>
              <input type="file" accept=".json" onChange={handleFileUpload} className="hidden" />
            </label>
          </div>

          <form onSubmit={handleImportSubmit} className="space-y-2">
            <textarea
              value={importJson}
              onChange={(e) => setImportJson(e.target.value)}
              placeholder="Paste JSON dictionary or translations object here..."
              rows={2}
              className="w-full p-2 bg-[#06070a] border border-[#1f232f] rounded text-white text-xs placeholder-[#555] focus:outline-none focus:border-emerald-500 font-mono"
            />
            <button
              type="submit"
              className="w-full py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Merge & Apply Translations</span>
            </button>
          </form>
        </div>
      </div>

      {/* Danger Zone: Reset Overrides */}
      <div className="bg-[#12080a] p-4 rounded-lg border border-rose-950 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
        <div>
          <div className="text-rose-400 font-bold flex items-center gap-1.5">
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Reset Custom Overrides</span>
          </div>
          <p className="text-[#8a8d9a] text-[11px] mt-0.5">
            Clear all user-added dictionary translations and restore platform defaults.
          </p>
        </div>

        {showResetConfirm ? (
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowResetConfirm(false)}
              className="px-3 py-1 bg-[#141722] text-[#8a8d9a] rounded text-[10px]"
            >
              Cancel
            </button>
            <button
              onClick={handleResetAll}
              className="px-3 py-1 bg-rose-600 hover:bg-rose-500 text-white rounded text-[10px] font-bold"
            >
              Confirm Reset
            </button>
          </div>
        ) : (
          <button
            onClick={() => setShowResetConfirm(true)}
            className="px-3 py-1.5 bg-rose-950/60 hover:bg-rose-900 border border-rose-700/50 text-rose-300 rounded text-[10px] font-bold cursor-pointer"
          >
            Reset to Factory Defaults
          </button>
        )}
      </div>
    </div>
  );
};
