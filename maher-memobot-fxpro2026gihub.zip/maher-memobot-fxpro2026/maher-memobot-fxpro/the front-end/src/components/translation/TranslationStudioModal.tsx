import React, { useState, useEffect } from "react";
import { 
  Globe, 
  X, 
  BookOpen, 
  MousePointerClick, 
  Sparkles, 
  Database, 
  RefreshCw,
  Sliders,
  CheckCircle2
} from "lucide-react";
import { translationStore, TranslationState } from "../../services/translationStore";
import { TranslationService } from "../../services/translationService";
import { TranslationDictionaryTable } from "./TranslationDictionaryTable";
import { TranslationPlayground } from "./TranslationPlayground";
import { TranslationBackupSync } from "./TranslationBackupSync";
import { useLanguage } from "../LanguageProvider";
import { useTheme } from "../ThemeProvider";

interface Props {
  showAlert: (msg: string) => void;
}

export const TranslationStudioModal: React.FC<Props> = ({ showAlert }) => {
  const [state, setState] = useState<TranslationState>(translationStore.getState());
  const [activeTab, setActiveTab] = useState<"dictionary" | "inspector" | "playground" | "backup">("dictionary");
  const { language, isArabic, setLanguage } = useLanguage();
  
  let accentColor = "#FA1F4E";
  try {
    const theme = useTheme();
    if (theme?.accentColor) accentColor = theme.accentColor;
  } catch (e) {}

  useEffect(() => {
    return translationStore.subscribe((next) => setState({ ...next }));
  }, []);

  if (!state.isOpen) return null;

  const allItems = TranslationService.getAllTranslations();

  const handleStartInspector = () => {
    TranslationService.toggleInspector(true);
    TranslationService.closeStudio();
    showAlert("Click-to-Translate active! Hover & click any text on screen to edit.");
  };

  return (
    <div className="fixed inset-0 z-[9999] bg-black/80 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4 animate-in fade-in duration-150 font-mono">
      <div 
        style={{ borderColor: `${accentColor}40` }}
        className="w-full max-w-5xl max-h-[92vh] bg-[#07080c] border rounded-xl flex flex-col shadow-[0_20px_60px_rgba(0,0,0,0.9)] overflow-hidden"
      >
        {/* Modal Header */}
        <div className="p-4 bg-[#0c0d13] border-b border-[#1a1d26] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div 
              style={{ backgroundColor: `${accentColor}20`, borderColor: accentColor }}
              className="p-2 rounded-lg border"
            >
              <Globe className="w-5 h-5" style={{ color: accentColor }} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm sm:text-base font-bold text-white tracking-wide uppercase">
                  MEMOBOT TRANSLATION STUDIO
                </h2>
                <span className="px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-400 text-[10px] font-extrabold border border-cyan-500/30">
                  V7.1
                </span>
              </div>
              <p className="text-[11px] text-[#8a8d9a] font-sans">
                Full dictionary master editor, live click-to-translate inspector & instant reactive syncing.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Quick Language Preview Switcher */}
            <div className="hidden sm:flex items-center bg-[#06070a] border border-[#1f232f] rounded-lg p-0.5 text-[10px]">
              <button
                onClick={() => setLanguage("en")}
                className={`px-2.5 py-1 rounded font-bold cursor-pointer transition-all ${
                  language === "en" ? "bg-cyan-600 text-white" : "text-[#8a8d9a] hover:text-white"
                }`}
              >
                🇬🇧 EN
              </button>
              <button
                onClick={() => setLanguage("ar")}
                className={`px-2.5 py-1 rounded font-bold cursor-pointer transition-all ${
                  language === "ar" ? "bg-cyan-600 text-white" : "text-[#8a8d9a] hover:text-white"
                }`}
              >
                🇸🇦 العربية
              </button>
            </div>

            <button
              onClick={() => TranslationService.closeStudio()}
              className="p-1.5 rounded-lg bg-[#141722] hover:bg-[#1f2334] border border-[#222] text-[#8a8d9a] hover:text-white cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Stats & Quick Action Bar */}
        <div className="px-4 py-2 bg-[#090a0f] border-b border-[#141722] flex flex-wrap items-center justify-between gap-2 text-[10px] text-[#8a8d9a] shrink-0">
          <div className="flex items-center gap-4">
            <span>
              Total Dictionary: <b className="text-white">{state.totalCount}</b> phrases
            </span>
            <span>
              Custom Overrides: <b className="text-amber-400">{state.customCount}</b> active
            </span>
            <span className="flex items-center gap-1 text-emerald-400">
              <CheckCircle2 className="w-3 h-3" />
              Live Sync Ready
            </span>
          </div>

          <button
            onClick={handleStartInspector}
            className="px-3 py-1 rounded bg-cyan-950/60 hover:bg-cyan-900/80 border border-cyan-500/50 text-cyan-300 font-bold flex items-center gap-1.5 cursor-pointer shadow-sm"
          >
            <MousePointerClick className="w-3 h-3" />
            <span>Launch On-Page Click & Translate</span>
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-[#141722] bg-[#0c0d14] px-4 gap-2 pt-2 shrink-0">
          {[
            { id: "dictionary", label: "Dictionary Editor", icon: BookOpen },
            { id: "playground", label: "Live Tester", icon: Sparkles },
            { id: "backup", label: "Import / Export & Backup", icon: Database },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                style={
                  isActive
                    ? { borderColor: accentColor, color: "#ffffff", borderBottomColor: "transparent" }
                    : {}
                }
                className={`px-4 py-2 border-t-2 border-x rounded-t text-xs font-bold uppercase transition-all flex items-center gap-1.5 cursor-pointer ${
                  isActive
                    ? "bg-[#07080c] border-[#1f232f]"
                    : "border-transparent text-[#8a8d9a] hover:text-white bg-transparent"
                }`}
              >
                <Icon className="w-3.5 h-3.5" style={{ color: isActive ? accentColor : "#8a8d9a" }} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tab Body */}
        <div className="flex-1 p-4 overflow-y-auto bg-[#07080c]">
          {activeTab === "dictionary" && (
            <TranslationDictionaryTable
              items={allItems}
              accentColor={accentColor}
              showAlert={showAlert}
            />
          )}

          {activeTab === "playground" && (
            <TranslationPlayground
              accentColor={accentColor}
              showAlert={showAlert}
            />
          )}

          {activeTab === "backup" && (
            <TranslationBackupSync
              accentColor={accentColor}
              showAlert={showAlert}
            />
          )}
        </div>
      </div>
    </div>
  );
};
