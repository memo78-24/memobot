import React, { useState } from "react";
import { ApiClient } from "../services/api";
import { useNotification } from "./NotificationProvider";
import { Zap, ShieldCheck, CheckCircle2, RefreshCw, AlertTriangle, Power, Octagon } from "lucide-react";

interface IndividualTradeFormProps {
  selectedSymbol: string;
  onSymbolChange: (symbol: string) => void;
  indexPrice: number;
  availableUsdt: number;
  onOrderExecuted: () => void;
  emergencyHalted?: boolean;
  onToggleEmergencyKill?: () => void;
}

export const IndividualTradeForm: React.FC<IndividualTradeFormProps> = ({
  selectedSymbol,
  onSymbolChange,
  indexPrice,
  availableUsdt,
  onOrderExecuted,
  emergencyHalted = false,
  onToggleEmergencyKill
}) => {
  const [side, setSide] = useState<"BUY" | "SELL">("BUY");
  const [orderSize, setOrderSize] = useState<number>(500);
  const [leverage, setLeverage] = useState<number>(10);
  const [executing, setExecuting] = useState<boolean>(false);
  const { showAlert, showConfirm } = useNotification();

  const price = indexPrice || 67875.95;
  const requiredMargin = leverage > 0 ? orderSize / leverage : orderSize;

  const handlePercentageClick = (pct: number) => {
    const calculatedSize = Math.floor(availableUsdt * pct * leverage);
    setOrderSize(calculatedSize > 0 ? calculatedSize : 100);
  };

  const handleExecuteOrder = async () => {
    if (emergencyHalted) {
      showAlert("ORDER REJECTED: Emergency Kill Switch is engaged on this individual trade terminal. Please disarm the Emergency Switch first.");
      return;
    }

    if (orderSize <= 0) {
      showAlert("Invalid order size. Please enter an order size greater than 0 USDT.");
      return;
    }

    setExecuting(true);
    try {
      const res = await ApiClient.post("/execution/trade", {
        symbol: selectedSymbol,
        side,
        type: "MARKET",
        amount: Math.round((orderSize / price) * 10000) / 10000,
        engine: "ENG-001"
      });

      showAlert(`ORDER DISPATCH SUCCESS: ${side} ${res.fill_amount || (orderSize / (price ?? 1)).toFixed(4)} ${selectedSymbol} filled at $${res.fill_price || (price ?? 0).toLocaleString()}`);
      onOrderExecuted();
    } catch (err: any) {
      showAlert(`Order Execution Rejected: ${err.message}`);
    } finally {
      setExecuting(false);
    }
  };

  const handleTriggerEmergencyFlatten = () => {
    showConfirm(
      "DANGER: Execute Emergency Flatten & Instant Halt for Individual Trading? This will trigger an immediate emergency circuit breaker and freeze all order routing.",
      async () => {
        try {
          await ApiClient.post("/execution/kill-switch", {});
          showAlert("EMERGENCY KILL SWITCH ENGAGED! ALL INDIVIDUAL TRADE ENGINES Halted.");
          if (onToggleEmergencyKill) onToggleEmergencyKill();
        } catch (e: any) {
          showAlert(`Emergency Kill Switch Triggered: ${e.message || "Circuit breaker activated"}`);
          if (onToggleEmergencyKill) onToggleEmergencyKill();
        }
      },
      undefined,
      "EMERGENCY KILL SWITCH CONFIRMATION"
    );
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 font-mono text-xs">
      
      {/* LEFT BOX: Individual Trade Form */}
      <div className="bg-[#090a0d] border border-[#1a1d26] rounded p-5 space-y-4 panel-glow relative">
        
        {/* Header with Emergency Switch Quick Toggle */}
        <div className="flex items-center justify-between border-b border-[#11131c] pb-2">
          <h3 className="text-sm font-bold font-mono text-white tracking-wide flex items-center gap-2">
            <span>Individual Trade</span>
            {emergencyHalted && (
              <span className="px-2 py-0.5 rounded bg-[#ef4444]/20 border border-[#ef4444] text-[#ef4444] text-[9px] font-extrabold uppercase animate-pulse">
                HALTED
              </span>
            )}
          </h3>

          <button
            onClick={onToggleEmergencyKill || handleTriggerEmergencyFlatten}
            className={`px-2.5 py-1 rounded text-[10px] font-bold uppercase tracking-wider flex items-center gap-1.5 transition-all border ${
              emergencyHalted
                ? "bg-[#ef4444] text-white border-[#ef4444] shadow-[0_0_10px_rgba(239,68,68,0.5)]"
                : "bg-[#0d0e12] hover:bg-[#ef4444]/20 text-[#ef4444] border-[#ef4444]/40 hover:border-[#ef4444]"
            }`}
            title="Emergency Switch / Circuit Breaker"
          >
            <Power className="w-3 h-3" />
            <span>{emergencyHalted ? "EMERGENCY HALTED" : "EMERGENCY SWITCH"}</span>
          </button>
        </div>

        {/* Emergency Halted Warning Banner if engaged */}
        {emergencyHalted && (
          <div className="bg-[#ef4444]/15 border border-[#ef4444] p-3 rounded flex items-center justify-between text-[#ef4444] space-x-2">
            <div className="flex items-center gap-2">
              <Octagon className="w-5 h-5 shrink-0 text-[#ef4444] animate-spin" />
              <div>
                <p className="font-extrabold text-xs uppercase">EMERGENCY KILL SWITCH ACTIVE</p>
                <p className="text-[10px] text-[#8a8d9a]">Individual trading execution is currently frozen by safety protocol.</p>
              </div>
            </div>
            <button
              onClick={onToggleEmergencyKill}
              className="px-2.5 py-1 bg-[#ef4444] hover:bg-[#dc2626] text-white rounded text-[9px] font-bold uppercase shrink-0 transition-colors"
            >
              DISARM
            </button>
          </div>
        )}

        {/* LONG (BUY) / SHORT (SELL) Buttons */}
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={() => setSide("BUY")}
            className={`py-2.5 rounded font-extrabold text-xs uppercase tracking-wider transition-all border ${
              side === "BUY"
                ? "bg-[rgba(0,230,118,0.15)] text-[#00e676] border-[#00e676] shadow-[0_0_12px_rgba(0,230,118,0.3)]"
                : "bg-[#06070a] text-[#8a8d9a] border-[#1a1d26] hover:text-white"
            }`}
          >
            LONG (BUY)
          </button>
          <button
            onClick={() => setSide("SELL")}
            className={`py-2.5 rounded font-extrabold text-xs uppercase tracking-wider transition-all border ${
              side === "SELL"
                ? "bg-[rgba(250,31,78,0.15)] text-[#FA1F4E] border-[#FA1F4E] shadow-[0_0_12px_rgba(250,31,78,0.3)]"
                : "bg-[#06070a] text-[#8a8d9a] border-[#1a1d26] hover:text-white"
            }`}
          >
            SHORT (SELL)
          </button>
        </div>

        {/* ASSET SYMBOL */}
        <div className="space-y-1.5">
          <label className="text-[10px] text-[#8a8d9a] font-bold uppercase tracking-wider block">
            ASSET SYMBOL
          </label>
          <select
            value={selectedSymbol}
            onChange={(e) => onSymbolChange(e.target.value)}
            className="w-full bg-[#06070a] border border-[#1a1d26] focus:border-[#FA1F4E] text-white p-2.5 rounded outline-none font-extrabold text-xs cursor-pointer transition-colors"
          >
            <option value="BTCUSDT">BTCUSDT (Bitcoin Spot)</option>
            <option value="ETHUSDT">ETHUSDT (Ethereum Spot)</option>
            <option value="SOLUSDT">SOLUSDT (Solana Spot)</option>
            <option value="BNBUSDT">BNBUSDT (Binance Coin)</option>
            <option value="XRPUSDT">XRPUSDT (Ripple Spot)</option>
            <option value="AVAXUSDT">AVAXUSDT (Avalanche)</option>
          </select>
        </div>

        {/* ORDER SIZE (USDT) & Quick Allocation */}
        <div className="space-y-1.5">
          <div className="flex justify-between items-center text-[10px] text-[#8a8d9a]">
            <label className="font-bold uppercase tracking-wider">ORDER SIZE (USDT)</label>
            <span>AVAIL: <strong className="text-white">${(availableUsdt ?? 0).toLocaleString()} USDT</strong></span>
          </div>
          <input
            type="number"
            value={orderSize}
            onChange={(e) => setOrderSize(Number(e.target.value))}
            className="w-full bg-[#06070a] border border-[#1a1d26] focus:border-[#FA1F4E] text-white p-2.5 rounded outline-none font-extrabold text-xs transition-colors"
          />

          {/* Quick Percentage Chips */}
          <div className="grid grid-cols-4 gap-1.5 pt-1">
            {[0.25, 0.5, 0.75, 1.0].map((pct) => (
              <button
                key={pct}
                type="button"
                onClick={() => handlePercentageClick(pct)}
                className="py-1 bg-[#06070a] border border-[#1a1d26] hover:border-[#3b82f6] text-[#8a8d9a] hover:text-[#3b82f6] rounded text-[9px] font-bold uppercase transition-all"
              >
                {pct * 100}%
              </button>
            ))}
          </div>
        </div>

        {/* LEVERAGE (10X) Slider */}
        <div className="space-y-1.5">
          <div className="flex justify-between text-[10px] text-[#8a8d9a]">
            <label className="font-bold uppercase tracking-wider">LEVERAGE ({leverage}X)</label>
            <span className={leverage === 1 ? "text-[#00e676] font-bold" : "text-[#ffb800] font-bold"}>
              {leverage === 1 ? "100% PURE SPOT (NON-DEBT)" : `${leverage}X ALLOCATION`}
            </span>
          </div>
          <input
            type="range"
            min="1"
            max="20"
            step="1"
            value={leverage}
            onChange={(e) => setLeverage(Number(e.target.value))}
            className="w-full accent-[#FA1F4E] bg-[#06070a] h-1.5 rounded cursor-pointer"
          />
        </div>

        {/* Calculated Metrics Row */}
        <div className="pt-2 border-t border-[#11131c] space-y-2 text-[11px]">
          <div className="flex justify-between items-center text-[#8a8d9a]">
            <span>Required Margin:</span>
            <span className="text-white font-extrabold">${requiredMargin.toFixed(2)} USDT</span>
          </div>
          <div className="flex justify-between items-center text-[#8a8d9a]">
            <span>Index Price:</span>
            <span className="text-white font-extrabold">${(price ?? 0).toLocaleString("en-US", { minimumFractionDigits: 2 })}</span>
          </div>
        </div>

        {/* Primary Action Button */}
        <button
          onClick={handleExecuteOrder}
          disabled={executing || emergencyHalted}
          className={`w-full py-3 rounded text-white font-extrabold text-xs uppercase tracking-wider transition-all shadow-lg flex items-center justify-center gap-2 ${
            emergencyHalted
              ? "bg-[#1a1d26] text-[#8a8d9a] border border-[#ef4444]/40 cursor-not-allowed"
              : side === "BUY"
              ? "bg-[#FA1F4E] hover:bg-[#d4153d] shadow-[0_0_15px_rgba(250,31,78,0.4)]"
              : "bg-[#ef4444] hover:bg-[#dc2626] shadow-[0_0_15px_rgba(239,68,68,0.4)]"
          } disabled:opacity-50`}
        >
          {executing ? (
            <>
              <RefreshCw className="w-4 h-4 animate-spin" />
              DISPATCHING ORDER TO EXCHANGES...
            </>
          ) : emergencyHalted ? (
            <>
              <Octagon className="w-4 h-4 text-[#ef4444]" />
              TRADING FROZEN (DISARM SWITCH TO TRADE)
            </>
          ) : (
            <>
              <Zap className="w-4 h-4" />
              {side === "BUY" ? "EXECUTE BUY ORDER" : "EXECUTE SELL ORDER"}
            </>
          )}
        </button>

      </div>

      {/* RIGHT BOX: NEURAL ORDER ROUTER */}
      <div className="bg-[#090a0d] border border-[#1a1d26] rounded p-5 flex flex-col justify-between space-y-4 panel-glow">
        <div className="space-y-4">
          <div className="flex items-center justify-between border-b border-[#11131c] pb-2">
            <h3 className="text-xs font-bold font-mono text-[#8a8d9a] tracking-wider uppercase">
              NEURAL ORDER ROUTER
            </h3>
            <span className="text-[10px] text-[#3b82f6] font-bold">SAFETY INTERLOCK ACTIVE</span>
          </div>

          {/* Item 1: TIGRE Gate Execution Safety */}
          <div className="bg-[#06070a] border border-[#1a1d26] p-3.5 rounded space-y-1">
            <div className="flex items-center gap-2 text-[#FA1F4E] font-bold text-xs">
              <Zap className="w-4 h-4 text-[#FA1F4E]" />
              <span>TIGRE Gate Execution Safety</span>
            </div>
            <p className="text-[11px] text-[#8a8d9a] leading-relaxed pl-6">
              Verifying capital security parameters and anti-slippage guard before routing to exchange cluster.
            </p>
          </div>

          {/* Item 2: Islamic Shariah Compliance */}
          <div className="bg-[#06070a] border border-[#1a1d26] p-3.5 rounded space-y-1">
            <div className="flex items-center gap-2 text-[#00e676] font-bold text-xs">
              <ShieldCheck className="w-4 h-4 text-[#00e676]" />
              <span>Islamic Shariah Compliance</span>
            </div>
            <p className="text-[11px] text-[#8a8d9a] leading-relaxed pl-6">
              Strictly margin-free spot matching protocols active with rolling swap components disabled automatically.
            </p>
          </div>

          {/* Emergency Circuit Breaker Trigger Panel */}
          <div className="bg-[#110508] border border-[#ef4444]/30 p-3.5 rounded space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-[#ef4444] font-bold text-xs uppercase">
                <AlertTriangle className="w-4 h-4 text-[#ef4444]" />
                <span>INDIVIDUAL EMERGENCY SWITCH</span>
              </div>
              <span className="text-[9px] text-[#ef4444] font-bold uppercase">HALT / FLATTEN</span>
            </div>
            <p className="text-[10px] text-[#8a8d9a]">
              Instantly trigger global trade halt and cancel pending individual execution routes across all exchange adapters.
            </p>
            <button
              onClick={handleTriggerEmergencyFlatten}
              className="w-full py-2 bg-[#ef4444]/20 hover:bg-[#ef4444] border border-[#ef4444] text-[#ef4444] hover:text-white rounded font-bold text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 shadow-[0_0_10px_rgba(239,68,68,0.2)]"
            >
              <Power className="w-3.5 h-3.5" />
              <span>TRIGGER EMERGENCY KILL SWITCH</span>
            </button>
          </div>
        </div>

        {/* Footer Telemetry Banner */}
        <div className="pt-4 border-t border-[#11131c] flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 text-[10px] text-[#8a8d9a]">
          <span className="uppercase font-bold tracking-wider">
            MEMOBOT™ FX HIGH PRECISION TELEMETRY
          </span>
          <span className={`font-bold flex items-center gap-1.5 uppercase ${emergencyHalted ? "text-[#ef4444]" : "text-[#00e676]"}`}>
            <span className={`w-2 h-2 rounded-full ${emergencyHalted ? "bg-[#ef4444] animate-ping" : "bg-[#00e676] animate-pulse"}`} />
            {emergencyHalted ? "ROUTER HALTED" : "ROUTER ONLINE"}
          </span>
        </div>

      </div>

    </div>
  );
};

