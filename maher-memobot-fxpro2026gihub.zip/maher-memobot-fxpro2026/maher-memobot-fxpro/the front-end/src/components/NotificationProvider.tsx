import React, { createContext, useContext, useState, ReactNode } from "react";
import { motion, AnimatePresence } from "motion/react";
import { AlertTriangle, CheckCircle, Info, X } from "lucide-react";
import { useTheme } from "./ThemeProvider";

interface Notification {
  id: string;
  type: "alert" | "confirm";
  title?: string;
  message: string;
  onConfirm?: () => void;
  onCancel?: () => void;
}

interface NotificationContextType {
  showAlert: (message: string, title?: string) => void;
  showConfirm: (message: string, onConfirm: () => void, onCancel?: () => void, title?: string) => void;
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export const NotificationProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  let accentColor = "#FA1F4E";
  try {
    const theme = useTheme();
    if (theme?.accentColor) accentColor = theme.accentColor;
  } catch (e) {
    // Graceful fallback if theme context isn't ready
  }

  const playAlertSound = () => {
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextClass) return;
      const ctx = new AudioContextClass();
      
      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gainNode = ctx.createGain();
      
      osc1.type = "sine";
      osc2.type = "triangle";
      
      // Dual-tone high-tech digital chime sweep
      osc1.frequency.setValueAtTime(880, ctx.currentTime); // A5
      osc1.frequency.exponentialRampToValueAtTime(1320, ctx.currentTime + 0.15); // E6
      
      osc2.frequency.setValueAtTime(440, ctx.currentTime); // A4
      osc2.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.15); // A5
      
      gainNode.gain.setValueAtTime(0.08, ctx.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.35);
      
      osc1.connect(gainNode);
      osc2.connect(gainNode);
      gainNode.connect(ctx.destination);
      
      osc1.start();
      osc2.start();
      osc1.stop(ctx.currentTime + 0.35);
      osc2.stop(ctx.currentTime + 0.35);
    } catch (e) {
      console.warn("AudioContext blocked or uninitialized:", e);
    }
  };

  const showAlert = (message: string, title: string = "SYSTEM NOTIFICATION") => {
    const id = Math.random().toString(36).substring(2, 9);
    setNotifications(prev => [...prev, { id, type: "alert", message, title }]);
    playAlertSound();
  };

  const showConfirm = (message: string, onConfirm: () => void, onCancel?: () => void, title: string = "CONFIRMATION REQUIRED") => {
    const id = Math.random().toString(36).substring(2, 9);
    setNotifications(prev => [...prev, { id, type: "confirm", message, title, onConfirm, onCancel }]);
    playAlertSound();
  };

  const removeNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const isLightTextNeeded = accentColor === "#FA1F4E" || accentColor === "#ff1744" || accentColor === "#a855f7";

  return (
    <NotificationContext.Provider value={{ showAlert, showConfirm }}>
      {children}
      <div className="inspector-exclude fixed top-4 right-4 z-[9999] pointer-events-none flex flex-col items-end gap-2">
        <AnimatePresence>
          {notifications.map((n) => (
            <motion.div
              key={n.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              style={{ borderColor: `${accentColor}40` }}
              className="pointer-events-auto bg-[#0d0e12] border shadow-[0_20px_50px_rgba(0,0,0,0.8)] rounded-lg max-w-md w-[350px] overflow-hidden flex flex-col"
            >
              <div className="px-4 py-3 border-b border-[#1a1d26] flex items-center justify-between bg-[#06070a]">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4" style={{ color: accentColor }} />
                  <span className="text-[10px] font-black text-white uppercase tracking-widest font-mono">{n.title}</span>
                </div>
                <button 
                  onClick={() => {
                    if (n.type === "confirm" && n.onCancel) n.onCancel();
                    removeNotification(n.id);
                  }}
                  className="text-[#8a8d9a] hover:text-white transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <div className="p-6">
                <p className="text-xs text-[#8a8d9a] leading-relaxed font-mono whitespace-pre-wrap">{n.message}</p>
              </div>
              <div className="px-4 py-3 border-t border-[#1a1d26] bg-[#06070a] flex justify-end gap-3">
                {n.type === "confirm" && (
                  <button
                    onClick={() => {
                      if (n.onCancel) n.onCancel();
                      removeNotification(n.id);
                    }}
                    className="px-4 py-1.5 border border-[#1a1d26] text-[#8a8d9a] hover:bg-[#1a1d26] rounded text-[10px] font-bold uppercase transition-all"
                  >
                    Cancel
                  </button>
                )}
                <button
                  onClick={() => {
                    if (n.onConfirm) n.onConfirm();
                    removeNotification(n.id);
                  }}
                  style={{
                    backgroundColor: accentColor,
                    color: isLightTextNeeded ? "#ffffff" : "#06070a",
                    boxShadow: `0 0 15px ${accentColor}60`
                  }}
                  className="px-4 py-1.5 rounded text-[10px] font-black uppercase transition-all hover:brightness-110 active:scale-95"
                >
                  {n.type === "confirm" ? "Confirm Action" : "Acknowledge"}
                </button>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </NotificationContext.Provider>
  );
};

export const useNotification = () => {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error("useNotification must be used within a NotificationProvider");
  }
  return context;
};
