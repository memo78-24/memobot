import React, { useEffect, useState } from "react";
import { useTheme } from "./ThemeProvider";
import { useLanguage } from "./LanguageProvider";
import { identityStore } from "../services/identityStore";
import { IdentityService } from "../services/identityService";
import { TranslationService } from "../services/translationService";
import { Globe, LogOut, ShieldCheck, Zap, Wifi, WifiOff, RefreshCw, Shield, Sparkles, Layers, Menu, Languages } from "lucide-react";

interface HeaderProps {
  onLogout: () => void;
  complianceMode: "Islamic" | "Commercial";
  onComplianceToggle: (mode: "Islamic" | "Commercial") => void;
  wsStatus?: "CONNECTED" | "DISCONNECTED";
  onReconnect?: () => void;
  onOpenSupport?: () => void;
  onToggleMobileSidebar?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ 
  onLogout, 
  complianceMode, 
  onComplianceToggle,
  wsStatus = "CONNECTED",
  onReconnect,
  onOpenSupport,
  onToggleMobileSidebar
}) => {
  let accentColor = "#FA1F4E";
  let brandRedTitle = "MEMOBOT";
  let brandWhiteTitle = "FX-PRO";
  let brandSubtitle = "PRIME EDITION • HIGH-PRECISION TRADING";
  let inspectorActive = false;
  let setInspectorActive = (val: boolean) => {};
  try {
    const theme = useTheme();
    if (theme?.accentColor) accentColor = theme.accentColor;
    if (theme?.brandRedTitle) brandRedTitle = theme.brandRedTitle;
    if (theme?.brandWhiteTitle) brandWhiteTitle = theme.brandWhiteTitle;
    if (theme?.brandSubtitle) brandSubtitle = theme.brandSubtitle;
    if (theme?.inspectorActive !== undefined) inspectorActive = theme.inspectorActive;
    if (theme?.setInspectorActive) setInspectorActive = theme.setInspectorActive;
  } catch (e) {}

  const { isArabic, toggleLanguage, t } = useLanguage();
  const [identity, setIdentity] = useState(identityStore.getState());

  useEffect(() => {
    const unsub = identityStore.subscribe((state) => setIdentity({ ...state }));
    return () => unsub();
  }, []);

  const currentTier = identity.tierProfile;

  return (
    <header className="h-16 bg-[#06070a] px-3 sm:px-6 flex items-center justify-between z-10 shrink-0 border-b border-[#11131c]">
      <div className="flex items-center gap-2.5 sm:gap-3">
        {/* Mobile Hamburger Toggle Button */}
        <button
          onClick={onToggleMobileSidebar}
          className="lg:hidden p-2 rounded-lg bg-[#0d0e12] hover:bg-[#161a23] border border-[#1a1d26] text-white transition-all cursor-pointer flex items-center justify-center"
          title="Open Navigation Matrix"
          aria-label="Open Navigation Matrix"
        >
          <Menu className="w-4 h-4 text-[#FA1F4E]" />
        </button>

        <div className="flex flex-col">
          <div className="flex items-baseline gap-1 sm:gap-2">
            <h1 className="text-base sm:text-xl font-aquire tracking-tighter text-white flex items-center gap-1">
              <span>{t(brandRedTitle)}<span style={{ color: accentColor }} className="text-[10px] sm:text-xs font-mono font-black -mt-1 sm:-mt-2 inline-block">™</span></span>
              <span style={{ color: accentColor }}>{t(brandWhiteTitle)}</span>
            </h1>
          </div>
          <div className="flex items-center gap-1.5 -mt-0.5 sm:-mt-1">
            <span className="text-[7px] sm:text-[8px] text-[#6b6f77] tracking-[0.15em] sm:tracking-[0.2em] uppercase font-black truncate max-w-[160px] sm:max-w-none">
              {t(brandSubtitle)}
            </span>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-1.5 sm:gap-2.5">
        {/* Identity Matrix Tier Trigger */}
        <button
          onClick={() => IdentityService.toggleIdentityDrawer(true)}
          className="px-2 sm:px-2.5 py-1.5 rounded-lg border font-mono text-xs font-bold flex items-center gap-1 sm:gap-1.5 transition-all shadow-sm cursor-pointer bg-[#0d0e12] hover:bg-[#161a23]"
          style={{ borderColor: `${currentTier.colorAccent}50` }}
          title={t("Open Identity Matrix & Decrypted Token Claims")}
        >
          <Shield className="w-3.5 h-3.5" style={{ color: currentTier.colorAccent }} />
          <span className="text-[9px] sm:text-[10px] tracking-wider font-extrabold" style={{ color: currentTier.colorAccent }}>
            {isArabic ? currentTier.nameAr : currentTier.name}
          </span>
          <span className="text-[9px] text-[#8a8d9a] hidden lg:inline">
            ({currentTier.maxEngines} {t("ENGINES")})
          </span>
        </button>

        {/* Modifier Core Quick Launch */}
        <button
          onClick={() => setInspectorActive(!inspectorActive)}
          style={inspectorActive ? { backgroundColor: `${accentColor}20`, borderColor: accentColor } : {}}
          className={`px-2 sm:px-2.5 py-1.5 rounded-lg border font-mono text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm cursor-pointer ${
            inspectorActive 
              ? "text-white shadow-[0_0_15px_rgba(250,31,78,0.3)]" 
              : "bg-[#0d0e12] hover:bg-[#161a23] border-[#1a1d26] hover:border-[#444] text-[#8a8d9a] hover:text-white"
          }`}
          title="Launch Live Element Modifier & Page Manifest Tool"
        >
          <Sparkles className="w-3.5 h-3.5" style={{ color: accentColor }} />
          <span className="hidden md:inline uppercase text-[10px] tracking-wider">
            {inspectorActive ? t("MODIFIER OPEN") : t("MODIFIER CORE")}
          </span>
        </button>

        {/* Translation Studio Quick Tool */}
        <button
          onClick={() => {
            const marked = window.getSelection()?.toString().trim();
            if (marked) {
              window.dispatchEvent(new CustomEvent("memobot:open_selection_translator", { detail: { text: marked } }));
            } else {
              TranslationService.openStudio();
            }
          }}
          className="px-2 sm:px-2.5 py-1.5 rounded-lg bg-[#0d0e12] hover:bg-[#161a23] border border-[#1a1d26] hover:border-cyan-500/50 text-cyan-400 hover:text-white font-mono text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm cursor-pointer"
          title={t("Translate Marked Text / Open Translation Studio (Alt+T)")}
        >
          <Languages className="w-3.5 h-3.5 text-cyan-400" />
          <span className="hidden lg:inline uppercase text-[10px] tracking-wider">
            {t("TRANSLATION STUDIO")}
          </span>
        </button>

        {/* Arabic / English Language Toggle */}
        <button
          onClick={toggleLanguage}
          className="px-2.5 sm:px-3 py-1.5 rounded-lg bg-[#0d0e12] hover:bg-[#161a23] border border-[#1a1d26] hover:border-cyan-500/40 text-white font-mono text-xs font-bold flex items-center gap-1.5 sm:gap-2 transition-all shadow-sm group cursor-pointer"
          title={t("Toggle Language / تبديل اللغة")}
        >
          <Globe className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-cyan-400 group-hover:scale-110 transition-transform" />
          <span className="tracking-wide text-[10px] sm:text-[11px] hidden xs:inline sm:inline">
            {isArabic ? "🇸🇦 العربية" : "🇬🇧 EN"}
          </span>
        </button>

        {/* Exit / Logout Button */}
        <button
          onClick={onLogout}
          className="p-1.5 sm:p-2 sm:px-2.5 rounded-lg bg-[#0d0e12] hover:bg-[#161a23] border border-[#1a1d26] hover:border-rose-500/40 text-[#8a8d9a] hover:text-white transition-all flex items-center gap-1.5 text-xs font-mono font-bold cursor-pointer"
          title={t("Logout / خروج")}
        >
          <LogOut className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-rose-500" />
        </button>
      </div>
    </header>
  );
};


