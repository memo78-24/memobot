import React from "react";
import { Power, Zap } from "lucide-react";

interface ControlPanelProps {
  isPowerOn: boolean;
  handleKillSwitch: () => void;
  handlePowerOnAll: () => void;
  paymentOption: "daily" | "weekly" | "monthly";
  setPaymentOption: (opt: "daily" | "weekly" | "monthly") => void;
  paymentMethod: "card" | "apple" | "gpay" | "paypal" | "crypto";
  setPaymentMethod: (m: "card" | "apple" | "gpay" | "paypal" | "crypto") => void;
  geminiFlash: boolean;
  handleToggleGeminiFlash: () => void;
  exchangesEnabled: { Binance: boolean; KuCoin: boolean; OKX: boolean; Bybit: boolean };
  handleToggleExchange: (ex: "Binance" | "KuCoin" | "OKX" | "Bybit") => void;
  handleToggleComplianceMode: () => void;
  isIslamic: boolean;
}

export const ControlPanel: React.FC<ControlPanelProps> = ({
  isPowerOn,
  handleKillSwitch,
  handlePowerOnAll,
  paymentOption,
  setPaymentOption,
  paymentMethod,
  setPaymentMethod,
  geminiFlash,
  handleToggleGeminiFlash,
  exchangesEnabled,
  handleToggleExchange,
  handleToggleComplianceMode,
  isIslamic,
}) => {
  return (
    <div className="bg-[#0c0e16] border border-slate-800 rounded-lg overflow-hidden shadow-xl flex flex-col w-full h-auto select-none">
      
      {/* 1. POWER & TELEMETRY SECTION */}
      <div className="p-4 border-b border-slate-800 bg-slate-950/20">
        <div className="flex items-center justify-between mb-3.5">
          <span className="text-[10px] font-mono text-slate-400 font-bold uppercase tracking-wider">
            CORE POWER & DIAGNOSTICS
          </span>
          <span className="text-[8px] font-mono text-red-500 font-bold uppercase bg-red-950/30 px-2 py-0.5 rounded border border-red-900/50">
            MASTER CONTROL
          </span>
        </div>

        <div className="flex items-center justify-between gap-4 flex-nowrap">
          {/* Gauges Group */}
          <div className="flex items-center gap-3.5 font-mono">
            {/* Neural Load Gauge */}
            <div className="flex flex-col items-center">
              <div className="relative w-11 h-11 rounded-full border border-red-500/20 flex flex-col items-center justify-center bg-[#0d1017]">
                <span className="text-[11px] font-black text-slate-100">{isPowerOn ? "78" : "0"}</span>
                <div className="absolute inset-0 rounded-full border border-red-500 border-t-transparent animate-[spin_5s_linear_infinite]" />
              </div>
              <span className="text-[7px] text-slate-400 tracking-wider mt-1 uppercase font-bold">LOAD</span>
            </div>

            {/* Clock Speed Gauge */}
            <div className="flex flex-col items-center">
              <div className="relative w-11 h-11 rounded-full border border-cyan-500/20 flex flex-col items-center justify-center bg-[#0d1017]">
                <span className="text-[9px] font-black text-slate-100">{isPowerOn ? "2167" : "0"}</span>
                <div className="absolute inset-0 rounded-full border border-cyan-400 border-l-transparent animate-[spin_3s_linear_infinite]" />
              </div>
              <span className="text-[7px] text-slate-400 tracking-wider mt-1 uppercase font-bold">SPEED</span>
            </div>

            {/* Throughput Gauge */}
            <div className="flex flex-col items-center">
              <div className="relative w-11 h-11 rounded-full border border-red-500/20 flex flex-col items-center justify-center bg-[#0d1017]">
                <span className="text-[9px] font-black text-slate-100">{isPowerOn ? "998" : "0"}</span>
                <div className="absolute inset-0 rounded-full border border-red-500 border-b-transparent animate-[spin_6s_linear_infinite]" />
              </div>
              <span className="text-[7px] text-slate-400 tracking-wider mt-1 uppercase font-bold">THRUPUT</span>
            </div>
          </div>

          {/* Master Tactile Power Toggle Slider */}
          <div className="flex flex-col items-end font-mono">
            <span className="text-[7px] text-slate-500 tracking-widest uppercase font-bold mb-1">MAIN PWR</span>
            <button
              onClick={() => {
                if (isPowerOn) {
                  handleKillSwitch();
                } else {
                  handlePowerOnAll();
                }
              }}
              className={`h-8 w-14 rounded-full p-0.5 flex items-center transition-all ${
                isPowerOn
                  ? "bg-red-950/30 border border-red-500/60 justify-end shadow-[0_0_12px_rgba(239,68,68,0.1)]"
                  : "bg-[#0b0c10] border border-slate-850 justify-start"
              }`}
            >
              <div className={`h-6 w-6 rounded-full flex items-center justify-center transition-all shadow-md ${isPowerOn ? "bg-red-500" : "bg-slate-700"}`}>
                <Power className="w-3 h-3 text-black font-bold" />
              </div>
            </button>
          </div>
        </div>
      </div>

      {/* 2. PAYMENT BENCH SECTION */}
      <div className={`flex-1 transition-all duration-300 ${!isPowerOn ? "opacity-35 pointer-events-none" : ""}`}>
        {/* Header section of the bench */}
        <div className="flex items-center justify-between border-b border-slate-800/80 px-4 py-2.5 bg-slate-950/40 font-mono text-[9px] text-slate-400">
          <div className="flex items-center gap-1.5 text-cyan-400">
            <Zap className="w-3 h-3" />
            <span className="font-bold uppercase tracking-widest">MEMO CORE INTERACTIVE CONTROL BENCH</span>
          </div>
        </div>

        <div className="p-4 space-y-4">
          {/* Billing options cards */}
          <div className="grid grid-cols-3 gap-2.5">
            <button 
              onClick={() => setPaymentOption("daily")}
              className={`py-2 px-1.5 rounded border text-center transition-all duration-300 ${
                paymentOption === "daily" 
                  ? "border-cyan-500 bg-cyan-950/15" 
                  : "border-slate-800 bg-slate-900/30"
              }`}
            >
              <span className="block text-[8px] font-mono text-slate-400 tracking-wider">DAILY</span>
              <span className="block text-sm font-black text-white mt-0.5">$3</span>
              <span className="block text-[6px] font-mono text-slate-500 mt-0.5">Billed Daily</span>
            </button>

            <button 
              onClick={() => setPaymentOption("weekly")}
              className={`relative py-2 px-1.5 rounded border text-center transition-all duration-300 ${
                paymentOption === "weekly" 
                  ? "border-red-500 bg-red-950/15" 
                  : "border-slate-800 bg-slate-900/30"
              }`}
            >
              <div className="absolute -top-1.5 left-1/2 -translate-x-1/2 bg-red-500 text-white text-[5px] font-extrabold px-1 py-0.5 rounded tracking-wider uppercase font-mono leading-none">
                POPULAR
              </div>
              <span className="block text-[8px] font-mono text-slate-400 tracking-wider">WEEKLY</span>
              <span className="block text-sm font-black text-white mt-0.5">$18</span>
              <span className="block text-[6px] font-mono text-slate-500 mt-0.5">Billed Weekly</span>
            </button>

            <button 
              onClick={() => setPaymentOption("monthly")}
              className={`relative py-2 px-1.5 rounded border text-center transition-all duration-300 ${
                paymentOption === "monthly" 
                  ? "border-cyan-500 bg-cyan-950/15" 
                  : "border-slate-800 bg-slate-900/30"
              }`}
            >
              <div className="absolute -top-1.5 left-1/2 -translate-x-1/2 bg-cyan-500 text-black text-[5px] font-extrabold px-1 py-0.5 rounded tracking-wider uppercase font-mono leading-none">
                BEST VALUE
              </div>
              <span className="block text-[8px] font-mono text-slate-400 tracking-wider">MONTHLY</span>
              <span className="block text-sm font-black text-white mt-0.5">$50</span>
              <span className="block text-[6px] font-mono text-slate-500 mt-0.5">Billed Monthly</span>
            </button>
          </div>

          {/* 6 core gateway toggles */}
          <div className="border-t border-slate-800/80 pt-3">
            <span className="text-[8px] text-slate-500 font-mono font-bold uppercase block tracking-widest mb-2">
              6-CHANNEL SYSTEM ACTIVE CONTROL TOGGLES:
            </span>
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5">
              <div className="flex flex-col items-center bg-black/40 border border-slate-855 p-1 rounded">
                <span className="text-[6px] text-slate-400 font-mono font-bold mb-1 truncate uppercase">Gemini Flash</span>
                <button
                  onClick={handleToggleGeminiFlash}
                  className={`w-7 h-3.5 rounded-full p-0.5 flex items-center transition-all ${
                    geminiFlash ? "bg-purple-600 justify-end" : "bg-zinc-800 justify-start"
                  }`}
                >
                  <div className="w-2.5 h-2.5 rounded-full bg-white shadow-sm" />
                </button>
              </div>

              <div className="flex flex-col items-center bg-black/40 border border-slate-855 p-1 rounded">
                <span className="text-[6px] text-slate-400 font-mono font-bold mb-1 truncate uppercase">Binance</span>
                <button
                  onClick={() => handleToggleExchange("Binance")}
                  className={`w-7 h-3.5 rounded-full p-0.5 flex items-center transition-all ${
                    exchangesEnabled.Binance ? "bg-emerald-600 justify-end" : "bg-zinc-800 justify-start"
                  }`}
                >
                  <div className="w-2.5 h-2.5 rounded-full bg-white shadow-sm" />
                </button>
              </div>

              <div className="flex flex-col items-center bg-black/40 border border-slate-855 p-1 rounded">
                <span className="text-[6px] text-slate-400 font-mono font-bold mb-1 truncate uppercase">KuCoin</span>
                <button
                  onClick={() => handleToggleExchange("KuCoin")}
                  className={`w-7 h-3.5 rounded-full p-0.5 flex items-center transition-all ${
                    exchangesEnabled.KuCoin ? "bg-emerald-600 justify-end" : "bg-zinc-800 justify-start"
                  }`}
                >
                  <div className="w-2.5 h-2.5 rounded-full bg-white shadow-sm" />
                </button>
              </div>

              <div className="flex flex-col items-center bg-black/40 border border-slate-855 p-1 rounded">
                <span className="text-[6px] text-slate-400 font-mono font-bold mb-1 truncate uppercase">OKX</span>
                <button
                  onClick={() => handleToggleExchange("OKX")}
                  className={`w-7 h-3.5 rounded-full p-0.5 flex items-center transition-all ${
                    exchangesEnabled.OKX ? "bg-emerald-600 justify-end" : "bg-zinc-800 justify-start"
                  }`}
                >
                  <div className="w-2.5 h-2.5 rounded-full bg-white shadow-sm" />
                </button>
              </div>

              <div className="flex flex-col items-center bg-black/40 border border-slate-855 p-1 rounded">
                <span className="text-[6px] text-slate-400 font-mono font-bold mb-1 truncate uppercase">Bybit</span>
                <button
                  onClick={() => handleToggleExchange("Bybit")}
                  className={`w-7 h-3.5 rounded-full p-0.5 flex items-center transition-all ${
                    exchangesEnabled.Bybit ? "bg-emerald-600 justify-end" : "bg-zinc-800 justify-start"
                  }`}
                >
                  <div className="w-2.5 h-2.5 rounded-full bg-white shadow-sm" />
                </button>
              </div>

              <div className="flex flex-col items-center bg-black/40 border border-slate-855 p-1 rounded">
                <span className="text-[6px] text-slate-400 font-mono font-bold mb-1 truncate uppercase">Policy</span>
                <button
                  onClick={handleToggleComplianceMode}
                  className={`w-7 h-3.5 rounded-full p-0.5 flex items-center transition-all ${
                    isIslamic ? "bg-emerald-500 justify-end" : "bg-rose-600 justify-start"
                  }`}
                >
                  <div className="w-2.5 h-2.5 rounded-full bg-white shadow-sm" />
                </button>
              </div>
            </div>
          </div>

          {/* Card payment choices */}
          <div className="border-t border-slate-800/80 pt-3">
            <div className="flex justify-between items-center mb-2 font-mono text-[8px] text-slate-500 tracking-widest uppercase">
              <span>SELECT ACTIVE PAYMENT METHOD:</span>
              <span className="text-cyan-400 font-bold">CARD ACTIVE</span>
            </div>
            <div className="grid grid-cols-5 gap-1">
              {[
                { id: "card", name: "CARD" },
                { id: "apple", name: "APPLE" },
                { id: "gpay", name: "G-PAY" },
                { id: "paypal", name: "PAYPAL" },
                { id: "crypto", name: "CRYPTO" }
              ].map(method => (
                <button
                  key={method.id}
                  onClick={() => setPaymentMethod(method.id as any)}
                  className={`py-1 rounded font-mono text-[7px] font-bold uppercase tracking-wider transition-all border ${
                    paymentMethod === method.id 
                      ? "border-red-500 bg-red-950/20 text-white" 
                      : "border-slate-850 bg-slate-950/60 text-slate-400 hover:text-slate-200 hover:border-slate-750"
                  }`}
                >
                  {method.name}
                </button>
              ))}
            </div>
          </div>

        </div>
      </div>

    </div>
  );
};
