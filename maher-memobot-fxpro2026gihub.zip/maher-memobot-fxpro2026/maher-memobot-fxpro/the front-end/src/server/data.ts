import ccxt from "ccxt";

export let cachedPrices: Record<string, number> = {
  BTC: 75940.65, ETH: 2088.80, USDT: 1.0, BNB: 585.0, SOL: 73.0,
  XRP: 0.58, USDC: 1.0, ADA: 0.45, DOGE: 0.12, AVAX: 28.5,
  SHIB: 0.000018, DOT: 6.8, LINK: 14.2, BCH: 380.0, NEAR: 5.1,
  TRX: 0.13, MATIC: 0.52, LTC: 72.0, ICP: 8.4, UNI: 7.6,
  APT: 6.9, FET: 1.35, SUI: 0.88, ATOM: 6.2, RENDER: 6.1,
  FIL: 4.4, XLM: 0.1, HBAR: 0.07, ARB: 0.75, OP: 1.8,
  PEPE: 0.0000095, INJ: 21.5, KAS: 0.17, TIA: 6.4, WIF: 2.1,
  STX: 1.75, XMR: 160.0, FTM: 0.48, OKB: 42.0, CRO: 0.09,
  LDO: 1.9, AAVE: 98.0, GRT: 0.21, ALGO: 0.14, THETA: 1.4,
  RUNE: 3.8, FLOW: 0.65, EGLD: 29.0, SAND: 0.32, MANA: 0.34
};

export const top50Meta = [
  { rank: 1, symbol: "BTC", name: "Bitcoin", status: "COMPLIANT", group: "Store of Value", vol24h: "$38.4B", audit: "Physical spot asset, halal utility", volatility: "MODERATE" },
  { rank: 2, symbol: "ETH", name: "Ethereum", status: "COMPLIANT", group: "Utility Ledger", vol24h: "$18.2B", audit: "Gas layer, spot utility", volatility: "MODERATE" },
  { rank: 3, symbol: "USDT", name: "Tether USD", status: "COMPLIANT", group: "Stablecoin", vol24h: "$52.1B", audit: "1:1 collateralized fiat reserves", volatility: "LOW" },
  { rank: 4, symbol: "BNB", name: "BNB", status: "COMPLIANT", group: "Ecosystem Token", vol24h: "$1.8B", audit: "Chain gas & fee discount utility", volatility: "MODERATE" },
  { rank: 5, symbol: "SOL", name: "Solana", status: "COMPLIANT", group: "Utility Ledger", vol24h: "$3.4B", audit: "High speed smart contract execution", volatility: "HIGH" },
  { rank: 6, symbol: "XRP", name: "XRP", status: "COMPLIANT", group: "Payment Rail", vol24h: "$1.1B", audit: "Cross-border payment messaging", volatility: "MODERATE" },
  { rank: 7, symbol: "USDC", name: "USD Coin", status: "COMPLIANT", group: "Stablecoin", vol24h: "$6.8B", audit: "Audited 1:1 USD reserves", volatility: "LOW" },
  { rank: 8, symbol: "ADA", name: "Cardano", status: "COMPLIANT", group: "Utility Ledger", vol24h: "$420M", audit: "Academic PoS smart contract platform", volatility: "MODERATE" },
  { rank: 9, symbol: "DOGE", name: "Dogecoin", status: "NON-COMPLIANT", group: "Meme Token", vol24h: "$950M", audit: "Speculative meme, no utility, Gharar risk", volatility: "VERY HIGH" },
  { rank: 10, symbol: "AVAX", name: "Avalanche", status: "COMPLIANT", group: "Utility Ledger", vol24h: "$380M", audit: "Subnet L1 consensus architecture", volatility: "HIGH" },
  { rank: 11, symbol: "SHIB", name: "Shiba Inu", status: "NON-COMPLIANT", group: "Meme Token", vol24h: "$410M", audit: "High speculation meme token", volatility: "VERY HIGH" },
  { rank: 12, symbol: "DOT", name: "Polkadot", status: "COMPLIANT", group: "Interoperability", vol24h: "$220M", audit: "Parachain relay chain protocol", volatility: "MODERATE" },
  { rank: 13, symbol: "LINK", name: "Chainlink", status: "COMPLIANT", group: "Oracle Network", vol24h: "$290M", audit: "Decentralized data oracle network", volatility: "MODERATE" },
  { rank: 14, symbol: "BCH", name: "Bitcoin Cash", status: "COMPLIANT", group: "Payment Rail", vol24h: "$310M", audit: "Peer-to-peer electronic cash", volatility: "HIGH" },
  { rank: 15, symbol: "NEAR", name: "NEAR Protocol", status: "COMPLIANT", group: "Utility Ledger", vol24h: "$340M", audit: "Sharded PoS developer platform", volatility: "HIGH" },
  { rank: 16, symbol: "TRX", name: "TRON", status: "COMPLIANT", group: "Payment Rail", vol24h: "$450M", audit: "High throughput stablecoin settlement", volatility: "LOW" },
  { rank: 17, symbol: "MATIC", name: "Polygon", status: "COMPLIANT", group: "L2 Scaling", vol24h: "$210M", audit: "Ethereum zero-knowledge L2 aggregator", volatility: "MODERATE" },
  { rank: 18, symbol: "LTC", name: "Litecoin", status: "COMPLIANT", group: "Payment Rail", vol24h: "$390M", audit: "Scrypt PoW digital silver", volatility: "MODERATE" },
  { rank: 19, symbol: "ICP", name: "Internet Computer", status: "COMPLIANT", group: "Cloud Compute", vol24h: "$180M", audit: "Decentralized web compute infrastructure", volatility: "HIGH" },
  { rank: 20, symbol: "UNI", name: "Uniswap", status: "COMPLIANT", group: "DeFi Governance", vol24h: "$260M", audit: "Automated market maker governance", volatility: "HIGH" },
  { rank: 21, symbol: "APT", name: "Aptos", status: "COMPLIANT", group: "Utility Ledger", vol24h: "$195M", audit: "Move language parallel execution L1", volatility: "HIGH" },
  { rank: 22, symbol: "FET", name: "ASI Alliance", status: "COMPLIANT", group: "AI & Data", vol24h: "$320M", audit: "Autonomous AI agent compute mesh", volatility: "VERY HIGH" },
  { rank: 23, symbol: "SUI", name: "Sui", status: "COMPLIANT", group: "Utility Ledger", vol24h: "$410M", audit: "Object-centric Move L1 blockchain", volatility: "HIGH" },
  { rank: 24, symbol: "ATOM", name: "Cosmos", status: "COMPLIANT", group: "Interoperability", vol24h: "$140M", audit: "IBC inter-blockchain communication hub", volatility: "MODERATE" },
  { rank: 25, symbol: "RENDER", name: "Render", status: "COMPLIANT", group: "GPU Compute", vol24h: "$230M", audit: "Decentralized 3D rendering GPU network", volatility: "HIGH" },
  { rank: 26, symbol: "FIL", name: "Filecoin", status: "COMPLIANT", group: "Storage Mesh", vol24h: "$160M", audit: "Decentralized data storage network", volatility: "MODERATE" },
  { rank: 27, symbol: "XLM", name: "Stellar", status: "COMPLIANT", group: "Payment Rail", vol24h: "$110M", audit: "Cross-border asset issuance platform", volatility: "MODERATE" },
  { rank: 28, symbol: "HBAR", name: "Hedera", status: "COMPLIANT", group: "Utility Ledger", vol24h: "$95M", audit: "Hashgraph enterprise consensus ledger", volatility: "MODERATE" },
  { rank: 29, symbol: "ARB", name: "Arbitrum", status: "COMPLIANT", group: "L2 Scaling", vol24h: "$270M", audit: "Optimistic rollup L2 scaling layer", volatility: "HIGH" },
  { rank: 30, symbol: "OP", name: "Optimism", status: "COMPLIANT", group: "L2 Scaling", vol24h: "$185M", audit: "OP Stack modular rollup infrastructure", volatility: "HIGH" },
  { rank: 31, symbol: "PEPE", name: "Pepe", status: "NON-COMPLIANT", group: "Meme Token", vol24h: "$820M", audit: "Pure speculation meme, no utility", volatility: "EXTREME" },
  { rank: 32, symbol: "INJ", name: "Injective", status: "COMPLIANT", group: "DeFi L1", vol24h: "$150M", audit: "Interoperable orderbook L1 for finance", volatility: "HIGH" },
  { rank: 33, symbol: "KAS", name: "Kaspa", status: "COMPLIANT", group: "PoW BlockDAG", vol24h: "$130M", audit: "GHOSTDAG protocol fast PoW ledger", volatility: "HIGH" },
  { rank: 34, symbol: "TIA", name: "Celestia", status: "COMPLIANT", group: "Data Availability", vol24h: "$210M", audit: "Modular data availability network", volatility: "VERY HIGH" },
  { rank: 35, symbol: "WIF", name: "dogwifhat", status: "NON-COMPLIANT", group: "Meme Token", vol24h: "$510M", audit: "Speculative meme, zero intrinsic utility", volatility: "EXTREME" },
  { rank: 36, symbol: "STX", name: "Stacks", status: "COMPLIANT", group: "Bitcoin L2", vol24h: "$115M", audit: "Bitcoin smart contracts & sBTC layer", volatility: "HIGH" },
  { rank: 37, symbol: "XMR", name: "Monero", status: "HIGH-RISK", group: "Privacy Token", vol24h: "$85M", audit: "Anonymized ring signature private ledger", volatility: "HIGH" },
  { rank: 38, symbol: "FTM", name: "Fantom", status: "COMPLIANT", group: "Utility Ledger", vol24h: "$140M", audit: "Lachesis DAG consensus smart platform", volatility: "HIGH" },
  { rank: 39, symbol: "OKB", name: "OKB", status: "COMPLIANT", group: "Ecosystem Token", vol24h: "$65M", audit: "Exchange utility & fee reduction token", volatility: "LOW" },
  { rank: 40, symbol: "CRO", name: "Cronos", status: "COMPLIANT", group: "Ecosystem Token", vol24h: "$45M", audit: "EVM-compatible chain utility asset", volatility: "MODERATE" },
  { rank: 41, symbol: "LDO", name: "Lido DAO", status: "COMPLIANT", group: "DeFi Staking", vol24h: "$125M", audit: "Liquid staking governance protocol", volatility: "HIGH" },
  { rank: 42, symbol: "AAVE", name: "Aave", status: "COMPLIANT", group: "DeFi Liquidity", vol24h: "$175M", audit: "Liquidity protocol governance token", volatility: "HIGH" },
  { rank: 43, symbol: "GRT", name: "The Graph", status: "COMPLIANT", group: "Data Indexing", vol24h: "$90M", audit: "Decentralized blockchain indexing query protocol", volatility: "HIGH" },
  { rank: 44, symbol: "ALGO", name: "Algorand", status: "COMPLIANT", group: "Utility Ledger", vol24h: "$70M", audit: "Pure PoS instant finality blockchain", volatility: "MODERATE" },
  { rank: 45, symbol: "THETA", name: "Theta Network", status: "COMPLIANT", group: "Video & AI", vol24h: "$55M", audit: "Decentralized video streaming & edge compute", volatility: "MODERATE" },
  { rank: 46, symbol: "RUNE", name: "THORChain", status: "COMPLIANT", group: "Cross-Chain Liquidity", vol24h: "$135M", audit: "Decentralized cross-chain liquidity protocol", volatility: "VERY HIGH" },
  { rank: 47, symbol: "FLOW", name: "Flow", status: "COMPLIANT", group: "Consumer L1", vol24h: "$40M", audit: "Developer-friendly blockchain for apps", volatility: "MODERATE" },
  { rank: 48, symbol: "EGLD", name: "MultiversX", status: "COMPLIANT", group: "Utility Ledger", vol24h: "$35M", audit: "Adaptive state sharding architecture", volatility: "HIGH" },
  { rank: 49, symbol: "SAND", name: "The Sandbox", status: "COMPLIANT", group: "Metaverse", vol24h: "$60M", audit: "User-generated gaming ecosystem asset", volatility: "HIGH" },
  { rank: 50, symbol: "MANA", name: "Decentraland", status: "COMPLIANT", group: "Metaverse", vol24h: "$50M", audit: "Virtual world spatial utility token", volatility: "HIGH" }
];

export const binancePublic = new ccxt.binance();
export async function updatePrices() {
  try {
    const pairs = top50Meta.slice(0, 15).filter(m => m.symbol !== 'USDT').map(m => `${m.symbol}/USDT`);
    const tickers = await binancePublic.fetchTickers(pairs);
    top50Meta.forEach(meta => {
      const pairKey = `${meta.symbol}/USDT`;
      if (tickers[pairKey] && tickers[pairKey].last) {
        cachedPrices[meta.symbol] = tickers[pairKey].last;
      }
    });
  } catch (err) {
    console.error("Failed to update prices", err);
  }
}
setInterval(updatePrices, 10000);
updatePrices();
