import { Application, Request, Response } from "express";
import { db } from "../../db";
import { authenticateToken } from "../auth";
import { strategies } from "../../db/schema";
import { eq, and } from "drizzle-orm";
import { v4 as uuidv4 } from "uuid";
import { broadcastEvent } from "../websocket";

export function setupStrategiesRoutes(app: Application) {
  app.get("/api/v1/strategies/list", authenticateToken, async (req: Request, res: Response) => {
    res.json({
      strategies: [
        { id: "tmpl-sirius-momentum", strategy_name: "SIRIUS MOMENTUM TREND", description: "Follows strong bullish momentum with trailing stop locks.", win_rate: "74.8%", sharpe: "2.12", max_dd: "2.1%" },
        { id: "tmpl-rigel-hft", strategy_name: "RIGEL HFT SCALPER", description: "High-frequency micro-channel scalper for sideways consolidation.", win_rate: "79.2%", sharpe: "2.45", max_dd: "1.8%" },
        { id: "tmpl-canopus-arb", strategy_name: "CANOPUS STAT ARBITRAGE", description: "Statistical arbitrage model based on multi-exchange price spreads.", win_rate: "82.4%", sharpe: "2.85", max_dd: "3.2%" },
        { id: "tmpl-halal-guard", strategy_name: "HALAL GUARD GRID", description: "Islamic compliance grid order routing with 100% physical spot asset backing.", win_rate: "70.5%", sharpe: "1.98", max_dd: "1.1%" },
        { id: "tmpl-vega-neural", strategy_name: "VEGA NEURAL SWARM", description: "Multi-layered neural consensus swarm predicting short-term order flow.", win_rate: "84.1%", sharpe: "3.02", max_dd: "2.9%" },
        { id: "tmpl-beta-reversion", strategy_name: "BETA MEAN REVERSION", description: "Identifies statistically overextended deviation from moving average ribbons.", win_rate: "72.1%", sharpe: "2.05", max_dd: "2.4%" },
        { id: "tmpl-alpha-vwap", strategy_name: "ALPHA WEIGHTED VWAP", description: "Volume-weighted average price positioning for institutional block execution.", win_rate: "75.6%", sharpe: "2.22", max_dd: "1.5%" },
        { id: "tmpl-theta-depth", strategy_name: "THETA DEPTH FEED", description: "Monitors order book order flow imbalance to scalp liquidity sweeps.", win_rate: "77.8%", sharpe: "2.38", max_dd: "2.0%" },
        { id: "tmpl-sigma-sentiment", strategy_name: "SIGMA SENTIMENT PARSER", description: "Uses natural language API feeds to score global crypto macro news sentiment.", win_rate: "73.5%", sharpe: "2.10", max_dd: "2.5%" },
        { id: "tmpl-delta-breakout", strategy_name: "DELTA OVERBOUGHT BREAKOUT", description: "Monitors consolidation zones and schedules breakout execution protocols.", win_rate: "71.4%", sharpe: "1.95", max_dd: "3.5%" }
      ]
    });
  });

  app.get("/api/v1/strategies/instances", authenticateToken, async (req: Request, res: Response) => {
    const userId = req.body.authenticated_user_id;
    const userStrategies = await db.select().from(strategies).where(eq(strategies.userId, userId));
    res.json({ strategies: userStrategies });
  });

  app.post("/api/v1/strategies/create", authenticateToken, async (req: Request, res: Response) => {
    const userId = req.body.authenticated_user_id;
    const { strategy_name, config } = req.body;
    const id = "STR-" + uuidv4();

    const newStrat = {
      id,
      userId,
      strategyName: strategy_name,
      status: "Draft",
      version: 1,
      config: config || { ema_fast: 20, ema_slow: 50, leverage: 1, stop_loss: 2.5, revision: 1 },
    };

    await db.insert(strategies).values(newStrat);

    res.json({ success: true, strategy_id: id });
  });

  app.post("/api/v1/strategies/:strategy_id/update-config", authenticateToken, async (req: Request, res: Response) => {
    const userId = req.body.authenticated_user_id;
    const stratId = req.params.strategy_id;
    const { config } = req.body;

    const strat = (await db.select().from(strategies).where(and(eq(strategies.userId, userId), eq(strategies.id, stratId))))[0];
    
    if (!strat) {
      return res.status(404).json({ error: "Strategy workspace not found." });
    }

    const currentConfig = strat.config as any;
    const incomingRevision = config.revision || 1;
    const currentRevision = currentConfig.revision || 1;
    if (incomingRevision < currentRevision) {
      return res.status(409).json({ error: "Draft updated elsewhere. Please merge the latest changes." });
    }

    const newConfig = { ...config, revision: currentRevision + 1 };
    await db.update(strategies).set({ config: newConfig, updatedAt: new Date() }).where(eq(strategies.id, stratId));

    res.json({ success: true, config: newConfig });
  });

  app.post("/api/v1/strategies/:strategy_id/simulate", authenticateToken, async (req: Request, res: Response) => {
    const userId = req.body.authenticated_user_id;
    const stratId = req.params.strategy_id;
    let config = req.body.config;

    if (!config) {
      const strat = (await db.select().from(strategies).where(and(eq(strategies.userId, userId), eq(strategies.id, stratId))))[0];
      config = strat?.config || {};
    }

    const emaFast = Number(config?.ema_fast) || 20;
    const emaSlow = Number(config?.ema_slow) || 50;
    const stopLoss = Number(config?.stop_loss) || 2.5;

    // Deterministic simulation based on config parameters
    const count = 40;
    const equity_curve = [];
    let current = 10000;
    const luck = (emaFast / emaSlow) * 0.9 + (3 / stopLoss) * 0.1;
    
    for (let i = 0; i < count; i++) {
        const volatility = 0.015 + (Math.random() * 0.008);
        const direction = Math.sin(i * 0.4) * 0.08 + (luck - 0.45) * 0.15;
        current = current * (1 + (direction * volatility));
        equity_curve.push(Math.round(current * 100) / 100);
    }

    const profitPct = Math.round(((current - 10000) / 10000) * 1000) / 10;

    res.json({
      equity_curve,
      win_rate: Math.min(92, Math.max(30, Math.round(luck * 100))),
      profit_pct: profitPct,
      annual_return: profitPct * 1.8,
      total_trades: 120 + Math.floor(Math.random() * 20),
      sharpe_ratio: (luck * 2.2).toFixed(2),
      max_drawdown: (stopLoss * 1.15).toFixed(2)
    });
  });

  app.post("/api/v1/strategies/:strategy_id/start", authenticateToken, async (req: Request, res: Response) => {
    const userId = req.body.authenticated_user_id;
    const stratId = req.params.strategy_id;
    const cid = req.headers["x-correlation-id"] as string;
    
    const strat = (await db.select().from(strategies).where(and(eq(strategies.userId, userId), eq(strategies.id, stratId))))[0];
    if (!strat) {
        return res.status(404).json({ error: "Strategy workspace not found." });
    }

    await db.update(strategies).set({ status: "Active", version: strat.version + 1, updatedAt: new Date() }).where(eq(strategies.id, stratId));

    broadcastEvent({
        event: "STRATEGY_DEPLOYED",
        strategy_id: stratId,
        version: strat.version + 1,
        deployed_by: "admin",
        cid
    });

    res.json({ success: true, version: strat.version + 1 });
  });

  app.post("/api/v1/strategies/:strategy_id/stop", authenticateToken, async (req: Request, res: Response) => {
    const userId = req.body.authenticated_user_id;
    const stratId = req.params.strategy_id;

    await db.update(strategies).set({ status: "Draft", updatedAt: new Date() }).where(and(eq(strategies.userId, userId), eq(strategies.id, stratId)));

    res.json({ success: true });
  });

  app.delete("/api/v1/strategies/:strategy_id", authenticateToken, async (req: Request, res: Response) => {
    const userId = req.body.authenticated_user_id;
    const stratId = req.params.strategy_id;

    await db.delete(strategies).where(and(eq(strategies.userId, userId), eq(strategies.id, stratId)));
    res.json({ success: true });
  });
}
