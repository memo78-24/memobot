import fs from "fs";
import path from "path";

const DB_PATH = path.join(process.cwd(), "db.json");

export interface TrialInvitation {
  id: string;
  recipientName: string;
  recipientContact: string;
  duration: '24hrs' | '3days' | '1week' | '1month';
  createdAt: string;
  expiresAt: string;
  status: 'PENDING' | 'ACTIVE' | 'EXPIRED' | 'REVOKED';
  invitedBy: string;
}

export interface DBState {
  users: Record<string, { id: string; username: string; role: string; isActive: boolean; token: string; password?: string; mustChangePassword?: boolean }>;
  trial_invitations?: TrialInvitation[];
  vault: Record<string, Record<string, { apiKey: string; apiSecret: string; apiPassphrase?: string }>>;
  portfolios: Record<string, {
    net_worth: number;
    balance_usdt: number;
    locked_margin: number;
    unrealized_pnl: number;
    win_rate: number;
    total_trades: number;
    wins: number;
    losses: number;
  }>;
  engines: Record<string, Record<string, {
    engine_id: string;
    display_name: string;
    nickname: string;
    subtitle: string;
    theme: string;
    status: 'Running' | 'Paused' | 'Stopped';
    uptime_seconds: number;
    current_stage_idx: number;
    latency_ms: number;
    cpu_load: number;
    memory_mb: number;
    strategy: string;
    asset: string;
    amount: number;
    leverage?: number;
    runtime_hours: number;
    last_tick: number;
  }>>;
  strategies: Record<string, Array<{
    id: string;
    strategy_name: string;
    status: 'Draft' | 'Active';
    version: number;
    config: Record<string, any>;
    created_at: string;
    updated_at: string;
  }>>;
  positions: Record<string, Array<{
    engine_id: string;
    symbol: string;
    amount: number;
    entry_price: number;
    current_price: number;
    pnl: number;
    roi: number;
    locked_margin: number;
  }>>;
  audit_logs: Record<string, Array<{
    id: string;
    timestamp: string;
    action: string;
    status: 'SUCCESS' | 'FAILED' | 'WARN';
    details: string;
    correlation_id: string;
    integrity_hash: string;
  }>>;
  compliance_mode: Record<string, 'Islamic' | 'Commercial'>;
  execution_mode: Record<string, 'Paper' | 'Live'>;
  live_mode_confirmed: Record<string, boolean>;
  trades: Record<string, Array<{
    id: string;
    timestamp: string;
    side: 'BUY' | 'SELL';
    symbol: string;
    amount: number;
    price: number;
    fill_price: number;
    fill_amount: number;
    engine_id: string;
  }>>;
  risk_settings?: Record<string, {
    max_daily_drawdown_pct: number;
    max_position_size_usdt: number;
    default_stop_loss_pct: number;
    default_take_profit_pct: number;
    stealth_mode: boolean;
    auto_kill_switch_enabled: boolean;
    shariah_guard_enabled: boolean;
  }>;
  decisions?: Record<string, Array<any>>;
  circuit_breaker_active?: Record<string, boolean>;
  gifts?: Record<string, Array<{
    id: string;
    timestamp: string;
    amount_usdt: number;
    currency: string;
    message: string;
    recipient: string;
    type: 'ONE_TIME' | 'PROFIT_SHARE';
    status: 'SUCCESS';
  }>>;
  gift_settings?: Record<string, {
    auto_gifting_enabled: boolean;
    auto_gift_percentage: number;
    preferred_recipient: string;
  }>;
    vip_users?: Array<{
      id: string;
      name: string;
      contact: string;
      email: string;
      role: string;
      isVIP: boolean;
      vipBadge?: string;
      isFrozen: boolean;
      joinedAt: string;
      patchGroup: "Family (1st Patch)" | "Close Friends (2nd Patch)" | "Marketing Ambassador (3rd Patch)" | "Standard Client";
      lastActive: string;
      activities: Array<{ timestamp: string; action: string; details: string }>;
      billingStatus?: 'Waived' | 'Active' | 'Pending';
      successFeePct?: number;
      monthlyFee?: number;
      invoices?: Array<{ id: string; date: string; type: string; amount: number; status: 'PAID' | 'WAIVED' | 'PENDING' }>;
      logins?: Array<{ timestamp: string; ip: string; device: string; location: string; status: 'SUCCESS' | 'FAILED' }>;
    }>;
    translations?: Record<string, string>;
  }
  
  export function getInitialDBState(): DBState {
    return {
      translations: {},
      vip_users: [
        {
          id: "USR-9001",
          name: "Founding Executive Member",
          contact: "+1 (555) 019-2831",
          email: "founding.partner@memobot-fxpro.com",
          role: "Executive Founding Partner",
          isVIP: true,
          vipBadge: "FOUNDING VIP PARTNER (LIFETIME)",
          isFrozen: false,
          joinedAt: "2026-07-23 04:12:00",
          patchGroup: "Family (1st Patch)",
          lastActive: "2 mins ago",
          billingStatus: "Waived",
          successFeePct: 0,
          monthlyFee: 0,
          invoices: [
            { id: "INV-9001-01", date: "2026-08-01", type: "SUBSCRIPTION", amount: 499.00, status: "WAIVED" },
            { id: "INV-9001-02", date: "2026-08-15", type: "SUCCESS_FEE", amount: 145.20, status: "WAIVED" }
          ],
          logins: [
            { timestamp: "2026-08-27 02:40:15", ip: "192.168.1.45", device: "iPhone 15 Pro Max (Mobile)", location: "London, UK", status: "SUCCESS" },
            { timestamp: "2026-08-26 18:12:40", ip: "192.168.1.45", device: "iPhone 15 Pro Max (Mobile)", location: "London, UK", status: "SUCCESS" },
            { timestamp: "2026-08-25 09:30:12", ip: "192.168.1.45", device: "iPad Air (Safari)", location: "London, UK", status: "SUCCESS" }
          ],
          activities: [
            { timestamp: "2026-07-23 04:12:00", action: "ACCOUNT_CREATED", details: "Account generated with Lifetime Free VIP status." },
            { timestamp: "2026-07-23 04:15:20", action: "STRATEGY_ATTACHED", details: "Automated Capital Safeguard Engine initialized." },
            { timestamp: "2026-07-23 05:01:10", action: "LOGIN_SUCCESS", details: "Session started via Secure Mobile Gateway." },
          ],
        },
        {
          id: "USR-9002",
          name: "Senior Advisory Member",
          contact: "+1 (555) 019-8812",
          email: "advisory.member@memobot-fxpro.com",
          role: "Strategic Advisory Partner",
          isVIP: true,
          vipBadge: "STRATEGIC VIP PARTNER (LIFETIME)",
          isFrozen: false,
          joinedAt: "2026-07-23 04:20:00",
          patchGroup: "Family (1st Patch)",
          lastActive: "12 mins ago",
          billingStatus: "Waived",
          successFeePct: 0,
          monthlyFee: 0,
          invoices: [
            { id: "INV-9002-01", date: "2026-08-01", type: "SUBSCRIPTION", amount: 499.00, status: "WAIVED" }
          ],
          logins: [
            { timestamp: "2026-08-27 02:30:10", ip: "82.45.191.12", device: "MacBook Pro (Chrome)", location: "London, UK", status: "SUCCESS" },
            { timestamp: "2026-08-24 15:20:00", ip: "82.45.191.12", device: "MacBook Pro (Chrome)", location: "London, UK", status: "SUCCESS" }
          ],
          activities: [
            { timestamp: "2026-07-23 04:20:00", action: "ACCOUNT_CREATED", details: "Lifetime VIP profile initialized with zero fees." },
            { timestamp: "2026-07-23 04:45:00", action: "PORTFOLIO_VIEW", details: "Inspected Live PnL & Halal Compliance Badge." },
          ],
        },
        {
          id: "USR-7014",
          name: "Alexander Wright (Close Friend)",
          contact: "+44 7700 900077",
          email: "alex.wright@tradingnet.org",
          role: "VIP Close Friend",
          isVIP: true,
          vipBadge: "INNER CIRCLE VIP 💎",
          isFrozen: false,
          joinedAt: "2026-07-23 05:10:00",
          patchGroup: "Close Friends (2nd Patch)",
          lastActive: "1 hour ago",
          billingStatus: "Waived",
          successFeePct: 2.5,
          monthlyFee: 0,
          invoices: [
            { id: "INV-7014-01", date: "2026-08-01", type: "SUBSCRIPTION", amount: 499.00, status: "WAIVED" },
            { id: "INV-7014-02", date: "2026-08-20", type: "SUCCESS_FEE", amount: 88.50, status: "WAIVED" }
          ],
          logins: [
            { timestamp: "2026-08-27 01:10:05", ip: "148.25.10.122", device: "Desktop Workstation (Windows)", location: "New York, USA", status: "SUCCESS" },
            { timestamp: "2026-08-26 14:02:50", ip: "148.25.10.122", device: "Desktop Workstation (Windows)", location: "New York, USA", status: "SUCCESS" }
          ],
          activities: [
            { timestamp: "2026-07-23 05:10:00", action: "ACCOUNT_CREATED", details: "Added to 2nd Patch Close Friends lifetime roster." },
            { timestamp: "2026-07-23 05:30:15", action: "VAULT_KEYS_UPDATED", details: "Connected Binance Mainnet API via Secure Vault." },
          ],
        },
        {
          id: "USR-3309",
          name: "Marcus Vance",
          contact: "+1 (555) 349-1120",
          email: "marcus.vance@institutional-alpha.io",
          role: "Standard Trader",
          isVIP: false,
          isFrozen: false,
          joinedAt: "2026-07-20 11:30:00",
          patchGroup: "Standard Client",
          lastActive: "5 mins ago",
          billingStatus: "Active",
          successFeePct: 15,
          monthlyFee: 499,
          invoices: [
            { id: "INV-3309-01", date: "2026-08-01", type: "SUBSCRIPTION", amount: 499.00, status: "PAID" },
            { id: "INV-3309-02", date: "2026-08-15", type: "SUCCESS_FEE", amount: 320.40, status: "PAID" },
            { id: "INV-3309-03", date: "2026-08-25", type: "SUCCESS_FEE", amount: 180.10, status: "PENDING" }
          ],
          logins: [
            { timestamp: "2026-08-27 02:35:10", ip: "201.88.102.5", device: "Chrome OS Laptop", location: "Zurich, Switzerland", status: "SUCCESS" },
            { timestamp: "2026-08-26 11:24:15", ip: "201.88.102.5", device: "Chrome OS Laptop", location: "Zurich, Switzerland", status: "SUCCESS" },
            { timestamp: "2026-08-25 09:15:30", ip: "201.88.102.5", device: "Mobile App Trigger", location: "Zurich, Switzerland", status: "SUCCESS" },
            { timestamp: "2026-08-24 22:11:04", ip: "201.88.102.5", device: "Chrome OS Laptop", location: "Zurich, Switzerland", status: "FAILED" }
          ],
          activities: [
            { timestamp: "2026-07-20 11:30:00", action: "INITIAL_LOGIN", details: "Authenticated via Email & Telegram Bot." },
            { timestamp: "2026-07-22 18:22:00", action: "ORDER_EXECUTED", details: "Executed BTC/USDT Long Position via HFT Engine." },
          ],
        },
      ],
    users: {
      "admin": { id: "USR-001", username: "admin", role: "Admin", isActive: true, token: "mbot-session-token-admin", password: "admin", mustChangePassword: false }
    },
    vault: {
      "USR-001": {
        "Binance": { apiKey: "", apiSecret: "" },
        "KuCoin": { apiKey: "", apiSecret: "", apiPassphrase: "" },
        "OKX": { apiKey: "", apiSecret: "", apiPassphrase: "" },
        "Bybit": { apiKey: "", apiSecret: "" },
        "Telegram": { apiKey: "", apiSecret: "" }
      }
    },
    portfolios: {
      "USR-001": {
        net_worth: 0.0,
        balance_usdt: 0.0,
        locked_margin: 0.0,
        unrealized_pnl: 0.0,
        win_rate: 0.0,
        total_trades: 0,
        wins: 0,
        losses: 0
      }
    },
    engines: {
      "USR-001": {
        "ENG-001": {
          engine_id: "ENG-001",
          display_name: "Quant Alpha",
          nickname: "RIGEL (LAM000R)",
          subtitle: "Manual Scalper Engine",
          theme: "rigel",
          status: "Stopped",
          uptime_seconds: 0,
          current_stage_idx: 0,
          latency_ms: 12,
          cpu_load: 0,
          memory_mb: 18,
          strategy: "FAST SCALPER",
          asset: "BTCUSDT",
          amount: 0,
          runtime_hours: 0,
          last_tick: Date.now()
        },
        "ENG-002": {
          engine_id: "ENG-002",
          display_name: "Market Hunter",
          nickname: "SIRIUS (L000L)",
          subtitle: "Full Auto Swarm Engine (AI)",
          theme: "sirius",
          status: "Stopped",
          uptime_seconds: 0,
          current_stage_idx: 0,
          latency_ms: 18,
          cpu_load: 0,
          memory_mb: 24,
          strategy: "AI SWARMconsensus",
          asset: "ETHUSDT",
          amount: 0,
          runtime_hours: 0,
          last_tick: Date.now()
        },
        "ENG-003": {
          engine_id: "ENG-003",
          display_name: "Trend Intelligence",
          nickname: "CANOPUS (OOOKA)",
          subtitle: "Hybrid Margin Balancer",
          theme: "canopus",
          status: "Stopped",
          uptime_seconds: 0,
          current_stage_idx: 0,
          latency_ms: 14,
          cpu_load: 0,
          memory_mb: 20,
          strategy: "TREND BALANCER",
          asset: "SOLUSDT",
          amount: 0,
          runtime_hours: 0,
          last_tick: Date.now()
        },
        "ENG-004": {
          engine_id: "ENG-004",
          display_name: "Arbitrage Swarm",
          nickname: "Gemini",
          subtitle: "Statistical Arbitrage Core",
          theme: "gemini",
          status: "Stopped",
          uptime_seconds: 0,
          current_stage_idx: 0,
          latency_ms: 8,
          cpu_load: 0,
          memory_mb: 15,
          strategy: "STAT ARBITRAGE",
          asset: "BNBUSDT",
          amount: 0,
          runtime_hours: 0,
          last_tick: Date.now()
        },
        "ENG-005": {
          engine_id: "ENG-005",
          display_name: "Shariah Guard",
          nickname: "Halal",
          subtitle: "Islamic Compliance Auditor",
          theme: "halal",
          status: "Stopped",
          uptime_seconds: 0,
          current_stage_idx: 0,
          latency_ms: 10,
          cpu_load: 0,
          memory_mb: 16,
          strategy: "CONSERVATIVE COMPLIANT",
          asset: "ADAUSDT",
          amount: 0,
          runtime_hours: 0,
          last_tick: Date.now()
        }
      }
    },
    strategies: {
      "USR-001": [
        {
          id: "STR-001",
          strategy_name: "FAST SCALPER",
          status: "Draft",
          version: 1,
          config: { ema_fast: 20, ema_slow: 50, stop_loss: 2.5, leverage: 1, revision: 1 },
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        }
      ]
    },
    positions: {
      "USR-001": []
    },
    audit_logs: {
      "USR-001": [
        {
          id: "AUD-001",
          timestamp: new Date().toISOString(),
          action: "SYSTEM_INITIALIZATION",
          status: "SUCCESS",
          details: "MemoBot FX-Pro Core Platform initialized in secure zero-state.",
          correlation_id: "CID-INIT-001",
          integrity_hash: "INTEGRITY-VERIFIED"
        }
      ]
    },
    compliance_mode: {
      "USR-001": "Islamic"
    },
    execution_mode: {
      "USR-001": "Paper"
    },
    live_mode_confirmed: {
      "USR-001": false
    },
    trades: {
      "USR-001": []
    },
    risk_settings: {
      "USR-001": {
        max_daily_drawdown_pct: 25,
        max_position_size_usdt: 1000,
        default_stop_loss_pct: 1.5,
        default_take_profit_pct: 1.0,
        stealth_mode: true,
        auto_kill_switch_enabled: true,
        shariah_guard_enabled: true
      }
    },
    decisions: {
      "USR-001": []
    },
    circuit_breaker_active: {
      "USR-001": false
    },
    gifts: {
      "USR-001": [
        {
          id: "GFT-0921",
          timestamp: "2026-08-15T10:30:00.000Z",
          amount_usdt: 25.0,
          currency: "USDT",
          message: "Thank you MemoBot for the amazing results! Supporting the inclusive mission.",
          recipient: "Senior Trader Shield Fund",
          type: "ONE_TIME",
          status: "SUCCESS"
        },
        {
          id: "GFT-0834",
          timestamp: "2026-08-10T14:45:00.000Z",
          amount_usdt: 12.5,
          currency: "USDT",
          message: "Auto profit-share from 85% ROI SOL trade.",
          recipient: "Universal Inclusion Fund",
          type: "PROFIT_SHARE",
          status: "SUCCESS"
        }
      ]
    },
    gift_settings: {
      "USR-001": {
        auto_gifting_enabled: false,
        auto_gift_percentage: 2.5,
        preferred_recipient: "Universal Inclusion Fund"
      }
    },
    trial_invitations: [
      {
        id: "MB-TRIAL-8A2F9",
        recipientName: "Hamad Al-Mansoori",
        recipientContact: "hamad.mansoori@gmail.com",
        duration: "3days",
        createdAt: "2026-08-26 12:00:00",
        expiresAt: "2026-08-29 12:00:00",
        status: "ACTIVE",
        invitedBy: "admin"
      },
      {
        id: "MB-TRIAL-1C5D2",
        recipientName: "Zoe Dubois",
        recipientContact: "+33 6 1234 5678",
        duration: "24hrs",
        createdAt: "2026-08-25 10:30:00",
        expiresAt: "2026-08-26 10:30:00",
        status: "EXPIRED",
        invitedBy: "admin"
      }
    ]
  };
}

export let db: DBState = getInitialDBState();

export function loadDB() {
  try {
    if (fs.existsSync(DB_PATH)) {
      const raw = fs.readFileSync(DB_PATH, "utf8");
      db = JSON.parse(raw);
      if (!db.trades || !db.portfolios || db.portfolios["USR-001"]?.net_worth === 0) {
        db = getInitialDBState();
        saveDB();
      } else {
        let dirty = false;
        if (!db.vip_users) {
          db.vip_users = getInitialDBState().vip_users;
          dirty = true;
        }
        if (!db.trial_invitations) {
          db.trial_invitations = getInitialDBState().trial_invitations;
          dirty = true;
        }
        if (dirty) {
          saveDB();
        }
      }
    } else {
      saveDB();
    }
  } catch (err) {
    console.error("Failed to load local DB state, using default:", err);
  }
}

export function saveDB() {
  try {
    fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2), "utf8");
  } catch (err) {
    console.error("Failed to write local DB state:", err);
  }
}
