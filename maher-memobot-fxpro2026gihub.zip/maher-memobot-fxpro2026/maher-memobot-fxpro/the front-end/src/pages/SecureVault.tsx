import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ApiClient } from "../services/api";
import { useVaultSecureLayer } from "../hooks/useVaultSecureLayer";
import { VaultSecurityBar } from "../components/vault/VaultSecurityBar";
import { VaultStealthCover } from "../components/vault/VaultStealthCover";
import { VaultCredentialsCard, ServiceCredentialConfig } from "../components/vault/VaultCredentialsCard";
import { VaultEndpointsMatrix, EndpointTest } from "../components/vault/VaultEndpointsMatrix";
import { PageLoader } from "../components/PageLoader";
import { Radio, RefreshCw, Play, Shield, Terminal, Zap } from "lucide-react";

interface TestResult {
  status: "idle" | "testing" | "success" | "error";
  message?: string;
  latency_ms?: number;
  timestamp?: string;
}

export const SecureVault: React.FC = () => {
  const {
    config,
    isLocked,
    forms,
    updateFormInput,
    lockVault,
    unlockVault,
    refreshConfig,
  } = useVaultSecureLayer();

  const [vaultStatus, setVaultStatus] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [savingStates, setSavingStates] = useState<Record<string, boolean>>({});
  const [saveMessages, setSaveMessages] = useState<Record<string, { type: "success" | "error"; text: string } | null>>({});
  const [testResults, setTestResults] = useState<Record<string, TestResult>>({
    Binance: { status: "idle" },
    Binance_Slot2: { status: "idle" },
    Binance_Slot3: { status: "idle" },
    Binance_Slot4: { status: "idle" },
    KuCoin: { status: "idle" },
    KuCoin_Slot2: { status: "idle" },
    KuCoin_Slot3: { status: "idle" },
    KuCoin_Slot4: { status: "idle" },
    OKX: { status: "idle" },
    OKX_Slot2: { status: "idle" },
    OKX_Slot3: { status: "idle" },
    OKX_Slot4: { status: "idle" },
    Bybit: { status: "idle" },
    Bybit_Slot2: { status: "idle" },
    Bybit_Slot3: { status: "idle" },
    Bybit_Slot4: { status: "idle" },
    Telegram: { status: "idle" },
    WhatsApp: { status: "idle" },
    Gemini: { status: "idle" },
    OpenAI: { status: "idle" },
    Anthropic: { status: "idle" },
    DeepSeek: { status: "idle" },
  });
  const [isBatchTesting, setIsBatchTesting] = useState(false);

  const [activeSlots, setActiveSlots] = useState<Record<string, number>>({
    Binance: 1,
    KuCoin: 1,
    OKX: 1,
    Bybit: 1,
  });

  const [unlockedSlots, setUnlockedSlots] = useState<Record<string, number[]>>({
    Binance: [1],
    KuCoin: [1],
    OKX: [1],
    Bybit: [1],
  });

  const getServiceIdForSlot = (baseId: string, slot: number) => {
    return slot === 1 ? baseId : `${baseId}_Slot${slot}`;
  };

  // Automatically read and unlock configured slots on status load
  useEffect(() => {
    if (vaultStatus) {
      const updatedUnlocked = { ...unlockedSlots };
      ["Binance", "KuCoin", "OKX", "Bybit"].forEach((exch) => {
        const slots = [1];
        if (vaultStatus[`${exch}_Slot2` as any]) slots.push(2);
        if (vaultStatus[`${exch}_Slot3` as any]) slots.push(3);
        if (vaultStatus[`${exch}_Slot4` as any]) slots.push(4);
        updatedUnlocked[exch] = slots;
      });
      setUnlockedSlots(updatedUnlocked);
    }
  }, [vaultStatus]);

  const handleAddSlot = (exch: string) => {
    const current = unlockedSlots[exch] || [1];
    if (current.length < 4) {
      const nextSlot = current.length + 1;
      setUnlockedSlots((prev) => ({
        ...prev,
        [exch]: [...current, nextSlot],
      }));
      setActiveSlots((prev) => ({
        ...prev,
        [exch]: nextSlot,
      }));
    }
  };

  const [endpointTests, setEndpointTests] = useState<EndpointTest[]>([
    { id: "ep-vault", name: "Secrets Vault Status", method: "GET", path: "/vault/status", status: "idle" },
    { id: "ep-balances", name: "Account Balances & Net Worth", method: "GET", path: "/execution/balances", status: "idle" },
    { id: "ep-engine", name: "Trading Engine Status", method: "GET", path: "/engine/status", status: "idle" },
    { id: "ep-stats", name: "Daily PnL & Margin Stats", method: "GET", path: "/execution/daily-stats", status: "idle" },
    { id: "ep-prices", name: "Live Market Ticker Prices", method: "GET", path: "/market/prices", status: "idle" },
    { id: "ep-logs", name: "Audit Observability Logs", method: "GET", path: "/observability/logs", status: "idle" },
    { id: "ep-ai", name: "Gemini AI Copilot Chat", method: "POST", path: "/ai/chat", payload: { message: "Test API latency ping" }, status: "idle" },
    { id: "ep-orders", name: "Active Orders List", method: "GET", path: "/orders", status: "idle" },
  ]);

  const fetchVaultStatus = async () => {
    try {
      const data = await ApiClient.get("/vault/status");
      setVaultStatus(data);
      setLoading(false);
    } catch (err) {
      console.error("Failed to fetch vault status:", err);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchVaultStatus();
  }, []);

  const handleSave = async (service: string) => {
    const creds = forms[service] || { api_key: "", api_secret: "", api_passphrase: "" };
    const keyToSave = creds.api_key.trim();
    const secretToSave = creds.api_secret.trim();
    const passphraseToSave = creds.api_passphrase?.trim();

    if (!keyToSave && !secretToSave) {
      setSaveMessages((prev) => ({
        ...prev,
        [service]: { type: "error", text: "Please enter an API Key or Secret before saving." },
      }));
      return;
    }

    setSavingStates((prev) => ({ ...prev, [service]: true }));
    setSaveMessages((prev) => ({ ...prev, [service]: null }));

    try {
      await ApiClient.post("/vault/credentials", {
        service,
        api_key: keyToSave || undefined,
        api_secret: secretToSave || undefined,
        api_passphrase: passphraseToSave || undefined,
      });

      setSaveMessages((prev) => ({
        ...prev,
        [service]: { type: "success", text: `Credentials saved and encrypted securely for ${service}.` },
      }));

      await fetchVaultStatus();
    } catch (err: any) {
      setSaveMessages((prev) => ({
        ...prev,
        [service]: { type: "error", text: `Save failed: ${err.message || "Server error"}` },
      }));
    } finally {
      setSavingStates((prev) => ({ ...prev, [service]: false }));
    }
  };

  const handleTestConnection = async (service: string) => {
    const creds = forms[service] || { api_key: "", api_secret: "", api_passphrase: "" };
    setTestResults((prev) => ({ ...prev, [service]: { status: "testing" } }));
    const startTime = Date.now();
    try {
      const resp = await ApiClient.post("/vault/test-connection", {
        service,
        api_key: creds.api_key.trim() || undefined,
        api_secret: creds.api_secret.trim() || undefined,
        api_passphrase: creds.api_passphrase?.trim() || undefined,
      });
      const elapsed = Date.now() - startTime;
      setTestResults((prev) => ({
        ...prev,
        [service]: {
          status: "success",
          message: resp.message || `${service} API verified successfully.`,
          latency_ms: resp.latency_ms || elapsed,
          timestamp: new Date().toLocaleTimeString(),
        },
      }));
    } catch (err: any) {
      const elapsed = Date.now() - startTime;
      setTestResults((prev) => ({
        ...prev,
        [service]: {
          status: "error",
          message: err.message || `Failed connection test for ${service}.`,
          latency_ms: elapsed,
          timestamp: new Date().toLocaleTimeString(),
        },
      }));
    }
  };

  const handleTestAllVaultEntries = async () => {
    setIsBatchTesting(true);
    const servicesToTest: string[] = [];
    
    // Test all unlocked slots for exchanges
    ["Binance", "KuCoin", "OKX", "Bybit"].forEach((exch) => {
      const slots = unlockedSlots[exch] || [1];
      slots.forEach((slot) => {
        servicesToTest.push(getServiceIdForSlot(exch, slot));
      });
    });

    // Test notification & AI models
    servicesToTest.push("Telegram", "WhatsApp", "Gemini", "OpenAI", "Anthropic", "DeepSeek");

    for (const service of servicesToTest) {
      await handleTestConnection(service);
    }
    setIsBatchTesting(false);
  };

  const handleTestSingleEndpoint = async (epId: string) => {
    const targetEp = endpointTests.find((e) => e.id === epId);
    if (!targetEp) return;

    setEndpointTests((prev) => prev.map((ep) => (ep.id === epId ? { ...ep, status: "testing" } : ep)));
    const startTime = Date.now();

    try {
      let resData: any;
      if (targetEp.method === "POST") {
        resData = await ApiClient.post(targetEp.path, targetEp.payload || {});
      } else {
        resData = await ApiClient.get(targetEp.path);
      }
      const elapsed = Date.now() - startTime;

      setEndpointTests((prev) =>
        prev.map((ep) => (ep.id === epId ? { ...ep, status: "success", httpCode: 200, latency_ms: elapsed, response: resData } : ep))
      );
    } catch (err: any) {
      const elapsed = Date.now() - startTime;
      setEndpointTests((prev) =>
        prev.map((ep) =>
          ep.id === epId ? { ...ep, status: "error", httpCode: err.status || 500, latency_ms: elapsed, response: { error: err.message || "Request failed" } } : ep
        )
      );
    }
  };

  const handleTestAllSystemEndpoints = async () => {
    for (const ep of endpointTests) {
      await handleTestSingleEndpoint(ep.id);
    }
  };

  if (loading) {
    return <PageLoader message="DECRYPTING SECURE CREDENTIAL LAYERS..." subMessage="Unlocking AES-256 GCM Hardware Keystores" />;
  }

  const credentialsList: ServiceCredentialConfig[] = [
    { id: "Binance", label: "Binance Exchange", fields: ["API KEY", "SECRET KEY"], help: "Required for mainnet live order routing and wallet balance checks." },
    { id: "KuCoin", label: "KuCoin Exchange", fields: ["API KEY", "SECRET KEY", "PASSPHRASE"], help: "Required for KuCoin live trading bot routing and balance auditing." },
    { id: "OKX", label: "OKX Exchange", fields: ["API KEY", "SECRET KEY", "PASSPHRASE"], help: "Required for OKX high-frequency automated trade executions." },
    { id: "Bybit", label: "Bybit Exchange", fields: ["API KEY", "SECRET KEY"], help: "Required for Bybit Unified Trading Account (UTA) order management." },
    { id: "Telegram", label: "Telegram Bot", fields: ["BOT TOKEN", "CHAT ID"], help: "Asynchronous bilateral notification outbox & trading alerts." },
    { id: "WhatsApp", label: "WhatsApp Meta Cloud", fields: ["ACCESS TOKEN", "PHONE ID"], help: "Decoupled outbox notification channel for critical position alerts." },
    { id: "Gemini", label: "Google Gemini AI", fields: ["API KEY"], help: "Conversational co-pilot models and AI strategy analysis access." },
    { id: "OpenAI", label: "OpenAI GPT-4o API", fields: ["API KEY"], help: "Required for GPT-4o autonomous market analysis, trading signals, and multi-agent consensus." },
    { id: "Anthropic", label: "Anthropic Claude API", fields: ["API KEY"], help: "Required for Claude 3.5 Sonnet to enable deep strategy auditing and advanced code execution analysis." },
    { id: "DeepSeek", label: "DeepSeek AI API", fields: ["API KEY"], help: "Required for DeepSeek-R1 deep-thinking logical deduction and mathematical validation." },
  ];

  return (
    <div id="secure-vault-container" className="flex-1 bg-[#06070a] p-6 overflow-y-auto space-y-6 text-xs text-[#8a8d9a] font-mono">
      {/* Page Header */}
      <div className="flex flex-col xl:flex-row justify-between items-start xl:items-center gap-4 border-b border-[#FA1F4E]/20 pb-4 shrink-0">
        <div>
          <h2 className="text-2xl font-aquire text-[#FA1F4E] tracking-tighter drop-shadow-[0_0_15px_rgba(250,31,78,0.2)] uppercase flex items-center gap-1">
            MEMOBOT VAULT
            <span className="text-xs font-mono text-white font-extrabold -mt-2">™</span>
            <span className="ml-1">& API DIAGNOSTICS</span>
          </h2>
          <p className="font-sans text-[13px] text-[#8a8d9a] mt-1">
            Manage and test all exchange APIs, notification credentials, and system endpoints in real time.
          </p>
        </div>

        <button
          onClick={handleTestAllVaultEntries}
          disabled={isBatchTesting || isLocked}
          className="px-4 py-2 bg-[#3b82f6]/10 border border-[#3b82f6] text-[#3b82f6] hover:bg-[#3b82f6] hover:text-white rounded text-[10px] font-extrabold uppercase transition-all flex items-center gap-2 shrink-0 disabled:opacity-40"
        >
          {isBatchTesting ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5" />}
          {isBatchTesting ? "TESTING ALL ENTRIES..." : "TEST ALL API ENTRIES"}
        </button>
      </div>

      {/* Reframed Hero Manifesto Card (Attachment Location & Styling) */}
      <div className="bg-[#0b0d12] border border-[#FA1F4E]/30 p-4 rounded-lg shadow-[0_0_20px_rgba(250,31,78,0.1)] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-[#FA1F4E]/15 border border-[#FA1F4E]/40 rounded-lg text-[#FA1F4E] shrink-0">
            <Radio className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-white font-extrabold uppercase tracking-widest text-[11px] font-mono">
                SYSTEM AUDITING & FREEDOM MATRIX
              </span>
              <span className="px-2 py-0.5 bg-[#00f2ff]/10 border border-[#00f2ff]/40 text-[#00f2ff] text-[8.5px] font-mono font-extrabold rounded uppercase">
                OPERATIONAL MANIFESTO
              </span>
            </div>
            <p className="text-[12px] font-mono text-[#00f2ff] font-extrabold mt-1 tracking-wide uppercase drop-shadow-[0_0_10px_rgba(0,242,255,0.3)]">
              MAIN POLICY: LIFE IS SIMPLE. SECURITY MEANS PERSONAL FREEDOM, NOT FORCING LOCKS OR RESTRICTIONS ON YOU!
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
          <div className="px-3 py-1.5 bg-[#06070a] border border-[#1a1d28] rounded font-mono text-[9.5px] text-[#8a8d9a] flex items-center gap-1.5">
            <Shield className="w-3.5 h-3.5 text-[#00e676]" />
            <span>USER-CONTROLLED MATRIX</span>
          </div>
        </div>
      </div>

      {/* Vault Freedom & Stealth Security Control Bar */}
      <VaultSecurityBar
        isLocked={isLocked}
        onLock={lockVault}
        onConfigChange={refreshConfig}
      />

      {/* Smooth CSS/Motion folding/fading transition container */}
      <AnimatePresence mode="wait">
        {isLocked ? (
          <motion.div
            key="stealth-cover"
            initial={{ opacity: 0, scaleY: 0.85, rotateX: -15, transformOrigin: "top" }}
            animate={{ opacity: 1, scaleY: 1, rotateX: 0 }}
            exit={{ opacity: 0, scaleY: 0.85, rotateX: 15 }}
            transition={{ duration: 0.35, ease: "easeInOut" }}
          >
            <VaultStealthCover
              decoyTheme={config.decoyTheme}
              onUnlockSuccess={(pass) => unlockVault(pass)}
            />
          </motion.div>
        ) : (
          <motion.div
            key="unlocked-content"
            initial={{ opacity: 0, scale: 0.98, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scaleY: 0.85, rotateX: -15, transformOrigin: "top" }}
            transition={{ duration: 0.35, ease: "easeInOut" }}
            className="space-y-6"
          >
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              {/* Credentials cards (lg:span-8) */}
              <div className="lg:col-span-8 space-y-4">
                {credentialsList.map((service) => {
                  const isExch = ["Binance", "KuCoin", "OKX", "Bybit"].includes(service.id);
                  const activeSlot = activeSlots[service.id] || 1;
                  const serviceIdForSlot = isExch ? getServiceIdForSlot(service.id, activeSlot) : service.id;
                  
                  const isConfigured = vaultStatus?.[serviceIdForSlot] || vaultStatus?.[serviceIdForSlot.toLowerCase()] || false;
                  
                  // Track configured status for all slots of this exchange
                  const slotConfiguredStates: Record<number, boolean> = {};
                  if (isExch) {
                    [1, 2, 3, 4].forEach(slotNum => {
                      const sid = getServiceIdForSlot(service.id, slotNum);
                      slotConfiguredStates[slotNum] = !!(vaultStatus?.[sid] || vaultStatus?.[sid.toLowerCase()]);
                    });
                  }

                  return (
                    <VaultCredentialsCard
                      key={service.id}
                      service={service}
                      isConfigured={isConfigured}
                      formValues={forms[serviceIdForSlot] || { api_key: "", api_secret: "" }}
                      onInputChange={(field, val) => updateFormInput(serviceIdForSlot, field, val)}
                      onSave={() => handleSave(serviceIdForSlot)}
                      onTest={() => handleTestConnection(serviceIdForSlot)}
                      isSaving={savingStates[serviceIdForSlot]}
                      testResult={testResults[serviceIdForSlot]}
                      saveMessage={saveMessages[serviceIdForSlot]}
                      // Slots support
                      isExchange={isExch}
                      activeSlot={activeSlot}
                      unlockedSlots={unlockedSlots[service.id] || [1]}
                      onSelectSlot={(slot) => setActiveSlots(prev => ({ ...prev, [service.id]: slot }))}
                      onAddSlot={() => handleAddSlot(service.id)}
                      slotConfiguredStates={slotConfiguredStates}
                    />
                  );
                })}
              </div>

              {/* Security Diagnostics Sidebar (lg:span-4) */}
              <div className="lg:col-span-4 bg-[#0d0e12] border border-[#1a1d26] p-5 rounded space-y-4">
                <div className="flex items-center gap-2 text-[#FA1F4E] font-bold border-b border-[#11131c] pb-2 uppercase text-[10px]">
                  <Terminal className="w-4 h-4 text-[#00f2ff]" />
                  SECURE LAYER STATE TELEMETRY
                </div>

                <div className="space-y-3 leading-relaxed text-[10px]">
                  <div className="p-3 bg-[#06070a] border border-[#1a1d26] rounded text-[#00f2ff] font-bold text-[9px] uppercase space-y-1.5">
                    <div className="flex justify-between items-center">
                      <span className="text-[#8a8d9a]">SECURE LAYER HOOK:</span>
                      <span className="text-[#00e676]">ACTIVE</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-[#8a8d9a]">RAM INPUT PURGE:</span>
                      <span className="text-[#00e676]">AUTO ON UNLOAD</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-[#8a8d9a]">STEALTH TRANSITION:</span>
                      <span className="text-[#00f2ff]">3D FOLD / FADE</span>
                    </div>
                  </div>

                  <p className="text-[#8a8d9a]">
                    When locked or navigated away, sensitive memory buffers are completely wiped from state and DOM to guarantee maximum key privacy.
                  </p>
                </div>

                {/* AI Copilot Suggestions Panel */}
                <div className="mt-4 pt-4 border-t border-[#11131c] space-y-3">
                  <div className="flex items-center gap-2 text-[#00f2ff] font-bold uppercase text-[10px]">
                    <Zap className="w-4 h-4 text-[#f59e0b]" />
                    AI CO-PILOT DECK RECOMMENDATIONS
                  </div>
                  <p className="text-[10px] text-[#8a8d9a] leading-normal uppercase">
                    TO PROTECT YOUR DECISIONS AGAINST SINGLE-MODEL BIAS, WE RECOMMEND CONFIGURING 3 ELITE REASONING AI ENGINES IN CONJUNCTION WITH GEMINI:
                  </p>
                  
                  <div className="space-y-2 text-[9.5px]">
                    <div className="p-2.5 bg-[#1a1d26]/40 border border-[#1a1d26] rounded space-y-1">
                      <div className="flex justify-between items-center">
                        <span className="text-[#f59e0b] font-bold">1. OpenAI GPT-4o</span>
                        <span className="text-[#8a8d9a] text-[8px] bg-black/40 px-1 py-0.2 rounded border border-[#1a1d26]">REAL-TIME</span>
                      </div>
                      <p className="text-[#8a8d9a] leading-relaxed">
                        Industry-standard for low-latency news parsing, multilingual audit reporting, and rapid signal extraction.
                      </p>
                    </div>

                    <div className="p-2.5 bg-[#1a1d26]/40 border border-[#1a1d26] rounded space-y-1">
                      <div className="flex justify-between items-center">
                        <span className="text-[#a855f7] font-bold">2. Anthropic Claude 3.5</span>
                        <span className="text-[#8a8d9a] text-[8px] bg-black/40 px-1 py-0.2 rounded border border-[#1a1d26]">STRATEGY</span>
                      </div>
                      <p className="text-[#8a8d9a] leading-relaxed">
                        Unmatched logical reasoning for strategy verification, strict rule-compliance checking, and advanced code executions.
                      </p>
                    </div>

                    <div className="p-2.5 bg-[#1a1d26]/40 border border-[#1a1d26] rounded space-y-1">
                      <div className="flex justify-between items-center">
                        <span className="text-[#00e676] font-bold">3. DeepSeek-R1 / V3</span>
                        <span className="text-[#8a8d9a] text-[8px] bg-black/40 px-1 py-0.2 rounded border border-[#1a1d26]">DEEP THINK</span>
                      </div>
                      <p className="text-[#8a8d9a] leading-relaxed">
                        Extremely fast, open-weights reasoning model for high-frequency mathematical evaluations and strict trade-log validation.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Endpoints Diagnostic Matrix */}
            <VaultEndpointsMatrix
              endpointTests={endpointTests}
              onTestSingle={handleTestSingleEndpoint}
              onTestAll={handleTestAllSystemEndpoints}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default SecureVault;
