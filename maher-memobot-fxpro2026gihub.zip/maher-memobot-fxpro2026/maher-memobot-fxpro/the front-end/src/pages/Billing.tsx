import React from "react";
import { CreditCard, Zap, CheckCircle2, Package, Clock, BarChart3 } from "lucide-react";

export const Billing: React.FC = () => {
  const currentPlan = {
    name: "Proprietary Institutional",
    status: "ACTIVE",
    renewal: "2026-08-22",
    features: [
      "Unlimited Engine Execution",
      "Priority HFT WebSocket Gateway",
      "Shariah Compliance Auditor Pro",
      "Full AI Co-Pilot Suite",
      "Multi-Exchange Connectivity"
    ]
  };

  const fees = [
    { id: "INV-0842", date: "2026-07-20", type: "SUCCESS_FEE", amount: 145.20, status: "PAID" },
    { id: "INV-0721", date: "2026-07-01", type: "SUBSCRIPTION", amount: 499.00, status: "PAID" },
    { id: "INV-0615", date: "2026-06-20", type: "SUCCESS_FEE", amount: 88.50, status: "PAID" },
  ];

  return (
    <div className="flex-1 bg-[#06070a] p-6 overflow-y-auto space-y-6 font-mono text-xs text-[#8a8d9a]">
      {/* Page Header */}
      <div className="flex flex-col xl:flex-row justify-between items-start xl:items-center gap-4 border-b border-[#FA1F4E]/20 pb-4 shrink-0">
        <div>
          <h2 className="text-2xl font-aquire text-[#FA1F4E] tracking-tighter drop-shadow-[0_0_15px_rgba(250,31,78,0.2)] uppercase">SUBSCRIPTION & SUCCESS FEES</h2>
          <p className="font-sans text-[13px] text-[#8a8d9a] mt-1 uppercase">
            Institutional billing management, performance-based fee tracking, and license orchestration.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Active Plan Card */}
        <div className="lg:col-span-1 bg-[#0d0e12] border border-[#1a1d26] p-5 rounded space-y-4">
          <div className="flex items-center gap-2 border-b border-[#11131c] pb-2">
            <Package className="w-4 h-4 text-[#FA1F4E]" />
            <span className="text-xs text-[#FA1F4E] font-bold uppercase tracking-wider">ACTIVE LICENSE PLAN</span>
          </div>

          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="font-bold text-white text-sm">{currentPlan.name}</span>
              <span className="bg-[rgba(0,230,118,0.15)] text-[#00e676] px-2 py-0.5 rounded text-[10px] font-bold border border-[#00e676]">
                {currentPlan.status}
              </span>
            </div>
            
            <div className="bg-[#06070a] p-3 rounded border border-[#1a1d26] space-y-2">
              <div className="flex justify-between text-[10px]">
                <span>NEXT RENEWAL:</span>
                <span className="text-white font-bold">{currentPlan.renewal}</span>
              </div>
              <div className="flex justify-between text-[10px]">
                <span>BILLING CYCLE:</span>
                <span className="text-white">MONTHLY (INSTITUTIONAL)</span>
              </div>
            </div>

            <div className="space-y-1.5">
              <span className="text-[10px] font-bold text-[#FA1F4E] block uppercase">INCLUDED CAPABILITIES:</span>
              {currentPlan.features.map((f, i) => (
                <div key={i} className="flex items-center gap-2 text-[10px]">
                  <CheckCircle2 className="w-3 h-3 text-[#00e676]" />
                  <span>{f}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Success Fee / Invoices Table */}
        <div className="lg:col-span-2 bg-[#0d0e12] border border-[#1a1d26] rounded overflow-hidden flex flex-col h-full">
          <div className="bg-[#090a0d] px-4 py-3 border-b border-[#11131c] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-[#FA1F4E]" />
              <span className="text-[10px] text-[#FA1F4E] font-mono font-bold tracking-wider uppercase">
                INVOICE & PERFORMANCE FEE LEDGER
              </span>
            </div>
            <button className="text-[9px] text-[#3b82f6] hover:underline font-bold uppercase">
              EXPORT DATA (.CSV)
            </button>
          </div>
          
          <div className="flex-1 overflow-y-auto">
            <table className="w-full text-left border-collapse text-[10px]">
              <thead>
                <tr className="border-b border-[#11131c] text-[#8a8d9a] uppercase bg-[#06070a]">
                  <th className="py-2.5 px-4 font-semibold">INVOICE ID</th>
                  <th className="py-2.5 px-4 font-semibold">DATE</th>
                  <th className="py-2.5 px-4 font-semibold">FEE TYPE</th>
                  <th className="py-2.5 px-4 font-semibold">AMOUNT (USDT)</th>
                  <th className="py-2.5 px-4 font-semibold">STATUS</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1a1d26]">
                {fees.map((fee) => (
                  <tr key={fee.id} className="hover:bg-[#12161f] transition-colors">
                    <td className="py-3 px-4 text-white font-bold">{fee.id}</td>
                    <td className="py-3 px-4">{fee.date}</td>
                    <td className="py-3 px-4">{fee.type}</td>
                    <td className="py-3 px-4 text-white font-bold">${fee.amount.toFixed(2)}</td>
                    <td className="py-3 px-4">
                      <span className="text-[#00e676] font-bold">{fee.status}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          
          <div className="bg-[#090a0d] p-4 border-t border-[#1a1d26] flex justify-between items-center">
            <div className="text-[10px] text-[#8a8d9a]">
              SUCCESS FEES ARE COMPUTED BASED ON NET NEW PNL AUDITED ON-CHAIN.
            </div>
            <button className="px-4 py-1.5 bg-[#3b82f6]/10 border border-[#3b82f6] text-[#3b82f6] hover:bg-[#3b82f6] hover:text-white rounded text-[10px] font-bold uppercase transition-all">
              UPDATE PAYMENT METHOD
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
export default Billing;
