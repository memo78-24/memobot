import React, { useState, useEffect } from "react";
import { CampaignCard } from "../components/social/CampaignCard";
import { ActivityQueueList } from "../components/social/ActivityQueueList";
import { SocialService } from "../services/socialService";
import { socialStore, SocialState } from "../services/socialStore";
import { useNotification } from "../components/NotificationProvider";
import { Activity, Target, Zap, Plus, ShieldCheck, Play, Pause, Globe, ArrowRight, Image } from "lucide-react";
import { SocialCampaign } from "../types";

export const SocialManager: React.FC = () => {
  const [storeState, setStoreState] = useState<SocialState>(socialStore.getState());
  const { showAlert } = useNotification();

  // Selected campaign for outbound generation
  const [selectedCampaign, setSelectedCampaign] = useState<SocialCampaign | null>(null);
  const [customContext, setCustomContext] = useState("");
  const [generatedContent, setGeneratedContent] = useState("");
  const [generating, setGenerating] = useState(false);
  const [includePic, setIncludePic] = useState(false);

  // New Campaign Form States
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [newCampName, setNewCampName] = useState("");
  const [newCampPlatform, setNewCampPlatform] = useState<any>("Twitter/X");
  const [newCampType, setNewCampType] = useState<any>("Authority Thread");
  const [newCampAudience, setNewCampAudience] = useState("");

  useEffect(() => {
    SocialService.init();
    const unsubscribe = socialStore.subscribe((state) => {
      setStoreState(state);
    });
    return () => {
      unsubscribe();
      SocialService.destroy();
    };
  }, []);

  const handleCreateCampaign = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCampName || !newCampAudience) {
      showAlert("All fields are required to seed an organic campaign.");
      return;
    }
    try {
      await SocialService.createCampaign({
        name: newCampName,
        platform: newCampPlatform,
        type: newCampType,
        status: "Active",
        targetAudience: newCampAudience
      });
      setNewCampName("");
      setNewCampAudience("");
      setIsFormOpen(false);
      showAlert("Organic growth campaign successfully seeded.");
    } catch (err: any) {
      showAlert(`Seeding error: ${err.message}`);
    }
  };

  const handleGenerateOutbound = async () => {
    if (!selectedCampaign) {
      showAlert("Select a target campaign to guide the Community Advisor.");
      return;
    }
    setGenerating(true);
    setGeneratedContent("");
    try {
      const content = await SocialService.generateCampaignOutbound(selectedCampaign.id, customContext, includePic);
      setGeneratedContent(content);
      showAlert("Organic growth content resolved by Chief AI Growth Advisor.");
    } catch (err: any) {
      showAlert(`Outbound generation failed: ${err.message}`);
    } finally {
      setGenerating(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col p-4 overflow-y-auto space-y-4 select-none bg-[#06070a] text-slate-100 min-h-0">
      
      {/* 1. Header: Brand, Title, and State Toggles */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-900/80 pb-3">
        <div>
          <h2 className="text-sm font-aquire tracking-[0.2em] text-white flex items-center gap-2">
            <Globe className="w-4 h-4 text-rose-500 animate-spin" /> SOCIAL INTELLIGENCE SUITE
          </h2>
          <span className="text-[7.5px] font-mono text-[#22d3ee] tracking-widest uppercase">
            ORGANIC TRAFFIC BUILDER / DIRECT OUTBOUND APPROACH / CAMPAIGNS QUEUE
          </span>
        </div>

        {/* Daily activity running state toggle */}
        <div className="flex items-center gap-3">
          <span className="text-[7.5px] font-mono text-slate-400 font-bold uppercase tracking-widest">
            DAILY OUTBOUND RUNNER
          </span>
          <button
            onClick={() => SocialService.toggleDailyRunning(!storeState.runningDaily)}
            className={`px-3 py-1.5 rounded font-mono text-[9px] font-black uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer border ${
              storeState.runningDaily
                ? "border-emerald-500/40 text-emerald-400 bg-emerald-950/20 hover:bg-emerald-900/20"
                : "border-amber-500/40 text-amber-400 bg-amber-950/20 hover:bg-amber-900/20"
            }`}
          >
            {storeState.runningDaily ? <Play className="w-2.5 h-2.5" /> : <Pause className="w-2.5 h-2.5" />}
            {storeState.runningDaily ? "RUNNING" : "PAUSED"}
          </button>
        </div>
      </div>

      {/* 2. Unified Status Indicators */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div className="bg-[#02050c]/90 border border-slate-900 p-3 flex items-center justify-between rounded-lg">
          <div>
            <span className="text-[7px] font-mono text-slate-500 block uppercase tracking-widest">TOTAL OUTBOUND APPROACHES</span>
            <h3 className="text-lg font-mono font-black text-slate-100 mt-1">{storeState.totalApproachesSent}</h3>
          </div>
          <Activity className="w-6 h-6 text-[#22d3ee] opacity-80" />
        </div>
        <div className="bg-[#02050c]/90 border border-slate-900 p-3 flex items-center justify-between rounded-lg">
          <div>
            <span className="text-[7px] font-mono text-slate-500 block uppercase tracking-widest">ORGANIC CONVERSION RATE</span>
            <h3 className="text-lg font-mono font-black text-rose-500 mt-1">{storeState.overallSuccessRate}%</h3>
          </div>
          <Target className="w-6 h-6 text-rose-500 opacity-80" />
        </div>
        <div className="bg-[#02050c]/90 border border-slate-900 p-3 flex items-center justify-between rounded-lg">
          <div>
            <span className="text-[7px] font-mono text-slate-500 block uppercase tracking-widest">ECOSYSTEM STREAK</span>
            <h3 className="text-lg font-mono font-black text-emerald-400 mt-1">100% ORGANIC</h3>
          </div>
          <ShieldCheck className="w-6 h-6 text-emerald-400 opacity-80 animate-pulse" />
        </div>
      </div>

      {/* 3. Main Dashboard Layout Section */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-4">
        
        {/* LEFT COLUMN: CAMPAIGNS (7 COLS) */}
        <div className="xl:col-span-7 flex flex-col space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-[11px] font-black tracking-widest text-[#22d3ee] uppercase">
              ACTIVE OUTBOUND CHANNELS
            </h3>
            
            <button
              onClick={() => setIsFormOpen(!isFormOpen)}
              className="px-2 py-1 bg-red-800 hover:bg-red-700 font-mono text-[8.5px] font-bold rounded uppercase tracking-wider transition-all flex items-center gap-1 cursor-pointer"
            >
              <Plus className="w-3 h-3" /> SEED NEW CAMPAIGN
            </button>
          </div>

          {/* New Campaign Creation Form Modal/Drop Block */}
          {isFormOpen && (
            <form onSubmit={handleCreateCampaign} className="bg-[#02050e] border border-slate-900 rounded-lg p-3 space-y-3">
              <h4 className="text-[10px] font-black text-slate-300 uppercase tracking-wider">GUIDE ORGANIC CHANNELS SEEDING</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-[6.5px] font-mono text-slate-500 block uppercase mb-1">Campaign Name</label>
                  <input
                    type="text"
                    value={newCampName}
                    onChange={(e) => setNewCampName(e.target.value)}
                    placeholder="e.g. Outbound Halal Capital"
                    className="w-full bg-black/60 border border-slate-800 focus:border-red-500/50 rounded px-2 py-1 text-[9px] font-mono outline-none text-white"
                  />
                </div>
                <div>
                  <label className="text-[6.5px] font-mono text-slate-500 block uppercase mb-1">Target Platform</label>
                  <select
                    value={newCampPlatform}
                    onChange={(e: any) => setNewCampPlatform(e.target.value)}
                    className="w-full bg-black/60 border border-slate-800 focus:border-red-500/50 rounded px-2 py-1 text-[9px] font-mono outline-none text-white animate-fade-in"
                  >
                    <option value="Twitter/X">Twitter/X</option>
                    <option value="LinkedIn">LinkedIn</option>
                    <option value="Reddit">Reddit</option>
                    <option value="Telegram">Telegram</option>
                    <option value="Discord">Discord</option>
                    <option value="WhatsApp">WhatsApp</option>
                    <option value="Email">Email Newsletter</option>
                    <option value="SMS">SMS Dispatch</option>
                    <option value="Instagram">Instagram Media</option>
                    <option value="TikTok">TikTok Video</option>
                    <option value="Facebook">Facebook Group</option>
                  </select>
                </div>
                <div>
                  <label className="text-[6.5px] font-mono text-slate-500 block uppercase mb-1">Approach Mode</label>
                  <select
                    value={newCampType}
                    onChange={(e: any) => setNewCampType(e.target.value)}
                    className="w-full bg-black/60 border border-slate-800 focus:border-red-500/50 rounded px-2 py-1 text-[9px] font-mono outline-none text-white"
                  >
                    <option value="Outbound DM">Direct Value DM</option>
                    <option value="Reddit Thread">Informative Post</option>
                    <option value="Authority Thread">Educational Thread</option>
                    <option value="LinkedIn Outreach">Institutional Message</option>
                    <option value="Value Comment">Value-First Comment</option>
                    <option value="Newsletter">Newsletter Broadcast</option>
                    <option value="Blast SMS">Blast SMS Alert</option>
                    <option value="Visual Post">Dynamic Photo/Graphic Post</option>
                    <option value="Video Script">Interactive Video/Reel Script</option>
                  </select>
                </div>
                <div>
                  <label className="text-[6.5px] font-mono text-slate-500 block uppercase mb-1">Target Audience Segment</label>
                  <input
                    type="text"
                    value={newCampAudience}
                    onChange={(e) => setNewCampAudience(e.target.value)}
                    placeholder="e.g. Professional prop firm traders"
                    className="w-full bg-black/60 border border-slate-800 focus:border-red-500/50 rounded px-2 py-1 text-[9px] font-mono outline-none text-white"
                  />
                </div>
              </div>
              <div className="flex justify-end gap-2 pt-2 border-t border-slate-900/60">
                <button
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  className="px-2 py-1 border border-slate-900 text-slate-500 font-mono text-[8px] uppercase tracking-wider rounded cursor-pointer"
                >
                  CANCEL
                </button>
                <button
                  type="submit"
                  className="px-3 py-1 bg-[#10b981] text-white font-mono text-[8px] font-black uppercase tracking-wider rounded cursor-pointer"
                >
                  ENGAGE OUTBOX
                </button>
              </div>
            </form>
          )}

          {/* Grid list of campaigns */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {storeState.campaigns.map((camp) => (
              <CampaignCard
                key={camp.id}
                campaign={camp}
                onSelect={(c) => {
                  setSelectedCampaign(c);
                  setGeneratedContent("");
                }}
                onToggle={(id) => SocialService.toggleCampaignStatus(id)}
                onDelete={(id) => SocialService.deleteCampaign(id)}
              />
            ))}
          </div>
        </div>

        {/* RIGHT COLUMN: AI GENERATOR & QUEUE (5 COLS) */}
        <div className="xl:col-span-5 flex flex-col space-y-4">
          
          {/* AI ADVISOR FORM BLOCK */}
          <div className="bg-[#02050c]/90 border border-slate-900 rounded-lg p-3 flex flex-col space-y-3 relative overflow-hidden">
            <h3 className="text-[11px] font-black tracking-widest text-[#22d3ee] uppercase">
              CHIEF AI SOCIAL ADVISOR
            </h3>
            
            {/* Guide selection */}
            <div>
              <span className="text-[6.5px] font-mono text-slate-500 uppercase tracking-widest block mb-1">Guided Campaign</span>
              {selectedCampaign ? (
                <div className="flex items-center justify-between bg-black/60 border border-slate-800 rounded px-2.5 py-1.5 text-[9px]">
                  <div>
                    <span className="text-white font-bold">{selectedCampaign.name}</span>
                    <span className="text-slate-500 ml-1.5 font-mono text-[7px]">[{selectedCampaign.platform} / {selectedCampaign.type}]</span>
                  </div>
                  <button
                    onClick={() => setSelectedCampaign(null)}
                    className="text-red-500 hover:text-red-400 font-bold font-mono text-[7px]"
                  >
                    DESELECT
                  </button>
                </div>
              ) : (
                <div className="bg-black/30 border border-dashed border-slate-900 rounded px-2.5 py-3 text-center text-slate-500 text-[8.5px] uppercase tracking-wider">
                  SELECT GENERATE OUTBOUND ON A CAMPAIGN LEFT TO GUIDE
                </div>
              )}
            </div>

            {/* Custom context box */}
            <div>
              <span className="text-[6.5px] font-mono text-[#ef4444] uppercase tracking-widest block mb-1">Dynamic Market Context (Optional)</span>
              <textarea
                value={customContext}
                onChange={(e) => setCustomContext(e.target.value)}
                placeholder="e.g. We just observed a BTC arbitrage spread of 0.05% between Binance/OKX executed under Islamic zero-riba spot rules."
                className="w-full h-12 bg-black/60 border border-slate-800 rounded p-1.5 text-[9px] font-mono outline-none text-white resize-none"
              />
            </div>

            {/* Dynamic visual picture attachment toggle */}
            <div className="flex items-center gap-2 p-1.5 bg-black/40 border border-slate-900 rounded">
              <input
                id="include-pic-checkbox"
                type="checkbox"
                checked={includePic}
                onChange={(e) => setIncludePic(e.target.checked)}
                className="w-3.5 h-3.5 text-red-500 border-slate-800 bg-black rounded focus:ring-0 cursor-pointer"
              />
              <label htmlFor="include-pic-checkbox" className="flex items-center gap-1.5 text-[8.5px] font-mono font-bold text-slate-300 uppercase tracking-wider cursor-pointer">
                <Image className="w-3.5 h-3.5 text-[#00ffcc]" /> GENERATE GRAPHIC / ATTACH PIC
              </label>
            </div>

            {/* Trigger generation */}
            <button
              onClick={handleGenerateOutbound}
              disabled={generating || !selectedCampaign}
              className={`w-full py-2 rounded-full font-sans text-[9px] font-black uppercase tracking-[0.15em] transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-md ${
                selectedCampaign && !generating
                  ? "bg-[#e11d48] text-white hover:bg-red-600 shadow-[0_3px_8px_rgba(225,29,72,0.25)]"
                  : "bg-slate-900/60 text-slate-600 border border-slate-950 cursor-not-allowed"
              }`}
            >
              <Zap className="w-3 h-3 text-yellow-400 animate-pulse" />
              {generating ? "DECODING SENTIMENT PROTOCOLS..." : "TRANSMIT COMMAND TO ADVISOR"}
            </button>

            {/* Generated output box */}
            {generatedContent && (
              <div className="border border-red-500/20 bg-black/90 p-2.5 rounded font-mono text-[8px] text-[#22d3ee] flex flex-col space-y-1.5">
                <span className="text-[6px] font-mono text-red-500 font-bold uppercase block tracking-wider">RESOLVED COPY SCHEMATIC:</span>
                <p className="text-slate-200 text-[9px] font-sans border-l-2 border-red-500/80 pl-2 leading-relaxed">
                  {generatedContent}
                </p>
                <div className="flex items-center gap-1.5 text-[6.5px] text-emerald-400 font-bold uppercase pt-1">
                  <ArrowRight className="w-2.5 h-2.5 text-emerald-400 animate-pulse" /> ADDED TO DAILY SCHEDULED QUEUE
                </div>
              </div>
            )}
          </div>

          {/* Outbound queue tracker */}
          <ActivityQueueList 
            queue={storeState.queue} 
            onClear={(id) => SocialService.clearQueueItem(id)} 
          />

        </div>

      </div>

    </div>
  );
};
export default SocialManager;
