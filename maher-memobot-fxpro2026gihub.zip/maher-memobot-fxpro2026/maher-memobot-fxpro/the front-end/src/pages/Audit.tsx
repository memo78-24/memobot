import React, { useState, useEffect } from "react";
import { useLanguage } from "../components/LanguageProvider";
import { useNotification } from "../components/NotificationProvider";
import { ApiClient } from "../services/api";
import { HolographicAuditStudio } from "../components/audit/HolographicAuditStudio";

export const Audit: React.FC<{ initialSubTab?: string }> = () => {
  const { t } = useLanguage();
  const { showAlert } = useNotification();
  const [complianceMode, setComplianceMode] = useState<"Islamic" | "Commercial">("Islamic");

  useEffect(() => {
    const fetchStatus = async () => {
      try {
        const sData = await ApiClient.get("/engine/status").catch(() => null);
        if (sData?.compliance_mode) {
          setComplianceMode(sData.compliance_mode);
        }
      } catch (err) {}
    };
    fetchStatus();
  }, []);

  const handleComplianceToggle = async (mode: "Islamic" | "Commercial") => {
    try {
      setComplianceMode(mode);
      await ApiClient.post("/engine/compliance", { mode }).catch(() => null);
      showAlert(t(`Audit Protocol calibrated to: ${mode.toUpperCase()}`));
    } catch (e) {
      setComplianceMode(mode);
    }
  };

  return (
    <div className="flex-1 p-4 sm:p-6 bg-[#040508] text-white font-mono space-y-5 max-w-[1700px] mx-auto min-h-screen">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-3 border-b border-[#FA1F4E]/20 pb-4 shrink-0">
        <div className="flex items-center gap-3">
          <div 
            className="w-11 h-11 rounded-xl bg-[#090b13] border border-[#FA1F4E]/40 flex items-center justify-center shrink-0 shadow-[0_0_15px_rgba(250,31,78,0.2)] relative overflow-hidden group"
          >
            <img 
              src="/MemoBot.png" 
              alt="MemoBot Logo" 
              className="w-7 h-7 object-contain mix-blend-screen drop-shadow-[0_0_8px_rgba(250,31,78,0.6)] transition-transform group-hover:scale-110" 
            />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="text-xl sm:text-2xl font-aquire text-[#FA1F4E] tracking-tight uppercase drop-shadow-[0_0_12px_rgba(250,31,78,0.25)]">
                {t("INSTITUTIONAL AUDITING HUB")}
              </h1>
              <span className="text-[9px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-bold uppercase tracking-wider">
                100% VERIFIED SPOT
              </span>
            </div>
            <p className="font-sans text-xs text-[#8a8d9a] mt-0.5">
              {t("Deterministic execution passports, multi-stage trade verification, and holographic audit dossiers.")}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-stretch md:self-auto justify-between md:justify-end">
          <div className="flex items-center gap-1.5 bg-[#090c15] border border-[#1b202e] px-3 py-1.5 rounded-xl shadow-inner text-[10.5px]">
            <span className="text-[#717688] font-bold uppercase">{t("VERIFICATION LEDGER:")}</span>
            <span className="text-[#FA1F4E] font-black font-mono">SHA-256 PROVEN</span>
          </div>
        </div>
      </div>

      {/* Central Holographic Audit Studio: Live Creation with Engine Selection & Interactive Nodes */}
      <HolographicAuditStudio
        complianceMode={complianceMode}
        onComplianceToggle={handleComplianceToggle}
      />
    </div>
  );
};

export default Audit;
