import React, { useEffect, useState } from "react";
import { ApiClient } from "../services/api";
import { WebSocketManager } from "../services/websocket";
import { TOPICS } from "../config/constants";
import { useNotification } from "../components/NotificationProvider";
import { TradingChart } from "../components/TradingChart";
import { PageLoader } from "../components/PageLoader";
import {
  RefreshCw,
  Zap,
  Layers,
  Terminal,
  Activity,
  Info
} from "lucide-react";

interface Order {
  id: string;
  timestamp: string;
  symbol: string;
  side: "BUY" | "SELL";
  type: string;
  amount: number;
  price: number;
  fill_price: number;
  fill_amount: number;
  engine_id: string;
}

interface LogEntry {
  time: string;
  msg: string;
  type?: "info" | "success" | "warn";
}

export const Orders: React.FC = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  // Real Account State
  const [availableBalance, setAvailableBalance] = useState<number>(0);
  const [equity, setEquity] = useState<number>(0);
  const [unrealizedPnl, setUnrealizedPnl] = useState<number>(0);

  // Order Placement Form State
  const [side, setSide] = useState<"BUY" | "SELL">("BUY");
  const [assetSymbol, setAssetSymbol] = useState<string>("BTCUSDT");
  const [orderType, setOrderType] = useState<"MARKET" | "LIMIT">("MARKET");
  const [sizeUsdt, setSizeUsdt] = useState<number>(0);
  const [leverage, setLeverage] = useState<number>(10);
  const [executing, setExecuting] = useState<boolean>(false);

  // Live Prices
  const [livePrices, setLivePrices] = useState<Record<string, number>>({});

  // Activity Monitor Logs
  const [logs, setLogs] = useState<LogEntry[]>([
    { time: new Date().toLocaleTimeString(), msg: "Secure trading environment initialized.", type: "info" }
  ]);

  const { showAlert } = useNotification();

  const addLog = (msg: string, type: "info" | "success" | "warn" = "info") => {
    const time = new Date().toLocaleTimeString();
    setLogs((prev) => [{ time, msg, type }, ...prev]);
  };

  const fetchOrdersAndBalance = async () => {
    try {
      const [histData, balData, pricesData] = await Promise.all([
        ApiClient.get("/execution/history").catch(() => []),
        ApiClient.get("/execution/balances").catch(() => null),
        ApiClient.get("/market/prices").catch(() => null)
      ]);

      if (histData) setOrders(histData);
      if (balData) {
        // Paper Trade MUST use isolated paper_balances, never live Binance balance
        const paperBal = balData.paper_balances?.USDT ?? balData.paper_net_worth ?? 100000;
        setAvailableBalance(paperBal);
        setEquity(paperBal);
        setUnrealizedPnl(0);
      }
      if (pricesData?.prices) {
        setLivePrices(pricesData.prices);
      }
      setLoading(false);
    } catch (err) {
      console.error("Failed to load trading state:", err);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrdersAndBalance();

    const unsubBalance = WebSocketManager.subscribe(TOPICS.BALANCE_CHANGED, () => {
      fetchOrdersAndBalance();
    });

    const interval = setInterval(() => {
      ApiClient.get("/market/prices").then((res) => {
        if (res && res.prices) {
          setLivePrices(res.prices);
        }
      }).catch(() => {});
    }, 4000);

    return () => {
      unsubBalance();
      clearInterval(interval);
    };
  }, []);

  const symbolKey = assetSymbol.replace("USDT", "");
  const currentPrice = livePrices[symbolKey] || 0;
  const requiredMargin = leverage > 0 ? sizeUsdt / leverage : sizeUsdt;

  const handlePercentageSelect = (pct: number) => {
    const calculated = Math.floor(availableBalance * pct);
    setSizeUsdt(calculated > 0 ? calculated : 0);
  };

  const handleExecuteOrder = async () => {
    if (sizeUsdt <= 0) {
      showAlert("Please specify a valid order size greater than 0 USDT.");
      return;
    }

    setExecuting(true);
    addLog(`Initiating ${side} ${orderType} order for ${assetSymbol}...`, "info");

    try {
      const amount = Math.round((sizeUsdt / currentPrice) * 10000) / 10000;
      const res = await ApiClient.post("/execution/trade", {
        symbol: assetSymbol,
        side,
        type: orderType,
        amount,
        engine: "ENG-PRO"
      });

      const fillPrice = res.fill_price || currentPrice;
      const fillAmount = res.fill_amount || amount;

      showAlert(`ORDER FILLED: ${side} ${fillAmount} ${assetSymbol} @ $${(fillPrice ?? 0).toLocaleString()}`);
      addLog(`ORDER FILLED: Dispatched ${side} ${fillAmount} ${assetSymbol} at $${(fillPrice ?? 0).toLocaleString()}. Margin: $${requiredMargin.toFixed(2)} USDT`, "success");

      fetchOrdersAndBalance();
    } catch (err: any) {
      showAlert(`Order Rejected: ${err.message}`);
      addLog(`ORDER REJECTED: ${err.message}`, "warn");
    } finally {
      setExecuting(false);
    }
  };

  if (loading) {
    return <PageLoader message="LOADING SECURE TRADING ENVIRONMENT..." subMessage="Syncing Order Books & Execution Gateways" />;
  }

  return (
    <div className="flex-1 bg-[#06070a] p-6 overflow-y-auto space-y-6 font-mono select-none">
      
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-[#FA1F4E]/20 pb-4 shrink-0">
        <div>
          <div className="flex items-center gap-3">
            <h2 className="text-2xl font-aquire text-[#FA1F4E] tracking-tighter drop-shadow-[0_0_15px_rgba(250,31,78,0.2)] uppercase">
              PAPER TRADING HUB
            </h2>
            <span className="px-2.5 py-1 rounded bg-[#3b82f6]/10 border border-[#3b82f6]/40 text-[#3b82f6] text-[10px] font-bold uppercase tracking-wider">
              ISOLATED PAPER SANDBOX
            </span>
          </div>
          <p className="font-sans text-[13px] text-[#8a8d9a] mt-1">
            Simulated paper execution sandbox — 100% isolated from real Binance live balances.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        <div className="bg-[#0d0e12] border border-[#1a1d26] p-4 rounded space-y-2 panel-glow">
          <span className="text-[9px] text-[#8a8d9a] font-bold uppercase tracking-wider block">
            AVAILABLE BALANCE
          </span>
          <div className="text-xl font-extrabold text-white">
            ${(availableBalance ?? 0).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <span className="text-[9px] text-[#3b82f6] font-bold uppercase block">
            USDT COLLATERAL
          </span>
        </div>

        <div className="bg-[#0d0e12] border border-[#1a1d26] p-4 rounded space-y-2 panel-glow">
          <span className="text-[9px] text-[#8a8d9a] font-bold uppercase tracking-wider block">
            TOTAL EQUITY
          </span>
          <div className="text-xl font-extrabold text-white">
            ${(equity ?? 0).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <span className="text-[9px] text-[#8a8d9a] font-bold uppercase block">
            LIQUIDATED VALUE
          </span>
        </div>

        <div className="bg-[#0d0e12] border border-[#1a1d26] p-4 rounded space-y-2 panel-glow">
          <span className="text-[9px] text-[#8a8d9a] font-bold uppercase tracking-wider block">
            UNREALIZED PROFIT
          </span>
          <div className="text-xl font-extrabold text-white">
            {unrealizedPnl >= 0 ? "+" : ""}${unrealizedPnl.toFixed(2)}
          </div>
          <span className="text-[9px] text-[#8a8d9a] font-bold uppercase block">
            ACTIVE POSITIONS
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        <div className="lg:col-span-2 space-y-6">
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            <div className="bg-[#0d0e12] border border-[#1a1d26] rounded p-5 space-y-4 panel-glow">
              <div className="flex items-center gap-2 text-xs font-bold text-white uppercase tracking-wider border-b border-[#11131c] pb-3">
                <Layers className="w-4 h-4 text-[#FA1F4E]" />
                <span>PLACE ORDER</span>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => setSide("BUY")}
                  className={`py-2.5 rounded font-extrabold text-xs uppercase tracking-wider transition-all border ${
                    side === "BUY"
                      ? "bg-[rgba(0,230,118,0.15)] text-[#00e676] border-[#00e676] shadow-[0_0_12px_rgba(0,230,118,0.3)]"
                      : "bg-[#06070a] text-[#8a8d9a] border-[#1a1d26] hover:text-white"
                  }`}
                >
                  LONG (BUY)
                </button>
                <button
                  onClick={() => setSide("SELL")}
                  className={`py-2.5 rounded font-extrabold text-xs uppercase tracking-wider transition-all border ${
                    side === "SELL"
                      ? "bg-[rgba(250,31,78,0.15)] text-[#FA1F4E] border-[#FA1F4E] shadow-[0_0_12px_rgba(250,31,78,0.3)]"
                      : "bg-[#06070a] text-[#8a8d9a] border-[#1a1d26] hover:text-white"
                  }`}
                >
                  SHORT (SELL)
                </button>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] text-[#8a8d9a] font-bold uppercase tracking-wider block">
                  ASSET INSTRUMENT
                </label>
                <select
                  value={assetSymbol}
                  onChange={(e) => setAssetSymbol(e.target.value)}
                  className="w-full bg-[#06070a] border border-[#1a1d26] focus:border-[#FA1F4E] text-white p-2.5 rounded outline-none font-bold text-xs cursor-pointer transition-colors"
                >
                  <option value="BTCUSDT">BTC / USDT</option>
                  <option value="ETHUSDT">ETH / USDT</option>
                  <option value="SOLUSDT">SOL / USDT</option>
                  <option value="BNBUSDT">BNB / USDT</option>
                  <option value="XRPUSDT">XRP / USDT</option>
                </select>
              </div>

              <div className="space-y-3">
                <div className="space-y-1">
                  <div className="flex justify-between items-center text-[10px] text-[#8a8d9a]">
                    <label className="font-bold uppercase tracking-wider">SIZE (USDT VALUE)</label>
                    <span>AVAIL: <strong className="text-white">${(availableBalance ?? 0).toLocaleString()}</strong></span>
                  </div>
                  <input
                    type="number"
                    value={sizeUsdt}
                    onChange={(e) => setSizeUsdt(Number(e.target.value))}
                    className="w-full bg-[#06070a] border border-[#1a1d26] focus:border-[#FA1F4E] text-white p-2.5 rounded outline-none font-bold text-xs transition-colors"
                  />
                  <div className="grid grid-cols-4 gap-1.5 pt-1">
                    {[0.25, 0.5, 0.75, 1.0].map((pct) => (
                      <button
                        key={pct}
                        type="button"
                        onClick={() => handlePercentageSelect(pct)}
                        className="py-1 bg-[#06070a] border border-[#1a1d26] hover:border-[#3b82f6] text-[#8a8d9a] hover:text-[#3b82f6] rounded text-[9px] font-bold uppercase transition-all"
                      >
                        {pct * 100}%
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-[10px] text-[#8a8d9a]">
                    <label className="font-bold uppercase tracking-wider">LEVERAGE ({leverage}X)</label>
                    <span className="text-[#3b82f6] font-bold">{leverage}x</span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="20"
                    step="1"
                    value={leverage}
                    onChange={(e) => setLeverage(Number(e.target.value))}
                    className="w-full accent-[#FA1F4E] bg-[#06070a] h-1.5 rounded cursor-pointer"
                  />
                </div>
              </div>

              <button
                onClick={handleExecuteOrder}
                disabled={executing}
                className={`w-full py-3 rounded text-white font-extrabold text-xs uppercase tracking-wider transition-all shadow-lg flex items-center justify-center gap-2 ${
                  side === "BUY"
                    ? "bg-[#FA1F4E] hover:bg-[#d4153d] shadow-[0_0_15px_rgba(250,31,78,0.4)]"
                    : "bg-[#ef4444] hover:bg-[#dc2626] shadow-[0_0_15px_rgba(239,68,68,0.4)]"
                } disabled:opacity-50`}
              >
                {executing ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    EXECUTING...
                  </>
                ) : (
                  <>
                    <Zap className="w-4 h-4" />
                    {side === "BUY" ? "EXECUTE BUY ORDER" : "EXECUTE SELL ORDER"}
                  </>
                )}
              </button>
            </div>

            <TradingChart symbol={assetSymbol} livePrice={currentPrice} />
          </div>

          <div className="bg-[#0d0e12] border border-[#1a1d26] rounded overflow-hidden">
            <div className="bg-[#090a0d] px-4 py-3 border-b border-[#11131c] flex items-center justify-between">
              <span className="text-[10px] text-[#FA1F4E] font-bold tracking-wider uppercase">
                COMPLETED ORDERS
              </span>
              <button onClick={fetchOrdersAndBalance} className="text-[#8a8d9a] hover:text-[#3b82f6] transition-colors">
                <RefreshCw className="w-4 h-4" />
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-[#11131c] text-[#8a8d9a] uppercase bg-[#06070a]">
                    <th className="py-3 px-4 font-semibold">TIMESTAMP</th>
                    <th className="py-3 px-4 font-semibold">SIDE</th>
                    <th className="py-3 px-4 font-semibold">PAIR</th>
                    <th className="py-3 px-4 font-semibold">AMOUNT</th>
                    <th className="py-3 px-4 font-semibold">FILL PRICE</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1a1d26]">
                  {orders.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-10 text-center text-[#8a8d9a]">
                        NO ORDERS
                      </td>
                    </tr>
                  ) : (
                    orders.map((ord, idx) => (
                      <tr key={idx} className="hover:bg-[#12161f]">
                        <td className="py-3 px-4 text-[#8a8d9a]">{new Date(ord.timestamp).toLocaleString()}</td>
                        <td className="py-3 px-4">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            ord.side === "BUY"
                              ? "bg-[rgba(0,230,118,0.15)] text-[#00e676] border border-[#00e676]"
                              : "bg-[rgba(239,68,68,0.15)] text-[#ef4444] border border-[#ef4444]"
                          }`}>
                            {ord.side}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-white font-bold">{ord.symbol}</td>
                        <td className="py-3 px-4 text-white font-bold">{ord.amount}</td>
                        <td className="py-3 px-4 text-white font-bold">${(ord.fill_price ?? 0).toLocaleString("en-US", { minimumFractionDigits: 2 })}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-[#0d0e12] border border-[#1a1d26] rounded p-4 panel-glow space-y-3">
            <div className="flex items-center justify-between border-b border-[#11131c] pb-2.5">
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 text-[#3b82f6]" />
                <span className="text-[10px] text-white font-bold uppercase tracking-wider">
                  MARKET DATA
                </span>
              </div>
            </div>
            <div className="text-[10px] text-[#8a8d9a]">Market data feed is active.</div>
          </div>

          <div className="bg-[#0d0e12] border border-[#1a1d26] rounded p-4 panel-glow space-y-3">
            <div className="flex items-center gap-2 text-xs font-bold text-white uppercase tracking-wider border-b border-[#11131c] pb-2.5">
              <Terminal className="w-4 h-4 text-[#3b82f6]" />
              <span>ACTIVITY LOGS</span>
            </div>
            <div className="bg-[#06070a] border border-[#11131c] p-3 rounded h-[180px] overflow-y-auto space-y-2 font-mono text-[10px] leading-relaxed">
              {logs.map((log, idx) => (
                <div key={idx} className="flex items-start gap-2">
                  <span className="text-[#8a8d9a] shrink-0">[{log.time}]</span>
                  <span
                    className={
                      log.type === "success"
                        ? "text-[#3b82f6]"
                        : log.type === "warn"
                        ? "text-[#ff1744]"
                        : "text-[#8a8d9a]"
                    }
                  >
                    {log.msg}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Orders;
