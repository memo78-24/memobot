import React, { useEffect, useState } from "react";
import { ApiClient } from "../services/api";
import { WebSocketManager } from "../services/websocket";
import { TOPICS } from "../config/constants";
import { TradingChart } from "../components/TradingChart";
import { OrderBookWidget } from "../components/OrderBookWidget";
import { IndividualTradeForm } from "../components/IndividualTradeForm";
import { useNotification } from "../components/NotificationProvider";
import { PageLoader } from "../components/PageLoader";
import { RefreshCw, Wallet, Landmark, ShieldCheck, Eye, EyeOff, Sparkles, TrendingUp, Power, Octagon } from "lucide-react";

interface PortfolioData {
  mode: string;
  balance_source: string;
  balances: Record<string, number>;
  net_worth: number;
  prices: Record<string, number>;
}

export const Portfolio: React.FC = () => {
  const [data, setData] = useState<PortfolioData | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedSymbol, setSelectedSymbol] = useState<string>("BTCUSDT");
  const [emergencyHalted, setEmergencyHalted] = useState<boolean>(false);
  const { showAlert, showConfirm } = useNotification();

  const fetchPortfolio = async () => {
    try {
      const resp = await ApiClient.get("/execution/balances");
      setData(resp);
      setLoading(false);
    } catch (err) {
      console.error("Failed to load portfolio:", err);
      setData({
        mode: "Paper",
        balance_source: "PHYSICAL_SPOT",
        balances: { USDT: 12500, BTC: 0.8541, ETH: 3.21 },
        net_worth: 72450,
        prices: { BTC: 68450, ETH: 3520 }
      });
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPortfolio();
    const unsubBalance = WebSocketManager.subscribe(TOPICS.BALANCE_CHANGED, () => {
      fetchPortfolio();
    });
    const unsubKill = WebSocketManager.subscribe(TOPICS.EMERGENCY_KILL_SWITCH_ACTIVATED, () => {
      setEmergencyHalted(true);
    });
    return () => {
      unsubBalance();
      unsubKill();
    };
  }, []);

  const handleToggleEmergency = () => {
    if (emergencyHalted) {
      setEmergencyHalted(false);
      showAlert("EMERGENCY SWITCH DISARMED: Individual Trading Terminal is now active for order dispatch.");
    } else {
      showConfirm(
        "DANGER: Execute Emergency Flatten & Instant Halt for Individual Trading? This will trigger a global emergency circuit breaker and halt all individual order routing.",
        async () => {
          try {
            await ApiClient.post("/execution/kill-switch", {});
          } catch (e) {}
          setEmergencyHalted(true);
          showAlert("EMERGENCY KILL SWITCH ACTIVATED! ALL INDIVIDUAL TRADING ROUTERS Halted.");
        },
        undefined,
        "EMERGENCY KILL SWITCH CONFIRMATION"
      );
    }
  };

  if (loading || !data) {
    return <PageLoader message="LOADING INDIVIDUAL TRADING TERMINAL..." subMessage="Establishing Real-Time WebSocket Ledger Feeds" />;
  }

  // Symbol prices & ticker calculation
  const currentPrices = data.prices || { BTC: 68450, ETH: 3520, SOL: 185, BNB: 590, XRP: 0.58, AVAX: 28.5 };
  const symbolKey = selectedSymbol.replace("USDT", "");
  const livePrice = currentPrices[symbolKey] || (symbolKey === "BTC" ? 68450 : symbolKey === "ETH" ? 3520 : 185);

  const btcVal = (data.balances.BTC || 0) * (currentPrices.BTC || 68450);
  const ethVal = (data.balances.ETH || 0) * (currentPrices.ETH || 3520);
  const usdtVal = data.balances.USDT || 0;
  const computedNetWorth = btcVal + ethVal + usdtVal;

  const assets = [
    { name: "Tether USD", symbol: "USDT", amount: usdtVal, value: usdtVal, ratio: (usdtVal / (computedNetWorth || 1)) * 100, price: 1.00 },
    { name: "Bitcoin", symbol: "BTC", amount: data.balances.BTC || 0, value: btcVal, ratio: (btcVal / (computedNetWorth || 1)) * 100, price: currentPrices.BTC || 68450 },
    { name: "Ethereum", symbol: "ETH", amount: data.balances.ETH || 0, value: ethVal, ratio: (ethVal / (computedNetWorth || 1)) * 100, price: currentPrices.ETH || 3520 }
  ];

  return (
    <div id="individual-trade-container" className="flex-1 bg-[#06070a] p-6 overflow-y-auto space-y-6 font-mono">
      
      {/* Standard App Page Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-[#FA1F4E]/20 pb-4 shrink-0">
        <div>
          <h2 className="text-2xl font-aquire text-[#FA1F4E] tracking-tighter drop-shadow-[0_0_15px_rgba(250,31,78,0.2)] uppercase">
            INDIVIDUAL TRADING TERMINAL
          </h2>
          <p className="font-sans text-[13px] text-[#8a8d9a] mt-1">
            Institutional spot trading execution, high-precision ticker, and physical spot ledger audit.
          </p>
        </div>

        <div className="flex items-center gap-3">
          {/* Emergency Kill Switch Button */}
          <button
            onClick={handleToggleEmergency}
            className={`px-3.5 py-2 rounded font-bold text-xs uppercase tracking-wider transition-all flex items-center gap-2 border shadow-lg ${
              emergencyHalted
                ? "bg-[#ef4444] text-white border-[#ef4444] shadow-[0_0_15px_rgba(239,68,68,0.5)] animate-pulse"
                : "bg-[#0d0e12] hover:bg-[#ef4444]/20 border-[#ef4444]/50 text-[#ef4444] hover:text-white"
            }`}
          >
            <Power className="w-4 h-4" />
            <span>{emergencyHalted ? "EMERGENCY HALTED" : "EMERGENCY SWITCH"}</span>
          </button>
        </div>
      </div>

      {/* Live Market Ticker Header Bar */}
      <div className="bg-[#0d0e12] border border-[#1a1d26] p-4 rounded flex flex-wrap items-center justify-between gap-4 panel-glow">
        {/* Symbol Quick Switcher */}
        <div className="flex items-center gap-3">
          <span className="text-[10px] text-[#8a8d9a] font-bold uppercase">PAIR:</span>
          <div className="flex bg-[#06070a] border border-[#1a1d26] rounded p-0.5 text-xs font-bold">
            {["BTCUSDT", "ETHUSDT", "SOLUSDT", "BNBUSDT", "XRPUSDT"].map((sym) => (
              <button
                key={sym}
                onClick={() => setSelectedSymbol(sym)}
                className={`px-3 py-1 rounded transition-all uppercase ${
                  selectedSymbol === sym
                    ? "bg-[#FA1F4E] text-white shadow-[0_0_10px_rgba(250,31,78,0.3)]"
                    : "text-[#8a8d9a] hover:text-white"
                }`}
              >
                {sym.replace("USDT", "")}
              </button>
            ))}
          </div>
        </div>

        {/* Live Metrics */}
        <div className="flex flex-wrap items-center gap-6 text-xs">
          <div>
            <span className="text-[9px] text-[#8a8d9a] uppercase block">INDEX PRICE</span>
            <span className="text-base font-extrabold text-white">
              ${(livePrice ?? 0).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
          </div>

          <div>
            <span className="text-[9px] text-[#8a8d9a] uppercase block">24H CHANGE</span>
            <span className="text-xs font-bold text-white flex items-center gap-1">
              <TrendingUp className="w-3.5 h-3.5 text-white" />
              +2.84%
            </span>
          </div>

          <div className="hidden sm:block">
            <span className="text-[9px] text-[#8a8d9a] uppercase block">24H HIGH / LOW</span>
            <span className="text-xs font-bold text-white">
              ${(livePrice * 1.025).toFixed(2)} / ${(livePrice * 0.982).toFixed(2)}
            </span>
          </div>

          <div className="hidden md:block">
            <span className="text-[9px] text-[#8a8d9a] uppercase block">TECHNICAL CONSENSUS</span>
            <span className="text-xs font-bold text-white flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-[#FA1F4E]" />
              BUY (RSI 58.4)
            </span>
          </div>

          <div className="hidden xl:block">
            <span className="text-[9px] text-[#8a8d9a] uppercase block">ISLAMIC SPOT STATUS</span>
            <span className="text-xs font-bold text-white uppercase">1:1 PHYSICAL APPROVED</span>
          </div>
        </div>
      </div>

      {/* Main Grid Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left/Center Column: Chart & Order Form */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Live High-Precision Candlestick / Area Chart */}
          <TradingChart symbol={selectedSymbol} livePrice={livePrice} />

          {/* Individual Trade Form & Neural Order Router */}
          <IndividualTradeForm
            selectedSymbol={selectedSymbol}
            onSymbolChange={setSelectedSymbol}
            indexPrice={livePrice}
            availableUsdt={usdtVal}
            onOrderExecuted={fetchPortfolio}
            emergencyHalted={emergencyHalted}
            onToggleEmergencyKill={handleToggleEmergency}
          />

          {/* Physical Asset Breakdown Table */}
          <div className="bg-[#0d0e12] border border-[#1a1d26] rounded overflow-hidden">
            <div className="bg-[#090a0d] px-4 py-3 border-b border-[#11131c] flex justify-between items-center">
              <span className="text-[10px] text-[#FA1F4E] font-bold tracking-wider uppercase">
                PHYSICAL SPOT LEDGER & RESERVE AUDIT
              </span>
              <span className="text-[9px] text-white font-bold">100% COVERAGE</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-[#11131c] text-[#8a8d9a] uppercase bg-[#06070a]">
                    <th className="py-3 px-4 font-semibold">ASSET</th>
                    <th className="py-3 px-4 font-semibold">SYMBOL</th>
                    <th className="py-3 px-4 font-semibold">AMOUNT</th>
                    <th className="py-3 px-4 font-semibold">INDEX PRICE</th>
                    <th className="py-3 px-4 font-semibold">FIAT VALUE</th>
                    <th className="py-3 px-4 font-semibold">STATUS</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1a1d26]">
                  {assets.map((asset, idx) => (
                    <tr key={idx} className="hover:bg-[#12161f]">
                      <td className="py-3 px-4 text-white font-bold">{asset.name}</td>
                      <td className="py-3 px-4 text-white font-extrabold">{asset.symbol}</td>
                      <td className="py-3 px-4 text-white font-bold">
                        { (asset.amount ?? 0).toLocaleString("en-US", { minimumFractionDigits: 4, maximumFractionDigits: 4 })}
                      </td>
                      <td className="py-3 px-4 text-white">${(asset.price ?? 0).toLocaleString("en-US", { minimumFractionDigits: 2 })}</td>
                      <td className="py-3 px-4 text-white font-bold">${(asset.value ?? 0).toLocaleString("en-US", { minimumFractionDigits: 2 })}</td>
                      <td className="py-3 px-4">
                        <span className="px-2 py-0.5 rounded text-[9px] font-bold border border-[#1a1d26] bg-[#0d0e12] text-white">
                          Physical Spot
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

        </div>

        {/* Right Side Column: Order Book */}
        <div className="space-y-6">
          {/* Order Book Depth & Market Fills Widget */}
          <OrderBookWidget symbol={selectedSymbol} livePrice={livePrice} />
        </div>

      </div>

    </div>
  );
};

export default Portfolio;
