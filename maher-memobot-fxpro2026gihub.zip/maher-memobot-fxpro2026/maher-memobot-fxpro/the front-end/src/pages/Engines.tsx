import React, { useState, useEffect, useRef } from "react";
import { motion } from "motion/react";
import { Terminal, Power, Cpu, Shield, Globe, ChevronDown, Check, Coins, TrendingUp, BarChart3, ArrowUpRight, Activity, ArrowLeft, ArrowRight, Compass } from "lucide-react";
import { engineStore, EngineState } from "../services/engineStore";
import { EngineService } from "../services/engineService";
import { ApiClient } from "../services/api";
import { useNotification } from "../components/NotificationProvider";
import { HologramPanel } from "../components/HologramPanel";
import { useLanguage } from "../components/LanguageProvider";

// ==========================================
// 1. DATA STRUCTURES & CONFIGS
// ==========================================
interface MemoNode {
  id: string;
  storeId: string;
  badge?: string;
  title: string;
  subtitle: string;
  exchange: string;
}

interface EnginePerf {
  pnl24h: number;
  pnlPercent: number;
  winRate: number;
  tradesCount: number;
  volume24h: string;
  rankBadge: string;
  isTopPerformer?: boolean;
}

const INITIAL_ENGINE_PERFS: Record<string, EnginePerf> = {
  // Left Wing Engines
  "ENG-002": { pnl24h: 2480.20, pnlPercent: 8.6, winRate: 94.2, tradesCount: 142, volume24h: "$48.5K", rankBadge: "#2 HIGH PNL" },
  "ENG-003": { pnl24h: 1120.40, pnlPercent: 4.1, winRate: 89.0, tradesCount: 98, volume24h: "$22.4K", rankBadge: "STABLE" },
  "ENG-004": { pnl24h: 890.15, pnlPercent: 3.2, winRate: 86.5, tradesCount: 74, volume24h: "$18.2K", rankBadge: "BALANCED" },
  "ENG-006": { pnl24h: 1760.80, pnlPercent: 6.4, winRate: 91.8, tradesCount: 116, volume24h: "$34.8K", rankBadge: "HIGH EFF" },
  "ENG-005": { pnl24h: 640.50, pnlPercent: 2.1, winRate: 84.2, tradesCount: 62, volume24h: "$14.5K", rankBadge: "MODERATE" },
  "MEMOBOT": { pnl24h: 3150.00, pnlPercent: 14.2, winRate: 96.8, tradesCount: 184, volume24h: "$62.1K", rankBadge: "⭐ #1 TOP ALPHA", isTopPerformer: true },

  // Right Wing Engines
  "MEMOCODEX": { pnl24h: 2940.60, pnlPercent: 11.8, winRate: 95.4, tradesCount: 168, volume24h: "$56.3K", rankBadge: "⭐ #1 TOP ALPHA", isTopPerformer: true },
  "ENG-008": { pnl24h: 1340.20, pnlPercent: 4.9, winRate: 90.1, tradesCount: 104, volume24h: "$28.0K", rankBadge: "HIGH EFF" },
  "ENG-001": { pnl24h: 2110.00, pnlPercent: 7.8, winRate: 93.2, tradesCount: 138, volume24h: "$42.6K", rankBadge: "#2 HIGH PNL" },
  "ENG-010": { pnl24h: 980.50, pnlPercent: 3.7, winRate: 87.4, tradesCount: 82, volume24h: "$19.8K", rankBadge: "BALANCED" },
  "ENG-007": { pnl24h: 720.00, pnlPercent: 2.8, winRate: 85.0, tradesCount: 66, volume24h: "$15.4K", rankBadge: "MODERATE" },
  "ENG-009": { pnl24h: 1450.30, pnlPercent: 5.6, winRate: 91.0, tradesCount: 112, volume24h: "$31.2K", rankBadge: "OPTIMIZED" },
};

const WING_L_NODES: MemoNode[] = [
  // Column 1 (Outermost, 1 node vertically centered)
  { id: "ENG-005", storeId: "ENG-005", title: "UY SCUTI", subtitle: "OKX CONNECTOR / AUTO", exchange: "OKX" },
  // Column 2 (Middle, 2 nodes)
  { id: "ENG-003", storeId: "ENG-003", title: "ALGOL", subtitle: "BYBIT ROUTER / AUTO", exchange: "Bybit" },
  { id: "ENG-004", storeId: "ENG-004", title: "NEXUS", subtitle: "KUCOIN CONNECTOR / AUTO", exchange: "KuCoin" },
  // Column 3 (Innermost, closest to center circle: 3 nodes, middle node is Horizontal ENG-002)
  { id: "ENG-006", storeId: "ENG-006", title: "ALPHA CENTAURI", subtitle: "OKX SWARM / AUTO", exchange: "OKX" },
  { id: "ENG-002", storeId: "ENG-002", badge: "REGULUS ENGINE", title: "REGULUS", subtitle: "BYBIT GATEWAY / AUTO", exchange: "Bybit" },
  { id: "MEMOBOT", storeId: "MEMOBOT", badge: "MEMOBOT PRIME", title: "MEMOBOT", subtitle: "OKX MANUAL / ACTIVE", exchange: "OKX" },
];

const WING_R_NODES: MemoNode[] = [
  // Column 1 (Innermost, closest to center circle: 3 nodes, middle node is Horizontal MEMOCODEX/RIGEL)
  { id: "ENG-008", storeId: "ENG-008", title: "CANOPUS (OOOka)", subtitle: "BINANCE CONNECTOR / AUTO", exchange: "Binance" },
  { id: "MEMOCODEX", storeId: "MEMOCODEX", badge: "APP: MEMOCODEX", title: "RIGEL (LAMOOR)", subtitle: "BINANCE MANUAL / ACTIVE", exchange: "Binance" },
  { id: "ENG-001", storeId: "ENG-001", badge: "SIRIUS ENGINE", title: "SIRIUS (Loool)", subtitle: "BINANCE SWARM / AUTO", exchange: "Binance" },
  // Column 2 (Middle, 2 nodes)
  { id: "ENG-010", storeId: "ENG-010", title: "POLARIS", subtitle: "KUCOIN OPTIMIZER / AUTO", exchange: "KuCoin" },
  { id: "ENG-007", storeId: "ENG-007", title: "BETELGEUSE", subtitle: "KUCOIN CONNECTOR / AUTO", exchange: "KuCoin" },
  // Column 3 (Outermost, 1 node vertically centered)
  { id: "ENG-009", storeId: "ENG-009", title: "ARCTURUS", subtitle: "BYBIT MANUAL / ACTIVE", exchange: "Bybit" },
];

const ENGINE_CONFIGS = [
  { id: 1, color: '#ff006e' },
  { id: 2, color: '#00f2ff' },
  { id: 3, color: '#3a86ff' },
  { id: 4, color: '#a855f7' },
  { id: 5, color: '#38bdf8' },
  { id: 6, color: '#ff003c' },
  { id: 7, color: '#00f0ff' },
  { id: 8, color: '#ec4899' },
  { id: 9, color: '#38bdf8' },
  { id: 10, color: '#06b6d4' },
  { id: 11, color: '#8b5cf6' },
  { id: 12, color: '#FA1F4E' },
];

export const Engines: React.FC<{ complianceMode?: "Islamic" | "Commercial" }> = ({ complianceMode }) => {
  const { t, isArabic } = useLanguage();
  const [storeState, setStoreState] = useState<EngineState>(engineStore.getState());
  const { showAlert } = useNotification();
  const mainScrollRef = useRef<HTMLDivElement>(null);

  const [selectedEngineId, setSelectedEngineId] = useState<string>("ENG-002");
  const [maximizedEngineId, setMaximizedEngineId] = useState<string | null>(null);
  const [hoveredEngineId, setHoveredEngineId] = useState<string | null>(null);
  const [engineStoppedTimes, setEngineStoppedTimes] = useState<Record<string, number>>({});
  const [currentTime, setCurrentTime] = useState<number>(Date.now());
  const [isCommandOpen, setIsCommandOpen] = useState<boolean>(false);
  const [powerOn, setPowerOn] = useState(true);
  const [magneticWaves, setMagneticWaves] = useState<{ id: number }[]>([]);
  const waveIdCounter = useRef(0);

  // 1-second ticker to drive live countdowns, 60s counter decay, and reactive pipeline animation
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(Date.now());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Track stopped timestamps for each engine when its status changes
  useEffect(() => {
    setEngineStoppedTimes(prev => {
      const next = { ...prev };
      Object.keys(storeState.engines).forEach(id => {
        const eng = storeState.engines[id];
        if (eng.status === "Stopped") {
          if (!next[id]) {
            next[id] = Date.now();
          }
        } else if (eng.status === "Running") {
          delete next[id];
        }
      });
      return next;
    });
  }, [storeState.engines]);

  const panToLeft = () => {
    if (!mainScrollRef.current) return;
    mainScrollRef.current.scrollTo({ left: 0, behavior: "smooth" });
  };

  const panToCenter = () => {
    if (!mainScrollRef.current) return;
    const target = (mainScrollRef.current.scrollWidth - mainScrollRef.current.clientWidth) / 2;
    mainScrollRef.current.scrollTo({ left: target, behavior: "smooth" });
  };

  const panToRight = () => {
    if (!mainScrollRef.current) return;
    mainScrollRef.current.scrollTo({ left: mainScrollRef.current.scrollWidth, behavior: "smooth" });
  };

  const [selectedRoute, setSelectedRoute] = useState<{ [key: string]: string }>({
    "ENG-008": "Binance",
    "MEMOCODEX": "Binance",
    "ENG-001": "Binance",
    "ENG-010": "KuCoin",
    "ENG-007": "KuCoin",
    "ENG-009": "Bybit",
    "ENG-005": "OKX",
    "ENG-003": "Bybit",
    "ENG-004": "KuCoin",
    "ENG-006": "OKX",
    "ENG-002": "Bybit",
    "MEMOBOT": "OKX"
  });

  const [paymentOption, setPaymentOption] = useState<"daily" | "weekly" | "monthly">("weekly");
  const [paymentMethod, setPaymentMethod] = useState<string>("CARD");
  const [exchangesEnabled, setExchangesEnabled] = useState<{ Binance: boolean; KuCoin: boolean; OKX: boolean; Bybit: boolean }>({
    Binance: true,
    KuCoin: true,
    OKX: true,
    Bybit: true
  });
  const [isPaying, setIsPaying] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const coreBtnRef = useRef<HTMLButtonElement | null>(null);

  // 24H Performance Tracking per Engine (Dynamic State)
  const [enginePerfs, setEnginePerfs] = useState<Record<string, EnginePerf>>(INITIAL_ENGINE_PERFS);

  // Telemetry View Modes (24H PnL Matrix vs Real-time Node Execution Logs)
  const [leftTelemetryTab, setLeftTelemetryTab] = useState<"pnl" | "logs">("pnl");
  const [rightTelemetryTab, setRightTelemetryTab] = useState<"pnl" | "logs">("pnl");
  const [leftLogFilter, setLeftLogFilter] = useState<string>("ALL");
  const [rightLogFilter, setRightLogFilter] = useState<string>("ALL");

  // Granular Real-time Node Execution Logs Stream
  const [nodeLogs, setNodeLogs] = useState<Array<{
    id: string;
    engineId: string;
    time: string;
    exchange: string;
    text: string;
    correlationId: string;
    type: "trade" | "signal" | "arb" | "pnl";
  }>>([
    { id: "init-1", engineId: "ENG-002", time: new Date(Date.now() - 45000).toTimeString().split(' ')[0], exchange: "Bybit", text: "ORDER FILLED: BUY 0.35 ETH @ $3,420.50 | REALIZED PNL: +$18.40", correlationId: "MEMO-8A4F10", type: "trade" },
    { id: "init-2", engineId: "MEMOBOT", time: new Date(Date.now() - 32000).toTimeString().split(' ')[0], exchange: "OKX", text: "AI NATURAL SENTIMENT: ALPHA SIGNAL DETECTED BTC/USDT SPREAD +0.09%", correlationId: "MEMO-B9204A", type: "signal" },
    { id: "init-3", engineId: "MEMOCODEX", time: new Date(Date.now() - 20000).toTimeString().split(' ')[0], exchange: "Binance", text: "STAT ARBITRAGE ARB EXECUTION COMPLETED 1.45 BNB @ $582.10 | PNL: +$32.10", correlationId: "MEMO-6C8E19", type: "arb" },
    { id: "init-4", engineId: "ENG-001", time: new Date(Date.now() - 12000).toTimeString().split(' ')[0], exchange: "Binance", text: "SWARM CONSENSUS: LIQUIDITY REBALANCING EXECUTED WITH ZERO SLIPPAGE", correlationId: "MEMO-44A9F2", type: "trade" },
    { id: "init-5", engineId: "ENG-006", time: new Date(Date.now() - 5000).toTimeString().split(' ')[0], exchange: "OKX", text: "HIGH-EFFICIENCY ROUTE MATCHED (LATENCY: 0.24ms) | 24H ROI TARGET MET", correlationId: "MEMO-1E77BC", type: "pnl" },
  ]);

  // Dynamic telemetry states
  const [metrics, setMetrics] = useState({
    neuralLoad: 78,
    clockSpeed: 2167,
    thruput: 998,
  });

  // Dynamic pipeline logs with standard format & correlation ID
  const [logs, setLogs] = useState<string[]>([
    "NEURAL NETWORK LAYER FEEDING BACKEND STACK.",
    "DYNAMIC REBALANCING: ADJUSTING SWARM ALLOCATIONS.",
    "CORRELATION ID ASSIGNED FOR DISTRIBUTED AUDIT.",
    "SYNCHRONIZING EXCHANGES: OKX, BINANCE, BYBIT ACTIVE.",
    "PARSING INBOUND WEBSOCKET TRADING DATA FRAMES.",
    "STABLE CONNECTION ACTIVE ON ALL SPECIFIED NODES."
  ].map((msg, i) => {
    // initialize past logs with a few minutes offset
    const time = new Date(Date.now() - (6 - i) * 60000);
    const timeStr = time.toTimeString().split(' ')[0];
    const randId = Math.floor(100000 + Math.random() * 900000).toString(16).toUpperCase();
    return `[${timeStr}] ${msg} X-Correlation-ID: MEMO-${randId}`;
  }));

  const addLog = (message: string) => {
    const now = new Date();
    const timeStr = now.toTimeString().split(' ')[0];
    const randId = Math.floor(100000 + Math.random() * 900000).toString(16).toUpperCase();
    setLogs(prev => {
      const newLog = `[${timeStr}] ${message} X-Correlation-ID: MEMO-${randId}`;
      const next = [...prev, newLog];
      if (next.length > 15) {
        return next.slice(next.length - 15);
      }
      return next;
    });
  };

  const handleToggleExchange = (excKey: "Binance" | "KuCoin" | "OKX" | "Bybit") => {
    if (!powerOn) return;
    const currentlyEnabled = exchangesEnabled[excKey];
    playBeep(currentlyEnabled ? 350 : 550, "sine", 0.08);
    setExchangesEnabled(prev => {
      const nextVal = !prev[excKey];
      addLog(`[GATEWAY COUPLING] ${excKey.toUpperCase()} ROUTING CHANNEL STATE SET TO: ${nextVal ? "CONNECTED / SECURED" : "ISOLATED / DEREGISTERED"}.`);
      return { ...prev, [excKey]: nextVal };
    });
  };

  const handleRecalibrateCorrelation = () => {
    if (!powerOn) return;
    playBeep(880, "triangle", 0.15);
    addLog("CALIBRATION COMMAND RECEIVED. INITIATING SWARM METRIC DISTRIBUTED SHIFT...");
    setMetrics(p => ({
      ...p,
      neuralLoad: Math.min(95, p.neuralLoad + 14),
      thruput: Math.min(1200, p.thruput + 180)
    }));
    setTimeout(() => {
      addLog("SWARM CORRELATION RECALIBRATED SUCCESSFULLY. JITTER FACTOR <0.02ms REGISTERED.");
    }, 1500);
  };

  const handleAuditCompliance = () => {
    if (!powerOn) return;
    playBeep(660, "sine", 0.2);
    addLog("SHARI'AH BUREAU SANITY AUDIT RUNNING ACROSS UNIFIED SPOKES...");
    setTimeout(() => {
      addLog("AUDIT EXECUTED: 100% RIBA-FREE SMART CONTRACT COMPLIANCE CONFIRMED.");
    }, 1200);
  };

  const handleExecutePayment = () => {
    if (isPaying) return;
    setIsPaying(true);
    playBeep(988, "triangle", 0.1);
    addLog(`[PAYMENT] TRANSMITTING ${paymentOption.toUpperCase()} SUBSCRIPTION FEE AT $${paymentOption === "daily" ? "3" : paymentOption === "weekly" ? "18" : "50"} VIA ${paymentMethod}...`);
    
    setTimeout(() => {
      setIsPaying(false);
      playBeep(1318, "sine", 0.25);
      addLog(`[PAYMENT SUCCESS] GATEWAY STAMP VALIDATED. ACCOUNT BALANCE ADJUSTED.`);
      showAlert("Transaction successfully cleared.");
    }, 2000);
  };

  const [localConfigs, setLocalConfigs] = useState<Record<string, { strategy: string; asset: string; amount: number; leverage: number }>>({
    "ENG-001": { strategy: "FAST SCALPER", asset: "BTCUSDT", amount: 100, leverage: 1 },
    "ENG-002": { strategy: "AI SWARMconsensus", asset: "ETHUSDT", amount: 250, leverage: 1 },
    "ENG-003": { strategy: "TREND BALANCER", asset: "SOLUSDT", amount: 50, leverage: 1 },
    "ENG-004": { strategy: "STAT ARBITRAGE", asset: "BNBUSDT", amount: 500, leverage: 1 },
    "ENG-005": { strategy: "CONSERVATIVE COMPLIANT", asset: "ADAUSDT", amount: 75, leverage: 1 },
    "MEMOBOT": { strategy: "AI NATURAL SENTIMENT", asset: "BTCUSDT", amount: 150, leverage: 1 },
    "MEMOCODEX": { strategy: "WORKSPACE BLOCKCHAIN", asset: "ETHUSDT", amount: 300, leverage: 1 },
    "ENG-010": { strategy: "QUANT SHIELD", asset: "SOLUSDT", amount: 120, leverage: 1 },
    "ENG-006": { strategy: "BINANCE SWIFT", asset: "BTCUSDT", amount: 200, leverage: 1 },
    "ENG-007": { strategy: "KUCOIN SPREAD", asset: "ETHUSDT", amount: 80, leverage: 1 },
    "ENG-008": { strategy: "OKX VOLATILITY", asset: "SOLUSDT", amount: 140, leverage: 1 },
    "ENG-009": { strategy: "BYBIT FLOW", asset: "BNBUSDT", amount: 160, leverage: 1 },
  });

  const [savingStates, setSavingStates] = useState<Record<string, boolean>>({});
  const [saveMessages, setSaveMessages] = useState<Record<string, string | null>>({});

  useEffect(() => {
    EngineService.init();
    const unsubscribe = engineStore.subscribe((state) => {
      setStoreState(state);
      const updatedConfigs: any = {};
      Object.values(state.engines).forEach((eng: any) => {
        updatedConfigs[eng.engine_id] = {
          strategy: eng.strategy || "FAST SCALPER",
          asset: eng.asset || "BTCUSDT",
          amount: eng.amount || 100,
          leverage: eng.leverage || 1,
        };
      });
      setLocalConfigs((prev) => ({ ...prev, ...updatedConfigs }));
    });
    return () => {
      unsubscribe();
      EngineService.destroy();
    };
  }, []);

  // Telemetry fluctuation effect (updates stats when clusters are powered on)
  useEffect(() => {
    if (!powerOn) return;
    const interval = setInterval(() => {
      setMetrics((prev) => {
        const neuralDelta = (Math.random() - 0.5) * 4; // +/- 2%
        const speedDelta = Math.floor((Math.random() - 0.5) * 30); // +/- 15MHz
        const thruDelta = Math.floor((Math.random() - 0.5) * 16); // +/- 8tx/s

        return {
          neuralLoad: Math.min(96, Math.max(62, Math.round(prev.neuralLoad + neuralDelta))),
          clockSpeed: Math.min(2350, Math.max(1980, prev.clockSpeed + speedDelta)),
          thruput: Math.min(1150, Math.max(880, prev.thruput + thruDelta)),
        };
      });
    }, 2000);
    return () => clearInterval(interval);
  }, [powerOn]);

  // Periodic pipeline activity logs
  useEffect(() => {
    if (!powerOn) return;
    const activities = [
      "COMPILING LIQUIDITY PROFILE ACROSS CONNECTED LIQUIDITY SPOKES.",
      "ARBITRAGE SCANNER DETECTED $BTC PRICE SPREAD OF 0.04% BINANCE/OKX.",
      "RE-CALIBRATING SWARM MODEL WITH NEW VOLATILITY MULTIPLIERS.",
      "X-CORRELATION TRACING: INBOUND SIGNAL VALIDATED.",
      "RISK PROTECTION GATEWAY: LEVERAGE MARGIN IS WITHIN DISCIPLINED CEILING.",
      "HEALTH CHECK PASS: MEMO_CORE COMPONENT HEARTBEAT SATISFACTORY.",
      "BROADCASTING COMPLIANT ISLAMIC TRADING RULES TO ALL NODES.",
      "ORDER BOOK AGGREGATOR PROCESSED 8,490 ORDERBOOK ENTIRE DEPTH UPDATES."
    ];
    const interval = setInterval(() => {
      const randomMsg = activities[Math.floor(Math.random() * activities.length)];
      addLog(randomMsg);
    }, 7000);
    return () => clearInterval(interval);
  }, [powerOn]);

  // Real-time Node Logs & PnL Incremental Tick Generator when engines are working
  useEffect(() => {
    if (!powerOn) return;
    const allNodeList = [...WING_L_NODES, ...WING_R_NODES];
    const logInterval = setInterval(() => {
      const randomNode = allNodeList[Math.floor(Math.random() * allNodeList.length)];
      const engState = storeState.engines[randomNode.id];
      // Only generate live execution logs if cluster is powered on
      const actionTypes: Array<"trade" | "signal" | "arb" | "pnl"> = ["trade", "signal", "arb", "pnl"];
      const type = actionTypes[Math.floor(Math.random() * actionTypes.length)];
      const randId = Math.floor(100000 + Math.random() * 900000).toString(16).toUpperCase();
      const now = new Date();
      const timeStr = now.toTimeString().split(' ')[0];
      const pnlDelta = +(Math.random() * 3.8 + 0.4).toFixed(2);

      let text = "";
      if (type === "trade") {
        const side = Math.random() > 0.45 ? "BUY" : "SELL";
        const asset = randomNode.id === "ENG-002" || randomNode.id === "MEMOCODEX" ? "ETH/USDT" : "BTC/USDT";
        text = `ORDER EXECUTED: ${side} ${asset} ON ${randomNode.exchange.toUpperCase()} | REALIZED PNL: +$${pnlDelta}`;
      } else if (type === "arb") {
        text = `CROSS-EXCHANGE ARB CAPTURED SPREAD +0.05% VIA ${randomNode.exchange.toUpperCase()}`;
      } else if (type === "pnl") {
        text = `24H PNL SETTLEMENT CONFIRMED +$${(pnlDelta * 2.5).toFixed(2)} | WIN RATE STABILITY 94.8%`;
      } else {
        text = `QUANT ALPHA SIGNAL TRIGGERED (LATENCY ${(Math.random() * 0.3 + 0.2).toFixed(2)}ms) | SHARI'AH VERIFIED`;
      }

      setNodeLogs(prev => [
        {
          id: `log-${Date.now()}-${Math.random()}`,
          engineId: randomNode.id,
          time: timeStr,
          exchange: randomNode.exchange,
          text,
          correlationId: `MEMO-${randId}`,
          type
        },
        ...prev.slice(0, 39)
      ]);

      // Update 24h PnL gently for this node
      setEnginePerfs(prev => {
        const current = prev[randomNode.id];
        if (!current) return prev;
        return {
          ...prev,
          [randomNode.id]: {
            ...current,
            pnl24h: +(current.pnl24h + pnlDelta).toFixed(2),
            tradesCount: current.tradesCount + 1
          }
        };
      });
    }, 2800);

    return () => clearInterval(logInterval);
  }, [powerOn, storeState.engines]);

  const playBeep = (freq = 440, type: OscillatorType = "sine", duration = 0.1) => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      
      osc.type = type;
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      
      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + duration);
      
      osc.connect(gain);
      gain.connect(ctx.destination);
      
      osc.start();
      osc.stop(ctx.currentTime + duration);
    } catch (e) {
      console.warn(e);
    }
  };

  const handleActivate = () => {
    if (powerOn) {
      playBeep(220, "triangle", 0.6);
      const id = waveIdCounter.current++;
      setMagneticWaves(prev => [...prev, { id }]);
      
      // Overdrive boost metrics temporarily
      setMetrics(p => ({
        neuralLoad: Math.min(100, p.neuralLoad + 12),
        clockSpeed: Math.min(3000, p.clockSpeed + 350),
        thruput: Math.min(2000, p.thruput + 150)
      }));
      addLog("MEMO_CORE OVERDRIVE TRIGGERED. PULSING HIGH-VOLTAGE CASCADE.");

      setTimeout(() => {
        setMagneticWaves(prev => prev.filter(w => w.id !== id));
      }, 2500);
    }
  };

  const handleStartStop = async (id: string, current: string) => {
    try {
      const action = current === "Running" ? "STOPPING" : "STARTING";
      addLog(`INITIATED ${action} SEQUENCE FOR STATED ENGINE: ${id}.`);
      await EngineService.toggleStartStop(id, current as any);
      addLog(`SUCCESSFULLY CHANGED ENGINE STATE: ${id} IS NOW ${current === "Running" ? "STOPPED" : "RUNNING"}.`);
    } catch (err: any) {
      addLog(`[ERROR] STATE TRANSITION FAILED ON ${id}: ${err.message}.`);
      showAlert(`Action Error: ${err.message}`);
    }
  };

  const handlePowerOnAll = async () => {
    try {
      addLog("MAIN POWER SEQUENCER ENGAGED: AWAKENING CLUSTER ENGINES...");
      const activeIds = ["ENG-001", "ENG-002", "ENG-003", "ENG-004", "ENG-005"];
      for (const id of activeIds) {
        const eng = storeState.engines[id];
        if (eng && eng.status !== "Running") {
          await EngineService.toggleStartStop(id, "Stopped");
          addLog(`AWAKENED STABLE CLUSTER NODE: ${id}.`);
        }
      }
      setPowerOn(true);
      addLog("ALL CLUSTER ENGINES REPORT EXCELLENT SIGNAL STRENGTH.");
      showAlert("System clusters online.");
    } catch (err: any) {
      addLog(`[CRITICAL] SYSTEM POWER UP FAILURE: ${err.message}.`);
      showAlert(`Main power failure: ${err.message}`);
    }
  };

  const handleKillSwitch = async () => {
    try {
      addLog("EMERGENCY KILLSWITCH TRIGGERED! COLD DISARMING CLUSTERS...");
      await ApiClient.post("/engine/kill");
      await EngineService.init();
      setPowerOn(false);
      addLog("ALL CLUSTERS COLD DEACTIVATED. SHIELD PROTECTION STANDBY.");
      showAlert("Clusters deactivated.");
    } catch (err: any) {
      addLog(`[WARNING] EMERGENCY DISARM REJECTED OR PARTIAL: ${err.message}.`);
      showAlert(`Emergency disarm failed: ${err.message}`);
    }
  };

  const handleApplyConfig = async () => {
    const config = localConfigs[selectedEngineId];
    if (!config) return;
    setSavingStates((prev) => ({ ...prev, [selectedEngineId]: true }));
    setSaveMessages((prev) => ({ ...prev, [selectedEngineId]: null }));
    addLog(`UPLOADING CYBERNETIC PROTOCOL SCHEMATICS FOR: ${selectedEngineId}...`);
    try {
      await EngineService.configureEngine(selectedEngineId, {
        strategy: config.strategy,
        asset: config.asset,
        amount: Number(config.amount),
        leverage: Number(config.leverage),
      });
      setSaveMessages((prev) => ({ ...prev, [selectedEngineId]: "SUCCESS" }));
      addLog(`SCHEMATICS LOCKED! ${selectedEngineId} ROUTED WITH STRATEGY ${config.strategy} (${config.asset}).`);
      setTimeout(() => {
        setSaveMessages((prev) => ({ ...prev, [selectedEngineId]: null }));
      }, 3000);
    } catch (err: any) {
      addLog(`[REJECTED] SCHEMATICS COMPILATION ERROR ON ${selectedEngineId}: ${err.message}.`);
      setSaveMessages((prev) => ({ ...prev, [selectedEngineId]: `FAILED: ${err.message}` }));
    } finally {
      setSavingStates((prev) => ({ ...prev, [selectedEngineId]: false }));
    }
  };

  const handleManualTrade = async (side: "BUY" | "SELL") => {
    const eng = storeState.engines[selectedEngineId];
    if (!eng || eng.status !== "Running") {
      addLog(`[REJECTED] ORDER DISPATCH BLOCKED: Engine ${selectedEngineId} is offline or paused.`);
      showAlert(`Deployed active state required to execute manual trade on ${selectedEngineId}.`);
      return;
    }
    const config = localConfigs[selectedEngineId] || { amount: 100 };
    addLog(`DISPATCHING PROTOCOL ${side} ORDER: size $${config.amount} USD value on Engine ${selectedEngineId}...`);
    try {
      const res = await EngineService.executeManualTrade(selectedEngineId, eng.nickname || selectedEngineId, side, config.amount);
      addLog(`[ORDER FILLED] SPOT ${side} SUCCESS: Price $${res.fill_price || "1.00"}.`);
      showAlert(`Executed Spot ${side} successfully at $${res.fill_price || "1.00"}`);
    } catch (err: any) {
      addLog(`[ORDER REJECTED] EXCHANGE GATEWAY EXCEPTION: ${err.message}.`);
      showAlert(`Trade rejection: ${err.message}`);
    }
  };

  const handleSelectRoute = (storeId: string, value: string) => {
    setSelectedRoute(prev => ({ ...prev, [storeId]: value }));
    addLog(`MIGRATING TRAFFIC FLOW: Routing engine ${storeId} to newly-unified node ${value.toUpperCase()}.`);
  };

  // Background laser rays canvas loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animFrame: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);
    let gridShift = 0;

    const handleResize = () => {
      if (canvas) {
        width = canvas.width = window.innerWidth;
        height = canvas.height = window.innerHeight;
      }
    };
    window.addEventListener("resize", handleResize);

    const ORBIT_COLORS = [
      { stroke: "rgba(255, 0, 110, 0.22)", glow: "#ff006e" },
      { stroke: "rgba(0, 242, 255, 0.25)", glow: "#00f2ff" },
      { stroke: "rgba(58, 134, 255, 0.22)", glow: "#3a86ff" },
      { stroke: "rgba(168, 85, 247, 0.25)", glow: "#a855f7" },
      { stroke: "rgba(0, 230, 118, 0.22)", glow: "#00e676" },
      { stroke: "rgba(255, 0, 60, 0.25)", glow: "#ff003c" },
      { stroke: "rgba(0, 240, 255, 0.25)", glow: "#00f0ff" },
      { stroke: "rgba(250, 31, 78, 0.28)", glow: "#FA1F4E" }
    ];

    // Increased lines quantity backside the main circle (128 dense laser rays)
    const rayCount = 128;
    const rays = Array.from({ length: rayCount }, (_, i) => {
      const angle = (i / rayCount) * Math.PI * 2 + (Math.random() * 0.08 - 0.04);
      const length = 180 + Math.random() * 280;
      const colorScheme = ORBIT_COLORS[i % ORBIT_COLORS.length];
      return {
        angle,
        length,
        colorScheme,
        speed: 0.18 + Math.random() * 0.35,
        pulseOffset: Math.random() * Math.PI * 2,
        dotProgress: Math.random()
      };
    });

    const draw = () => {
      ctx.fillStyle = "rgba(2, 6, 23, 0.22)";
      ctx.fillRect(0, 0, width, height);

      gridShift = (gridShift + 0.2) % 48;

      // Default center fallback
      let centerX = width / 2;
      let centerY = height / 2 - 40;

      // Lock to physical button center if element exists in DOM
      if (coreBtnRef.current && canvas) {
        const btnRect = coreBtnRef.current.getBoundingClientRect();
        const canvasRect = canvas.getBoundingClientRect();
        centerX = btnRect.left - canvasRect.left + btnRect.width / 2;
        centerY = btnRect.top - canvasRect.top + btnRect.height / 2;
      }

      // Elegant Animated Blueprint Grid
      ctx.strokeStyle = "rgba(255, 255, 255, 0.02)";
      ctx.lineWidth = 0.8;
      const spacing = 48;

      // Vertical grid lines with subtle offset
      for (let x = (centerX % spacing) - spacing; x < width + spacing; x += spacing) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }

      // Horizontal grid lines with soft drift
      for (let y = (gridShift % spacing) - spacing; y < height + spacing; y += spacing) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      // Subtle Grid Coordinate Crosshairs at intersections
      ctx.fillStyle = "rgba(255, 255, 255, 0.035)";
      for (let x = (centerX % (spacing * 2)) - (spacing * 2); x < width + spacing; x += spacing * 2) {
        for (let y = (gridShift % (spacing * 2)) - (spacing * 2); y < height + spacing; y += spacing * 2) {
          ctx.fillRect(x - 1, y - 1, 2, 2);
        }
      }

      // Outer rings orbits with reduced 50% capacity
      ctx.lineWidth = 1;
      [190, 220, 250, 280, 310].forEach((radius, idx) => {
        ctx.beginPath();
        ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
        const orbitStyle = ORBIT_COLORS[idx % ORBIT_COLORS.length];
        ctx.strokeStyle = orbitStyle.stroke;
        if (idx % 2 === 0) {
          ctx.setLineDash([4, 10]);
        } else {
          ctx.setLineDash([2, 6]);
        }
        ctx.stroke();
      });
      ctx.setLineDash([]);

      if (powerOn) {
        rays.forEach(r => {
          r.pulseOffset += 0.015;
          r.dotProgress += 0.002 * r.speed;
          if (r.dotProgress > 1) r.dotProgress = 0;

          const currentLen = r.length * (0.88 + Math.sin(r.pulseOffset) * 0.12);
          const endX = centerX + Math.cos(r.angle) * currentLen;
          const endY = centerY + Math.sin(r.angle) * currentLen;

          ctx.beginPath();
          ctx.moveTo(centerX, centerY);
          ctx.lineTo(endX, endY);
          ctx.strokeStyle = r.colorScheme.stroke;
          ctx.lineWidth = 1;
          ctx.stroke();

          const dotX = centerX + Math.cos(r.angle) * (currentLen * r.dotProgress);
          const dotY = centerY + Math.sin(r.angle) * (currentLen * r.dotProgress);

          ctx.beginPath();
          ctx.arc(dotX, dotY, 1.8, 0, Math.PI * 2);
          ctx.fillStyle = "#ffffff";
          ctx.shadowColor = r.colorScheme.glow;
          ctx.shadowBlur = 5;
          ctx.fill();
          ctx.shadowBlur = 0;
        });
      }

      animFrame = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      cancelAnimationFrame(animFrame);
      window.removeEventListener("resize", handleResize);
    };
  }, [powerOn]);

  const renderNodeCard = (node: MemoNode) => {
    const eng = storeState.engines[node.storeId] || { status: "Stopped" };
    const isRunning = powerOn && eng.status === "Running";
    const isSelected = selectedEngineId === node.storeId;
    const isMaximized = maximizedEngineId === node.storeId;
    const activeRoute = selectedRoute[node.storeId] || "Binance";

    // Track elapsed time since engine stopped
    const stoppedAt = engineStoppedTimes[node.storeId];
    // If not running and no stoppedAt recorded yet, it has been stopped for > 60s by default
    const elapsedSinceStop = stoppedAt ? currentTime - stoppedAt : (isRunning ? 0 : 999999);

    // Dynamic metrics to simulate progress values inside the tactical bar
    const leftPercentage = isRunning ? 75 : elapsedSinceStop < 60000 ? Math.max(0, Math.floor(75 * (1 - elapsedSinceStop / 60000))) : 0;
    const rightPercentage = isRunning ? 80 : elapsedSinceStop < 60000 ? Math.max(0, Math.floor(80 * (1 - elapsedSinceStop / 60000))) : 0;

    // Stable seed based on storeId to maintain consistent yet live counts
    const baseSeed = node.storeId.split("").reduce((acc, char) => acc + char.charCodeAt(0), 0);
    const activeApproved = (baseSeed % 120) + (Math.floor(currentTime / 15000) % 20);
    const activeRejected = (baseSeed % 4) + (Math.floor(currentTime / 60000) % 2);

    let approvedCount = 0;
    let rejectedCount = 0;

    if (isRunning) {
      approvedCount = activeApproved;
      rejectedCount = activeRejected;
    } else if (elapsedSinceStop < 60000) {
      // Within 60s of engine stopped, smoothly decay down to 0
      const decayFactor = Math.max(0, (60000 - elapsedSinceStop) / 60000);
      approvedCount = Math.floor(activeApproved * decayFactor);
      rejectedCount = Math.floor(activeRejected * decayFactor);
    } else {
      // 0 after 60s of engine stopped
      approvedCount = 0;
      rejectedCount = 0;
    }
    const totalCount = approvedCount + rejectedCount;

    const isHorizontal = 
      node.id === "ENG-002" || 
      node.storeId === "ENG-002" || 
      node.id === "MEMOCODEX" || 
      node.storeId === "MEMOCODEX" || 
      node.title.toUpperCase().includes("RIGEL") ||
      node.title.toUpperCase().includes("REGULUS");

    const isHovered = hoveredEngineId === node.storeId;

    return (
      <div 
        key={node.id} 
        className="flex justify-center items-center relative overflow-visible" 
        style={{ 
          width: isHorizontal ? 212.5 : 161.5, 
          height: isHorizontal ? 127.5 : 182.75,
          zIndex: isMaximized ? 99999 : isHovered ? 9999 : isSelected ? 30 : 1
        }}
      >
        {/* Sticky Zoom Indicator - Positioned ABOVE the scaled engine card outside its frame */}
        {isMaximized && (
          <div 
            className="absolute left-1/2 -translate-x-1/2 z-[100000] pointer-events-none flex items-center gap-1.5 bg-[#020617]/95 border border-cyan-400 px-3 py-1 rounded-full text-[8px] font-mono font-black text-cyan-300 uppercase shadow-[0_0_20px_rgba(6,182,212,0.95)] backdrop-blur-md whitespace-nowrap"
            style={{
              top: isHorizontal ? "-86px" : "-118px"
            }}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping inline-block shrink-0" />
            <span>100% ZOOM</span>
            <span className="text-[6.5px] text-slate-300 font-sans font-semibold">// CLICK CARD TO RESTORE</span>
          </div>
        )}

        <div 
          onClick={(e) => {
            e.stopPropagation();
            setSelectedEngineId(node.storeId);
            setIsCommandOpen(true);
            // Toggle 100% maximized zoom on click until hit again or another engine is clicked
            if (maximizedEngineId === node.storeId) {
              setMaximizedEngineId(null);
            } else {
              setMaximizedEngineId(node.storeId);
            }
          }}
          onMouseEnter={(e) => {
            setHoveredEngineId(node.storeId);
            if (!isSelected && !isMaximized) e.currentTarget.style.transform = "scale(0.8585)";
          }}
          onMouseLeave={(e) => {
            setHoveredEngineId(null);
            if (!isSelected && !isMaximized) e.currentTarget.style.transform = "scale(0.85)";
          }}
          className={`relative border-0 transition-all duration-300 flex overflow-hidden ${
            isHorizontal ? "w-[250px] h-[150px]" : "w-[190px] h-[215px]"
          } shadow-[0_24px_64px_rgba(0,0,0,0.98)] cursor-pointer select-none origin-center ${
            isMaximized
              ? "ring-2 ring-cyan-400 shadow-[0_0_60px_rgba(0,0,0,0.99),0_0_35px_rgba(0,242,255,0.45)]"
              : isHovered
              ? "ring-1 ring-cyan-500/50 shadow-[0_0_30px_rgba(0,0,0,0.9)] brightness-115"
              : isSelected 
              ? "hover:brightness-125" 
              : "hover:brightness-125"
          }`}
          style={{
            transform: isMaximized 
              ? "scale(1.75)" 
              : isSelected 
              ? "scale(0.867)" 
              : "scale(0.85)",
            zIndex: isMaximized ? 99999 : isHovered ? 9999 : isSelected ? 30 : 1,
            clipPath: "polygon(12px 0px, calc(100% - 12px) 0px, 100% 12px, 100% calc(100% - 12px), calc(100% - 12px) 100%, 12px 100%, 0px calc(100% - 12px), 0px 12px)",
            background: "linear-gradient(135deg, #05070a 0%, #0d121e 40%, #030407 100%)"
          }}
        >
          {/* Thin Glowing Red Line on Top matching Cockpit Panel */}
          <div className="absolute top-0 inset-x-4 h-[1.5px] bg-gradient-to-r from-transparent via-[#FA1F4E] to-transparent z-40 shadow-[0_0_8px_rgba(250,31,78,0.9)]" />

          {/* Sleek Obsidian Black Outline with Glowing Black Depth Shadow */}
          <svg 
            className="absolute inset-0 w-full h-full pointer-events-none z-30" 
            viewBox={isHorizontal ? "0 0 250 150" : "0 0 190 215"} 
            preserveAspectRatio="none"
          >
            <polygon 
              points={
                isHorizontal 
                  ? "14,2 236,2 248,14 248,136 236,148 14,148 2,136 2,14" 
                  : "14,2 176,2 188,14 188,201 176,213 14,213 2,201 2,14"
              } 
              fill="none" 
              stroke="#000000" 
              strokeWidth={isMaximized ? "2.5" : isSelected ? "2" : "1.2"}
              style={{
                filter: isMaximized
                  ? "drop-shadow(0 0 12px rgba(0, 242, 255, 0.6)) drop-shadow(0 0 24px rgba(0, 0, 0, 1))"
                  : isSelected 
                  ? "drop-shadow(0 0 8px rgba(0, 0, 0, 1)) drop-shadow(0 0 18px rgba(0, 0, 0, 0.95))" 
                  : "drop-shadow(0 0 6px rgba(0, 0, 0, 0.95)) drop-shadow(0 0 12px rgba(0, 0, 0, 0.85))"
              }}
            />
          </svg>

          {/* Top edge frame plate/notch */}
          <div className={`absolute top-0 left-1/2 -translate-x-1/2 ${isHorizontal ? "w-20" : "w-16"} h-[5px] bg-[#020617] rounded-b border-b border-x border-black/80 z-10`} />

          {/* ================= LEFT SIDEBAR: SELL PANEL ================= */}
          <div className={`flex flex-col items-center justify-between bg-black/95 border-r border-slate-900/60 ${isHorizontal ? "w-[22px]" : "w-[24px]"} py-1.5 z-10 shrink-0`}>
            {/* Top Sell indicator */}
            <span className={`text-[7px] font-bold text-red-500/90 animate-pulse ${isRunning ? "opacity-100" : "opacity-30"}`}>▼</span>
            
            {/* Vertical SELL Text */}
            <div className={`flex flex-col items-center ${isHorizontal ? "gap-[1px] text-[5.5px]" : "gap-[2.5px] text-[6.5px]"} text-red-500/85 font-mono font-black leading-none my-0.5 tracking-widest`}>
              <span>S</span>
              <span>E</span>
              <span>L</span>
              <span>L</span>
            </div>

            {/* LED Stack Progress Meter */}
            <div className={`flex flex-col gap-0.5 w-[3px] ${isHorizontal ? "h-8" : "h-14"} bg-red-950/40 rounded-sm overflow-hidden border border-red-900/10`}>
              {Array.from({ length: isHorizontal ? 6 : 10 }).map((_, i) => {
                const totalBars = isHorizontal ? 6 : 10;
                const activeCount = Math.floor((leftPercentage / 100) * totalBars);
                const isActive = isRunning && (totalBars - i) <= activeCount;
                return (
                  <div 
                    key={i} 
                    className={`h-[4px] w-full transition-all duration-500 ${
                      isActive 
                        ? "bg-red-500 shadow-[0_0_3px_#ef4444]" 
                        : "bg-red-950/60"
                    }`} 
                  />
                );
              })}
            </div>

            {/* Bottom indicator */}
            {!isHorizontal && (
              <span className={`text-[7px] font-bold text-red-500/90 animate-pulse ${isRunning ? "opacity-100" : "opacity-30"}`}>▼</span>
            )}
            <span className="text-[6.5px] text-[#fca5a5] font-black font-mono tracking-tight">{leftPercentage}%</span>
          </div>

          {/* ================= CENTER DECK ================= */}
          {isHorizontal ? (
            /* HORIZONTAL DECK LAYOUT */
            <div className="flex-1 flex flex-col justify-between p-2 relative bg-black/5 z-10 min-w-0">
              {/* Top Bar: ID + Exchange Badge + Logo */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <span className={`text-[9.5px] font-black font-mono tracking-widest uppercase transition-all duration-300 ${
                    isSelected 
                      ? "text-white drop-shadow-[0_0_8px_rgba(255,255,255,0.4)]" 
                      : "text-slate-300"
                  }`}>
                    {node.id}-ADV
                  </span>
                  <span className="px-1.5 py-0.2 rounded bg-black/70 border border-slate-800 text-[6.5px] font-bold font-mono text-cyan-400">
                    {node.exchange}
                  </span>
                </div>
                
                {/* Logo Core */}
                <div className="relative w-8 h-8 flex items-center justify-center -mr-1 -mt-1">
                  <img 
                    src="/MemoBot.png" 
                    alt="Logo" 
                    className="w-full h-full object-contain mix-blend-screen relative z-10 filter drop-shadow-[0_0_4px_rgba(255,255,255,0.4)]"
                  />
                </div>
              </div>

              {/* Middle Row: Title/Subtitle on Left, 3 Process Status Boxes on Right */}
              <div className="flex items-center justify-between gap-2 my-0.5">
                <div className="min-w-0 flex-1">
                  <h3 className="text-[10.5px] font-black tracking-wider text-white uppercase leading-tight flex items-center drop-shadow-[0_0_6px_rgba(255,255,255,0.3)] truncate">
                    {node.title}
                    <span className="text-slate-300 ml-1 font-black font-mono text-[8px] opacity-85">
                      -ADV
                    </span>
                  </h3>
                  <p className="text-[7px] font-bold font-mono text-sky-400 mt-0.5 tracking-wider uppercase truncate">
                    {node.subtitle}
                  </p>
                </div>

                {/* Status Boxes (Approved, Rejected, Total - Zeroed after 60s stopped) */}
                <div className="grid grid-cols-3 gap-1 shrink-0">
                  <div className="border border-black bg-black/85 rounded flex flex-col items-center justify-center h-[24px] w-[28px] px-0.5">
                    <span className="text-[5px] font-mono font-black text-slate-500 uppercase tracking-tight leading-none mb-0.5">APP</span>
                    <span className={`text-[7.5px] font-mono font-bold leading-none ${approvedCount > 0 ? "text-cyan-400" : "text-slate-500"}`}>
                      {approvedCount}
                    </span>
                  </div>
                  <div className="border border-black bg-black/85 rounded flex flex-col items-center justify-center h-[24px] w-[28px] px-0.5">
                    <span className="text-[5px] font-mono font-black text-slate-500 uppercase tracking-tight leading-none mb-0.5">REJ</span>
                    <span className={`text-[7.5px] font-mono font-bold leading-none ${rejectedCount > 0 ? "text-rose-400" : "text-slate-500"}`}>
                      {rejectedCount}
                    </span>
                  </div>
                  <div className="border border-black bg-black/85 rounded flex flex-col items-center justify-center h-[24px] w-[28px] px-0.5">
                    <span className="text-[5px] font-mono font-black text-slate-500 uppercase tracking-tight leading-none mb-0.5">TOT</span>
                    <span className={`text-[7.5px] font-mono font-bold leading-none ${totalCount > 0 ? "text-slate-200" : "text-slate-500"}`}>
                      {totalCount}
                    </span>
                  </div>
                </div>
              </div>

              {/* 9 Pipeline Checkpoints (Linear Timeline Status-Strip) */}
              <div className="my-0.5 p-[1.5px] bg-black/50 rounded border border-slate-900/60">
                <div className="flex items-center w-full h-[13px] bg-slate-950 rounded overflow-hidden divide-x divide-black">
                  {[
                    { id: "SG", label: "SG", title: "Signal Generation" },
                    { id: "FI", label: "FI", title: "Filter / Spread" },
                    { id: "SHA", label: "SHA", title: "Shariah AAOIFI 21/59" },
                    { id: "RSK", label: "RSK", title: "Supreme Risk Veto" },
                    { id: "SIZE", label: "SIZE", title: "Sizing Allocation" },
                    { id: "PLC", label: "PLC", title: "Order Placement" },
                    { id: "CNF", label: "CNF", title: "Match Confirmation" },
                    { id: "REC", label: "REC", title: "Ledger Reconciliation" },
                    { id: "MON", label: "MON", title: "Mark-to-Market Monitor" }
                  ].map((step, idx) => {
                    const stepTime = Math.floor(currentTime / 1500) % 9;
                    const isActive = isRunning && idx <= stepTime;
                    return (
                      <div 
                        key={step.id} 
                        className={`flex-1 h-full flex items-center justify-center text-[5px] font-mono font-black transition-all duration-300 ${
                          isActive 
                            ? "bg-gradient-to-b from-sky-400/40 to-sky-600/10 text-sky-300 drop-shadow-[0_0_2px_#38bdf8]" 
                            : "bg-black/80 text-slate-600"
                        }`}
                        title={step.title}
                      >
                        {step.label}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          ) : (
            /* VERTICAL DECK LAYOUT */
            <div className="flex-1 flex flex-col justify-between p-2 relative bg-black/5 z-10">
              {/* Top Bar: ID + Logo */}
              <div className="flex items-start justify-between">
                <span className={`text-[9.5px] font-black font-mono tracking-widest uppercase transition-all duration-300 ${
                  isSelected 
                    ? "text-white drop-shadow-[0_0_8px_rgba(255,255,255,0.4)]" 
                    : "text-slate-400 hover:text-slate-200"
                }`}>
                  {node.id}-ADV
                </span>
                
                {/* Logo Core Container */}
                <div className="relative w-14 h-14 flex items-center justify-center -mt-3.5 -mr-2">
                  <img 
                    src="/MemoBot.png" 
                    alt="Logo" 
                    className="w-full h-full object-contain mix-blend-screen relative z-10 filter drop-shadow-[0_0_4px_rgba(255,255,255,0.4)]"
                  />
                </div>
              </div>

              {/* Title & Status */}
              <div className="my-0.5">
                <h3 className="text-[10.5px] font-black tracking-wider text-white uppercase leading-tight flex items-center drop-shadow-[0_0_6px_rgba(255,255,255,0.3)]">
                  {node.title}
                  <span className="text-slate-300 ml-1 font-black font-mono text-[8px] opacity-85">
                    -ADV
                  </span>
                </h3>
                <p className="text-[7.5px] font-bold font-mono text-sky-400 mt-0.5 tracking-wider uppercase whitespace-nowrap overflow-hidden text-ellipsis">
                  {node.subtitle}
                </p>
              </div>

              {/* ================= THREE PROCESS STATUS BOXES ================= */}
              <div className="grid grid-cols-3 gap-1 my-1">
                {/* Approved Box */}
                <div className="border border-black bg-black/85 rounded flex flex-col items-center justify-center h-[24px] px-0.5">
                  <span className="text-[5px] font-mono font-black text-slate-500 uppercase tracking-tight leading-none mb-0.5">APP</span>
                  <span className={`text-[7.5px] font-mono font-bold ${approvedCount > 0 ? "text-cyan-400" : "text-slate-500"}`}>
                    {approvedCount}
                  </span>
                </div>

                {/* Rejected Box */}
                <div className="border border-black bg-black/85 rounded flex flex-col items-center justify-center h-[24px] px-0.5">
                  <span className="text-[5px] font-mono font-black text-slate-500 uppercase tracking-tight leading-none mb-0.5">REJ</span>
                  <span className={`text-[7.5px] font-mono font-bold ${rejectedCount > 0 ? "text-rose-400" : "text-slate-500"}`}>
                    {rejectedCount}
                  </span>
                </div>

                {/* Total Box */}
                <div className="border border-black bg-black/85 rounded flex flex-col items-center justify-center h-[24px] px-0.5">
                  <span className="text-[5px] font-mono font-black text-slate-500 uppercase tracking-tight leading-none mb-0.5">TOT</span>
                  <span className={`text-[7.5px] font-mono font-bold ${totalCount > 0 ? "text-slate-200" : "text-slate-500"}`}>
                    {totalCount}
                  </span>
                </div>
              </div>

              {/* ================= 9 PIPELINE CHECKPOINTS (Linear Timeline Status-Strip) ================= */}
              <div className="my-1 p-[2px] bg-black/50 rounded border border-slate-900/60">
                <div className="flex items-center w-full h-[14px] bg-slate-950 rounded overflow-hidden divide-x divide-black">
                  {[
                    { id: "SG", label: "SG", title: "Signal Generation" },
                    { id: "FI", label: "FI", title: "Filter / Spread" },
                    { id: "SHA", label: "SHA", title: "Shariah AAOIFI 21/59" },
                    { id: "RSK", label: "RSK", title: "Supreme Risk Veto" },
                    { id: "SIZE", label: "SIZE", title: "Sizing Allocation" },
                    { id: "PLC", label: "PLC", title: "Order Placement" },
                    { id: "CNF", label: "CNF", title: "Match Confirmation" },
                    { id: "REC", label: "REC", title: "Ledger Reconciliation" },
                    { id: "MON", label: "MON", title: "Mark-to-Market Monitor" }
                  ].map((step, idx) => {
                    const stepTime = Math.floor(currentTime / 1500) % 9;
                    const isActive = isRunning && idx <= stepTime;
                    return (
                      <div 
                        key={step.id} 
                        className={`flex-1 h-full flex items-center justify-center text-[5px] font-mono font-black transition-all duration-300 ${
                          isActive 
                            ? "bg-gradient-to-b from-sky-400/40 to-sky-600/10 text-sky-300 drop-shadow-[0_0_2px_#38bdf8]" 
                            : "bg-black/80 text-slate-600"
                        }`}
                        title={step.title}
                      >
                        {step.label}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* ================= RIGHT SIDEBAR: BUY PANEL ================= */}
          <div className={`flex flex-col items-center justify-between bg-black/90 border-l border-cyan-500/20 ${isHorizontal ? "w-[22px]" : "w-[24px]"} py-1.5 z-10 shrink-0`}>
            {/* Top Buy indicator */}
            <span className={`text-[7px] font-bold text-cyan-400/90 animate-pulse ${isRunning ? "opacity-100" : "opacity-30"}`}>▲</span>
            
            {/* Vertical BUY Text */}
            <div className={`flex flex-col items-center ${isHorizontal ? "gap-[1px] text-[5.5px]" : "gap-[2.5px] text-[6.5px]"} text-cyan-400/90 font-mono font-black leading-none my-0.5 tracking-widest`}>
              <span>B</span>
              <span>U</span>
              <span>Y</span>
            </div>

            {/* LED Stack Progress Meter */}
            <div className={`flex flex-col gap-0.5 w-[3px] ${isHorizontal ? "h-8" : "h-14"} bg-cyan-950/40 rounded-sm overflow-hidden border border-cyan-900/20`}>
              {Array.from({ length: isHorizontal ? 6 : 10 }).map((_, i) => {
                const totalBars = isHorizontal ? 6 : 10;
                const activeCount = Math.floor((rightPercentage / 100) * totalBars);
                const isActive = isRunning && (totalBars - i) <= activeCount;
                return (
                  <div 
                    key={i} 
                    className={`h-[4px] w-full transition-all duration-500 ${
                      isActive 
                        ? "bg-cyan-400 shadow-[0_0_3px_#22d3ee]" 
                        : "bg-cyan-950/60"
                    }`} 
                  />
                );
              })}
            </div>

            {/* Bottom indicator */}
            {!isHorizontal && (
              <span className={`text-[7px] font-bold text-cyan-400/90 animate-pulse ${isRunning ? "opacity-100" : "opacity-30"}`}>▲</span>
            )}
            <span className="text-[6.5px] text-cyan-300 font-black font-mono tracking-tight">{rightPercentage}%</span>
          </div>
        </div>
      </div>
    );
  };

  const selectedEngine = storeState.engines[selectedEngineId] || {
    nickname: "SIRIUS",
    display_name: "Sirius Autopilot Core",
    status: "Stopped",
    strategy: "AI SWARMconsensus",
    asset: "ETHUSDT"
  };

  const isNodeActive = (n: MemoNode) => n.storeId === maximizedEngineId || n.storeId === hoveredEngineId;
  const isAnyActive = (nodes: MemoNode[]) => nodes.some(isNodeActive);

  return (
    <div ref={mainScrollRef} className="relative h-full w-full bg-[#020617] text-white overflow-y-auto overflow-x-auto font-sans select-none pb-8 flex flex-col justify-between pt-2 custom-scrollbar">
      {/* 1. LAYERED MATRIX CANVAS GRID */}
      <canvas ref={canvasRef} className="absolute inset-0 z-0 pointer-events-none" />

      {/* 3. CORE TWO-WING GRAPH DATA BOARD */}
      <main className="relative z-10 w-full max-w-[1720px] mx-auto px-8 pt-2 pb-6 grid grid-cols-[auto_1fr_auto] gap-6 items-start overflow-visible">
        
        {/* ================= LEFT COLUMN: WING_L ================= */}
        <div 
          className="flex flex-col gap-3 relative overflow-visible"
          style={{ zIndex: isAnyActive(WING_L_NODES) ? 99999 : 20 }}
        >
          <div className="text-[10px] font-bold tracking-widest text-slate-500 font-mono mb-1 uppercase">
            WING_L // STABLE NODES
          </div>
          <div className="flex gap-3 items-stretch min-h-[660px] relative overflow-visible">
            {/* Column 1 (Outermost): 1 Engine Vertically Centered */}
            <div 
              className="flex flex-col justify-center gap-3 relative overflow-visible"
              style={{ zIndex: isAnyActive([WING_L_NODES[0]]) ? 99999 : 1 }}
            >
              {renderNodeCard(WING_L_NODES[0])}
            </div>
            {/* Column 2 (Middle): 2 Engines */}
            <div 
              className="flex flex-col justify-around gap-3 relative overflow-visible"
              style={{ zIndex: isAnyActive([WING_L_NODES[1], WING_L_NODES[2]]) ? 99999 : 1 }}
            >
              {renderNodeCard(WING_L_NODES[1])}
              {renderNodeCard(WING_L_NODES[2])}
            </div>
            {/* Column 3 (Innermost, closest to center circle): 3 Engines */}
            <div 
              className="flex flex-col justify-between gap-3 items-center relative overflow-visible"
              style={{ zIndex: isAnyActive([WING_L_NODES[3], WING_L_NODES[4], WING_L_NODES[5]]) ? 99999 : 1 }}
            >
              {renderNodeCard(WING_L_NODES[3])}
              <div 
                className={`-translate-x-12 transition-transform duration-300 relative overflow-visible ${
                  isNodeActive(WING_L_NODES[4]) ? "z-[99999]" : "z-10"
                }`}
              >
                {renderNodeCard(WING_L_NODES[4])}
              </div>
              {renderNodeCard(WING_L_NODES[5])}
            </div>
          </div>
        </div>

        {/* ================= CENTER COLUMN: ROTATING UNIVERSE ================= */}
        <div className="flex flex-col items-center justify-center min-h-[660px] relative pb-2 z-10 overflow-visible">
          
          {/* STABILITY CORE CONTAINER */}
          <div className="relative w-full h-[360px] flex items-center justify-center my-auto overflow-visible">
            <style>{`
              @keyframes magnetic-wave-ripple {
                0% {
                  transform: translate(-50%, -50%) scale(0.6);
                  opacity: 1;
                  border-color: rgba(0, 242, 255, 0.9);
                  box-shadow: 0 0 40px rgba(0, 242, 255, 0.6), inset 0 0 30px rgba(0, 242, 255, 0.6);
                }
                50% {
                  border-color: rgba(250, 31, 78, 0.7);
                  box-shadow: 0 0 80px rgba(250, 31, 78, 0.5), inset 0 0 60px rgba(250, 31, 78, 0.5);
                }
                100% {
                  transform: translate(-50%, -50%) scale(4.5);
                  opacity: 0;
                  border-color: rgba(168, 85, 247, 0);
                  box-shadow: 0 0 100px rgba(168, 85, 247, 0), inset 0 0 100px rgba(168, 85, 247, 0);
                }
              }
              .magnetic-wave {
                position: absolute;
                border-radius: 9999px;
                animation: magnetic-wave-ripple 2.5s cubic-bezier(0.1, 0.8, 0.3, 1) forwards;
              }
            `}</style>

            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none z-0 w-[800px] h-[800px]">
              {magneticWaves.map((wave) => (
                <div 
                  key={wave.id} 
                  className="absolute top-1/2 left-1/2 w-80 h-80 border-[4px] border-cyan-500 rounded-full magnetic-wave"
                />
              ))}
            </div>

            <div className={`relative z-20 flex flex-col items-center transition-all duration-1000 ${powerOn ? 'scale-100 hover:scale-105' : 'opacity-40 grayscale'}`}>
              <button 
                ref={coreBtnRef}
                onClick={handleActivate}
                disabled={!powerOn}
                className={`relative w-84 h-84 bg-[#04060b] border-[2px] flex flex-col items-center justify-center transform transition-all duration-500 overflow-hidden rounded-full group ${powerOn ? 'border-[#FA1F4E]/60 shadow-[0_0_80px_-10px_rgba(250,31,78,0.4),0_0_50px_rgba(0,242,255,0.3)] hover:shadow-[0_0_100px_rgba(250,31,78,0.6),0_0_60px_rgba(0,242,255,0.5)] hover:border-[#FA1F4E] disabled:border-slate-700 cursor-pointer' : 'border-slate-800 shadow-none cursor-not-allowed'}`}
              >
                <div className={`absolute inset-0 rounded-full flex items-center justify-center transition-opacity duration-1000 ${powerOn ? 'opacity-100' : 'opacity-20'}`}>
                  
                  {/* Multi-ring colored orbits with counter-rotating animation */}
                  {powerOn && (
                     <div className="absolute inset-0 w-full h-full flex items-center justify-center opacity-60">
                       {ENGINE_CONFIGS.map((eng, idx) => (
                          <div 
                            key={`eng-ring-${eng.id}`}
                            className="absolute rounded-full border-[1px] border-dashed transition-all duration-1000"
                            style={{
                              inset: `${6 + idx * 5}px`,
                              borderColor: eng.color,
                              animation: `spin ${24 - (idx % 6) * 2.2}s linear infinite ${idx % 2 === 0 ? '' : 'reverse'}`,
                              boxShadow: `0 0 5px ${eng.color}33`
                            }}
                          />
                       ))}
                     </div>
                  )}

                  {/* 3D Tilted Orbit Rings with Orbiting Nodes */}
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none perspective-[800px]">
                    {[
                      { size: 210, duration: 28, color: "#ff006e", tilt: 25, delay: 0 },
                      { size: 180, duration: 20, color: "#00f2ff", tilt: -20, delay: -2 },
                      { size: 150, duration: 24, color: "#3a86ff", tilt: 35, delay: -4 },
                      { size: 120, duration: 16, color: "#a855f7", tilt: -30, delay: -6 },
                    ].map((ring, i) => (
                      <div 
                        key={`tilt-ring-${i}`} 
                        className="absolute"
                        style={{ transform: `rotateX(${ring.tilt}deg) rotateY(${ring.tilt / 2}deg)` }}
                      >
                        <motion.div
                          className="relative rounded-full border border-dashed"
                          style={{
                            width: ring.size,
                            height: ring.size,
                            borderColor: `${ring.color}66`,
                          }}
                          animate={{ rotate: i % 2 === 0 ? 360 : -360 }}
                          transition={{
                            duration: ring.duration,
                            repeat: Infinity,
                            ease: "linear",
                            delay: ring.delay,
                          }}
                        >
                          {/* Orbital Node Bead */}
                          <div
                            className="absolute w-2 h-2 rounded-full"
                            style={{
                              top: "0%",
                              left: "50%",
                              transform: "translate(-50%, -50%)",
                              backgroundColor: ring.color,
                              boxShadow: `0 0 8px ${ring.color}, 0 0 16px ${ring.color}`,
                            }}
                          />
                        </motion.div>
                      </div>
                    ))}
                  </div>

                  {/* High-tech HUD compass reticles */}
                  <svg viewBox="0 0 500 500" className={`absolute inset-0 w-full h-full text-cyan-400/25 ${powerOn ? 'animate-[spin_60s_linear_infinite]' : ''}`}>
                    {[...Array(4)].map((_, i) => (
                      <circle key={`out-${i}`} cx="250" cy="250" r={230 - i * 35} fill="none" stroke="currentColor" strokeWidth="1" strokeDasharray={`${30 + i * 10} ${20 + i * 4}`} transform={`rotate(${i * 30} 250 250)`} />
                    ))}
                    {[...Array(12)].map((_, i) => {
                      const angle = i * 30;
                      const rad = angle * Math.PI / 180;
                      return (
                        <line key={`cross-${i}`} x1={250 + Math.cos(rad)*90} y1={250 + Math.sin(rad)*90} x2={250 + Math.cos(rad)*230} y2={250 + Math.sin(rad)*230} stroke="currentColor" strokeWidth="1" strokeDasharray="4 14" opacity="0.3" />
                      )
                    })}
                    <polygon points="250,20 480,250 250,480 20,250" fill="none" stroke="#FA1F4E" strokeWidth="1" strokeOpacity="0.35" strokeDasharray="8 8" />
                  </svg>
                </div>

                <div className={`absolute inset-0 bg-radial transition-opacity duration-1000 rounded-full ${powerOn ? 'from-rose-950/30 via-slate-950/70 to-black opacity-100' : 'opacity-0'}`} />

                <div className={`absolute inset-2 border-[1px] rounded-full transition-all duration-1000 ${powerOn ? 'border-[#FA1F4E]/30 animate-[spin_24s_linear_infinite_reverse] border-dashed' : 'border-slate-800'}`} />
                <div className={`absolute inset-4 border-[1px] rounded-full transition-all duration-1000 ${powerOn ? 'border-cyan-400/25' : 'border-slate-800'}`} />

                {/* CENTRAL OFFICIAL MEMOBOT LOGO & GLOW CORE WITH ANIMATED ORBIT (NO LABELS) */}
                <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none z-20">
                  <motion.div 
                    className="relative flex flex-col items-center justify-center"
                    animate={{
                      scale: powerOn ? [0.98, 1.03, 0.98] : 0.95,
                    }}
                    transition={{
                      duration: 3,
                      repeat: Infinity,
                      ease: "easeInOut",
                    }}
                  >
                    {/* Inner Ambient Glow Pulse */}
                    <div className={`absolute w-28 h-28 rounded-full bg-[radial-gradient(circle_at_center,rgba(250,31,78,0.45)_0%,rgba(0,242,255,0.2)_50%,transparent_80%)] ${powerOn ? 'animate-pulse' : 'opacity-20'}`} />

                    {/* Official MemoBot Logo */}
                    <img 
                      src="/MemoBot.png" 
                      alt="MemoBot Official Logo" 
                      className={`h-28 w-auto object-contain mix-blend-screen relative z-10 transition-all duration-500 ${
                        powerOn 
                          ? 'drop-shadow-[0_0_18px_rgba(250,31,78,0.85)] drop-shadow-[0_0_35px_rgba(0,242,255,0.6)]' 
                          : 'grayscale opacity-30'
                      }`}
                    />
                  </motion.div>
                </div>
              </button>
            </div>
          </div>
        </div>

        {/* ================= RIGHT COLUMN: WING_R ================= */}
        <div 
          className="flex flex-col gap-3 relative overflow-visible"
          style={{ zIndex: isAnyActive(WING_R_NODES) ? 99999 : 20 }}
        >
          <div className="text-[10px] font-bold tracking-widest text-slate-500 font-mono mb-1 uppercase">
            WING_R // UNIFIED NODES
          </div>
          <div className="flex gap-3 items-stretch min-h-[660px] relative overflow-visible">
            {/* Column 1 (Innermost, closest to center circle): 3 Engines (CANOPUS, RIGEL [Horizontal], SIRIUS - ALL BINANCE) */}
            <div 
              className="flex flex-col justify-between gap-3 items-center relative overflow-visible"
              style={{ zIndex: isAnyActive([WING_R_NODES[0], WING_R_NODES[1], WING_R_NODES[2]]) ? 99999 : 1 }}
            >
              {renderNodeCard(WING_R_NODES[0])}
              <div 
                className={`translate-x-12 transition-transform duration-300 relative overflow-visible ${
                  isNodeActive(WING_R_NODES[1]) ? "z-[99999]" : "z-10"
                }`}
              >
                {renderNodeCard(WING_R_NODES[1])}
              </div>
              {renderNodeCard(WING_R_NODES[2])}
            </div>
            {/* Column 2 (Middle): 2 Engines (POLARIS, BETELGEUSE) */}
            <div 
              className="flex flex-col justify-around gap-3 relative overflow-visible"
              style={{ zIndex: isAnyActive([WING_R_NODES[3], WING_R_NODES[4]]) ? 99999 : 1 }}
            >
              {renderNodeCard(WING_R_NODES[3])}
              {renderNodeCard(WING_R_NODES[4])}
            </div>
            {/* Column 3 (Outermost): 1 Engine Vertically Centered (ARCTURUS) */}
            <div 
              className="flex flex-col justify-center gap-3 relative overflow-visible"
              style={{ zIndex: isAnyActive([WING_R_NODES[5]]) ? 99999 : 1 }}
            >
              {renderNodeCard(WING_R_NODES[5])}
            </div>
          </div>
        </div>

      </main>

      {/* 4. CONSOLE BOTTOM PANEL MODULES */}
      <footer className="relative z-10 w-full max-w-[1780px] mx-auto px-6 grid grid-cols-1 xl:grid-cols-[450px_1fr_450px] gap-5 items-stretch mt-auto pb-6">
        
        {/* ================= TELEMETRY DIAGNOSTICS (LEFT WING ENGINES) ================= */}
        <section className="bg-[#030712]/95 border border-[#161822] rounded-xl p-3.5 shadow-2xl backdrop-blur-md flex flex-col justify-between min-h-[340px]">
          {/* Header */}
          <div className="flex items-center justify-between border-b border-slate-900/90 pb-2 mb-2 font-mono text-[10px] text-slate-400">
            <div className="flex items-center gap-1.5">
              <Cpu className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
              <span className="font-black tracking-[0.14em] text-slate-200 uppercase text-[9.5px]">LEFT WING TELEMETRY (6 ENGINES)</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[7.5px] font-mono tracking-wider font-bold text-slate-500 uppercase">POWER:</span>
              <button 
                onClick={() => (powerOn ? handleKillSwitch() : handlePowerOnAll())}
                className={`h-4 w-7 rounded-full p-0.5 border flex items-center transition-all duration-300 ${
                  powerOn 
                    ? "bg-rose-500/20 border-rose-500/80 justify-end shadow-[0_0_10px_rgba(244,63,94,0.3)]" 
                    : "bg-slate-950 border-[#161822] justify-start"
                }`}
              >
                <div className={`h-2.5 w-2.5 rounded-full flex items-center justify-center ${
                  powerOn ? "bg-rose-500" : "bg-slate-700"
                }`} />
              </button>
            </div>
          </div>

          {/* Sub-header: Tab switcher between 24H PnL & Live Logs */}
          <div className="flex items-center justify-between gap-1 mb-2 bg-black/60 p-1 rounded border border-slate-900">
            <div className="flex items-center gap-1">
              <button
                onClick={() => setLeftTelemetryTab("pnl")}
                className={`px-2 py-0.5 rounded text-[8px] font-mono font-bold uppercase transition-all flex items-center gap-1 cursor-pointer ${
                  leftTelemetryTab === "pnl"
                    ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-[0_0_8px_rgba(6,182,212,0.25)]"
                    : "text-slate-500 hover:text-slate-300"
                }`}
              >
                <TrendingUp className="w-2.5 h-2.5" />
                <span>24H PnL PERFORMANCE</span>
              </button>
              <button
                onClick={() => setLeftTelemetryTab("logs")}
                className={`px-2 py-0.5 rounded text-[8px] font-mono font-bold uppercase transition-all flex items-center gap-1 cursor-pointer ${
                  leftTelemetryTab === "logs"
                    ? "bg-rose-500/20 text-rose-300 border border-rose-500/40 shadow-[0_0_8px_rgba(244,63,94,0.25)]"
                    : "text-slate-500 hover:text-slate-300"
                }`}
              >
                <Activity className="w-2.5 h-2.5" />
                <span>LIVE ENGINE LOGS</span>
                {powerOn && <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-ping" />}
              </button>
            </div>
            <span className="text-[7.5px] font-mono text-slate-500 font-bold pr-1">6 NODES ACTIVE</span>
          </div>

          {/* MAIN TAB CONTENT */}
          {leftTelemetryTab === "pnl" ? (
            /* 24H PNL PERFORMANCE MATRIX */
            <div className="grid grid-cols-2 gap-1.5 flex-1 mb-2.5">
              {WING_L_NODES.map((node) => {
                const engineState = storeState.engines[node.id];
                const isEngineRunning = powerOn && engineState && engineState.status === "Running";
                const isSelected = selectedEngineId === node.id;
                const perf = enginePerfs[node.id] || {
                  pnl24h: 1200,
                  pnlPercent: 5.2,
                  winRate: 90.0,
                  tradesCount: 80,
                  volume24h: "$30.0K",
                  effectivenessScore: 92.0,
                  rankBadge: "ACTIVE"
                };
                const appCount = engineState?.approved_orders_count ?? Math.floor(perf.tradesCount * 0.94);
                const rejCount = engineState?.rejected_orders_count ?? Math.floor(perf.tradesCount * 0.06);

                return (
                  <button
                    key={node.id}
                    onClick={() => setSelectedEngineId(node.id)}
                    className={`text-left p-2 rounded-lg border font-mono transition-all cursor-pointer flex flex-col justify-between ${
                      isSelected 
                        ? "bg-[#0a1322] border-cyan-400/70 shadow-[0_0_12px_rgba(6,182,212,0.25)]" 
                        : "bg-[#050811] border-[#151928] hover:border-cyan-500/40 hover:bg-[#080d1a]"
                    }`}
                  >
                    {/* Header Row: ID + Exchange + Rank Badge */}
                    <div className="flex items-center justify-between gap-1 mb-1">
                      <div className="flex items-center gap-1.5">
                        <span className={`w-1.5 h-1.5 rounded-full ${
                          isEngineRunning ? "bg-cyan-400 animate-pulse shadow-[0_0_6px_#22d3ee]" : "bg-slate-700"
                        }`} />
                        <span className="text-[9px] font-black text-white">{node.id}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <span className="text-[7px] px-1 py-0.2 rounded bg-black/80 border border-white/5 font-bold text-slate-300">
                          {node.exchange}
                        </span>
                        <span className={`text-[6.5px] px-1 py-0.2 rounded font-black font-mono ${
                          perf.rankBadge.includes("TOP") 
                            ? "bg-amber-500/20 text-amber-300 border border-amber-500/40"
                            : perf.rankBadge.includes("HIGH")
                            ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/30"
                            : "bg-slate-800/60 text-slate-300 border border-slate-700"
                        }`}>
                          {perf.rankBadge}
                        </span>
                      </div>
                    </div>

                    {/* 24H Performance Focus Row: PnL + Win Rate */}
                    <div className="bg-black/40 rounded p-1 my-0.5 border border-slate-900/60 flex items-baseline justify-between">
                      <div>
                        <div className="text-[6px] font-mono text-slate-400 uppercase font-black">24H NET PnL</div>
                        <div className="text-[10.5px] font-black font-mono text-emerald-400 leading-none">
                          {perf.pnl24h >= 0 ? `+$${perf.pnl24h.toLocaleString(undefined, { minimumFractionDigits: 2 })}` : `-$${Math.abs(perf.pnl24h).toFixed(2)}`}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-[6px] font-mono text-slate-400 uppercase font-black">WIN RATE</div>
                        <div className="text-[8.5px] font-bold font-mono text-cyan-300 leading-none">
                          {perf.winRate}% <span className="text-[6.5px] text-slate-400">({perf.tradesCount}tx)</span>
                        </div>
                      </div>
                    </div>

                    {/* Volume & Telemetry Footprint */}
                    <div className="flex items-center justify-between text-[7px] mt-1 pt-1 border-t border-slate-900 text-slate-500">
                      <span>VOL: <strong className="text-slate-300">{perf.volume24h}</strong></span>
                      <span>APP: <strong className="text-cyan-400">{appCount}</strong></span>
                      <span>REJ: <strong className="text-rose-400">{rejCount}</strong></span>
                    </div>
                  </button>
                );
              })}
            </div>
          ) : (
            /* LIVE ENGINE LOGS VIEW */
            <div className="flex flex-col flex-1 mb-2.5 bg-black/60 rounded-lg border border-slate-900 p-2 overflow-hidden">
              {/* Filter Row */}
              <div className="flex items-center gap-1 mb-1.5 pb-1 border-b border-slate-900 overflow-x-auto text-[7.5px] font-mono">
                <span className="text-slate-500 font-bold uppercase shrink-0">FILTER:</span>
                {["ALL", ...WING_L_NODES.map(n => n.id)].map(f => (
                  <button
                    key={f}
                    onClick={() => setLeftLogFilter(f)}
                    className={`px-1.5 py-0.2 rounded font-mono font-bold transition-all shrink-0 cursor-pointer ${
                      leftLogFilter === f
                        ? "bg-rose-500 text-white shadow-[0_0_6px_rgba(244,63,94,0.4)]"
                        : "bg-slate-900 text-slate-400 hover:text-white"
                    }`}
                  >
                    {f}
                  </button>
                ))}
              </div>

              {/* Log stream items */}
              <div className="flex flex-col gap-1 overflow-y-auto max-h-[145px] pr-1 font-mono text-[7.5px]">
                {nodeLogs
                  .filter(l => WING_L_NODES.some(n => n.id === l.engineId))
                  .filter(l => leftLogFilter === "ALL" || l.engineId === leftLogFilter)
                  .map(l => (
                    <div key={l.id} className="p-1 rounded bg-[#070b14] border border-[#161a28] flex flex-col gap-0.5 text-slate-300">
                      <div className="flex items-center justify-between text-[7px] text-slate-500 border-b border-slate-900 pb-0.5">
                        <div className="flex items-center gap-1">
                          <span className="text-slate-400 font-bold">[{l.time}]</span>
                          <span className="px-1 py-0.2 rounded bg-cyan-950/70 border border-cyan-800/40 text-cyan-300 font-bold">{l.engineId}</span>
                          <span className="px-1 py-0.2 rounded bg-slate-900 text-slate-400">{l.exchange}</span>
                        </div>
                        <span className="text-[6.5px] text-slate-600 truncate">{l.correlationId}</span>
                      </div>
                      <div className="text-[7.5px] font-mono leading-tight mt-0.5 flex items-center justify-between">
                        <span className={l.type === "trade" ? "text-emerald-300" : l.type === "arb" ? "text-amber-300" : "text-sky-300"}>
                          {l.text}
                        </span>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          )}

          {/* LEFT GATEWAYS & SENSORS */}
          <div className="flex flex-col gap-2 pt-2 border-t border-slate-900/80">
            <div className="flex items-center justify-between gap-2 bg-[#06070a] border border-[#1a1d26] p-1.5 rounded-lg">
              <div className="flex items-center gap-2">
                <span className="text-[7.5px] font-mono text-slate-500 uppercase font-black">LEFT GATEWAYS:</span>
                <div className="flex items-center gap-1.5">
                  {[
                    { key: "Bybit", label: "BYBIT", activeColor: "bg-rose-500 shadow-[0_0_8px_rgba(244,63,94,0.35)]" },
                    { key: "OKX", label: "OKX", activeColor: "bg-cyan-500 shadow-[0_0_8px_rgba(6,182,212,0.35)]" }
                  ].map((exc) => {
                    const isEnabled = exchangesEnabled[exc.key as keyof typeof exchangesEnabled];
                    return (
                      <div key={exc.key} className="flex items-center gap-1 bg-black/60 border border-[#161822] px-1.5 py-0.5 rounded">
                        <span className="text-[6.5px] font-black font-mono text-slate-300">{exc.label}</span>
                        <button
                          disabled={!powerOn}
                          onClick={() => handleToggleExchange(exc.key as any)}
                          className={`w-5 h-2.5 rounded-full p-0.5 flex items-center transition-all ${
                            !powerOn 
                              ? "bg-slate-950 opacity-30 cursor-not-allowed" 
                              : isEnabled 
                                ? `${exc.activeColor} justify-end` 
                                : "bg-slate-950 justify-start"
                          }`}
                        >
                          <div className={`w-1.5 h-1.5 rounded-full ${!powerOn ? 'bg-slate-700' : isEnabled ? 'bg-white' : 'bg-slate-500'}`} />
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>

              <button
                disabled={!powerOn}
                onClick={handleRecalibrateCorrelation}
                className="py-1 px-2 rounded border border-[#1a1d26] bg-[#0c0e17] hover:bg-[#161822] text-slate-300 font-mono text-[7px] font-bold uppercase transition-all hover:text-white disabled:opacity-40 cursor-pointer"
              >
                RECALIBRATE
              </button>
            </div>

            {/* SENSORS ROW */}
            <div className="grid grid-cols-2 gap-2 text-center py-0.5">
              <div className="flex items-center gap-2 bg-black/40 border border-slate-900 p-1.5 rounded-lg">
                <div className="relative w-8 h-8 rounded-full border border-rose-500/20 flex flex-col items-center justify-center bg-[#020617] shrink-0">
                  <span className="text-[8px] font-black font-mono text-slate-100">{powerOn ? `${metrics.neuralLoad}%` : "OFF"}</span>
                  {powerOn && (
                    <div className="absolute inset-0 rounded-full border-2 border-rose-500 border-t-transparent animate-[spin_5s_linear_infinite]" />
                  )}
                </div>
                <div className="text-left leading-none">
                  <span className="text-[7px] font-mono text-slate-400 uppercase font-black block">NEURAL LOAD</span>
                  <span className="text-[6.5px] font-mono text-slate-600">Left Wing Core</span>
                </div>
              </div>

              <div className="flex items-center gap-2 bg-black/40 border border-slate-900 p-1.5 rounded-lg">
                <div className="relative w-8 h-8 rounded-full border border-cyan-500/20 flex flex-col items-center justify-center bg-[#020617] shrink-0">
                  <span className="text-[8px] font-black font-mono text-slate-100">{powerOn ? `${metrics.clockSpeed}` : "OFF"}</span>
                  {powerOn && (
                    <div className="absolute inset-0 rounded-full border border-cyan-400 border-l-transparent animate-[spin_3s_linear_infinite]" />
                  )}
                </div>
                <div className="text-left leading-none">
                  <span className="text-[7px] font-mono text-slate-400 uppercase font-black block">CLOCK SPD</span>
                  <span className="text-[6.5px] font-mono text-slate-600">Deterministic</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ================= MIDDLE COCKPIT CONFIG PANEL ================= */}
        <div className="flex flex-1 items-stretch justify-center">
          <HologramPanel
            isOpen={true}
            onClose={() => {}}
            selectedEngineId={selectedEngineId}
            selectedEngine={selectedEngine}
            localConfig={localConfigs[selectedEngineId] || { strategy: "", asset: "", amount: 100, leverage: 1 }}
            onUpdateConfig={(field, val) => setLocalConfigs(p => ({ ...p, [selectedEngineId]: { ...p[selectedEngineId], [field]: val } }))}
            onApplyConfig={handleApplyConfig}
            savingState={savingStates[selectedEngineId] || false}
            saveMessage={saveMessages[selectedEngineId] || null}
            handleStartStop={handleStartStop}
            handleManualTrade={handleManualTrade}
            logs={logs}
            powerOn={powerOn}
          />
        </div>

        {/* ================= TELEMETRY DIAGNOSTICS (RIGHT WING ENGINES) ================= */}
        <section className="bg-[#030712]/95 border border-[#161822] rounded-xl p-3.5 shadow-2xl backdrop-blur-md flex flex-col justify-between min-h-[340px]">
          {/* Header */}
          <div className="flex items-center justify-between border-b border-slate-900/90 pb-2 mb-2 font-mono text-[10px] text-slate-400">
            <div className="flex items-center gap-1.5">
              <Cpu className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
              <span className="font-black tracking-[0.14em] text-slate-200 uppercase text-[9.5px]">RIGHT WING TELEMETRY (6 ENGINES)</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[7.5px] font-mono tracking-wider font-bold text-slate-500 uppercase">POWER:</span>
              <button 
                onClick={() => (powerOn ? handleKillSwitch() : handlePowerOnAll())}
                className={`h-4 w-7 rounded-full p-0.5 border flex items-center transition-all duration-300 ${
                  powerOn 
                    ? "bg-rose-500/20 border-rose-500/80 justify-end shadow-[0_0_10px_rgba(244,63,94,0.3)]" 
                    : "bg-slate-950 border-[#161822] justify-start"
                }`}
              >
                <div className={`h-2.5 w-2.5 rounded-full flex items-center justify-center ${
                  powerOn ? "bg-rose-500" : "bg-slate-700"
                }`} />
              </button>
            </div>
          </div>

          {/* Sub-header: Tab switcher between 24H PnL & Live Logs */}
          <div className="flex items-center justify-between gap-1 mb-2 bg-black/60 p-1 rounded border border-slate-900">
            <div className="flex items-center gap-1">
              <button
                onClick={() => setRightTelemetryTab("pnl")}
                className={`px-2 py-0.5 rounded text-[8px] font-mono font-bold uppercase transition-all flex items-center gap-1 cursor-pointer ${
                  rightTelemetryTab === "pnl"
                    ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-[0_0_8px_rgba(6,182,212,0.25)]"
                    : "text-slate-500 hover:text-slate-300"
                }`}
              >
                <TrendingUp className="w-2.5 h-2.5" />
                <span>24H PnL PERFORMANCE</span>
              </button>
              <button
                onClick={() => setRightTelemetryTab("logs")}
                className={`px-2 py-0.5 rounded text-[8px] font-mono font-bold uppercase transition-all flex items-center gap-1 cursor-pointer ${
                  rightTelemetryTab === "logs"
                    ? "bg-rose-500/20 text-rose-300 border border-rose-500/40 shadow-[0_0_8px_rgba(244,63,94,0.25)]"
                    : "text-slate-500 hover:text-slate-300"
                }`}
              >
                <Activity className="w-2.5 h-2.5" />
                <span>LIVE ENGINE LOGS</span>
                {powerOn && <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-ping" />}
              </button>
            </div>
            <span className="text-[7.5px] font-mono text-slate-500 font-bold pr-1">6 NODES ACTIVE</span>
          </div>

          {/* MAIN TAB CONTENT */}
          {rightTelemetryTab === "pnl" ? (
            /* 24H PNL PERFORMANCE MATRIX */
            <div className="grid grid-cols-2 gap-1.5 flex-1 mb-2.5">
              {WING_R_NODES.map((node) => {
                const engineState = storeState.engines[node.id];
                const isEngineRunning = powerOn && engineState && engineState.status === "Running";
                const isSelected = selectedEngineId === node.id;
                const perf = enginePerfs[node.id] || {
                  pnl24h: 1800,
                  pnlPercent: 7.2,
                  winRate: 92.0,
                  tradesCount: 110,
                  volume24h: "$40.0K",
                  effectivenessScore: 94.0,
                  rankBadge: "ACTIVE"
                };
                const appCount = engineState?.approved_orders_count ?? Math.floor(perf.tradesCount * 0.95);
                const rejCount = engineState?.rejected_orders_count ?? Math.floor(perf.tradesCount * 0.05);

                return (
                  <button
                    key={node.id}
                    onClick={() => setSelectedEngineId(node.id)}
                    className={`text-left p-2 rounded-lg border font-mono transition-all cursor-pointer flex flex-col justify-between ${
                      isSelected 
                        ? "bg-[#0a1322] border-cyan-400/70 shadow-[0_0_12px_rgba(6,182,212,0.25)]" 
                        : "bg-[#050811] border-[#151928] hover:border-cyan-500/40 hover:bg-[#080d1a]"
                    }`}
                  >
                    {/* Header Row: ID + Exchange + Rank Badge */}
                    <div className="flex items-center justify-between gap-1 mb-1">
                      <div className="flex items-center gap-1.5">
                        <span className={`w-1.5 h-1.5 rounded-full ${
                          isEngineRunning ? "bg-cyan-400 animate-pulse shadow-[0_0_6px_#22d3ee]" : "bg-slate-700"
                        }`} />
                        <span className="text-[9px] font-black text-white">{node.id}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <span className="text-[7px] px-1 py-0.2 rounded bg-black/80 border border-white/5 font-bold text-slate-300">
                          {node.exchange}
                        </span>
                        <span className={`text-[6.5px] px-1 py-0.2 rounded font-black font-mono ${
                          perf.rankBadge.includes("TOP") 
                            ? "bg-amber-500/20 text-amber-300 border border-amber-500/40"
                            : perf.rankBadge.includes("HIGH")
                            ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/30"
                            : "bg-slate-800/60 text-slate-300 border border-slate-700"
                        }`}>
                          {perf.rankBadge}
                        </span>
                      </div>
                    </div>

                    {/* 24H Performance Focus Row: PnL + Win Rate */}
                    <div className="bg-black/40 rounded p-1 my-0.5 border border-slate-900/60 flex items-baseline justify-between">
                      <div>
                        <div className="text-[6px] font-mono text-slate-400 uppercase font-black">24H NET PnL</div>
                        <div className="text-[10.5px] font-black font-mono text-emerald-400 leading-none">
                          {perf.pnl24h >= 0 ? `+$${perf.pnl24h.toLocaleString(undefined, { minimumFractionDigits: 2 })}` : `-$${Math.abs(perf.pnl24h).toFixed(2)}`}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-[6px] font-mono text-slate-400 uppercase font-black">WIN RATE</div>
                        <div className="text-[8.5px] font-bold font-mono text-cyan-300 leading-none">
                          {perf.winRate}% <span className="text-[6.5px] text-slate-400">({perf.tradesCount}tx)</span>
                        </div>
                      </div>
                    </div>

                    {/* Volume & Telemetry Footprint */}
                    <div className="flex items-center justify-between text-[7px] mt-1 pt-1 border-t border-slate-900 text-slate-500">
                      <span>VOL: <strong className="text-slate-300">{perf.volume24h}</strong></span>
                      <span>APP: <strong className="text-cyan-400">{appCount}</strong></span>
                      <span>REJ: <strong className="text-rose-400">{rejCount}</strong></span>
                    </div>
                  </button>
                );
              })}
            </div>
          ) : (
            /* LIVE ENGINE LOGS VIEW */
            <div className="flex flex-col flex-1 mb-2.5 bg-black/60 rounded-lg border border-slate-900 p-2 overflow-hidden">
              {/* Filter Row */}
              <div className="flex items-center gap-1 mb-1.5 pb-1 border-b border-slate-900 overflow-x-auto text-[7.5px] font-mono">
                <span className="text-slate-500 font-bold uppercase shrink-0">FILTER:</span>
                {["ALL", ...WING_R_NODES.map(n => n.id)].map(f => (
                  <button
                    key={f}
                    onClick={() => setRightLogFilter(f)}
                    className={`px-1.5 py-0.2 rounded font-mono font-bold transition-all shrink-0 cursor-pointer ${
                      rightLogFilter === f
                        ? "bg-rose-500 text-white shadow-[0_0_6px_rgba(244,63,94,0.4)]"
                        : "bg-slate-900 text-slate-400 hover:text-white"
                    }`}
                  >
                    {f}
                  </button>
                ))}
              </div>

              {/* Log stream items */}
              <div className="flex flex-col gap-1 overflow-y-auto max-h-[145px] pr-1 font-mono text-[7.5px]">
                {nodeLogs
                  .filter(l => WING_R_NODES.some(n => n.id === l.engineId))
                  .filter(l => rightLogFilter === "ALL" || l.engineId === rightLogFilter)
                  .map(l => (
                    <div key={l.id} className="p-1 rounded bg-[#070b14] border border-[#161a28] flex flex-col gap-0.5 text-slate-300">
                      <div className="flex items-center justify-between text-[7px] text-slate-500 border-b border-slate-900 pb-0.5">
                        <div className="flex items-center gap-1">
                          <span className="text-slate-400 font-bold">[{l.time}]</span>
                          <span className="px-1 py-0.2 rounded bg-cyan-950/70 border border-cyan-800/40 text-cyan-300 font-bold">{l.engineId}</span>
                          <span className="px-1 py-0.2 rounded bg-slate-900 text-slate-400">{l.exchange}</span>
                        </div>
                        <span className="text-[6.5px] text-slate-600 truncate">{l.correlationId}</span>
                      </div>
                      <div className="text-[7.5px] font-mono leading-tight mt-0.5 flex items-center justify-between">
                        <span className={l.type === "trade" ? "text-emerald-300" : l.type === "arb" ? "text-amber-300" : "text-sky-300"}>
                          {l.text}
                        </span>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          )}

          {/* RIGHT GATEWAYS & SENSORS */}
          <div className="flex flex-col gap-2 pt-2 border-t border-slate-900/80">
            <div className="flex items-center justify-between gap-2 bg-[#06070a] border border-[#1a1d26] p-1.5 rounded-lg">
              <div className="flex items-center gap-2">
                <span className="text-[7.5px] font-mono text-slate-500 uppercase font-black">RIGHT GATEWAYS:</span>
                <div className="flex items-center gap-1.5">
                  {[
                    { key: "Binance", label: "BINANCE", activeColor: "bg-amber-500 shadow-[0_0_8px_rgba(245,158,11,0.35)]" },
                    { key: "KuCoin", label: "KUCOIN", activeColor: "bg-cyan-500 shadow-[0_0_8px_rgba(6,182,212,0.35)]" }
                  ].map((exc) => {
                    const isEnabled = exchangesEnabled[exc.key as keyof typeof exchangesEnabled];
                    return (
                      <div key={exc.key} className="flex items-center gap-1 bg-black/60 border border-[#161822] px-1.5 py-0.5 rounded">
                        <span className="text-[6.5px] font-black font-mono text-slate-300">{exc.label}</span>
                        <button
                          disabled={!powerOn}
                          onClick={() => handleToggleExchange(exc.key as any)}
                          className={`w-5 h-2.5 rounded-full p-0.5 flex items-center transition-all ${
                            !powerOn 
                              ? "bg-slate-950 opacity-30 cursor-not-allowed" 
                              : isEnabled 
                                ? `${exc.activeColor} justify-end` 
                                : "bg-slate-950 justify-start"
                          }`}
                        >
                          <div className={`w-1.5 h-1.5 rounded-full ${!powerOn ? 'bg-slate-700' : isEnabled ? 'bg-white' : 'bg-slate-500'}`} />
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* AUDIT COMPLIANCE WITH ISLAMIC/SHARIAH ACCENT */}
              <button
                disabled={!powerOn}
                onClick={handleAuditCompliance}
                className="py-1 px-2 rounded border border-emerald-500/40 bg-emerald-950/30 hover:bg-emerald-900/40 text-emerald-400 font-mono text-[7px] font-bold uppercase transition-all shadow-[0_0_8px_rgba(16,185,129,0.2)] disabled:opacity-40 cursor-pointer flex items-center gap-1"
              >
                <span>🕌 SHARIAH AUDIT</span>
              </button>
            </div>

            {/* SENSORS ROW */}
            <div className="grid grid-cols-2 gap-2 text-center py-0.5">
              <div className="flex items-center gap-2 bg-black/40 border border-slate-900 p-1.5 rounded-lg">
                <div className="relative w-8 h-8 rounded-full border border-rose-500/20 flex flex-col items-center justify-center bg-[#020617] shrink-0">
                  <span className="text-[8px] font-black font-mono text-slate-100">{powerOn ? `${metrics.thruput}` : "OFF"}</span>
                  {powerOn && (
                    <div className="absolute inset-0 rounded-full border-2 border-rose-500 border-b-transparent animate-[spin_7s_linear_infinite]" />
                  )}
                </div>
                <div className="text-left leading-none">
                  <span className="text-[7px] font-mono text-slate-400 uppercase font-black block">THRUPUT</span>
                  <span className="text-[6.5px] font-mono text-slate-600">Right Wing Nodes</span>
                </div>
              </div>

              <div className="flex items-center gap-2 bg-black/40 border border-slate-900 p-1.5 rounded-lg">
                <div className="relative w-8 h-8 rounded-full border border-cyan-500/20 flex flex-col items-center justify-center bg-[#020617] shrink-0">
                  <span className="text-[8px] font-black font-mono text-slate-100">{powerOn ? "99.8%" : "OFF"}</span>
                  {powerOn && (
                    <div className="absolute inset-0 rounded-full border-2 border-cyan-400 border-l-transparent animate-[spin_3s_linear_infinite]" />
                  )}
                </div>
                <div className="text-left leading-none">
                  <span className="text-[7px] font-mono text-slate-400 uppercase font-black block">SYNC RATE</span>
                  <span className="text-[6.5px] font-mono text-slate-600">Deterministic</span>
                </div>
              </div>
            </div>
          </div>
        </section>

      </footer>

      {/* 4. DEDICATED BOTTOM HORIZONTAL VIEWPORT SCROLLER & PAN CONTROLLER */}
      <aside aria-label="Canvas viewport navigation" className="sticky bottom-2 z-30 mx-auto mt-4 px-4 py-2 bg-[#060812]/90 backdrop-blur-md border border-[#1e293b] rounded-full shadow-[0_4px_20px_rgba(0,0,0,0.8)] flex items-center gap-3 font-mono text-xs">
        <div className="flex items-center gap-1.5 text-slate-400 text-[10px] font-bold uppercase tracking-wider px-1">
          <Compass className="w-3.5 h-3.5 text-cyan-400 animate-spin" />
          <span>{t("CANVAS VIEWPORT")}</span>
        </div>

        <div className="h-4 w-[1px] bg-slate-800" />

        <button
          onClick={panToLeft}
          className="px-3 py-1 bg-slate-900/80 hover:bg-slate-800 border border-slate-700 hover:border-cyan-500/50 text-slate-200 hover:text-cyan-400 rounded-full text-[10px] font-bold flex items-center gap-1 transition-all cursor-pointer"
          title={t("Scroll to Left Wing")}
        >
          <ArrowLeft className="w-3 h-3 text-cyan-400" />
          <span>{t("LEFT WING (STABLE)")}</span>
        </button>

        <button
          onClick={panToCenter}
          className="px-3 py-1 bg-rose-950/40 hover:bg-rose-900/60 border border-rose-500/40 hover:border-rose-500 text-rose-300 rounded-full text-[10px] font-bold flex items-center gap-1 transition-all cursor-pointer"
          title={t("Center Universe")}
        >
          <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
          <span>{t("CENTER UNIVERSE")}</span>
        </button>

        <button
          onClick={panToRight}
          className="px-3 py-1 bg-slate-900/80 hover:bg-slate-800 border border-slate-700 hover:border-emerald-500/50 text-slate-200 hover:text-emerald-400 rounded-full text-[10px] font-bold flex items-center gap-1 transition-all cursor-pointer"
          title={t("Scroll to Right Wing")}
        >
          <span>{t("RIGHT WING (ALPHA)")}</span>
          <ArrowRight className="w-3 h-3 text-emerald-400" />
        </button>
      </aside>
    </div>
  );
}
