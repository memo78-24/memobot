import React, { useEffect, useState } from "react";
import { ApiClient } from "../services/api";
import { EngineService } from "../services/engineService";
import { engineStore } from "../services/engineStore";
import { ShariahLockBanner } from "../components/ShariahLockBanner";
import {
  Compass,
  Search,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Sliders,
  Flame,
  Globe,
  ArrowUpDown,
  ShieldAlert,
  ShieldCheck,
  TrendingUp,
  TrendingDown,
  Hash,
  Shield,
  Activity,
  Zap
} from "lucide-react";
import { useLanguage } from "../components/LanguageProvider";

interface CryptoAsset {
  rank: number;
  symbol: string;
  name: string;
  status: "COMPLIANT" | "NON-COMPLIANT" | "HIGH-RISK";
  group: string;
  vol24h: string;
  audit: string;
  volatility: string;
  price: number;
  change24h: number;
}

interface MarketIntelProps {
  complianceMode?: "Islamic" | "Commercial";
}

export const MarketIntel: React.FC<MarketIntelProps> = ({ complianceMode: propComplianceMode }) => {
  const [storeState, setStoreState] = useState(engineStore.getState());
  const [assets, setAssets] = useState<CryptoAsset[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [activeFilter, setActiveFilter] = useState<"ALL" | "COMPLIANT" | "TOP10" | "VOLATILE" | "NON_COMPLIANT">("ALL");
  const [sortField, setSortField] = useState<"rank" | "price" | "change24h">("rank");
  const [sortAsc, setSortAsc] = useState(true);
  const { t } = useLanguage();

  const complianceMode = propComplianceMode || storeState.complianceMode || "Islamic";

  const fetchMarketIntel = async () => {
    try {
      const res = await ApiClient.get("/market-intel/top50");
      if (res && res.data) {
        setAssets(res.data);
      }
    } catch (err) {
      console.error("Failed to fetch top 50 market intel:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    EngineService.init();
    fetchMarketIntel();

    const interval = setInterval(fetchMarketIntel, 8000);

    const unsub = engineStore.subscribe((state) => {
      setStoreState(state);
    });

    return () => {
      clearInterval(interval);
      unsub();
      EngineService.destroy();
    };
  }, []);

  const wings = storeState.wingsData["BTC/USDT"] || storeState.wingsData["ETH/USDT"] || {
    buy_pressure: 55,
    bids: [[68420.5, 0.45], [68410.2, 1.2], [68400.0, 3.4], [68390.1, 0.85], [68380.0, 1.9]],
    asks: [[68435.1, 0.95], [68445.0, 1.5], [68455.0, 2.1], [68465.8, 0.72], [68475.0, 4.25]]
  };

  // Filter logic
  const filteredAssets = assets.filter((asset) => {
    const matchesSearch =
      asset.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      asset.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
      asset.group.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;

    if (activeFilter === "COMPLIANT") return asset.status === "COMPLIANT";
    if (activeFilter === "NON_COMPLIANT") return asset.status === "NON-COMPLIANT" || asset.status === "HIGH-RISK";
    if (activeFilter === "TOP10") return asset.rank <= 10;
    if (activeFilter === "VOLATILE") return asset.volatility === "HIGH" || asset.volatility === "VERY HIGH" || asset.volatility === "EXTREME";

    return true;
  });

  // Sort logic
  const sortedAssets = [...filteredAssets].sort((a, b) => {
    let valA = a[sortField];
    let valB = b[sortField];

    if (typeof valA === "string") valA = (valA as string).toLowerCase();
    if (typeof valB === "string") valB = (valB as string).toLowerCase();

    if (valA < valB) return sortAsc ? -1 : 1;
    if (valA > valB) return sortAsc ? 1 : -1;
    return 0;
  });

  const handleSort = (field: "rank" | "price" | "change24h") => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      setSortAsc(true);
    }
  };

  const compliantCount = assets.filter((a) => a.status === "COMPLIANT").length;
  const nonCompliantCount = assets.filter((a) => a.status === "NON-COMPLIANT" || a.status === "HIGH-RISK").length;

  return (
    <div id="market-intel-container" className="flex-1 bg-[#06070a] p-6 overflow-y-auto space-y-6 font-mono text-xs text-[#8a8d9a]">
      
      {/* Header */}
      <div className="flex flex-col xl:flex-row justify-between items-start xl:items-center gap-4 border-b border-[#FA1F4E]/20 pb-4 shrink-0">
        <div>
          <h2 className="text-2xl font-aquire text-[#FA1F4E] tracking-tighter drop-shadow-[0_0_15px_rgba(250,31,78,0.2)] uppercase">
            {t("MARKET INTELLIGENCE TERMINAL")}
          </h2>
          <p className="font-sans text-[13px] text-[#8a8d9a] mt-1">
            {t("Real-time monitoring across top 50 global cryptocurrencies, order book depth sensors, and Shariah spot compliance audits.")}
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <div className="bg-[#0d0e12] border border-[#1a1d26] px-3 py-1.5 rounded flex items-center gap-2 text-[10px]">
            <Activity className="w-3.5 h-3.5 text-[#3b82f6]" />
            <span className="text-white font-bold">{t("50 MONITORED CURRENCIES")}</span>
          </div>
          <button
            onClick={fetchMarketIntel}
            className="p-2 bg-[#0d0e12] border border-[#1a1d26] hover:border-[#FA1F4E] text-[#8a8d9a] hover:text-[#FA1F4E] rounded transition-colors"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin text-[#FA1F4E]" : ""}`} />
          </button>
        </div>
      </div>

      {/* Shariah Lock Banner when in Islamic Mode */}
      {complianceMode === "Islamic" && <ShariahLockBanner />}

      {/* Top Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#0d0e12] border border-[#1a1d26] p-4 rounded panel-glow flex justify-between items-center relative overflow-hidden group">
          <div className="relative z-10">
            <span className="text-[10px] text-[#8a8d9a] uppercase font-bold tracking-wider block">{t("MONITORED ASSETS")}</span>
            <div className="text-2xl font-bold font-mono text-white mt-1">50 {t("CURRENCIES")}</div>
            <div className="text-[9px] text-[#8a8d9a] uppercase font-bold mt-0.5">{t("TOP MARKET CAP INDEX")}</div>
          </div>
          <Globe className="w-6 h-6 text-[#FA1F4E] relative z-10" />
          <div className="absolute -right-4 -bottom-4 w-20 h-20 bg-[#FA1F4E]/5 rounded-full blur-2xl group-hover:bg-[#FA1F4E]/10 transition-all" />
        </div>

        <div className="bg-[#0d0e12] border border-[#1a1d26] p-4 rounded panel-glow flex justify-between items-center relative overflow-hidden group">
          <div className="relative z-10">
            <span className="text-[10px] text-[#8a8d9a] uppercase font-bold tracking-wider block">{t("SHARIAH COMPLIANT")}</span>
            <div className="text-2xl font-bold font-mono text-white mt-1">{compliantCount} / 50</div>
            <div className="text-[9px] text-[#8a8d9a] uppercase font-bold mt-0.5">{t("APPROVED SPOT UTILITY")}</div>
          </div>
          <ShieldCheck className="w-6 h-6 text-[#FA1F4E] relative z-10" />
          <div className="absolute -right-4 -bottom-4 w-20 h-20 bg-[#FA1F4E]/5 rounded-full blur-2xl group-hover:bg-[#FA1F4E]/10 transition-all" />
        </div>

        <div className="bg-[#0d0e12] border border-[#1a1d26] p-4 rounded panel-glow flex justify-between items-center relative overflow-hidden group">
          <div className="relative z-10">
            <span className="text-[10px] text-[#8a8d9a] uppercase font-bold tracking-wider block">{t("RISK / NON-COMPLIANT")}</span>
            <div className="text-2xl font-bold font-mono text-white mt-1">{nonCompliantCount} / 50</div>
            <div className="text-[9px] text-[#8a8d9a] uppercase font-bold mt-0.5">{t("FLAGGED GHARAR / MEME")}</div>
          </div>
          <ShieldAlert className="w-6 h-6 text-[#FA1F4E] relative z-10" />
          <div className="absolute -right-4 -bottom-4 w-20 h-20 bg-[#FA1F4E]/5 rounded-full blur-2xl group-hover:bg-[#FA1F4E]/10 transition-all" />
        </div>

        <div className="bg-[#0d0e12] border border-[#1a1d26] p-4 rounded panel-glow flex justify-between items-center relative overflow-hidden group">
          <div className="relative z-10">
            <span className="text-[10px] text-[#8a8d9a] uppercase font-bold tracking-wider block">{t("BTC BUY PRESSURE")}</span>
            <div className="text-2xl font-bold font-mono text-white mt-1">{wings.buy_pressure}%</div>
            <div className="text-[9px] text-[#8a8d9a] uppercase font-bold mt-0.5">{t("ORDER BOOK SENSOR ACTIVE")}</div>
          </div>
          <TrendingUp className="w-6 h-6 text-[#FA1F4E] relative z-10" />
          <div className="absolute -right-4 -bottom-4 w-20 h-20 bg-[#FA1F4E]/5 rounded-full blur-2xl group-hover:bg-[#FA1F4E]/10 transition-all" />
        </div>
      </div>

      {/* Main Section: Top 50 Monitored Currencies Ledger */}
      <div className="bg-[#0d0e12] border border-[#1a1d26] rounded panel-glow overflow-hidden space-y-4 p-5 relative">
        <div className="absolute top-2 right-2 flex items-center gap-2 text-[8px] text-[#8a8d9a] font-bold opacity-50">
          <Shield className="w-2.5 h-2.5" />
          <span>{t("AES-256 ENCRYPTED TELEMETRY")}</span>
        </div>

        {/* Controls Bar: Search + Filter Tabs */}
        <div className="flex flex-col md:flex-row justify-between items-stretch md:items-center gap-4 border-b border-[#11131c] pb-4">
          
          {/* Search Box */}
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-[#8a8d9a] absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder={t("Search top 50 currencies (e.g., BTC, Solana, L2)...")}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#06070a] border border-[#1a1d26] focus:border-[#FA1F4E] text-white text-xs pl-9 pr-3 py-2 rounded outline-none transition-colors"
            />
          </div>

          {/* Filter Pills */}
          <div className="flex flex-wrap items-center gap-1.5 shrink-0">
            <button
              onClick={() => setActiveFilter("ALL")}
              className={`px-3 py-1.5 rounded text-[10px] font-bold uppercase transition-all ${
                activeFilter === "ALL"
                  ? "bg-[#FA1F4E] text-white shadow-[0_0_10px_rgba(250,31,78,0.3)]"
                  : "bg-[#06070a] text-[#8a8d9a] border border-[#1a1d26] hover:text-white"
              }`}
            >
              {t("ALL (50)")}
            </button>
            <button
              onClick={() => setActiveFilter("COMPLIANT")}
              className={`px-3 py-1.5 rounded text-[10px] font-bold uppercase transition-all ${
                activeFilter === "COMPLIANT"
                  ? "bg-[#0d0e12] text-white border border-[#FA1F4E]"
                  : "bg-[#06070a] text-[#8a8d9a] border border-[#1a1d26] hover:text-white"
              }`}
            >
              {t("ISLAMIC COMPLIANT")} ({compliantCount})
            </button>
            <button
              onClick={() => setActiveFilter("TOP10")}
              className={`px-3 py-1.5 rounded text-[10px] font-bold uppercase transition-all ${
                activeFilter === "TOP10"
                  ? "bg-[#0d0e12] text-white border border-[#FA1F4E]"
                  : "bg-[#06070a] text-[#8a8d9a] border border-[#1a1d26] hover:text-white"
              }`}
            >
              {t("TOP 10")}
            </button>
            <button
              onClick={() => setActiveFilter("VOLATILE")}
              className={`px-3 py-1.5 rounded text-[10px] font-bold uppercase transition-all ${
                activeFilter === "VOLATILE"
                  ? "bg-[#0d0e12] text-white border border-[#FA1F4E]"
                  : "bg-[#06070a] text-[#8a8d9a] border border-[#1a1d26] hover:text-white"
              }`}
            >
              {t("HIGH VOLATILITY")}
            </button>
            <button
              onClick={() => setActiveFilter("NON_COMPLIANT")}
              className={`px-3 py-1.5 rounded text-[10px] font-bold uppercase transition-all ${
                activeFilter === "NON_COMPLIANT"
                  ? "bg-[#FA1F4E] text-white shadow-[0_0_10px_rgba(250,31,78,0.3)]"
                  : "bg-[#06070a] text-[#8a8d9a] border border-[#1a1d26] hover:text-white"
              }`}
            >
              {t("FLAGGED / RISKY")} ({nonCompliantCount})
            </button>
          </div>
        </div>

        {/* Table View */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-[#11131c] text-[#8a8d9a] uppercase font-mono bg-[#06070a]">
                <th
                  onClick={() => handleSort("rank")}
                  className="py-3 px-3 font-semibold cursor-pointer hover:text-white transition-colors"
                >
                  <div className="flex items-center gap-1">
                    {t("RANK")} <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="py-3 px-3 font-semibold">{t("ASSET")}</th>
                <th
                  onClick={() => handleSort("price")}
                  className="py-3 px-3 font-semibold cursor-pointer hover:text-white transition-colors"
                >
                  <div className="flex items-center gap-1">
                    {t("LIVE PRICE")} <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th
                  onClick={() => handleSort("change24h")}
                  className="py-3 px-3 font-semibold cursor-pointer hover:text-white transition-colors"
                >
                  <div className="flex items-center gap-1">
                    {t("24H CHANGE")} <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="py-3 px-3 font-semibold">{t("24H VOLUME")}</th>
                <th className="py-3 px-3 font-semibold">{t("VOLATILITY")}</th>
                <th className="py-3 px-3 font-semibold">{t("CLASSIFICATION")}</th>
                <th className="py-3 px-3 font-semibold text-right">{t("COMPLIANCE AUDIT")}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1a1d26]">
              {sortedAssets.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-[#8a8d9a] font-mono italic">
                    {t("No currencies matched your search or filter query.")}
                  </td>
                </tr>
              ) : (
                sortedAssets.map((asset) => {
                  const isPositive = asset.change24h >= 0;
                  const isCompliant = asset.status === "COMPLIANT";
                  const isHighRisk = asset.status === "HIGH-RISK";
                  const auditHash = Math.random().toString(16).slice(2, 10).toUpperCase();

                  return (
                    <tr key={asset.symbol} className="hover:bg-[#12161f] transition-colors font-mono group">
                      {/* Rank */}
                      <td className="py-3 px-3 text-white font-bold">#{asset.rank}</td>

                      {/* Symbol & Name */}
                      <td className="py-3 px-3">
                        <div className="flex items-center gap-2">
                          <span className="w-6 h-6 rounded-full bg-[#11131c] border border-[#222634] flex items-center justify-center font-extrabold text-[10px] text-[#FA1F4E] shrink-0">
                            {asset.symbol.slice(0, 3)}
                          </span>
                          <div>
                            <div className="font-bold text-white uppercase">{asset.name}</div>
                            <div className="text-[10px] text-[#8a8d9a]">{asset.symbol}/USDT</div>
                          </div>
                        </div>
                      </td>

                      {/* Live Price */}
                      <td className="py-3 px-3 font-bold text-white">
                        ${(asset.price ?? 0) < 0.01 ? (asset.price ?? 0).toFixed(7) : (asset.price ?? 0).toLocaleString("en-US", { minimumFractionDigits: 2 })}
                      </td>

                      {/* 24h Change */}
                      <td className="py-3 px-3 font-bold text-white">
                        <div className="flex items-center gap-1 text-white">
                          {isPositive ? <TrendingUp className="w-3.5 h-3.5 text-white" /> : <TrendingDown className="w-3.5 h-3.5 text-[#FA1F4E]" />}
                          <span>{isPositive ? "+" : ""}{asset.change24h}%</span>
                        </div>
                      </td>

                      {/* 24h Volume */}
                      <td className="py-3 px-3 text-white font-bold">{asset.vol24h}</td>

                      {/* Volatility */}
                      <td className="py-3 px-3">
                        <span className="px-2 py-0.5 rounded text-[9px] font-bold border uppercase bg-[#06070a] text-white border-[#1a1d26]">
                          {t(asset.volatility)}
                        </span>
                      </td>

                      {/* Group Classification */}
                      <td className="py-3 px-3 text-[#8a8d9a] uppercase text-[10px] font-bold">
                        {t(asset.group)}
                      </td>

                      {/* Compliance Audit */}
                      <td className="py-3 px-3 text-right relative">
                        <div className="flex flex-col items-end gap-0.5">
                          <div className="flex items-center gap-1">
                            <span className={`px-2 py-0.5 rounded text-[9px] font-bold border uppercase inline-block ${
                              isCompliant
                                ? "bg-[#0d0e12] text-white border-[#1a1d26]"
                                : isHighRisk
                                ? "bg-[#1a1d26] text-white border-[#FA1F4E]"
                                : "bg-[rgba(250,31,78,0.1)] text-[#FA1F4E] border-[#FA1F4E]"
                            }`}>
                              {t(asset.status)}
                            </span>
                            <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                              <Hash className="w-2.5 h-2.5 text-[#FA1F4E]" />
                              <span className="text-[8px] text-white font-bold">{auditHash}</span>
                            </div>
                          </div>
                          <span className="text-[9px] text-[#8a8d9a] max-w-[180px] text-right truncate">
                            {t(asset.audit)}
                          </span>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Secondary Bottom Row: Order Book Depth Sensors */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <div className="lg:col-span-12 bg-[#0d0e12] border border-[#1a1d26] p-5 rounded space-y-4 panel-glow relative">
          <div className="absolute top-2 left-2 flex items-center gap-2 text-[8px] text-[#8a8d9a] font-bold opacity-30">
            <Activity className="w-2.5 h-2.5" />
            <span>{t("REAL-TIME SOCKET SYNC: 18ms")}</span>
          </div>

          <div className="flex justify-between items-center border-b border-[#11131c] pb-2 pt-2">
            <span className="text-[10px] text-[#FA1F4E] font-bold tracking-wider uppercase">
              {t("WINGS REAL-TIME DEPTH SENSORS (BTC/USDT HIGH FREQUENCY)")}
            </span>
            <span className="text-[9px] bg-[#06070a] text-white border border-[#1a1d26] px-2 py-0.5 rounded font-bold uppercase">
              {t("LIVE DEPTH FEED ACTIVE")}
            </span>
          </div>

          <div className="space-y-1.5">
            <div className="flex justify-between text-[10px] font-bold text-white">
              <span>{t("BUY PRESSURE:")} {wings.buy_pressure}%</span>
              <span>{t("SELL PRESSURE:")} {100 - wings.buy_pressure}%</span>
            </div>
            <div className="h-2 bg-[#06070a] rounded overflow-hidden flex">
              <div style={{ width: `${wings.buy_pressure}%` }} className="h-full bg-white" />
              <div style={{ width: `${100 - wings.buy_pressure}%` }} className="h-full bg-[#FA1F4E]" />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
            <div className="space-y-2">
              <span className="text-[10px] font-bold text-white block uppercase">{t("BIDS (BUY DEPTH)")}</span>
              <div className="space-y-1 text-[11px]">
                {(wings.bids || []).map((b, idx) => (
                  <div key={idx} className="flex justify-between font-mono p-1.5 bg-[#06070a] rounded border border-[#1a1d26] hover:border-[#FA1F4E] transition-all">
                    <span className="text-white font-bold">${(b[0] ?? 0).toLocaleString("en-US", { minimumFractionDigits: 1 })}</span>
                    <span className="text-white font-bold">{(b[1] ?? 0).toFixed(4)} BTC</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <span className="text-[10px] font-bold text-white block uppercase">{t("ASKS (SELL DEPTH)")}</span>
              <div className="space-y-1 text-[11px]">
                {(wings.asks || []).map((a, idx) => (
                  <div key={idx} className="flex justify-between font-mono p-1.5 bg-[#06070a] rounded border border-[#1a1d26] hover:border-[#FA1F4E] transition-all">
                    <span className="text-white font-bold">${(a[0] ?? 0).toLocaleString("en-US", { minimumFractionDigits: 1 })}</span>
                    <span className="text-white font-bold">{(a[1] ?? 0).toFixed(4)} BTC</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  );
};

export default MarketIntel;
