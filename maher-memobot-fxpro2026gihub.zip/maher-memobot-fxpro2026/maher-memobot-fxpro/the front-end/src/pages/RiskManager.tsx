import React, { useEffect, useState } from "react";
import { ApiClient } from "../services/api";
import { WebSocketManager } from "../services/websocket";
import { TOPICS } from "../config/constants";
import { ShariahLockBanner } from "../components/ShariahLockBanner";
import {
  ShieldAlert,
  Lock,
  TrendingDown,
  TrendingUp,
  RefreshCw,
  Sliders,
  CheckCircle2,
  AlertCircle,
  Zap,
  ShieldCheck,
  Activity,
  FileText,
  FileSpreadsheet,
  Printer,
  FileCode
} from "lucide-react";
import { useNotification } from "../components/NotificationProvider";
import { PageLoader } from "../components/PageLoader";

interface Position {
  engineId: string;
  symbol: string;
  amount: number;
  entry_price: number;
  current_price: number;
  pnl: number;
  roi: number;
  locked_margin: number;
}

interface RiskSettings {
  max_daily_drawdown_pct: number;
  max_position_size_usdt: number;
  default_stop_loss_pct: number;
  default_take_profit_pct: number;
  stealth_mode: boolean;
  auto_kill_switch_enabled: boolean;
  shariah_guard_enabled: boolean;
}

interface RiskManagerProps {
  complianceMode?: "Islamic" | "Commercial";
}

export const RiskManager: React.FC<RiskManagerProps> = ({ complianceMode = "Islamic" }) => {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [closing, setClosing] = useState<string | null>(null);
  const [saveSuccess, setSaveSuccess] = useState(false);

  const [positions, setPositions] = useState<Position[]>([]);
  const [formData, setFormData] = useState<RiskSettings>({
    max_daily_drawdown_pct: 25,
    max_position_size_usdt: 1000,
    default_stop_loss_pct: 1.5,
    default_take_profit_pct: 1.0,
    stealth_mode: true,
    auto_kill_switch_enabled: true,
    shariah_guard_enabled: true
  });

  const { showAlert, showConfirm } = useNotification();

  const fetchData = async () => {
    try {
      setLoading(true);
      const [posData, riskData] = await Promise.all([
        ApiClient.get("/execution/active-positions").catch(() => ({})),
        ApiClient.get("/risk/settings").catch(() => null)
      ]);

      // Flatten positions
      const flatPositions: Position[] = [];
      Object.keys(posData || {}).forEach((engId) => {
        const arr = posData[engId] || [];
        arr.forEach((p: any) => {
          flatPositions.push({ ...p, engineId: engId });
        });
      });
      setPositions(flatPositions);

      if (riskData) {
        setFormData({
          max_daily_drawdown_pct: riskData.max_daily_drawdown_pct ?? 25,
          max_position_size_usdt: riskData.max_position_size_usdt ?? 1000,
          default_stop_loss_pct: riskData.default_stop_loss_pct ?? 1.5,
          default_take_profit_pct: riskData.default_take_profit_pct ?? 1.0,
          stealth_mode: riskData.stealth_mode ?? true,
          auto_kill_switch_enabled: riskData.auto_kill_switch_enabled ?? true,
          shariah_guard_enabled: riskData.shariah_guard_enabled ?? true
        });
      }
    } catch (err) {
      console.error("Failed to load risk manager dataset:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();

    const unsubBalance = WebSocketManager.subscribe(TOPICS.BALANCE_CHANGED, () => {
      fetchData();
    });
    const unsubEngine = WebSocketManager.subscribe(TOPICS.ENGINE_STATUS_CHANGED, () => {
      fetchData();
    });
    const unsubRisk = WebSocketManager.subscribe(TOPICS.RISK_SETTINGS_CHANGED, (data) => {
      if (data?.settings) {
        setFormData(data.settings);
      }
    });

    return () => {
      unsubBalance();
      unsubEngine();
      unsubRisk();
    };
  }, []);

  const handleSaveRiskProtocols = async (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Sending risk settings:", formData);
    setSaving(true);
    setSaveSuccess(false);

    try {
      const res = await ApiClient.post("/risk/settings", formData);
      console.log("Risk settings save response:", res);
      setSaveSuccess(true);
      showAlert(res.message || "Risk matrix protocols successfully saved and applied across engines.");
      setTimeout(() => setSaveSuccess(false), 4000);
    } catch (err: any) {
      console.error("Risk settings save error:", err);
      showAlert(`Failed to update risk protocols: ${err.message}`);
    } finally {
      setSaving(false);
    }
  };

  const handleClosePosition = async (engineId: string, symbol: string, amount: number, side: string) => {
    showConfirm(
      `Are you sure you want to manually LIQUIDATE and close this ${side} position of ${amount} ${symbol}?`,
      async () => {
        setClosing(engineId);
        try {
          const oppositeSide = side === "BUY" ? "SELL" : "BUY";
          await ApiClient.post("/execution/trade", {
            symbol,
            side: oppositeSide,
            type: "MARKET",
            amount,
            engine: engineId
          });
          showAlert("Position liquidated successfully.");
          await fetchData();
        } catch (err: any) {
          showAlert(`Liquidation failed: ${err.message}`);
        } finally {
          setClosing(null);
        }
      },
      undefined,
      "MANUAL LIQUIDATION"
    );
  };

  const handleTriggerKillSwitch = async () => {
    showConfirm(
      "EMERGENCY ACTION: Initiate global trade halt and immediate liquidation of ALL open positions? This action is irreversible.",
      async () => {
        try {
          await ApiClient.post("/engine/kill");
          showAlert("Emergency Kill Switch Activated. Initiating liquidations.");
          await fetchData();
        } catch (err) {
          showAlert("Kill switch failed to propagate.");
        }
      },
      undefined,
      "GLOBAL KILL SWITCH"
    );
  };

  if (loading) {
    return <PageLoader message="SYNCHRONIZING RISK MATRIX & EXPOSURE PROTOCOLS..." subMessage="Computing Real-Time Value-at-Risk Engine" />;
  }

  const totalPnL = positions.reduce((acc, pos) => acc + pos.pnl, 0);

  // Asset exposure calculations
  const totalLockedMargin = positions.reduce((acc, pos) => acc + pos.locked_margin, 0);
  const assetExposureMap: Record<string, number> = {};
  positions.forEach((pos) => {
    const baseAsset = pos.symbol.replace("USDT", "");
    assetExposureMap[baseAsset] = (assetExposureMap[baseAsset] || 0) + pos.locked_margin;
  });

  return (
    <div id="risk-manager-container" className="flex-1 bg-[#06070a] p-6 overflow-y-auto space-y-6">
      
      {/* Page Header */}
      <div className="flex flex-col xl:flex-row justify-between items-start xl:items-center gap-4 border-b border-[#FA1F4E]/20 pb-4 shrink-0">
        <div>
          <h2 className="text-2xl font-aquire text-[#FA1F4E] tracking-tighter drop-shadow-[0_0_15px_rgba(250,31,78,0.2)] uppercase">
            RISK MANAGER & EXPOSURE PROTOCOLS
          </h2>
          <p className="font-sans text-[13px] text-[#8a8d9a] mt-1">
            Institutional-grade risk matrix control deck. Set max daily drawdown limits, position caps, automated stop losses, and anti-whale stealth execution.
          </p>
        </div>

        <div className="flex flex-col items-start sm:items-end gap-2 shrink-0 w-full sm:w-auto">
          {/* Top 4 Export Formats & Print */}
          <div className="flex flex-wrap items-center gap-1.5">
            <button
              onClick={() => {
                const docContent = `
                  <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
                  <head><title>MEMOBOT FX-PRO™ Risk Management Audit</title></head>
                  <body style="font-family: Arial; padding: 20px;">
                    <h1 style="color: #FA1F4E;">MEMOBOT FX-PRO™ RISK MANAGER PASSPORT</h1>
                    <p><strong>Compliance Mode:</strong> ${complianceMode.toUpperCase()} | <strong>Open Positions:</strong> ${positions.length}</p>
                    <pre>${JSON.stringify(formData, null, 2)}</pre>
                  </body></html>
                `;
                const blob = new Blob(["\ufeff", docContent], { type: "application/msword" });
                const url = URL.createObjectURL(blob);
                const link = document.createElement("a");
                link.href = url;
                link.download = `MEMOBOT_RISK_AUDIT_${new Date().toISOString().slice(0, 10)}.doc`;
                link.click();
                showAlert("RISK PROTOCOL WORD STATEMENT DOWNLOADED");
              }}
              className="flex items-center gap-1 px-2.5 py-1 bg-[#1e293b] hover:bg-[#2563eb] text-white border border-[#3b82f6]/40 rounded text-xs font-bold uppercase transition-all cursor-pointer"
            >
              <FileText className="w-3.5 h-3.5 text-blue-400" />
              <span>WORD</span>
            </button>

            <button
              onClick={() => {
                const csv = "\ufeff" + `Setting,Value\n` + Object.entries(formData).map(([k, v]) => `"${k}","${v}"`).join("\n");
                const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
                const url = URL.createObjectURL(blob);
                const link = document.createElement("a");
                link.href = url;
                link.download = `MEMOBOT_RISK_EXPOSURE_${new Date().toISOString().slice(0, 10)}.csv`;
                link.click();
                showAlert("RISK EXPOSURE EXCEL SPREADSHEET DOWNLOADED");
              }}
              className="flex items-center gap-1 px-2.5 py-1 bg-[#064e3b] hover:bg-[#059669] text-white border border-[#10b981]/40 rounded text-xs font-bold uppercase transition-all cursor-pointer"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
              <span>EXCEL</span>
            </button>

            <button
              onClick={() => window.print()}
              className="flex items-center gap-1 px-2.5 py-1 bg-[#7f1d1d] hover:bg-[#dc2626] text-white border border-[#ef4444]/40 rounded text-xs font-bold uppercase transition-all cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5 text-red-400" />
              <span>PDF / PRINT</span>
            </button>

            <button
              onClick={() => {
                const txt = `MEMOBOT FX-PRO™ RISK CONFIG\nMODE: ${complianceMode}\n${JSON.stringify(formData, null, 2)}`;
                const blob = new Blob([txt], { type: "text/plain;charset=utf-8" });
                const url = URL.createObjectURL(blob);
                const link = document.createElement("a");
                link.href = url;
                link.download = `MEMOBOT_RISK_MATRIX_${new Date().toISOString().slice(0, 10)}.txt`;
                link.click();
                showAlert("RISK TXT CONFIG EXPORTED");
              }}
              className="flex items-center gap-1 px-2.5 py-1 bg-[#431407] hover:bg-[#ea580c] text-white border border-[#f97316]/40 rounded text-xs font-bold uppercase transition-all cursor-pointer"
            >
              <FileCode className="w-3.5 h-3.5 text-orange-400" />
              <span>TXT</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            {/* Protocol Mode Display Badge */}
            <div className="flex items-center gap-2 bg-[#0d0e12] border border-[#FA1F4E]/30 px-3 py-1 rounded">
              <span className="text-[10px] font-mono font-bold text-[#8a8d9a] uppercase tracking-wider">
                PROTOCOL:
              </span>
              <span className={`font-mono text-xs font-bold uppercase ${
                complianceMode === "Islamic" ? "text-[#00e676]" : "text-[#60a5fa]"
              }`}>
                {complianceMode === "Islamic" ? "🕌 ISLAMIC SHARIAH" : "⚡ COMMERCIAL DESK"}
              </span>
            </div>

            {/* Emergency Button */}
            <button
              onClick={handleTriggerKillSwitch}
              className="flex items-center justify-center gap-1.5 px-3 py-1 border border-[#FA1F4E] bg-[rgba(250,31,78,0.1)] hover:bg-[#FA1F4E] text-[#FA1F4E] hover:text-white rounded text-xs font-mono font-extrabold transition-all uppercase shadow-[0_0_15px_rgba(250,31,78,0.2)] shrink-0"
            >
              <ShieldAlert className="w-4 h-4" />
              EMERGENCY HALT
            </button>
          </div>
        </div>
      </div>

      {/* Shariah Lock Banner Overlay */}
      {complianceMode === "Islamic" && <ShariahLockBanner />}

      {/* Central Risk Matrix Engine Synchronization Board */}
      <div className="bg-[#0c0d12]/90 border border-[#FA1F4E]/25 p-5 rounded-lg font-mono text-xs shadow-[0_0_15px_rgba(250,31,78,0.05)] space-y-4">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-3 border-b border-[#1a1d26] pb-3">
          <div className="space-y-1">
            <div className="flex items-center gap-1.5 text-white font-extrabold uppercase">
              <Activity className="w-4 h-4 text-[#FA1F4E] animate-pulse" />
              <span>CENTRAL SWARM RISK ENGINES STATUS DECK</span>
              <span className="text-[9px] bg-[#FA1F4E]/10 text-[#FA1F4E] border border-[#FA1F4E]/30 px-1.5 py-0.2 rounded font-normal">REAL-TIME RISK SYNC</span>
            </div>
            <p className="text-[10px] text-[#8a8d9a] font-sans leading-relaxed">
              Every change to the risk protocols below automatically propagates to all 12 exchange-specific engines instantly over secure WebSocket streams.
            </p>
          </div>
          <div className="flex items-center gap-1.5 text-[#00e676] bg-emerald-500/10 border border-emerald-500/20 px-3 py-1.5 rounded uppercase font-bold text-[10px]">
            <span className="w-2 h-2 bg-[#00e676] rounded-full animate-ping" />
            <span>12 ENGINES SECURED</span>
          </div>
        </div>

        {/* 4 Exchange Columns Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { exch: "Binance Desk", engines: ["ENG-001", "ENG-002", "ENG-003"] },
            { exch: "KuCoin Desk", engines: ["ENG-004", "ENG-005", "ENG-006"] },
            { exch: "OKX Desk", engines: ["ENG-007", "ENG-008", "ENG-009"] },
            { exch: "Bybit Desk", engines: ["ENG-010", "ENG-011", "ENG-012"] }
          ].map((item) => (
            <div key={item.exch} className="bg-black/45 border border-[#1a1d26] p-3 rounded space-y-2.5">
              <div className="text-[10px] text-white font-extrabold uppercase border-b border-[#1a1d26] pb-1.5">
                {item.exch}
              </div>
              <div className="space-y-1.5">
                {item.engines.map((engId) => (
                  <div key={engId} className="flex items-center justify-between text-[9px] bg-black/30 px-2 py-1.5 rounded border border-transparent hover:border-[#FA1F4E]/20">
                    <span className="text-[#8a8d9a] font-bold">{engId}</span>
                    <span className="text-[#00e676] font-bold uppercase flex items-center gap-1">
                      <span className="w-1 h-1 bg-[#00e676] rounded-full" />
                      SECURED
                    </span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Top Metric Cards Deck */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Max Daily Drawdown */}
        <div className="bg-[#0d0e12] border border-[#1a1d26] p-4 rounded flex justify-between items-start panel-glow">
          <div className="space-y-1">
            <span className="text-[10px] text-[#8a8d9a] uppercase font-bold tracking-wider font-mono block">
              MAX DAILY DRAWDOWN LIMIT
            </span>
            <div className="text-2xl font-bold font-mono text-white">
              {formData.max_daily_drawdown_pct}%
            </div>
            <div className="text-[9px] text-[#FA1F4E] font-mono uppercase font-bold">
              AUTOMATIC STOP THRESHOLD
            </div>
          </div>
          <AlertCircle className="w-5 h-5 text-[#FA1F4E]" />
        </div>

        {/* Max Position Sizing */}
        <div className="bg-[#0d0e12] border border-[#1a1d26] p-4 rounded flex justify-between items-start panel-glow">
          <div className="space-y-1">
            <span className="text-[10px] text-[#8a8d9a] uppercase font-bold tracking-wider font-mono block">
              MAX POSITION SIZING
            </span>
            <div className="text-2xl font-bold font-mono text-white">
              {formData.max_position_size_usdt} USDT
            </div>
            <div className="text-[9px] text-[#3b82f6] font-mono uppercase font-bold">
              ENFORCED PER ORDER
            </div>
          </div>
          <Lock className="w-5 h-5 text-[#3b82f6]" />
        </div>

        {/* Auto Stop Loss */}
        <div className="bg-[#0d0e12] border border-[#1a1d26] p-4 rounded flex justify-between items-start panel-glow">
          <div className="space-y-1">
            <span className="text-[10px] text-[#8a8d9a] uppercase font-bold tracking-wider font-mono block">
              AUTO STOP LOSS
            </span>
            <div className="text-2xl font-bold font-mono text-[#ffb800]">
              {formData.default_stop_loss_pct}%
            </div>
            <div className="text-[9px] text-[#ffb800] font-mono uppercase font-bold">
              TRAILING SL TRIGGER ACTIVE
            </div>
          </div>
          <TrendingDown className="w-5 h-5 text-[#ffb800]" />
        </div>

        {/* Auto Take Profit */}
        <div className="bg-[#0d0e12] border border-[#1a1d26] p-4 rounded flex justify-between items-start panel-glow">
          <div className="space-y-1">
            <span className="text-[10px] text-[#8a8d9a] uppercase font-bold tracking-wider font-mono block">
              AUTO TAKE PROFIT
            </span>
            <div className="text-2xl font-bold font-mono text-[#00e676]">
              {formData.default_take_profit_pct}%
            </div>
            <div className="text-[9px] text-[#00e676] font-mono uppercase font-bold">
              PROFIT CAPTURE TARGET
            </div>
          </div>
          <TrendingUp className="w-5 h-5 text-[#00e676]" />
        </div>
      </div>

      {/* Main Settings & Analysis Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Column: General Risk Settings Form (lg:span-6) */}
        <div className="lg:col-span-6 bg-[#0d0e12] border border-[#1a1d26] p-5 rounded space-y-5 panel-glow">
          <div className="flex items-center justify-between border-b border-[#11131c] pb-3">
            <div className="flex items-center gap-2 text-[#FA1F4E] font-mono font-bold text-xs uppercase tracking-wider">
              <Sliders className="w-4 h-4 text-[#FA1F4E]" />
              GENERAL RISK SETTINGS
            </div>
            {saveSuccess && (
              <span className="text-[10px] text-[#00e676] font-mono font-bold flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                PROTOCOL SYNCED
              </span>
            )}
          </div>

          <form onSubmit={handleSaveRiskProtocols} className="space-y-4">
            {/* Max Daily Drawdown (Percent) */}
            <div className="space-y-1.5">
              <label className="text-[10px] text-[#8a8d9a] font-mono font-bold uppercase tracking-wider block">
                MAX DAILY DRAWDOWN (PERCENT)
              </label>
              <input
                type="number"
                step="0.1"
                min="0.5"
                max="100"
                value={formData.max_daily_drawdown_pct}
                onChange={(e) => setFormData({ ...formData, max_daily_drawdown_pct: parseFloat(e.target.value) || 0 })}
                className="w-full bg-[#06070a] border border-[#1a1d26] focus:border-[#FA1F4E] text-white font-mono text-xs px-3 py-2.5 rounded outline-none transition-colors"
              />
            </div>

            {/* Max Position Size (USDT) */}
            <div className="space-y-1.5">
              <label className="text-[10px] text-[#8a8d9a] font-mono font-bold uppercase tracking-wider block">
                MAX POSITION SIZE (USDT)
              </label>
              <input
                type="number"
                step="10"
                min="10"
                max="1000000"
                value={formData.max_position_size_usdt}
                onChange={(e) => setFormData({ ...formData, max_position_size_usdt: parseFloat(e.target.value) || 0 })}
                className="w-full bg-[#06070a] border border-[#1a1d26] focus:border-[#FA1F4E] text-white font-mono text-xs px-3 py-2.5 rounded outline-none transition-colors"
              />
            </div>

            {/* Default Stop Loss (%) */}
            <div className="space-y-1.5">
              <label className="text-[10px] text-[#8a8d9a] font-mono font-bold uppercase tracking-wider block">
                DEFAULT STOP LOSS (%)
              </label>
              <input
                type="number"
                step="0.1"
                min="0.1"
                max="50"
                value={formData.default_stop_loss_pct}
                onChange={(e) => setFormData({ ...formData, default_stop_loss_pct: parseFloat(e.target.value) || 0 })}
                className="w-full bg-[#06070a] border border-[#1a1d26] focus:border-[#FA1F4E] text-white font-mono text-xs px-3 py-2.5 rounded outline-none transition-colors"
              />
            </div>

            {/* Default Take Profit (%) */}
            <div className="space-y-1.5">
              <label className="text-[10px] text-[#8a8d9a] font-mono font-bold uppercase tracking-wider block">
                DEFAULT TAKE PROFIT (%)
              </label>
              <input
                type="number"
                step="0.1"
                min="0.1"
                max="100"
                value={formData.default_take_profit_pct}
                onChange={(e) => setFormData({ ...formData, default_take_profit_pct: parseFloat(e.target.value) || 0 })}
                className="w-full bg-[#06070a] border border-[#1a1d26] focus:border-[#FA1F4E] text-white font-mono text-xs px-3 py-2.5 rounded outline-none transition-colors"
              />
            </div>

            {/* Stealth Mode (Anti-Whale) Toggle */}
            <div className="pt-2 border-t border-[#11131c] space-y-2">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-[11px] font-mono font-bold text-white uppercase block">
                    STEALTH MODE (ANTI-WHALE)
                  </span>
                  <p className="text-[10px] text-[#8a8d9a] font-sans mt-0.5 leading-snug max-w-sm">
                    Splits large orders and randomizes execution timing to avoid whale tracking and MEV front-running.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, stealth_mode: !formData.stealth_mode })}
                  className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${
                    formData.stealth_mode ? "bg-[#FA1F4E]" : "bg-[#1a1d26]"
                  }`}
                >
                  <div
                    className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                      formData.stealth_mode ? "translate-x-5" : "translate-x-0"
                    }`}
                  />
                </button>
              </div>
            </div>

            {/* Auto Kill Switch Toggle */}
            <div className="pt-2 border-t border-[#11131c] space-y-2">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-[11px] font-mono font-bold text-white uppercase block">
                    AUTOMATIC EMERGENCY SHUTDOWN
                  </span>
                  <p className="text-[10px] text-[#8a8d9a] font-sans mt-0.5 leading-snug max-w-sm">
                    Halt engine operations automatically if daily drawdown threshold is breached.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, auto_kill_switch_enabled: !formData.auto_kill_switch_enabled })}
                  className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${
                    formData.auto_kill_switch_enabled ? "bg-[#FA1F4E]" : "bg-[#1a1d26]"
                  }`}
                >
                  <div
                    className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                      formData.auto_kill_switch_enabled ? "translate-x-5" : "translate-x-0"
                    }`}
                  />
                </button>
              </div>
            </div>

            {/* Shariah Guard Toggle */}
            <div className="pt-2 border-t border-[#11131c] space-y-2">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-[11px] font-mono font-bold text-white uppercase block">
                    SHARIAH SPOT SAFEGUARD
                  </span>
                  <p className="text-[10px] text-[#8a8d9a] font-sans mt-0.5 leading-snug max-w-sm">
                    Enforces 100% physical spot backing, zero interest (Riba), and max 10x leverage restrictions.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, shariah_guard_enabled: !formData.shariah_guard_enabled })}
                  className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${
                    formData.shariah_guard_enabled ? "bg-[#00e676]" : "bg-[#1a1d26]"
                  }`}
                >
                  <div
                    className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                      formData.shariah_guard_enabled ? "translate-x-5" : "translate-x-0"
                    }`}
                  />
                </button>
              </div>
            </div>

            {/* Save CTA Button */}
            <div className="pt-3">
              <button
                type="submit"
                disabled={saving}
                className="w-full py-3 bg-[#FA1F4E] hover:bg-[#d4153d] text-white font-mono font-extrabold text-xs uppercase tracking-wider rounded transition-all shadow-[0_0_15px_rgba(250,31,78,0.3)] disabled:opacity-50"
              >
                {saving ? "APPLYING RISK PROTOCOLS..." : "SAVE RISK MATRIX PROTOCOLS"}
              </button>
            </div>
          </form>
        </div>

        {/* Right Column: Current Risk Analysis & Asset Exposure (lg:span-6) */}
        <div className="lg:col-span-6 space-y-6">
          
          {/* Current Risk Analysis Box */}
          <div className="bg-[#0d0e12] border border-[#1a1d26] p-5 rounded space-y-4 panel-glow">
            <div className="flex items-center gap-2 text-[#FA1F4E] font-mono font-bold text-xs uppercase tracking-wider border-b border-[#11131c] pb-3">
              <ShieldCheck className="w-4 h-4 text-[#FA1F4E]" />
              CURRENT RISK ANALYSIS
            </div>

            <div className="space-y-3 font-mono">
              {/* Healthy Status Box */}
              <div className="bg-[#06070a] border border-[#00e676]/30 p-3.5 rounded flex items-start gap-3">
                <ShieldCheck className="w-4 h-4 text-[#00e676] shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <div className="text-xs font-bold text-[#00e676] uppercase">SYSTEM STATUS HEALTHY</div>
                  <div className="text-[11px] text-[#8a8d9a]">
                    All systems operating normally. Zero drawdown protocol consumption.
                  </div>
                </div>
              </div>

              {/* Shariah Safeguard Box */}
              {formData.shariah_guard_enabled && (
                <div className="bg-[#06070a] border border-[#FA1F4E]/30 p-3.5 rounded flex items-start gap-3">
                  <AlertCircle className="w-4 h-4 text-[#FA1F4E] shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    <div className="text-xs font-bold text-[#FA1F4E] uppercase">SHARIAH SAFEGUARD ACTIVE</div>
                    <div className="text-[11px] text-[#8a8d9a]">
                      Islamic spot check validation locks margin lending and swaps securely.
                    </div>
                  </div>
                </div>
              )}

              {/* Anti-Whale Box */}
              {formData.stealth_mode && (
                <div className="bg-[#06070a] border border-[#3b82f6]/30 p-3.5 rounded flex items-start gap-3">
                  <Zap className="w-4 h-4 text-[#3b82f6] shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    <div className="text-xs font-bold text-[#3b82f6] uppercase">STEALTH ROUTING ONLINE</div>
                    <div className="text-[11px] text-[#8a8d9a]">
                      Order splitting active across liquidity pools with randomized delay buffers.
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Risk Distribution By Asset Box */}
          <div className="bg-[#0d0e12] border border-[#1a1d26] p-5 rounded space-y-4 panel-glow">
            <div className="flex items-center justify-between border-b border-[#11131c] pb-3">
              <div className="flex items-center gap-2 text-[#FA1F4E] font-mono font-bold text-xs uppercase tracking-wider">
                <Activity className="w-4 h-4 text-[#FA1F4E]" />
                RISK DISTRIBUTION BY ASSET
              </div>
              <span className="text-[10px] text-[#8a8d9a] font-mono font-bold uppercase">
                {positions.length > 0 ? `${positions.length} ACTIVE POSITIONS` : "100% USDT LIQUIDITY"}
              </span>
            </div>

            {positions.length === 0 ? (
              <div className="py-8 text-center text-[#8a8d9a] font-mono text-xs italic tracking-wider uppercase border border-dashed border-[#1a1d26] rounded p-4">
                NO ACTIVE TOKEN EXPOSURES. ALL CAPITAL IS HELD SAFELY IN USDT LIQUIDITY.
              </div>
            ) : (
              <div className="space-y-3 font-mono">
                {Object.keys(assetExposureMap).map((asset) => {
                  const locked = assetExposureMap[asset];
                  const pct = totalLockedMargin > 0 ? (locked / totalLockedMargin) * 100 : 0;
                  return (
                    <div key={asset} className="space-y-1 bg-[#06070a] border border-[#1a1d26] p-3 rounded">
                      <div className="flex justify-between items-center text-xs">
                        <span className="text-white font-bold">{asset}/USDT</span>
                        <span className="text-[#3b82f6] font-bold">
                          ${locked.toLocaleString("en-US", { minimumFractionDigits: 2 })} ({pct.toFixed(1)}%)
                        </span>
                      </div>
                      <div className="w-full bg-[#11131c] h-1.5 rounded-full overflow-hidden">
                        <div
                          className="bg-[#FA1F4E] h-full rounded-full transition-all duration-500"
                          style={{ width: `${Math.min(100, pct)}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

        </div>
      </div>

      {/* Bottom Deck: Active Real-Time Positions Ledger */}
      <div className="bg-[#0d0e12] border border-[#1a1d26] rounded overflow-hidden panel-glow">
        <div className="bg-[#090a0d] px-4 py-3 border-b border-[#11131c] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-[#FA1F4E]" />
            <span className="text-[10px] text-[#FA1F4E] font-mono font-bold tracking-wider uppercase">
              ACTIVE REAL-TIME POSITIONS LEDGER & RISK LIQUIDATION DECK
            </span>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-[10px] text-[#8a8d9a] font-mono font-bold">
              AGGREGATE P&L:{" "}
              <span className={totalPnL >= 0 ? "text-[#00e676]" : "text-[#ff1744]"}>
                {totalPnL >= 0 ? "+" : ""}${ (totalPnL ?? 0).toLocaleString("en-US", { minimumFractionDigits: 2 })}
              </span>
            </span>
            <button onClick={fetchData} className="text-[#8a8d9a] hover:text-[#FA1F4E] transition-colors">
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-[#11131c] text-[#8a8d9a] uppercase font-mono bg-[#06070a]">
                <th className="py-3 px-4 font-semibold">CORE ID</th>
                <th className="py-3 px-4 font-semibold">ASSET PAIR</th>
                <th className="py-3 px-4 font-semibold">POSITION SIZE</th>
                <th className="py-3 px-4 font-semibold">ENTRY PRICE</th>
                <th className="py-3 px-4 font-semibold">MARK PRICE</th>
                <th className="py-3 px-4 font-semibold">UNREALIZED P&L</th>
                <th className="py-3 px-4 font-semibold">MARGIN TYPE</th>
                <th className="py-3 px-4 font-semibold text-right">ACTION</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1a1d26]">
              {positions.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-10 text-center text-[#8a8d9a] font-mono uppercase text-xs">
                    NO ACTIVE SPOT POSITIONS RECORDED IN HIGH-FREQUENCY MEMORY
                  </td>
                </tr>
              ) : (
                positions.map((pos, idx) => (
                  <tr key={idx} className="hover:bg-[#12161f] font-mono">
                    <td className="py-3 px-4 text-white font-extrabold">{pos.engineId.toUpperCase()}</td>
                    <td className="py-3 px-4 text-white font-bold">{pos.symbol}</td>
                    <td className="py-3 px-4 text-[#3b82f6] font-bold">{pos.amount}</td>
                    <td className="py-3 px-4">${(pos.entry_price ?? 0).toLocaleString("en-US", { minimumFractionDigits: 2 })}</td>
                    <td className="py-3 px-4">${(pos.current_price ?? 0).toLocaleString("en-US", { minimumFractionDigits: 2 })}</td>
                    <td className={`py-3 px-4 font-bold ${pos.pnl >= 0 ? "text-[#00e676]" : "text-[#ff1744]"}`}>
                      {pos.pnl >= 0 ? "+" : ""}${(pos.pnl ?? 0).toLocaleString("en-US", { minimumFractionDigits: 2 })} ({(pos.roi ?? 0).toFixed(2)}%)
                    </td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 border border-[#ffb800] text-[#ffb800] bg-[rgba(255,184,0,0.05)] rounded text-[9px] font-bold">
                        ISOLATED SPOT
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => handleClosePosition(pos.engineId, pos.symbol, pos.amount, pos.pnl >= 0 ? "BUY" : "SELL")}
                        disabled={closing === pos.engineId}
                        className="px-2.5 py-1 bg-[rgba(255,23,68,0.15)] border border-[#ff1744] hover:bg-[#ff1744] text-[#ff1744] hover:text-white rounded text-[10px] font-bold uppercase transition-all"
                      >
                        {closing === pos.engineId ? "HALTING..." : "LIQUIDATE"}
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};

export default RiskManager;
