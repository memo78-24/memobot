import React, { useState } from "react";
import { 
  Users, 
  Crown, 
  Sparkles, 
  TrendingUp, 
  Award, 
  ShieldCheck, 
  Briefcase, 
  Globe, 
  ChevronRight, 
  Coins, 
  Zap, 
  CheckCircle2, 
  Lock,
  ArrowUpRight,
  MessageSquare,
  Gift,
  Building2,
  PieChart
} from "lucide-react";
import { useTheme } from "../components/ThemeProvider";
import { useLanguage } from "../components/LanguageProvider";
import { useNotification } from "../components/NotificationProvider";

export const BusinessClub: React.FC = () => {
  const { t } = useLanguage();
  const { showAlert } = useNotification();
  let accentColor = "#FA1F4E";
  try {
    const theme = useTheme();
    if (theme?.accentColor) accentColor = theme.accentColor;
  } catch (e) {}

  const [activeSubTab, setActiveSubTab] = useState<"tiers" | "deals" | "syndicate" | "events">("tiers");

  const clubTiers = [
    {
      id: "executive",
      name: "MEMO EXECUTIVE",
      subtitle: "High-Volume Quant Traders & Individual Family Offices",
      allocationReq: "$25,000+ AUM",
      accent: "#3b82f6",
      benefits: [
        "Priority Tier-1 Multi-Exchange WebSocket pipeline",
        "Direct Shariah Board fatwa validation engine",
        "Real-time HighTechEye multi-pair breakout alerts",
        "Executive Telegram Alpha Syndicate channel access",
        "Zero platform markup on algorithmic execution"
      ],
      current: false
    },
    {
      id: "vip-prime",
      name: "VIP PRO SPACE (PRIME)",
      subtitle: "Institutional Desks, Prop Firms & Sovereign Wealth Syndicates",
      allocationReq: "$100,000+ AUM",
      accent: accentColor,
      benefits: [
        "All Executive Tier Privileges Included",
        "Dedicated Quant & Shariah Risk Engineering Co-Pilot",
        "Exclusive Co-Investment in Proprietary Algo Vaults",
        "Direct API Dedicated VPS & Sub-millisecond Execution Hub",
        "VIP Quarterly Executive Roundtables & Alpha Briefings",
        "100% Capital Protection Drawdown Kernel Priority"
      ],
      current: true
    },
    {
      id: "sovereign",
      name: "SOVEREIGN GUILD",
      subtitle: "Enterprise Liquidity Providers & Global Islamic Funds",
      allocationReq: "$500,000+ AUM",
      accent: "#eab308",
      benefits: [
        "Custom Custom-Tailored Smart Contract Execution Enclaves",
        "Hardware Security Module (HSM) Dedicated Vault Enclave",
        "Institutional White-Label Engine Deployment License",
        "Direct Governance Seat on MemoBot Protocol Council",
        "Bespoke High-Frequency Strategy Architecture"
      ],
      current: false
    }
  ];

  const dealFlow = [
    {
      id: "DF-901",
      title: "HALAL DEFI LIQUIDITY HARVESTER SYNDICATE",
      roiEstimate: "18.4% APY (100% Shariah Certified)",
      capacity: "$1,200,000 / $2,000,000",
      progress: 60,
      riskRating: "LOW RISK (1x SPOT)",
      status: "OPEN",
      badge: "EXCLUSIVE"
    },
    {
      id: "DF-902",
      title: "HFT ARBITRAGE POOL (MEMOBOT PRIME ALPHA)",
      roiEstimate: "24.2% Net Target",
      capacity: "$4,850,000 / $5,000,000",
      progress: 97,
      riskRating: "CAPITAL SAFEGUARDED (1.5% MAX SL)",
      status: "FILLING FAST",
      badge: "HOT"
    },
    {
      id: "DF-903",
      title: "SUKUK-BACKED DIGITAL COMMODITY VAULT",
      roiEstimate: "12.8% Annualized",
      capacity: "$800,000 / $1,500,000",
      progress: 53,
      riskRating: "AAOIFI COMPLIANT",
      status: "OPEN",
      badge: "VERIFIED"
    }
  ];

  return (
    <div id="business-club-page" className="flex-1 bg-[#06070a] p-4 sm:p-6 overflow-y-auto space-y-6 font-mono text-xs text-[#8a8d9a]">
      {/* Page Header Banner */}
      <div 
        style={{ borderColor: `${accentColor}30`, background: `linear-gradient(135deg, ${accentColor}10 0%, transparent 60%)` }}
        className="border p-5 rounded-lg flex flex-col md:flex-row justify-between items-start md:items-center gap-4 shrink-0"
      >
        <div className="space-y-1.5">
          <div className="flex items-center gap-2">
            <Crown className="w-6 h-6 animate-pulse" style={{ color: accentColor }} />
            <h2 className="text-2xl font-aquire text-white tracking-wider uppercase">
              {t("MEMO BUSINESS CLUB")}
            </h2>
            <span 
              style={{ backgroundColor: `${accentColor}20`, color: accentColor, borderColor: `${accentColor}50` }}
              className="text-[9px] font-black border px-2 py-0.5 rounded tracking-widest uppercase ml-2"
            >
              VIP PRIVATE NETWORK
            </span>
          </div>
          <p className="text-[11px] text-[#8a8d9a] font-sans max-w-3xl leading-relaxed">
            {t("Exclusive institutional syndicate network for accredited partners, family offices, and quant prop traders operating under strict Capital Protection & AAOIFI Shariah governance.")}
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="bg-[#0b0d13] border border-[#1b1e2a] px-3.5 py-2 rounded text-right">
            <span className="text-[9px] text-[#555] block font-bold">YOUR CLUB STATUS</span>
            <span className="text-[11px] font-black uppercase text-emerald-400 flex items-center gap-1.5 justify-end">
              <Sparkles className="w-3.5 h-3.5" />
              VIP PRO SPACE ACTIVE
            </span>
          </div>
          <button
            onClick={() => showAlert("Direct concierge session requested. VIP account manager will reach out via encrypted channel.")}
            style={{ backgroundColor: accentColor }}
            className="px-4 py-2 rounded font-bold text-white uppercase text-[10px] tracking-wider hover:opacity-90 transition-all flex items-center gap-1.5 shadow-[0_0_15px_rgba(250,31,78,0.3)]"
          >
            <Briefcase className="w-3.5 h-3.5" />
            VIP CONCIERGE
          </button>
        </div>
      </div>

      {/* Futuristic Syndicate Pools Announcement Banner */}
      <div className="relative bg-gradient-to-r from-[#0a0d18] via-[#0d101d] to-[#0a0d18] border border-cyan-500/40 rounded-xl p-5 shadow-[0_0_30px_rgba(6,182,212,0.15)] overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-full bg-radial-gradient from-cyan-500/15 via-transparent to-transparent pointer-events-none blur-2xl" />
        <div className="absolute -left-10 -bottom-10 w-40 h-40 bg-[#FA1F4E]/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-5">
          <div className="space-y-2 max-w-3xl">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="px-2.5 py-0.5 rounded-full bg-cyan-950/80 border border-cyan-500/50 text-cyan-400 text-[9px] font-black uppercase tracking-widest flex items-center gap-1.5 shadow-[0_0_10px_rgba(6,182,212,0.4)]">
                <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
                OFFICIAL SYNDICATE DISPATCH
              </span>
              <span className="px-2 py-0.5 rounded bg-emerald-950/60 border border-emerald-500/40 text-emerald-400 text-[9px] font-bold uppercase">
                AAOIFI SHARIAH COMPLIANT 21/59
              </span>
              <span className="text-[10px] text-[#717684] font-mono">
                CYCLE Q3/Q4 • POOL STATUS: 80.5% COMMITTED
              </span>
            </div>

            <h3 className="text-base sm:text-lg font-black text-white uppercase tracking-wider font-sans flex items-center gap-2">
              <Zap className="w-5 h-5 text-cyan-400 shrink-0" />
              <span>PRIVATE QUANTITATIVE SYNDICATE POOLS NOW OPEN FOR ALLOCATION</span>
            </h3>

            <p className="text-[11px] text-[#a0a4b8] font-sans leading-relaxed">
              Institutional algorithmic pools (Physical Gold Arbitrage, Halal DeFi Liquidity, and Sub-millisecond HFT Momentum) are now accepting reserved capital allocations. Featuring automated high-watermark profit sharing (Mudharabah principle), zero margin loans, and hardware-enforced 1.0% stop-loss clamping.
            </p>

            <div className="flex items-center gap-4 text-[10px] pt-1 flex-wrap text-white/80">
              <div className="flex items-center gap-1.5 text-emerald-400">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>100% Non-Custodial Multi-Sig Escrow</span>
              </div>
              <div className="flex items-center gap-1.5 text-cyan-400">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Zero Overnight Swap (0.00% Riba)</span>
              </div>
              <div className="flex items-center gap-1.5 text-amber-400">
                <Coins className="w-3.5 h-3.5" />
                <span>Target Net APY: 18.4% - 34.2%</span>
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row lg:flex-col gap-2.5 shrink-0 w-full lg:w-auto">
            <button
              onClick={() => setActiveSubTab("deals")}
              className="px-5 py-2.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-black font-black uppercase text-[10px] tracking-wider transition-all flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(6,182,212,0.4)] cursor-pointer"
            >
              <PieChart className="w-4 h-4" />
              <span>EXPLORE ACTIVE POOLS</span>
            </button>
            <button
              onClick={() => showAlert("Syndicate prospectus and compliance term sheet routed to your registered account.")}
              className="px-5 py-2 rounded-lg bg-[#141824] hover:bg-[#1f2538] border border-[#262c40] text-white font-bold uppercase text-[10px] tracking-wider transition-all flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <ArrowUpRight className="w-3.5 h-3.5 text-cyan-400" />
              <span>REQUEST TERM SHEET</span>
            </button>
          </div>
        </div>
      </div>

      {/* Internal Navigation Subtabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-[#161822] pb-3">
        {[
          { id: "tiers" as const, label: "MEMBERSHIP TIERS", icon: Crown },
          { id: "deals" as const, label: "PRIVATE SYNDICATE DEALS", icon: PieChart },
          { id: "syndicate" as const, label: "GLOBAL ALPHA NETWORK", icon: Globe },
          { id: "events" as const, label: "EXECUTIVE ROUNDTABLES", icon: Building2 },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeSubTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveSubTab(tab.id)}
              style={
                isActive
                  ? {
                      borderColor: accentColor,
                      backgroundColor: `${accentColor}20`,
                      color: "#ffffff",
                      boxShadow: `0 0 12px ${accentColor}25`
                    }
                  : {}
              }
              className={`px-4 py-2 rounded text-[10px] font-bold uppercase transition-all flex items-center gap-2 border ${
                isActive
                  ? ""
                  : "bg-[#090a0d] border-[#181a24] text-[#8a8d9a] hover:border-[#333] hover:text-white"
              }`}
            >
              <Icon className="w-3.5 h-3.5" style={{ color: isActive ? accentColor : "#8a8d9a" }} />
              <span>{t(tab.label)}</span>
            </button>
          );
        })}
      </div>

      {/* Tiers View */}
      {activeSubTab === "tiers" && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {clubTiers.map((tier) => (
              <div
                key={tier.id}
                style={{ borderColor: tier.current ? tier.accent : "#1b1e2a" }}
                className={`bg-[#0b0d13] border rounded-lg p-5 flex flex-col justify-between space-y-5 transition-all ${
                  tier.current ? "shadow-[0_0_25px_rgba(250,31,78,0.15)] ring-1 ring-white/10" : "hover:border-[#333]"
                }`}
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span 
                      style={{ color: tier.accent }}
                      className="text-xs font-black uppercase tracking-wider font-aquire flex items-center gap-1.5"
                    >
                      <Award className="w-4 h-4" />
                      {tier.name}
                    </span>
                    {tier.current ? (
                      <span className="bg-emerald-500/15 text-emerald-400 border border-emerald-500/40 text-[9px] font-black px-2 py-0.5 rounded uppercase">
                        ACTIVE TIER
                      </span>
                    ) : (
                      <span className="text-[9px] text-[#666] font-bold uppercase">
                        QUALIFYING
                      </span>
                    )}
                  </div>

                  <p className="text-[11px] text-[#8a8d9a] font-sans leading-snug">
                    {tier.subtitle}
                  </p>

                  <div className="bg-[#07080b] p-2.5 rounded border border-[#161822] flex justify-between items-center text-[10px]">
                    <span className="text-slate-400">MINIMUM LIQUIDITY:</span>
                    <span className="text-white font-bold">{tier.allocationReq}</span>
                  </div>

                  <div className="space-y-2 pt-2 border-t border-[#161822]">
                    <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block">
                      TIER ADVANTAGES:
                    </span>
                    {tier.benefits.map((b, i) => (
                      <div key={i} className="flex items-start gap-2 text-[10px] text-slate-300">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                        <span>{b}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <button
                  onClick={() => showAlert(tier.current ? "You are currently operating on this tier." : `Upgrade inquiry submitted for ${tier.name}. Desk officer will verify AUM bounds.`)}
                  style={tier.current ? { borderColor: tier.accent, color: tier.accent } : { backgroundColor: tier.accent, color: "#ffffff" }}
                  className={`w-full py-2.5 rounded font-bold text-[10px] tracking-wider uppercase transition-all border ${
                    tier.current ? "bg-transparent hover:bg-white/5" : "hover:opacity-90"
                  }`}
                >
                  {tier.current ? "CURRENT SUBSCRIPTION" : "UPGRADE ACCESS"}
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Syndicate Deal Flow */}
      {activeSubTab === "deals" && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white uppercase font-aquire flex items-center gap-2">
              <Zap className="w-4 h-4 text-amber-400" />
              EXCLUSIVE SYNDICATE ALLOCATIONS & CO-INVESTMENT POOLS
            </h3>
            <span className="text-[10px] text-slate-400">UPDATED: REAL-TIME LEDGER FEED</span>
          </div>

          <div className="grid grid-cols-1 gap-4">
            {dealFlow.map((deal) => (
              <div key={deal.id} className="bg-[#0b0d13] border border-[#1b1e2a] p-4 rounded-lg flex flex-col md:flex-row justify-between items-start md:items-center gap-4 hover:border-[#333] transition-all">
                <div className="space-y-1.5 flex-1">
                  <div className="flex items-center gap-2.5">
                    <span className="text-white font-bold text-xs">{deal.title}</span>
                    <span className="text-[9px] bg-amber-500/10 text-amber-400 border border-amber-500/30 px-1.5 py-0.2 rounded font-black">
                      {deal.badge}
                    </span>
                    <span className="text-[9px] text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-1.5 py-0.2 rounded font-mono font-bold">
                      {deal.roiEstimate}
                    </span>
                  </div>
                  <div className="flex flex-wrap items-center gap-4 text-[10px] text-[#777]">
                    <span>DEAL ID: <strong className="text-slate-300">{deal.id}</strong></span>
                    <span>SECURITY: <strong className="text-slate-300">{deal.riskRating}</strong></span>
                    <span>CAPACITY COMMITTED: <strong className="text-white">{deal.capacity} ({deal.progress}%)</strong></span>
                  </div>
                  {/* Progress Bar */}
                  <div className="w-full bg-[#141722] h-1.5 rounded-full overflow-hidden">
                    <div 
                      className="bg-gradient-to-r from-emerald-500 to-cyan-500 h-full rounded-full"
                      style={{ width: `${deal.progress}%` }}
                    />
                  </div>
                </div>

                <button
                  onClick={() => showAlert(`Syndicate reservation request submitted for ${deal.id}. Compliance officer will route term sheet to your registered address.`)}
                  style={{ backgroundColor: accentColor }}
                  className="px-4 py-2 rounded font-bold text-white text-[10px] uppercase tracking-wider hover:opacity-90 transition-all flex items-center gap-1.5 shrink-0"
                >
                  <ArrowUpRight className="w-3.5 h-3.5" />
                  REQUEST PROSPECTUS
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Global Syndicate Network View */}
      {activeSubTab === "syndicate" && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-[#0b0d13] border border-[#1b1e2a] p-5 rounded-lg space-y-3">
            <h4 className="text-xs font-bold text-white uppercase font-aquire flex items-center gap-2">
              <Globe className="w-4 h-4 text-blue-400" />
              GLOBAL CAPITAL HUBS & DESKS
            </h4>
            <p className="text-[11px] text-[#8a8d9a] font-sans leading-relaxed">
              MemoBot FX-Pro operates private institutional gateway nodes connected with institutional liquidity hubs across London, Dubai, Singapore, Frankfurt, and Zurich.
            </p>
            <div className="space-y-2 pt-2 text-[10px]">
              <div className="flex justify-between items-center p-2 bg-[#07080b] rounded border border-[#141722]">
                <span className="text-slate-300">DUBAI (DIFC / MENA SHARIAH HUB)</span>
                <span className="text-emerald-400 font-bold">OPERATIONAL (0.24ms)</span>
              </div>
              <div className="flex justify-between items-center p-2 bg-[#07080b] rounded border border-[#141722]">
                <span className="text-slate-300">LONDON (LSEX / MAYFAIR DESK)</span>
                <span className="text-emerald-400 font-bold">OPERATIONAL (0.18ms)</span>
              </div>
              <div className="flex justify-between items-center p-2 bg-[#07080b] rounded border border-[#141722]">
                <span className="text-slate-300">SINGAPORE (SGX / MARINA BAY)</span>
                <span className="text-emerald-400 font-bold">OPERATIONAL (0.31ms)</span>
              </div>
            </div>
          </div>

          <div className="bg-[#0b0d13] border border-[#1b1e2a] p-5 rounded-lg space-y-3">
            <h4 className="text-xs font-bold text-white uppercase font-aquire flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              EXCLUSIVE SHARIAH GOVERNANCE COUNCIL
            </h4>
            <p className="text-[11px] text-[#8a8d9a] font-sans leading-relaxed">
              Every syndicate vehicle and automated strategy deployed under Memo Business Club undergoes continuous auditing under AAOIFI Standard No. 21 and Standard No. 59.
            </p>
            <div className="bg-[#07080b] p-3 rounded border border-[#141722] space-y-2 text-[10px]">
              <div className="flex justify-between">
                <span className="text-slate-400">CHIEF AUDITOR:</span>
                <span className="text-white font-bold">MEMOBOT SHARIAH BOARD</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">CERTIFICATE NO:</span>
                <span className="text-emerald-400 font-mono font-bold">AAOIFI-2026-FXPRO-9921</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">SPOT LEVERAGE:</span>
                <span className="text-white">STRICT 1:1 (ZERO RIBA & ZERO GHARAR)</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Events View */}
      {activeSubTab === "events" && (
        <div className="bg-[#0b0d13] border border-[#1b1e2a] p-6 rounded-lg space-y-4">
          <div className="flex items-center justify-between border-b border-[#161822] pb-3">
            <h3 className="text-xs font-bold text-white uppercase font-aquire flex items-center gap-2">
              <Building2 className="w-4 h-4" style={{ color: accentColor }} />
              UPCOMING EXECUTIVE ROUNDTABLES & SYNDICATE SUMMITS
            </h3>
            <span className="text-[10px] text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 rounded font-bold">
              INVITATION ONLY
            </span>
          </div>

          <div className="space-y-3">
            <div className="p-4 bg-[#07080b] border border-[#161822] rounded-lg flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div className="space-y-1">
                <span className="text-[9px] text-[#777] uppercase font-bold">OCTOBER 15, 2026 • DUBAI DIFC</span>
                <h5 className="text-xs font-bold text-white">MEMOBOT GLOBAL QUANT & ISLAMIC FINTECH SUMMIT 2026</h5>
                <p className="text-[10px] text-[#8a8d9a] font-sans">
                  Keynote sessions on autonomous multi-engine algorithmic execution, capital protection architecture, and AI-driven Shariah risk management.
                </p>
              </div>
              <button
                onClick={() => showAlert("VIP Summit Pass RSVP recorded. Confirmation sent to secure mailbox.")}
                style={{ backgroundColor: accentColor }}
                className="px-4 py-2 rounded text-[10px] font-bold text-white uppercase hover:opacity-90 transition-all shrink-0"
              >
                RESERVE VIP PASS
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default BusinessClub;
