import React, { useState, useEffect } from 'react';
import { Bot, TrendingUp, TrendingDown, Clock, Activity, Zap, RefreshCw, Briefcase, ChevronRight } from 'lucide-react';
import { ApiClient } from '../services/api';
import { useNotification } from '../components/NotificationProvider';

export function TelegramMiniApp() {
  const [advice, setAdvice] = useState<string>("Analyzing market sentiment...");
  const [paperBalance, setPaperBalance] = useState<number>(100000);
  const [activeTrades, setActiveTrades] = useState<any[]>([]);
  const { showAlert } = useNotification();

  // 1- Hourly Advice
  useEffect(() => {
    const advices = [
      "EUR/USD showing strong support at 1.0850. Consider long positions with tight stops.",
      "Gold (XAU/USD) volatility increasing ahead of FOMC. Reduce exposure.",
      "GBP/JPY breakout imminent. Watch 190.20 resistance level closely.",
      "Crypto markets consolidating. Bitcoin holding above 60k. Favorable risk/reward for altcoins."
    ];
    setAdvice(advices[Math.floor(Math.random() * advices.length)]);
    const interval = setInterval(() => {
      setAdvice(advices[Math.floor(Math.random() * advices.length)]);
    }, 3600000); // hourly
    return () => clearInterval(interval);
  }, []);

  // 3- Simulation Trading Engine
  const handlePaperTrade = (pair: string, side: 'BUY' | 'SELL', amount: number) => {
    if (paperBalance < amount) {
      showAlert("Insufficient paper balance!");
      return;
    }
    setPaperBalance(prev => prev - amount);
    const newTrade = {
      id: Math.random().toString(36).substr(2, 9),
      pair,
      side,
      amount,
      entryPrice: pair === 'EUR/USD' ? 1.0850 : 190.20,
      pnl: 0,
      time: new Date().toLocaleTimeString()
    };
    setActiveTrades(prev => [newTrade, ...prev]);
    showAlert(`Paper trade executed: ${side} ${pair} for $${amount}`);
  };

  const closeTrade = (id: string, amount: number) => {
    const trade = activeTrades.find(t => t.id === id);
    if (!trade) return;
    
    // Simulate random PnL between -5% and +10%
    const pnlPercent = (Math.random() * 0.15) - 0.05;
    const pnl = amount * pnlPercent;
    
    setPaperBalance(prev => prev + amount + pnl);
    setActiveTrades(prev => prev.filter(t => t.id !== id));
    showAlert(`Trade closed. PnL: $${pnl.toFixed(2)}`);
  };

  return (
    <div className="min-h-screen bg-[#06070a] text-white flex flex-col font-sans">
      {/* 4- Exact theme and logo header */}
      <header className="p-4 border-b border-[#1a1d26] bg-[#0d0e12] flex items-center justify-between sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#00e676] to-[#00b0ff] p-0.5 shadow-[0_0_15px_rgba(0,230,118,0.3)]">
            <div className="w-full h-full bg-[#06070a] rounded-full flex items-center justify-center">
              <Bot className="w-4 h-4 text-[#00e676]" />
            </div>
          </div>
          <div>
            <h1 className="text-white font-extrabold uppercase tracking-widest text-sm leading-none">MEMOBOT</h1>
            <span className="text-[#00e676] text-[9px] font-bold tracking-widest uppercase">FX-PRO MINI APP</span>
          </div>
        </div>
        
        {/* 2- Numbers counter on top Remaining 24 days */}
        <div className="bg-[#1a1d26] px-3 py-1.5 rounded-full flex items-center gap-2 border border-[#3b82f6]/30">
          <Clock className="w-3.5 h-3.5 text-[#3b82f6]" />
          <div className="flex flex-col">
            <span className="text-[8px] text-[#8a8d9a] uppercase font-bold leading-none">Trial Remaining</span>
            <span className="text-[#3b82f6] text-[11px] font-extrabold leading-none mt-0.5">24 DAYS</span>
          </div>
        </div>
      </header>

      <main className="flex-1 overflow-y-auto p-4 space-y-5 pb-24">
        {/* 1- Hourly Advice */}
        <section className="bg-gradient-to-r from-[#3b82f6]/10 to-transparent border border-[#3b82f6]/30 p-4 rounded-xl relative overflow-hidden">
          <div className="absolute top-0 right-0 p-2 opacity-10">
            <Activity className="w-16 h-16 text-[#3b82f6]" />
          </div>
          <h2 className="text-[#3b82f6] text-[10px] font-bold uppercase tracking-widest mb-2 flex items-center gap-1.5">
            <Zap className="w-3.5 h-3.5" />
            Live Market Advice (Hourly)
          </h2>
          <p className="text-white text-sm font-medium leading-relaxed">
            {advice}
          </p>
        </section>

        {/* 3- Simulation Trading Engine */}
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-white text-xs font-bold uppercase tracking-widest flex items-center gap-2">
              <Briefcase className="w-4 h-4 text-[#00e676]" />
              Paper Trading Engine
            </h2>
            <div className="text-right">
              <div className="text-[9px] text-[#8a8d9a] uppercase font-bold">Paper Balance</div>
              <div className="text-[#00e676] text-lg font-extrabold">${paperBalance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="bg-[#0d0e12] border border-[#1a1d26] p-3 rounded-xl flex flex-col gap-3">
              <div className="flex justify-between items-center">
                <span className="text-white font-bold text-sm">EUR/USD</span>
                <span className="text-[#00e676] text-xs">1.0850</span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <button 
                  onClick={() => handlePaperTrade('EUR/USD', 'BUY', 1000)}
                  className="bg-[#00e676]/10 hover:bg-[#00e676]/20 border border-[#00e676]/50 text-[#00e676] py-1.5 rounded text-[10px] font-bold uppercase transition-colors"
                >
                  Buy
                </button>
                <button 
                  onClick={() => handlePaperTrade('EUR/USD', 'SELL', 1000)}
                  className="bg-[#FA1F4E]/10 hover:bg-[#FA1F4E]/20 border border-[#FA1F4E]/50 text-[#FA1F4E] py-1.5 rounded text-[10px] font-bold uppercase transition-colors"
                >
                  Sell
                </button>
              </div>
            </div>

            <div className="bg-[#0d0e12] border border-[#1a1d26] p-3 rounded-xl flex flex-col gap-3">
              <div className="flex justify-between items-center">
                <span className="text-white font-bold text-sm">GBP/JPY</span>
                <span className="text-[#00e676] text-xs">190.20</span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <button 
                  onClick={() => handlePaperTrade('GBP/JPY', 'BUY', 1000)}
                  className="bg-[#00e676]/10 hover:bg-[#00e676]/20 border border-[#00e676]/50 text-[#00e676] py-1.5 rounded text-[10px] font-bold uppercase transition-colors"
                >
                  Buy
                </button>
                <button 
                  onClick={() => handlePaperTrade('GBP/JPY', 'SELL', 1000)}
                  className="bg-[#FA1F4E]/10 hover:bg-[#FA1F4E]/20 border border-[#FA1F4E]/50 text-[#FA1F4E] py-1.5 rounded text-[10px] font-bold uppercase transition-colors"
                >
                  Sell
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* Active Paper Trades */}
        <section className="space-y-3 pt-2">
          <h3 className="text-[#8a8d9a] text-[10px] font-bold uppercase tracking-widest border-b border-[#1a1d26] pb-2">
            Active Paper Positions ({activeTrades.length})
          </h3>
          
          <div className="space-y-2">
            {activeTrades.length === 0 ? (
              <div className="text-center py-6 text-[#8a8d9a] text-xs border border-dashed border-[#1a1d26] rounded-xl">
                No active paper trades
              </div>
            ) : (
              activeTrades.map(trade => (
                <div key={trade.id} className="bg-[#0d0e12] border border-[#1a1d26] p-3 rounded-lg flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded uppercase ${trade.side === 'BUY' ? 'bg-[#00e676]/20 text-[#00e676]' : 'bg-[#FA1F4E]/20 text-[#FA1F4E]'}`}>
                        {trade.side}
                      </span>
                      <span className="text-white font-bold text-xs">{trade.pair}</span>
                    </div>
                    <div className="text-[10px] text-[#8a8d9a] mt-1">
                      Amount: ${trade.amount} @ {trade.entryPrice}
                    </div>
                  </div>
                  
                  <button 
                    onClick={() => closeTrade(trade.id, trade.amount)}
                    className="text-[10px] bg-[#1a1d26] hover:bg-[#2a2d36] text-white px-3 py-1.5 rounded font-bold uppercase transition-colors border border-[#2a2d36]"
                  >
                    Close
                  </button>
                </div>
              ))
            )}
          </div>
        </section>
      </main>

      {/* Floating Action Button area for Telegram Mini App feel */}
      <div className="fixed bottom-4 left-4 right-4">
        <button 
          onClick={() => { window.location.href = "/"; }}
          className="w-full bg-gradient-to-r from-[#3b82f6] to-[#00b0ff] text-white font-bold text-xs py-3.5 rounded-xl uppercase tracking-widest shadow-[0_0_20px_rgba(59,130,246,0.4)] flex items-center justify-center gap-2"
        >
          Launch Full Terminal
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
