import React, { useEffect, useState } from "react";
import { STORAGE_KEYS, TOPICS } from "./config/constants";
import { ApiClient } from "./services/api";
import { WebSocketManager } from "./services/websocket";
import { Login } from "./pages/Login";
import { Header } from "./components/Header";
import { Sidebar } from "./components/Sidebar";
import { Dashboard } from "./pages/Dashboard";
import { Engines } from "./pages/Engines";
import { Strategies } from "./pages/Strategies";
import { RiskManager } from "./pages/RiskManager";
import { Portfolio } from "./pages/Portfolio";
import { Orders } from "./pages/Orders";
import { MarketIntel } from "./pages/MarketIntel";
import { Analytics } from "./pages/Analytics";
import { Audit } from "./pages/Audit";
import { AIChat } from "./pages/AIChat";
import { SecureVault } from "./pages/SecureVault";
import { BusinessClub } from "./pages/BusinessClub";
import { Billing } from "./pages/Billing";
import { Settings } from "./pages/Settings";
import { ShariyahBureau } from "./pages/ShariyahBureau";
import { IdentityMatrixDrawer } from "./components/IdentityMatrixDrawer";
import { ShariahConfirmationModal } from "./components/ShariahConfirmationModal";
import { useNotification } from "./components/NotificationProvider";
import { useLanguage } from "./components/LanguageProvider";
import { TelegramMiniApp } from "./pages/TelegramMiniApp";
import { ElementInspector } from "./components/ElementInspector";
import { TranslationStudioModal } from "./components/translation/TranslationStudioModal";
import { TranslationInspectorOverlay } from "./components/translation/TranslationInspectorOverlay";
import { SelectionQuickTranslator } from "./components/translation/SelectionQuickTranslator";
import { translationStore } from "./services/translationStore";
import { TranslationService } from "./services/translationService";


export default function App() {
  const isTelegramMiniApp = window.location.search.includes('tgWebAppData') || window.location.hash.includes('tgWebAppData') || window.location.hash.includes('telegram-mini');
  
  if (isTelegramMiniApp) {
    return <TelegramMiniApp />;
  }

  const { t } = useLanguage();
  const [token, setToken] = useState<string | null>(
    localStorage.getItem(STORAGE_KEYS.AUTH_TOKEN) || sessionStorage.getItem(STORAGE_KEYS.AUTH_TOKEN)
  );
  
  const sanitizeTab = (tab: string): string => {
    if (!tab) return "dashboard";
    if (tab === "control-deck") return "engines";
    const valid = [
      "dashboard", "decision-kernel", "engines", "strategies", "live-positions", "shariyah-bureau", "portfolio",
      "orders", "ai-chat", "market-intel", "analytics", "audit", "secure-vault", "business-club", "billing", "settings"
    ];
    return valid.includes(tab) ? tab : "dashboard";
  };

  const getInitialTab = () => {
    const hash = window.location.hash.replace("#", "");
    if (hash) return sanitizeTab(hash);
    const saved = localStorage.getItem(STORAGE_KEYS.ACTIVE_TAB);
    if (saved) return sanitizeTab(saved);
    return "dashboard";
  };

  const [activeTab, setActiveTabState] = useState<string>(getInitialTab());

  const navigateTab = (tab: string) => {
    const target = sanitizeTab(tab);
    setActiveTabState(target);
    localStorage.setItem(STORAGE_KEYS.ACTIVE_TAB, target);
    window.location.hash = target;
  };

  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.replace("#", "");
      if (hash) {
        const target = sanitizeTab(hash);
        setActiveTabState(target);
        localStorage.setItem(STORAGE_KEYS.ACTIVE_TAB, target);
      }
    };
    window.addEventListener("hashchange", handleHashChange);
    return () => window.removeEventListener("hashchange", handleHashChange);
  }, []);
  const [complianceMode, setComplianceMode] = useState<"Islamic" | "Commercial">("Islamic");
  const [engineStatus, setEngineStatus] = useState<string>("Stopped");
  const [portfolioBalances, setPortfolioBalances] = useState({
    equity: 0,
    unrealizedPnl: 0,
    usdtAvailable: 0,
    lockedMargin: 0,
    paperBalance: 0
  });
  const [wsStatus, setWsStatus] = useState<"CONNECTED" | "DISCONNECTED">("DISCONNECTED");
  const [translationState, setTranslationState] = useState(translationStore.getState());
  const { showAlert, showConfirm } = useNotification();

  useEffect(() => {
    return translationStore.subscribe((next) => setTranslationState({ ...next }));
  }, []);

  useEffect(() => {
    WebSocketManager.onStatusChange = (status) => {
      setWsStatus(status);
    };
    setWsStatus(WebSocketManager.isConnected() ? "CONNECTED" : "DISCONNECTED");
  }, []);

  const fetchGlobalSidebarStats = async () => {
    if (!token) return;
    try {
      const bData = await ApiClient.get("/execution/balances");
      const dData = await ApiClient.get("/execution/daily-stats");
      const sData = await ApiClient.get("/engine/status");

      setPortfolioBalances({
        equity: bData.net_worth || 0,
        unrealizedPnl: dData.unrealized_pnl || 0,
        usdtAvailable: bData.balances?.USDT || bData.balances?.usdt || 0,
        lockedMargin: dData.locked_margin || 0,
        paperBalance: bData.paper_balances?.USDT || bData.paper_balances?.usdt || 0
      });
      setComplianceMode(sData.compliance_mode);
      setEngineStatus(sData.status);
    } catch (err) {
      console.error("Failed to fetch global sidebar statistics:", err);
    }
  };

  useEffect(() => {
    if (token) {
      WebSocketManager.connect();
      fetchGlobalSidebarStats();

      // WS subscriptions (Rule 6, stateless reactivity)
      const unsubBalance = WebSocketManager.subscribe(TOPICS.BALANCE_CHANGED, () => {
        fetchGlobalSidebarStats();
      });

      const unsubEngine = WebSocketManager.subscribe(TOPICS.ENGINE_STATUS_CHANGED, () => {
        fetchGlobalSidebarStats();
      });

      const unsubMode = WebSocketManager.subscribe(TOPICS.ENGINE_MODE_CHANGED, () => {
        fetchGlobalSidebarStats();
      });

      const unsubCompliance = WebSocketManager.subscribe(TOPICS.COMPLIANCE_MODE_CHANGED, () => {
        fetchGlobalSidebarStats();
      });

      const unsubKill = WebSocketManager.subscribe(TOPICS.EMERGENCY_KILL_SWITCH_ACTIVATED, () => {
        fetchGlobalSidebarStats();
      });

      return () => {
        unsubBalance();
        unsubEngine();
        unsubMode();
        unsubCompliance();
        unsubKill();
      };
    } else {
      WebSocketManager.disconnect();
    }
  }, [token]);

  const handleLoginSuccess = (newToken: string) => {
    setToken(newToken);
    navigateTab("dashboard");
  };

  const [showShariahModal, setShowShariahModal] = useState(false);
  const [isSupportOpen, setIsSupportOpen] = useState(false);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  const handleLogout = () => {
    localStorage.removeItem(STORAGE_KEYS.AUTH_TOKEN);
    sessionStorage.removeItem(STORAGE_KEYS.AUTH_TOKEN);
    setToken(null);
  };

  const handleComplianceToggle = async (nextMode: "Islamic" | "Commercial") => {
    try {
      await ApiClient.post("/engine/compliance-mode", { compliance_mode: nextMode });
      setComplianceMode(nextMode);
      if (nextMode === "Islamic") {
        setShowShariahModal(true);
      } else {
        showAlert("Switched to Commercial Unrestricted Mode.");
      }
      await fetchGlobalSidebarStats();
    } catch (err: any) {
      showAlert(`Failed to set compliance protocol: ${err.message}`);
    }
  };

  if (!token) {
    return <Login onLoginSuccess={handleLoginSuccess} />;
  }

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[#06070a] text-white">
      {/* Mandatory Green Shariah Confirmation Modal */}
      <ShariahConfirmationModal
        isOpen={showShariahModal}
        onConfirm={() => setShowShariahModal(false)}
      />

      {/* Left Sidebar HUD (Responsive Drawer on Mobile, Sticky on Desktop) */}
      <Sidebar
        activeTab={activeTab}
        onNavigate={(tab) => {
          navigateTab(tab);
          setMobileSidebarOpen(false);
        }}
        engineStatus={engineStatus}
        equity={portfolioBalances.equity}
        unrealizedPnl={portfolioBalances.unrealizedPnl}
        usdtAvailable={portfolioBalances.usdtAvailable}
        lockedMargin={portfolioBalances.lockedMargin}
        paperBalance={portfolioBalances.paperBalance}
        isOpen={mobileSidebarOpen}
        onClose={() => setMobileSidebarOpen(false)}
      />

      {/* Center / Right main page canvas */}
      <div className="flex flex-col flex-1 min-w-0 overflow-hidden">
        {/* Upper header navigation */}
        <Header
          onLogout={handleLogout}
          complianceMode={complianceMode}
          onComplianceToggle={handleComplianceToggle}
          wsStatus={wsStatus}
          onOpenSupport={() => navigateTab("ai-chat")}
          onToggleMobileSidebar={() => setMobileSidebarOpen(!mobileSidebarOpen)}
          onReconnect={() => {
            WebSocketManager.disconnect();
            WebSocketManager.connect();
            setWsStatus("DISCONNECTED"); // visually toggle to allow reconnection blink
            setTimeout(() => {
              setWsStatus(WebSocketManager.isConnected() ? "CONNECTED" : "DISCONNECTED");
            }, 500);
            showAlert("Manually requesting WebSocket reconnection layer...");
          }}
        />

        <main className="flex-1 flex flex-col min-w-0 bg-[#06070a] overflow-x-auto overflow-y-auto relative custom-scrollbar">
          {activeTab === "dashboard" && (
            <Dashboard 
              onRefreshSidebar={fetchGlobalSidebarStats} 
              complianceMode={complianceMode}
              onComplianceToggle={handleComplianceToggle}
              onNavigateTo={(tab) => navigateTab(tab)}
            />
          )}
          {activeTab === "decision-kernel" && <Audit initialSubTab="decision-engine" />}
          {activeTab === "engines" && <Engines complianceMode={complianceMode} />}
          {activeTab === "strategies" && <Strategies complianceMode={complianceMode} />}
          {activeTab === "live-positions" && <RiskManager complianceMode={complianceMode} />}
          {activeTab === "shariyah-bureau" && (
            <ShariyahBureau
              complianceMode={complianceMode}
              onComplianceToggle={handleComplianceToggle}
            />
          )}
          {activeTab === "portfolio" && <Portfolio />}
          {activeTab === "orders" && <Orders />}
          {activeTab === "ai-chat" && <AIChat />}
          {activeTab === "market-intel" && (
            <MarketIntel complianceMode={complianceMode} />
          )}
          {activeTab === "analytics" && <Analytics />}
          {activeTab === "audit" && <Audit initialSubTab="audit-trail" />}
          {activeTab === "secure-vault" && <SecureVault />}
          {activeTab === "business-club" && <BusinessClub />}
          {activeTab === "billing" && <Settings initialSubTab="subscription" />}
          {activeTab === "settings" && <Settings />}
        </main>
      </div>

      {/* Global Visual DOM Inspector & Live Modifier Panel */}
      <ElementInspector />

      {/* Global Translation Studio Modal */}
      <TranslationStudioModal showAlert={showAlert} />

      {/* Global On-Screen Click-to-Translate Inspector Overlay */}
      <TranslationInspectorOverlay 
        isActive={translationState.isInspectorActive} 
        onClose={() => TranslationService.toggleInspector(false)}
        showAlert={showAlert}
      />

      {/* Global Mark-and-Translate Selection Tool */}
      <SelectionQuickTranslator showAlert={showAlert} />

      {/* Global Identity Matrix & Dynamic Role Routing Drawer */}
      <IdentityMatrixDrawer />
    </div>
  );
}
