export type TierId = "individual" | "investor" | "corporate" | "institutional";

export interface TierProfile {
  id: TierId;
  name: string;
  nameAr: string;
  category: string;
  categoryAr: string;
  resourceBound: string;
  resourceBoundAr: string;
  maxEngines: number;
  maxStrategies: number;
  authMethod: string;
  authMethodAr: string;
  scopes: string[];
  riskClamp: string;
  riskClampAr: string;
  interfaceHud: "Simplified HUD" | "Pro Dashboard" | "Multi-Tenant B2B" | "Quantum Mesh";
  interfaceHudAr: string;
  colorAccent: string;
  badge: string;
  tenantId?: string;
  latencySla: string;
  features: string[];
  featuresAr: string[];
}

export interface JWTPayloadInfo {
  sub: string;
  username: string;
  role: string;
  tier: TierId;
  scopes: string[];
  tenant_id?: string;
  max_engines: number;
  max_strategies: number;
  iat: number;
  exp: number;
  iss: string;
  aud: string;
  jti: string;
  raw_token: string;
}

export interface UserProfile {
  id: string;
  username: string;
  role: string;
  tier: TierId;
  email?: string;
  organization?: string;
  tenantId?: string;
  isActive: boolean;
  mfaEnabled?: boolean;
  biometricRegistered?: boolean;
  mtlsFingerprint?: string;
}

export interface EngineState {
  engine_id: string;
  display_name: string;
  nickname: string;
  subtitle: string;
  theme: string;
  status: 'Running' | 'Paused' | 'Stopped';
  uptime_seconds: number;
  current_stage_idx: number; // 0 to 9 representing the pipeline
  latency_ms: number;
  cpu_load: number;
  memory_mb: number;
  strategy: string;
  asset: string;
  amount: number;
  runtime_hours: number;
}

export interface StrategyInstance {
  id: string;
  strategy_name: string;
  status: 'Draft' | 'Active';
  version: number;
  revision: number;
  config: {
    ema_fast?: number;
    ema_slow?: number;
    stop_loss?: number;
    leverage?: number;
    learning_rate?: number;
    [key: string]: any;
  };
  created_at: string;
  updated_at: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  action: string;
  status: 'SUCCESS' | 'FAILED' | 'WARN';
  details: string;
  correlation_id: string;
  integrity_hash: string;
}

export interface LivePosition {
  symbol: string;
  amount: number;
  entry_price: number;
  current_price: number;
  pnl: number;
  roi: number;
  locked_margin: number;
}

export interface PortfolioBalances {
  net_worth: number;
  balance_usdt: number;
  locked_margin: number;
  unrealized_pnl: number;
  win_rate: number;
  total_trades: number;
  wins: number;
  losses: number;
}

export interface SocialCampaign {
  id: string;
  name: string;
  platform: 'Twitter/X' | 'LinkedIn' | 'Telegram' | 'Discord' | 'Reddit' | 'WhatsApp' | 'Email' | 'SMS' | 'Instagram' | 'TikTok' | 'Facebook';
  type: 'Outbound DM' | 'Reddit Thread' | 'Authority Thread' | 'LinkedIn Outreach' | 'Value Comment' | 'Newsletter' | 'Blast SMS' | 'Visual Post' | 'Video Script';
  status: 'Active' | 'Paused' | 'Completed';
  targetAudience: string;
  generatedApproachesCount: number;
  successRate: number;
}

export interface ActivityQueueItem {
  id: string;
  platform: 'Twitter/X' | 'LinkedIn' | 'Telegram' | 'Discord' | 'Reddit' | 'WhatsApp' | 'Email' | 'SMS' | 'Instagram' | 'TikTok' | 'Facebook';
  campaignName: string;
  content: string;
  recipient: string;
  scheduledAt: string;
  status: 'Pending' | 'Sent' | 'Failed';
  imageUrl?: string;
}
