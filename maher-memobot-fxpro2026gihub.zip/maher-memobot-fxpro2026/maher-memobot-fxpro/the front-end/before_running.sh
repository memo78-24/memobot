#!/bin/bash

# ==============================================================================
# MEMOBOT FX-PRO™ - LOCAL DEPLOYMENT BOOTSTRAP UTILITY
# ==============================================================================
# Run this script once immediately after downloading/extracting the application.
# It automatically inspects your environment, configures missing environment 
# variables, installs dependencies, and prepares the central engine system.
# ==============================================================================

# ANSI Color Codes for clean display
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

echo -e "${CYAN}====================================================${NC}"
echo -e "${CYAN}     MEMOBOT FX-PRO™ - INITIALIZATION UTILITY       ${NC}"
echo -e "${CYAN}====================================================${NC}"

# 1. Inspect Node.js Environment
echo -e "\n${BLUE}[1/4] Inspecting Local Runtime Engine...${NC}"
if ! command -v node &> /dev/null; then
    echo -e "${RED}ERROR: Node.js is not installed.${NC} Please download Node.js (v18+) to run this project."
    exit 1
else
    NODE_VERSION=$(node -v)
    echo -e "${GREEN}✓ Node.js detected: ${NODE_VERSION}${NC}"
fi

if ! command -v npm &> /dev/null; then
    echo -e "${RED}ERROR: npm is not installed.${NC} npm is required to install dependencies."
    exit 1
else
    NPM_VERSION=$(npm -v)
    echo -e "${GREEN}✓ npm detected: v${NPM_VERSION}${NC}"
fi

# 2. Re-establish Local Configuration (.env)
echo -e "\n${BLUE}[2/4] Setting Up Local Environment Settings...${NC}"
if [ ! -f .env ]; then
    if [ -f .env.example ]; then
        cp .env.example .env
        echo -e "${GREEN}✓ Created new '.env' file from '.env.example'.${NC}"
        echo -e "${YELLOW}👉 Note: Please edit '.env' and provide your secret API keys before booting up live engines.${NC}"
    else
        touch .env
        echo -e "PORT=3000\nNODE_ENV=production" > .env
        echo -e "${GREEN}✓ Created custom local '.env' file.${NC}"
    fi
else
    echo -e "${GREEN}✓ '.env' file already configured.${NC}"
fi

# 3. Installing Node.js Dependencies
echo -e "\n${BLUE}[3/4] Fetching Swarm Packages & Dependencies (npm install)...${NC}"
npm install
if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Swarm dependencies installed successfully.${NC}"
else
    echo -e "${RED}WARNING: Some dependency locks might have failed. Retrying with --legacy-peer-deps...${NC}"
    npm install --legacy-peer-deps
fi

# 4. Preparing Central SQLite/PostgreSQL Schema Migration
echo -e "\n${BLUE}[4/4] Aligning Central Engines Station Databases...${NC}"
# In case Drizzle migrations are pre-configured locally, run push:
npm run db:push 2>/dev/null || npx drizzle-kit push:pg 2>/dev/null || npx drizzle-kit push 2>/dev/null

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Central Engine databases and schemas migrated and synchronized.${NC}"
else
    echo -e "${YELLOW}Note: Local memory database used as secondary failover storage.${NC}"
fi

echo -e "\n${CYAN}====================================================${NC}"
echo -e "${GREEN}🎉 SETUP COMPLETED SUCCESSFULLY!${NC}"
echo -e "You can now boot up the server locally by running:"
echo -e "${YELLOW}  npm run dev${NC}"
echo -e "${CYAN}====================================================${NC}"
