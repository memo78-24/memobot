# MemoBot FX-Pro Custom Agent Instructions

## Core System Guidelines & Operational Guardrails

This project follows a strict architectural and layout philosophy. Do NOT deviate from these guidelines for any reason.

### 1. Structural Boundaries
- **Strict Dependency Flow**:
  `HTML ➔ Component ➔ Store ➔ Service ➔ ApiClient ➔ Backend`
  - Under no circumstances should a component fetch data directly or talk to the `ApiClient`.
  - Under no circumstances should a Service manipulate the DOM.
  - Under no circumstances should a Store know about HTML.
- **Component Fetching Rule**:
  - Components are 100% reactive. They subscribe to Stores and render. All fetch, retry, websocket, and state synchronization actions happen in Services and Core libraries.
- **WebSocket Rules**:
  - Exactly one connection through `WebSocketManager` handles message parsing and notifies/invalidates the relevant Stores. Individual components or pages must NEVER initialize WebSockets or read direct WS frames.

### 2. Architectural Honesty & Integrity (Anti-AI-Slop)
- **No Simulation Clutter**: Keep outer backgrounds clean. Do not add unrequested telemetry lines, terminal-style fake boot logs (`CORE_NODE_ONLINE`), port details, or visual margin decoration.
- **No Unrequested Theme Switchers**: Use a single polished aesthetic (slate dark/deep charcoal with clean blue/emerald accents) that fits the high-tech trading platform mood.

### 3. File Size Constraints
- **HTML**: < 200 lines
- **CSS**: < 250 lines
- **JS/TS**: < 300 lines
- **Services**: < 250 lines
- **Stores**: < 200 lines
- *If any file exceeds these thresholds, it MUST be modularized immediately.*

### 4. Critical Trading Integrity
- **No Client-Side Financial Magic**: No mock or simulated pricing/calculations on the client side. All figures must be calculated server-side or sourced directly from verified exchange responses.
- **Correlation ID Tracking**: Every API call and log entry must pass a generated Correlation ID in the headers (`X-Correlation-ID`) to ensure unified distributed tracing and robust auditing.
