# MEMOBOT-FXPRO Core Roadmap & Execution Plan

This document outlines the authoritative engineering roadmap and progress checklist for **MEMOBOT-FXPRO**, a highly advanced, multi-tenant proprietary algorithmic trading SaaS platform.

## Mandatory Engineering Rules
- **Rule 1: Strict Dependency Flow**: `HTML ➔ Component ➔ Store ➔ Service ➔ ApiClient ➔ Backend`. No reverse imports or skipped layers.
- **Rule 2: Zero Component Fetching**: Components must *never* execute network requests or invoke the ApiClient directly. They only `subscribe()`, `render()`, and `destroy()`.
- **Rule 3: One WebSocket Connection**: The entire application uses exactly *one* global `WebSocketManager` that broadcasts updates to the Stores.
- **Rule 4: Zero Placeholders**: No simulated calculations or client-side financial logic. All displayed data must originate from a backend-authoritative service.
- **Rule 5: File Size Limits**: HTML < 200 lines, CSS < 250 lines, JS/TS < 300 lines, Services < 250 lines, Stores < 200 lines.
- **Rule 6: Independent Cleanup**: Every module must cleanly implement `destroy()`, `unsubscribe()`, and remove any listeners or timers.
- **Rule 7: Mandatory Phase Validations**: Every completed phase must pass:
  - [] Unit Tests
  - [] Integration Tests
  - [] Performance Tests (<1s load)
  - [] Manual Validation

---

## Roadmap Checklist

### [] Phase 0 — Backend Foundation & Multi-Tenant Database
- [] Multi-user schema & session isolation (PostgreSQL/Express mock DB model in `server.ts`)
- [] Session tokens & JWT simulation (`mbot-session-token-*`)
- [] Portfolio snapshot and balance storage mechanics
- [] Position & FIFO calculation engine simulation
- [] Correlation ID generation & propagation in headers
- [] Audit chain implementation & logging structure

### [] Phase 1 — Frontend Structure & Standard Pages
- [] Independent page routers and entry structure
- [] Page declarations for Login, Dashboard, Engines, Market, Billing, Settings, Audit, High Tech Eye, 404

### [] Phase 2 — Folder Layout Refinement
- [] Establish strict frontend directories (`src/components`, `src/config`, `src/pages`, `src/services`, `src/types.ts`)
- [] Eliminate orphan/random files

### [] Phase 3 — Core Infrastructure
- [] `ApiClient` (Request deduplication, retry, timeout, Correlation IDs, error mapping)
- [] `Logger` (Unified console logging with severity and duration profiling)
- [] `Scheduler` / `PollingManager` (Visibility-aware pause/resume, backoff, network state)
- [] `WebSocketManager` (Single global WS hook subscribing components and stores)

### [] Phase 4 — Authentication (Session & Role Management)
- [] JWT token lifecycle and refresh token handling
- [] Login page layout, Remember Me, and simulated 2FA validation
- [] Session timeouts and auto-logout validation

### [] Phase 5 — Layout Framework
- [] Persistent responsive Sidebar
- [] Global Header (Connection indicators, user roles, notifications)
- [] Persistent Footer with real-time latency indicators

### [] Phase 6 — Dashboard (FULLY COMPLETE)
- [] Integrated portfolio metrics subscription
- [] Active positions monitoring
- [] Real-time Recharts/Performance display
- [] PortfolioStore domain-only data flow (Zero component fetch calls)

### [] Phase 7A — Engine Workspace
- [] Implement algorithmic engine selector workspace (Rigel, Sirius, Canopus, Gemini, Halal)
- [] Real-time Engine configuration Cards and pipeline displays
- [] Execution Pipeline Visualizations
- [] Shari'ah Compliance / Shariyah Audit execution engine panel (Halal Engine audit logs)
- [] Left Wing (Buy-Side Intelligence) & Right Wing (Sell-Side Intelligence) under engines

### [] Phase 7B — Engine Orchestration & Sync
- [] Real-time Synchronizer Engine state manager
- [] Anti-collision execution safety guards
- [] Runtime execution controller (Start/Stop controls mapped to Backend)
- [] Engine Arbitration and auto-throttling logic

### [] Phase 8 — Market Data Workspace
- [] High-frequency live orderbook stream subscription
- [] Market Store isolation (no billing, portfolio, or engine mixed logic)
- [] Dynamic ticker and depth charts

### [] Phase 9 — Billing & Subscription Panel
- [] Dedicated Subscription status indicators
- [] Success Fee performance invoices (computed by backend engine)
- [] Zero active WebSockets on billing page (pure REST/Store polling)

### [] Phase 10 — Audit Ledger Page
- [] Unified compliance ledger list
- [] Real-time audit detail sidebar drawer (fetching `/api/v1/observability/logs/:log_id/details`)
- [] Crytographically signed integrity-hash visualizer

### [] Phase 11 — Settings & Credentials Vault
- [] Secure credential encryption entry (Simulated local encryption / Key Vault)
- [] Engine operational settings (Max slip, trade limits)
- [] Real-time connection testing to exchanges (Binance, OKX, etc.)

### [] Phase 12 — AI Assistant (Intelligence Wing)
- [] Server-side Gemini API-powered intelligence wing
- [] Context-aware prompt shortcuts (Analyze positions, audit logs)
- [] Complete isolation of AI logic from global layout states

### [] Phase 13 — High Tech Eye (Platform Telemetry)
- [] Enterprise CPU, Memory, network traffic indicators
- [] WS broadcast latency metrics and rate-limiting diagnostics
- [] Real-time engine health telemetry dashboard

### [] Phase 14 — Production Readiness
- [] Cloud Run containers and production Docker setups
- [] Nginx ingress routing & SSL configuration
- [] Domain integration (www.memobot-fxpro.com)
- [] Secret manager environment setups (`.env.example` configurations)
- [] Database migration schema locks

### [] Phase 15 — Production Validation & Certification
- [] Live Binance / Paper Account end-to-end routing validation
- [] WebSocket connection loss and auto-reconnection tests
- [] Global Kill Switch circuit breaker triggers
- [] Compliance Islamic finance certified rules validation
